{% macro update_control_table(model_name, autosys_job_name) %}

    {% set app_name= var('app_name_by_schema').get(model.config.schema | upper) %}
    
    {% set exec_table = model.database ~ '.METADATA.' ~ app_name ~ '_JOB_CONTROL'%}

    update {{exec_table}}
        SET PREV_START_DATE = START_DATE,
        PREV_END_DATE = END_DATE,
        ROW_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP()
        WHERE JOB_NAME = '{{model_name.name}}'
        AND AUTOSYS_JOB_NAME = '{{autosys_job_name}}';


    UPDATE {{exec_table}}
        SET START_DATE = PREV_START_DATE + RUN_WINDOW,
        END_DATE = PREV_END_DATE + RUN_WINDOW,
        ROW_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP()
        WHERE JOB_NAME = '{{model_name.name}}'
        AND AUTOSYS_JOB_NAME = '{{autosys_job_name}}';

{% endmacro %}