
{% macro ar80_ps_z_job_control() %}
CREATE OR REPLACE TABLE 
    {{source('CRPDB01_EPMADM','PS_Z_JOB_CONTROL_AR80')}} 
    AS SELECT 
    "jobid" AS JOBID,
    "table_name" AS TABLE_NAME,
    "last_run_from_dttm" AS  LAST_RUN_FROM_DTTM,
    "last_run_to_dttm" as LAST_RUN_TO_DTTM,
    "status"  as STATUS 
    FROM {{source('BRNZ_PEOPLESOFT_TBL','PS_Z_JOB_CONTROL')}}
{% endmacro %}