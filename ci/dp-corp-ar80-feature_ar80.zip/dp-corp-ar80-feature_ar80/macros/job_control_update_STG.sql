{% macro job_control_update_clause_STG(bronze_table) %}

{% set app_name = var('app_name_by_schema').get(model.config.schema | upper) %}
    {% set exec_table = model.database ~ '.METADATA.' ~ app_name ~ '_JOB_CONTROL' %}

     {{ exec_table }}
SET PREV_START_DATE = NVL(START_DATE,CURRENT_TIMESTAMP() ),
    PREV_END_DATE   = END_DATE,
    START_DATE = NVL((SELECT MAX(aws_extract_dttm) FROM  {{source('MTCADM_STG',bronze_table)}} ), CURRENT_TIMESTAMP() ),
    END_DATE   = CURRENT_TIMESTAMP(), 
    ROW_UPDATE_TIMESTAMP =  CURRENT_TIMESTAMP()
WHERE JOB_NAME = '{{ this.identifier }}' 

{% endmacro %}