-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- SOURCE FILE       : JC.sql
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_JOB_CONTROL
-- AUTOSYS_JOB_NAME  : TBD
-- MATERIALIZATION   : incremental
-- ============================================================

{{ config(
    materialized='view',
    unique_key='JOB_ID',
    tags = ["LOAD_CUSTOMER","s_JC_CUSTOMER","JC","JC_CUSTOMER"],
    meta={"mapping_name": "JC"},
    pre_hook=[
    "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_JOB_CONTROL_AR80') }}  T
SET
    TABLE_NAME = S.TABLE_NAME,
    LAST_RUN_FROM_DTTM = S.LAST_RUN_FROM_DTTM,
    LAST_RUN_TO_DTTM = S.LAST_RUN_TO_DTTM,
    STATUS = S.STATUS
FROM(
WITH SQ_PS_Z_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        STATUS
    FROM {{ source('BRNZ_PEOPLESOFT_TBL', 'PS_Z_JOB_CONTROL') }}  --BRONZE_CORP_CONF.bronze_peoplesoft.ps_z_job_control  -- PS_Z_JOB_CONTROL
    WHERE JOBID = 'CUSTOMER'
),
EXP_DATA_QUALITY_STANDARDS1 AS (
    SELECT
        CASE
            WHEN LENGTH(LTRIM(RTRIM(JOBID))) = 0 THEN ' '
            ELSE RTRIM(JOBID)
        END AS JOBID,
        CASE
            WHEN LENGTH(LTRIM(RTRIM(TABLE_NAME))) = 0 THEN ' '
            ELSE RTRIM(TABLE_NAME)
        END AS TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        CASE
            WHEN LENGTH(LTRIM(RTRIM(STATUS))) = 0 THEN ' '
            ELSE RTRIM(STATUS)
        END AS STATUS
    FROM SQ_PS_Z_JOB_CONTROL
),
EXP_LAST_UPDATE_DTTM AS (
    SELECT
        JOBID,
        TABLE_NAME,
        CASE
            WHEN STATUS = 'R' THEN LAST_RUN_FROM_DTTM
            ELSE LAST_RUN_TO_DTTM
        END AS LAST_RUN_FROM_DTTM,
        CASE
            WHEN STATUS = 'R' THEN LAST_RUN_TO_DTTM
            ELSE CURRENT_TIMESTAMP()
        END AS LAST_RUN_TO_DTTM,
        CASE
            WHEN STATUS = 'C' THEN 'R'
            ELSE STATUS
        END AS STATUS
    FROM EXP_DATA_QUALITY_STANDARDS1
),
TGT_PS_Z_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        STATUS
    FROM EXP_LAST_UPDATE_DTTM
)SELECT * FROM TGT_PS_Z_JOB_CONTROL
)S
WHERE T.JOBID = S.JOBID",
log_model_start(this, 'DP_EPM1307C_S_JC_CUSTOMER')
    ],
    post_hook=[
        log_model_end(this, 'DP_EPM1307C_S_JC_CUSTOMER')
    ]
) }}

SELECT 'JC with filter PS_Z_JOB_CONTROL.JOB_ID = ''CUSTOMER''' as description