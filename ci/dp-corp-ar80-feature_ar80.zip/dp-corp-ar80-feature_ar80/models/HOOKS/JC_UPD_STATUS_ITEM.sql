-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- SOURCE FILE       : JC_UPD_STATUS.sql
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_JOB_CONTROL
-- AUTOSYS_JOB_NAME  : TBD
-- MATERIALIZATION   : incremental
-- ============================================================

{{ config(
    materialized='view',
    unique_key='JOB_ID',
    tags = ["LOAD_ITEM","s_JC_UPD_STATUS1","JC_UPD_STATUS","PS_Z_JOB_CONTROL"],
    meta={"mapping_name": "JC_UPD_STATUS"},
    pre_hook=[
    "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_JOB_CONTROL_AR80') }} T
SET
    TABLE_NAME = S.TABLE_NAME,
    LAST_RUN_FROM_DTTM = S.LAST_RUN_FROM_DTTM,
    LAST_RUN_TO_DTTM = S.LAST_RUN_TO_DTTM,
    STATUS = S.STATUS
FROM (
WITH SQ_PS_Z_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM
    FROM  {{ source('BRNZ_PEOPLESOFT_TBL', 'PS_Z_JOB_CONTROL') }}  --BRONZE_CORP_CONF.bronze_peoplesoft.ps_z_job_control  --PS_Z_JOB_CONTROL
    WHERE JOBID = 'ITEM'
),
EXP_DATA_QUALITY_STANDARDS1 AS (
    SELECT
        CASE
            WHEN LENGTH(LTRIM(RTRIM(JOBID))) = 0 THEN ' '
            ELSE RTRIM(JOBID)
        END AS JOBID,
        CASE
            WHEN LENGTH(LTRIM(RTRIM(TABLE_NAME))) = 0 THEN ' '
            ELSE RTRIM(TABLE_NAME)
        END AS TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM
    FROM SQ_PS_Z_JOB_CONTROL
),
EXP_UPD_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        'C' AS STATUS
    FROM EXP_DATA_QUALITY_STANDARDS1
),
TGT_PS_Z_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        STATUS
    FROM EXP_UPD_JOB_CONTROL
)SELECT * FROM TGT_PS_Z_JOB_CONTROL 
)S
WHERE T.JOBID = S.JOBID",
log_model_start(this, 'DP_EPM1307C_S_JC_UPD_STATUS')
    ],
    post_hook=[
        log_model_end(this, 'DP_EPM1307C_S_JC_UPD_STATUS')
    ]
) }}

SELECT 'JC_UPD_STATUS_ITEM with filter PS_Z_JOB_CONTROL.JOB_ID = ''ITEM''' as description