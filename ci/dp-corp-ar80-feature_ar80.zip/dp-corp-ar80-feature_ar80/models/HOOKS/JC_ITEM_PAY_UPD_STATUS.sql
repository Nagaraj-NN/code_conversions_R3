-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- SOURCE FILE       : JC_ITEM_PAY_UPD_STATUS.sql
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_JOB_CONTROL
-- AUTOSYS_JOB_NAME  : TBD
-- MATERIALIZATION   : incremental
-- ============================================================

{{ config(
    materialized='view',
    unique_key='JOB_ID',
    tags = ["LOAD_ITEM_PAYMENT","s_JC_ITEM_PAY_UPD_STATUS","JC_ITEM_PAY_UPD_STATUS","PS_Z_JOB_CONTROL"],
    meta={"mapping_name": "JC_ITEM_PAY_UPD_STATUS"},
    pre_hook=[
    "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_JOB_CONTROL_AR80') }} T
SET
    TABLE_NAME = S.TABLE_NAME,
    LAST_RUN_FROM_DTTM = S.LAST_RUN_FROM_DTTM,
    LAST_RUN_TO_DTTM = S.LAST_RUN_TO_DTTM,
    STATUS = S.STATUS
FROM (
WITH SQ_PS_Z_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM
    FROM {{ source('BRNZ_PEOPLESOFT_TBL', 'PS_Z_JOB_CONTROL') }}  --PS_Z_JOB_CONTROL
    WHERE JOBID = 'ITEM_PAY'
),
EXP_DATA_QUALITY_STANDARDS1 AS (
    SELECT
        CASE
            WHEN LENGTH(LTRIM(RTRIM(JOBID))) = 0 THEN ' '
            ELSE RTRIM(JOBID)
        END AS JOBID,
        CASE
            WHEN LENGTH(LTRIM(RTRIM(TABLE_NAME))) = 0 THEN ' '
            ELSE RTRIM(TABLE_NAME)
        END AS TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM
    FROM SQ_PS_Z_JOB_CONTROL
),
EXP_UPD_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        'C' AS STATUS
    FROM EXP_DATA_QUALITY_STANDARDS1
),
LKP_PS_Z_ITEM_PAY_F00 AS (
    SELECT
        MAX(PYMNT_RECONCILE_DT) AS MAX_RECON_DT
    FROM CRPDB01.EPMADM.PS_Z_ITEM_PAY_F00
),
LKP_PS_Z_ITEM_PAY_F00_RESULT AS (
    SELECT
        E.JOBID,
        E.TABLE_NAME,
        E.LAST_RUN_FROM_DTTM,
        E.LAST_RUN_TO_DTTM,
        E.STATUS,
        L.MAX_RECON_DT
    FROM EXP_UPD_JOB_CONTROL E
    LEFT JOIN LKP_PS_Z_ITEM_PAY_F00 L
        ON L.MAX_RECON_DT <> E.LAST_RUN_TO_DTTM
),
EXP_CHECK_NULL_MAX_DT AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        CASE
            WHEN MAX_RECON_DT IS NULL THEN LAST_RUN_TO_DTTM
            ELSE MAX_RECON_DT
        END AS LAST_RUN_TO_DTTM,
        STATUS
    FROM LKP_PS_Z_ITEM_PAY_F00_RESULT
),
TGT_PS_Z_JOB_CONTROL AS (
    SELECT
        JOBID,
        TABLE_NAME,
        LAST_RUN_FROM_DTTM,
        LAST_RUN_TO_DTTM,
        STATUS
    FROM EXP_CHECK_NULL_MAX_DT
)SELECT * FROM TGT_PS_Z_JOB_CONTROL
)S
WHERE T.JOBID = S.JOBID",
log_model_start(this, 'DP_EPM1307C_S_JC_ITEM_PAY_UPD_STATUS')
    ],
    post_hook=[
        log_model_end(this, 'DP_EPM1307C_S_JC_ITEM_PAY_UPD_STATUS')
    ]
) }}

SELECT 'JC_ITEM_PAY_UPD_STATUS with filter PS_Z_JOB_CONTROL.JOB_ID = ''ITEM_PAY''' as description