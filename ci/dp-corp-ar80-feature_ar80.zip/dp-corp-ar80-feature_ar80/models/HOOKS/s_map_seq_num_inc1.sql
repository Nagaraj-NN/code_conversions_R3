-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- SOURCE FILE       : map_seq_num_inc.sql
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_JOB_CONTROL
-- AUTOSYS_JOB_NAME  : TBD
-- MATERIALIZATION   : incremental
-- ============================================================

{{ config(
    materialized='view',
    unique_key='SEQ_ID',
    tags = ["LOAD_ITEM", "s_map_seq_num_inc1" , "map_seq_num_inc" ,"s_map_seq_num_inc1"],
    meta={"mapping_name": "map_seq_num_inc"},
    pre_hook=[
    "UPDATE {{ source('CRPDB01_EPMADM', 'PS_ETL_PROCESS_CTL') }} T
SET
    PROCESS_INSTANCE = S.PROCESS_INSTANCE,
    MAPPING_NAME = S.MAPPING_NAME
FROM(
WITH SQ_PS_ETL_PROCESS_CTL AS (
    SELECT
        SEQ_ID,
        PROCESS_INSTANCE,
        MAPPING_NAME 
    FROM {{ source('CRPDB01_EPMADM', 'PS_ETL_PROCESS_CTL') }}  --PS_ETL_PROCESS_CTL
    WHERE SEQ_ID = 5010
),
EXP_DATA_QUALITY_STANDARDS1 AS (
    SELECT
        SEQ_ID,
        PROCESS_INSTANCE,
        CASE
            WHEN LENGTH(LTRIM(RTRIM(MAPPING_NAME))) = 0 THEN ' '
            ELSE RTRIM(MAPPING_NAME)
        END AS MAPPING_NAME
    FROM SQ_PS_ETL_PROCESS_CTL
),
EXP_INC_NBR AS (
    SELECT
        SEQ_ID,
        CASE
            WHEN PROCESS_INSTANCE >= 9999999999 THEN 9990000001
            WHEN PROCESS_INSTANCE < 9990000001 THEN 9990000001
            ELSE PROCESS_INSTANCE + 1
        END AS PROCESS_INSTANCE,
        MAPPING_NAME
    FROM EXP_DATA_QUALITY_STANDARDS1
),
TGT_PS_ETL_PROCESS_CTL AS (
    SELECT
        SEQ_ID,
        PROCESS_INSTANCE,
        MAPPING_NAME
    FROM EXP_INC_NBR
)SELECT * FROM  TGT_PS_ETL_PROCESS_CTL
)S
WHERE T.SEQ_ID = S.SEQ_ID",
log_model_start(this, 'DP_EPM1307C_S_MAP_SEQ_NUM_INC1')
    ],
    post_hook=[
        log_model_end(this, 'DP_EPM1307C_S_MAP_SEQ_NUM_INC1')
    ]
) }}

SELECT 'map_seq_num_inc with filter PS_ETL_PROCESS_CTL.SEQ_ID = ''5010''' as description