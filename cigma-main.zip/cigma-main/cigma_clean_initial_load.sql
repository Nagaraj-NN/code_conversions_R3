-- =====================================================================
-- CIGMA - CLEAN INITIAL LOAD, WATERMARK-DRIVEN MODELS
-- =====================================================================
-- READ THIS FIRST
--
-- We have no write permission in Snowflake. AUTOSYS-triggered dbt is the
-- only writer. Everything below is therefore SELECT-only and is meant for
-- verification, not for driving the load.
--
-- For the go-live on an empty prod, NO MANUAL STEP IS NEEDED. The control
-- table does not exist yet, so the first run of CXNADM_JOB_CONTROL creates
-- all 27 rows with START_DATE = '2008-01-01' by itself, and every
-- watermark model backfills full history on its first run. Run the AUTOSYS
-- boxes in dependency order and use STEP 1 - STEP 4 to confirm.
--
-- The DBA-only section at the bottom is for the case where a job's window
-- has to be re-opened LATER, once the table already holds rows. We cannot
-- run it; it needs someone with write access, or a dbt run-operation.
--
-- 27 models read METADATA.CXNADM_JOB_CONTROL, in two families:
--
--   CLASS 1 (15) window is START_DATE -> END_DATE. Rows outside the
--                window are never revisited, so a wrong START_DATE at
--                init is a PERMANENT history gap.
--
--   CLASS 2 (12) window derives from END_DATE alone (REPORT_DT, or
--                END_DATE minus a fixed lookback). Self-healing.
-- =====================================================================

SET CTL = 'UTLDB01_PROD.METADATA.CXNADM_JOB_CONTROL';   -- set for the target env


-- =====================================================================
-- STEP 1 - BEFORE THE FIRST AUTOSYS RUN
-- =====================================================================
-- Expect: the table does not exist, or exists with zero rows.
-- If it already holds rows with WINDOW_DAYS = 1, it was created by the
-- OLD code and Class 1 already has a history gap - see the DBA section.
SELECT
    JOB_NAME,
    START_DATE,
    END_DATE,
    PREV_START_DATE,
    PREV_END_DATE,
    DATEDIFF('day', START_DATE, END_DATE) AS WINDOW_DAYS,
    ROW_UPDATE_TIMESTAMP
FROM IDENTIFIER($CTL)
ORDER BY WINDOW_DAYS DESC, JOB_NAME;


-- =====================================================================
-- STEP 2 - AFTER CXNADM_JOB_CONTROL HAS RUN, BEFORE THE REST
-- =====================================================================
-- All 27 rows must be present and anchored at 2008. Anything else means
-- the model did not seed correctly - stop and investigate before letting
-- the watermark models run, because Class 1 cannot recover afterwards.
SELECT
    COUNT(*)                                                     AS JOBS,
    COUNT_IF(START_DATE =  '2008-01-01 00:00:00.000'::TIMESTAMP) AS AT_ANCHOR,
    COUNT_IF(START_DATE <> '2008-01-01 00:00:00.000'::TIMESTAMP) AS NOT_AT_ANCHOR
FROM IDENTIFIER($CTL);
-- Expect: JOBS = 27, AT_ANCHOR = 27, NOT_AT_ANCHOR = 0

SELECT JOB_NAME, START_DATE, END_DATE
FROM IDENTIFIER($CTL)
WHERE START_DATE <> '2008-01-01 00:00:00.000'::TIMESTAMP
ORDER BY JOB_NAME;
-- Expect: zero rows


-- =====================================================================
-- STEP 3 - AFTER THE FULL AUTOSYS CYCLE
-- =====================================================================
-- open_control_window stamps END_DATE at the START of each run;
-- update_control_table then sets START_DATE = END_DATE, but only on
-- success. A healthy row ends with START_DATE = END_DATE = PREV_END_DATE.
SELECT
    JOB_NAME,
    PREV_START_DATE,
    PREV_END_DATE,
    START_DATE,
    END_DATE,
    CASE
        WHEN START_DATE = '2008-01-01 00:00:00.000'::TIMESTAMP
            THEN 'NEVER RAN - investigate'
        WHEN START_DATE = END_DATE
            THEN 'OK - window closed cleanly'
        WHEN START_DATE < END_DATE
            THEN 'RUN FAILED after pre-hook - window still open, next run re-covers'
        ELSE 'UNEXPECTED'
    END AS STATUS
FROM IDENTIFIER($CTL)
ORDER BY STATUS, JOB_NAME;


-- =====================================================================
-- STEP 4 - DUPLICATE ASSERTION. Should return zero rows.
-- =====================================================================
-- No target needed truncating before the backfill: all 27 already block
-- their own duplicates through a pre-hook TRUNCATE, a natural-key
-- anti-join, a (REPORT_DT, BILL_ACCOUNT_NB) anti-join, a scoped
-- KPI_METRIC_CD delete, or a hook-driven upsert. This confirms it.
SELECT 'PAYMENT_F' AS TBL, REPORT_DT, BILL_ACCOUNT_NB, COUNT(*) AS N
FROM UTLDB01_PROD.CXNADM.PAYMENT_F
GROUP BY 1,2,3 HAVING COUNT(*) > 1
UNION ALL
SELECT 'PROGRAM_ENROLLMENT_F', REPORT_DT, BILL_ACCOUNT_NB, COUNT(*)
FROM UTLDB01_PROD.CXNADM.PROGRAM_ENROLLMENT_F
GROUP BY 1,2,3 HAVING COUNT(*) > 1
UNION ALL
SELECT 'CALL_HISTORY_F', REPORT_DT, BILL_ACCOUNT_NB, COUNT(*)
FROM UTLDB01_PROD.CXNADM.CALL_HISTORY_F
GROUP BY 1,2,3 HAVING COUNT(*) > 1
UNION ALL
SELECT 'WEB_EVENT_INTERACTION_F', REPORT_DT, BILL_ACCOUNT_NB, COUNT(*)
FROM UTLDB01_PROD.CXNADM.WEB_EVENT_INTERACTION_F
GROUP BY 1,2,3 HAVING COUNT(*) > 1
UNION ALL
SELECT 'DIGITAL_ASSISTANT_EVENT_F', REPORT_DT, BILL_ACCOUNT_NB, COUNT(*)
FROM UTLDB01_PROD.CXNADM.DIGITAL_ASSISTANT_EVENT_F
GROUP BY 1,2,3 HAVING COUNT(*) > 1
ORDER BY 1,2;


-- =====================================================================
-- DBA ONLY - RE-OPENING A WINDOW AFTER THE TABLE ALREADY HAS ROWS
-- =====================================================================
-- WE CANNOT RUN THIS. It needs write access, or a dbt run-operation
-- executed through AUTOSYS. It is included so the request can be handed
-- over exactly as written.
--
-- Only the 15 CLASS 1 jobs are listed. The other 12 derive their window
-- from END_DATE alone and re-open themselves on the next run.
--
-- UPDATE UTLDB01_PROD.METADATA.CXNADM_JOB_CONTROL
--    SET PREV_START_DATE      = START_DATE,
--        PREV_END_DATE        = END_DATE,
--        START_DATE           = '2008-01-01 00:00:00.000'::TIMESTAMP,
--        ROW_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP()
--  WHERE JOB_NAME IN (
--        'ACCOUNT_D', 'PARTY_D', 'CIVR_V2D_DA_JAR_F', 'WEB_JAR_F',
--        'AGENT_CHAT_SPECIALIST_JAR_F_INCR',
--        'INTERACTION_TYPE_STG', 'MEDIA_TYPE_STG', 'ROUTING_TARGET_STG',
--        'TECHNICAL_DESCRIPTOR_STG',
--        'CALL_EVENTS', 'CALL_INTENTS',
--        'AG2_QUEUE_DAY_STG', 'AG2_I_SESS_STATE_DAY_STG',
--        'IRF_USER_DATA_CUST_2_STG', 'SM_RES_SESSION_FACT_GI2_STG'
--  );
--
-- END_DATE is deliberately not set: open_control_window stamps it at the
-- start of the next run. Re-running is safe - every one of the 15 blocks
-- its own duplicates, so a wider window cannot double-load.
