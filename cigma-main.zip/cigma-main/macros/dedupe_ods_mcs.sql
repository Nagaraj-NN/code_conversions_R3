{#
    Removes duplicate merge keys from the ODS_MCS targets.

    Confirmed 2026-09-01 against production. Three tables were measured, and all
    three hold rows sharing their own dbt unique_key:

        ODS_MCS_NOTES              318,930 groups     2,780,170 surplus rows
        ODS_MCS_DEBIT_ACTIVITY   5,891,286 groups    12,740,320 surplus rows
        ODS_MCS_BILL_COMPONENT  60,895,193 groups    61,813,886 surplus rows

    The other fifteen are unmeasured. Twelve of the eighteen carry more rows
    than their Bronze source (see cigma_odsmcs_rowcounts.tsv), so all eighteen
    are listed below and the report pass covers them in one go. Nothing is
    rewritten unless its own probe finds surplus rows.

    The current models cannot produce these. Each dedupes its source with
    QUALIFY ROW_NUMBER() PARTITION BY the exact unique_key, dedupes the target
    lookup the same way, and rejects NULL/blank keys before either. The
    duplicates pre-date the current model version.

    Nor can the models clear them. Snowflake raises 100090 only when one TARGET
    row is matched by MULTIPLE SOURCE rows; here the duplicates sit in the
    target, so one source row matches several target rows and Snowflake updates
    all of them without complaint. The merge keeps every copy current forever
    and never removes one.

    So this runs once, out of band:

        dbt run-operation dedupe_ods_mcs                      -- report only
        dbt run-operation dedupe_ods_mcs --args '{execute: true}'

    It is not a hook. A full-table rewrite has no business firing on every
    AUTOSYS run, and the tables stay correct once cleaned.

    Which row survives does not matter: duplicates share a merge key, so they
    are the same business entity, and the next run refreshes the survivor from
    Bronze regardless. The tiebreak keeps the most recently loaded copy.

    Rollback: the pre-rewrite image is left behind as <TABLE>__DEDUPE_BACKUP.
    Drop those once the counts have been signed off.
#}

{% macro dedupe_ods_mcs(execute=false) %}

    {# Every ODS_MCS model, keyed exactly as its config declares. Only three are
       measured; the probe is a cheap key-column GROUP BY, so the rest are
       reported in the same pass rather than guessed at. #}
    {% set targets = [
        {'name': 'ODS_MCS_ADDRESS',
         'keys': ['CO_CD_OWNR', 'ADDR_ID_AD']},
        {'name': 'ODS_MCS_BA_GREEN_PWR',
         'keys': ['BILL_ACCT_NB', 'GP_EFCT_DT']},
        {'name': 'ODS_MCS_BILLABLE_USAGE',
         'keys': ['BILL_ACCT_NB', 'BILL_HEAD_NB', 'BILL_COMP_NB', 'TIME_OF_DAY_CD']},
        {'name': 'ODS_MCS_BILL_ACCOUNT',
         'keys': ['BILL_ACCT_NB']},
        {'name': 'ODS_MCS_BILL_COMPONENT',
         'keys': ['BILL_ACCT_NB', 'BILL_HEAD_NB', 'BILL_COMP_NB']},
        {'name': 'ODS_MCS_BILL_HEADER',
         'keys': ['BILL_ACCT_NB', 'BILL_HEAD_NB']},
        {'name': 'ODS_MCS_BUS_DIR',
         'keys': ['BILL_ACCT_NB', 'PROD_ORDR_NB', 'DIR_TYPE_CD']},
        {'name': 'ODS_MCS_BUS_PA_CRDT_EX',
         'keys': ['BILL_ACCT_NB', 'PROD_ORDR_NB']},
        {'name': 'ODS_MCS_CREDIT_SOURCE',
         'keys': ['BILL_ACCT_NB', 'CRDT_CRTN_TS']},
        {'name': 'ODS_MCS_CUSTOMER',
         'keys': ['CUST_NB']},
        {'name': 'ODS_MCS_DEBIT_ACTIVITY',
         'keys': ['BILL_ACCT_NB', 'DIR_TYPE_CD', 'PROD_ORDR_NB', 'DEBT_TS']},
        {'name': 'ODS_MCS_INDICATIV_DATA',
         'keys': ['BILL_ACCT_NB', 'PREM_NB', 'CUST_NB', 'NAME_IDNT_CD']},
        {'name': 'ODS_MCS_NOTES',
         'keys': ['CO_CD_OWNR', 'CRTN_TS']},
        {'name': 'ODS_MCS_PREMISE',
         'keys': ['PREM_NB']},
        {'name': 'ODS_MCS_PREMISE_EXT',
         'keys': ['PREM_ID']},
        {'name': 'ODS_MCS_TRANS_HIST_HDR',
         'keys': ['CO_CD_OWNR', 'BILL_ACCT_NB', 'CNV_ID', 'TS_20_TS']},
        {'name': 'ODS_MCS_WEB_BILL_ACCT',
         'keys': ['WEB_ID', 'BILL_ACCT_NB']},
        {'name': 'ODS_MCS_WEB_USER',
         'keys': ['WEB_ID']}
    ] %}

    {% if not execute %}
        {{ log("dedupe_ods_mcs: REPORT ONLY. Re-run with --args '{execute: true}' to rewrite.", info=True) }}
    {% endif %}

    {% for t in targets %}

        {% set fq      = 'UTLDB01.UTLUSER.' ~ t.name %}
        {% set backup  = fq ~ '__DEDUPE_BACKUP' %}
        {% set keylist = t.keys | join(', ') %}

        {% set probe %}
            SELECT
                COUNT(*)                                AS DUP_GROUPS,
                COALESCE(SUM(N) - COUNT(*), 0)          AS SURPLUS_ROWS,
                (SELECT COUNT(*) FROM {{ fq }})         AS TOTAL_ROWS
            FROM (
                SELECT {{ keylist }}, COUNT(*) AS N
                FROM {{ fq }}
                GROUP BY {{ keylist }}
                HAVING COUNT(*) > 1
            )
        {% endset %}

        {% set res      = run_query(probe) %}
        {% set groups   = res.columns[0].values()[0] | int %}
        {% set surplus  = res.columns[1].values()[0] | int %}
        {% set total    = res.columns[2].values()[0] | int %}
        {% set expected = total - surplus %}

        {{ log(t.name ~ ': ' ~ total ~ ' rows, ' ~ groups ~ ' duplicated keys, '
               ~ surplus ~ ' surplus rows -> ' ~ expected ~ ' after dedupe', info=True) }}

        {% if surplus == 0 %}
            {{ log(t.name ~ ': already clean, skipped.', info=True) }}
        {% elif execute %}

            {# Full image of the deduped table. TRANSIENT, not TEMPORARY: it has
               to outlive this session to be usable as a rollback copy. #}
            {% call statement('build_' ~ t.name, fetch_result=False) %}
                CREATE OR REPLACE TRANSIENT TABLE {{ backup }} AS
                SELECT *
                FROM {{ fq }}
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY {{ keylist }}
                    ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
                ) = 1
            {% endcall %}

            {# Never overwrite on a count we did not predict. #}
            {% set check  = run_query('SELECT COUNT(*) FROM ' ~ backup) %}
            {% set actual = check.columns[0].values()[0] | int %}
            {% if actual != expected %}
                {{ exceptions.raise_compiler_error(
                    t.name ~ ': aborted. Deduped image has ' ~ actual ~ ' rows, expected '
                    ~ expected ~ '. ' ~ fq ~ ' is untouched; inspect ' ~ backup ~ '.') }}
            {% endif %}

            {# INSERT OVERWRITE is atomic and keeps the hand-written DDL -- the
               NOT NULL constraints and the column DEFAULTs. A TRUNCATE followed
               by an INSERT would leave the table empty if the INSERT failed. #}
            {% call statement('overwrite_' ~ t.name, fetch_result=False) %}
                INSERT OVERWRITE INTO {{ fq }} SELECT * FROM {{ backup }}
            {% endcall %}

            {{ log(t.name ~ ': rewritten with ' ~ actual ~ ' rows. Rollback copy: '
                   ~ backup, info=True) }}
        {% endif %}

    {% endfor %}

{% endmacro %}
