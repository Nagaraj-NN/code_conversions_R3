INSERT INTO UTLDB01_DEV_SANDBOX.CDWADM.CALLCTR_AGENT_D
(
    AGENT_USER_ID,
    CC_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    AGENT_FIRST_NM,
    AGENT_LAST_NM,
    SUPERVISOR_ID,
    AGENT_PHONE_NB,
    CALLCTR_AGENCY_D_ID,
    IS_ACTIVE,
    MD5_CHECKSUM_VAL
)
with
sq_va_users_stg AS (

SELECT
    SRC.USERID,
    SRC.CC_ID,
    SRC.FIRSTNAME,
    SRC.LASTNAME,
    SRC.SUPERVISOR_ID,
    SRC.IS_ACTIVE,
    SRC.PHONE,
    SRC.CALLCTR_AGENCY_D_ID,
    CA.CALLCTR_AGENT_D_ID,
    CA.MD5_CHECKSUM_VAL

FROM
(
    SELECT
        VAU_R.USERID,
        VAU_R.CC_ID,
        VAU_R.FIRSTNAME,
        VAU_R.LASTNAME,
        VAU_R.SUPERVISOR_ID,
        VAU_R.IS_ACTIVE,
        VAU_R.PHONE,
        CAD.CALLCTR_AGENCY_D_ID

    FROM
    (
        SELECT
            USERID,
            CC_ID,
            FIRSTNAME,
            LASTNAME,
            SUPERVISOR_ID,
            IS_ACTIVE,
            PHONE
        FROM UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG

        UNION

        SELECT
            RES.USERID,
            COALESCE(VUS.CC_ID,'-999') AS CC_ID,
            RES.FIRSTNAME,
            RES.LASTNAME,
            COALESCE(VUS.SUPERVISOR_ID,'_') AS SUPERVISOR_ID,
            COALESCE(VUS.IS_ACTIVE,-999) AS IS_ACTIVE,
            COALESCE(VUS.PHONE,'DEFAULT') AS PHONE
        FROM
        (
            SELECT *
            FROM
            (
                SELECT
                    EMPLOYEE_ID AS USERID,
                    AGENT_FIRST_NAME AS FIRSTNAME,
                    AGENT_LAST_NAME AS LASTNAME,
                    RANK() OVER
                    (
                        PARTITION BY EMPLOYEE_ID
                        ORDER BY GMT_END_TIME DESC
                    ) AS latest
                FROM UTLDB01_DEV_SANDBOX.CUSADM.RESOURCE_
                WHERE UPPER(RESOURCE_TYPE)=UPPER('AGENT')
            ) F
            WHERE F.latest=1
        ) RES

        LEFT JOIN UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG VUS
            ON VUS.USERID = RES.USERID

        WHERE VUS.USERID IS NULL

    ) VAU_R

    LEFT JOIN UTLDB01_DEV_SANDBOX.CDWADM.CALLCTR_AGENCY_D CAD
        ON CAD.CALLCTR_CD = VAU_R.CC_ID

) SRC

LEFT JOIN
(
    SELECT
        CALLCTR_AGENT_D_ID,
        CC_ID,
        MD5_CHECKSUM_VAL,
        AGENT_USER_ID
    FROM UTLDB01_DEV_SANDBOX.CDWADM.CALLCTR_AGENT_D
) CA

ON SRC.USERID = CA.AGENT_USER_ID
AND SRC.CC_ID  = CA.CC_ID

),


exp_audit_fields AS
(
    SELECT
        USERID,
        CC_ID,
        FIRSTNAME,
        LASTNAME,
        SUPERVISOR_ID,
        IS_ACTIVE,
        PHONE,
        CALLCTR_AGENCY_D_ID,
        CALLCTR_AGENT_D_ID,
        MD5_CHECKSUM_VAL,

        's_m_CALLCTR_AGENT_D' AS O_EDW_CREATE_NM,
        CURRENT_TIMESTAMP()   AS O_EDW_CREATE_TS,

        's_m_CALLCTR_AGENT_D' AS O_EDW_UPDT_NM,
        CURRENT_TIMESTAMP()   AS O_EDW_UPDT_TS,

        MD5
        (
            COALESCE(FIRSTNAME,'')
            || COALESCE(LASTNAME,'')
            || COALESCE(SUPERVISOR_ID,'')
            || COALESCE(TO_VARCHAR(IS_ACTIVE),'')
            || COALESCE(PHONE,'')
            || COALESCE(TO_VARCHAR(CALLCTR_AGENCY_D_ID),'')
        ) AS O_MD5_CHECKSUM_VAL

    FROM sq_va_users_stg
)
--select * from exp_audit_fields;
,

rtr_flag_record_INSERT AS
(
    SELECT *
    FROM exp_audit_fields
    WHERE CALLCTR_AGENT_D_ID IS NULL
)
--select * from rtr_flag_record_INSERT;
,
upd_tgt_insert AS
(
    SELECT *
    FROM rtr_flag_record_INSERT
)
--select * from upd_tgt_insert;

SELECT
    USERID,
    CC_ID,
    O_EDW_CREATE_TS,
    O_EDW_CREATE_NM,
    O_EDW_UPDT_TS,
    O_EDW_UPDT_NM,
    FIRSTNAME,
    LASTNAME,
    SUPERVISOR_ID,
    PHONE,
    CALLCTR_AGENCY_D_ID,
    IS_ACTIVE,
    O_MD5_CHECKSUM_VAL
FROM upd_tgt_insert;
---===============================update=================================
UPDATE UTLDB01_DEV_SANDBOX.CDWADM.CALLCTR_AGENT_D TGT
SET
      CC_ID               = SRC.CC_ID
    , EDW_LAST_UPDT_TS    = SRC.O_EDW_UPDT_TS
    , EDW_LAST_UPDT_NM    = SRC.O_EDW_UPDT_NM
    , AGENT_FIRST_NM      = SRC.FIRSTNAME
    , AGENT_LAST_NM       = SRC.LASTNAME
    , AGENT_PHONE_NB      = SRC.PHONE
    , CALLCTR_AGENCY_D_ID = SRC.CALLCTR_AGENCY_D_ID
    , IS_ACTIVE           = SRC.IS_ACTIVE
    , MD5_CHECKSUM_VAL    = SRC.O_MD5_CHECKSUM_VAL
FROM
( with
sq_va_users_stg AS (

SELECT
    SRC.USERID,
    SRC.CC_ID,
    SRC.FIRSTNAME,
    SRC.LASTNAME,
    SRC.SUPERVISOR_ID,
    SRC.IS_ACTIVE,
    SRC.PHONE,
    SRC.CALLCTR_AGENCY_D_ID,
    CA.CALLCTR_AGENT_D_ID,
    CA.MD5_CHECKSUM_VAL

FROM
(
    SELECT
        VAU_R.USERID,
        VAU_R.CC_ID,
        VAU_R.FIRSTNAME,
        VAU_R.LASTNAME,
        VAU_R.SUPERVISOR_ID,
        VAU_R.IS_ACTIVE,
        VAU_R.PHONE,
        CAD.CALLCTR_AGENCY_D_ID

    FROM
    (
        SELECT
            USERID,
            CC_ID,
            FIRSTNAME,
            LASTNAME,
            SUPERVISOR_ID,
            IS_ACTIVE,
            PHONE
        FROM UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG

        UNION

        SELECT
            RES.USERID,
            COALESCE(VUS.CC_ID,'-999') AS CC_ID,
            RES.FIRSTNAME,
            RES.LASTNAME,
            COALESCE(VUS.SUPERVISOR_ID,'_') AS SUPERVISOR_ID,
            COALESCE(VUS.IS_ACTIVE,-999) AS IS_ACTIVE,
            COALESCE(VUS.PHONE,'DEFAULT') AS PHONE
        FROM
        (
            SELECT *
            FROM
            (
                SELECT
                    EMPLOYEE_ID AS USERID,
                    AGENT_FIRST_NAME AS FIRSTNAME,
                    AGENT_LAST_NAME AS LASTNAME,
                    RANK() OVER
                    (
                        PARTITION BY EMPLOYEE_ID
                        ORDER BY GMT_END_TIME DESC
                    ) AS latest
                FROM UTLDB01_DEV_SANDBOX.CUSADM.RESOURCE_
                WHERE UPPER(RESOURCE_TYPE)=UPPER('AGENT')
            ) F
            WHERE F.latest=1
        ) RES

        LEFT JOIN UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG VUS
            ON VUS.USERID = RES.USERID

        WHERE VUS.USERID IS NULL

    ) VAU_R

    LEFT JOIN UTLDB01_DEV_SANDBOX.CDWADM.CALLCTR_AGENCY_D CAD
        ON CAD.CALLCTR_CD = VAU_R.CC_ID

) SRC

LEFT JOIN
(
    SELECT
        CALLCTR_AGENT_D_ID,
        CC_ID,
        MD5_CHECKSUM_VAL,
        AGENT_USER_ID
    FROM UTLDB01_DEV_SANDBOX.CDWADM.CALLCTR_AGENT_D
) CA

ON SRC.USERID = CA.AGENT_USER_ID
AND SRC.CC_ID  = CA.CC_ID

),
exp_audit_fields AS
(
    SELECT
        USERID,
        CC_ID,
        FIRSTNAME,
        LASTNAME,
        SUPERVISOR_ID,
        IS_ACTIVE,
        PHONE,
        CALLCTR_AGENCY_D_ID,
        CALLCTR_AGENT_D_ID,
        MD5_CHECKSUM_VAL,

        's_m_CALLCTR_AGENT_D' AS O_EDW_CREATE_NM,
        CURRENT_TIMESTAMP()   AS O_EDW_CREATE_TS,

        's_m_CALLCTR_AGENT_D' AS O_EDW_UPDT_NM,
        CURRENT_TIMESTAMP()   AS O_EDW_UPDT_TS,

        MD5
        (
            COALESCE(FIRSTNAME,'')
            || COALESCE(LASTNAME,'')
            || COALESCE(SUPERVISOR_ID,'')
            || COALESCE(TO_VARCHAR(IS_ACTIVE),'')
            || COALESCE(PHONE,'')
            || COALESCE(TO_VARCHAR(CALLCTR_AGENCY_D_ID),'')
        ) AS O_MD5_CHECKSUM_VAL

    FROM sq_va_users_stg
)
--select * from exp_audit_fields;
,

rtr_flag_record_UPDATE AS
(
    SELECT *
    FROM exp_audit_fields
    WHERE CALLCTR_AGENT_D_ID IS NOT NULL
      AND MD5_CHECKSUM_VAL <> O_MD5_CHECKSUM_VAL
)
--select * from rtr_flag_record_UPDATE;
,

upd_tgt_update AS
(
    SELECT *
    FROM rtr_flag_record_UPDATE
)
--select * from upd_tgt_update;
    SELECT *
    FROM upd_tgt_update
) SRC
WHERE TGT.CALLCTR_AGENT_D_ID = SRC.CALLCTR_AGENT_D_ID;