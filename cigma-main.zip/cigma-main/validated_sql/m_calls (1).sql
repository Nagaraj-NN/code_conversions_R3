
INSERT INTO UTLDB01_DEV_SANDBOX.CXNADM.CALLS
(
    CALL_ID,
    COMPANY_ID,
    ACCOUNT_D_ID,
    BILL_ACCOUNT_NB,
    EDW_CRTE_NM,
    EDW_CRTE_TS,
    EDW_LAST_UPDT_NM,
    EDW_LAST_UPDT_TS,
    VOICE_PLATFORM_SESSION_ID,
    VOICE_PLATFORM_FULL_CALL_ID,
    START_SITE_ID,
    START_SITE_NAME,
    CALL_START_TIME,
    CALL_START_DATE,
    CALL_START_HOUR,
    CALL_END_TIME,
    CALL_END_DATE,
    CALL_END_HOUR,
    CALL_END_SITE_ID,
    CALL_END_SITE_NAME,
    CALL_END_BLOCK_TYPE,
    CALL_END_BLOCK_NAME,
    CALL_END_RESULT,
    HAS_RECENT_FAILURE,
    IS_TEST_CALL,
    CALL_DURATION,
    CLI,
    DNIS,
    CLUSTER_ID,
    CLUSTER_NAME,
    CTI_FIELDS,
    LAST_MENU_BLOCK_TYPE,
    LAST_MENU_BLOCK_NAME,
    CLI_TYPE,
    SERVER_ID,
    START_CHANNEL,
    START_CHANNEL_CATEGORY,
    MD5_CHECKSUM_VAL
)
WITH SQ_VW_CALLS_STG AS
(
    WITH STG AS
    (
        SELECT
            CALL_ID,
            COMPANY_ID,

            REGEXP_SUBSTR(
                LTRIM(
                    REGEXP_SUBSTR(
                        CTI_FIELDS,
                        'var_AccountNumber:[^|]+'
                    ),
                    'var_AccountNumber:'
                ),
                '[^,]+',
                1
            ) AS BILL_ACCOUNT_NB,

            VOICE_PLATFORM_SESSION_ID,
            VOICE_PLATFORM_FULL_CALL_ID,
            START_SITE_ID,
            START_SITE_NAME,
            CALL_START_TIME,
            CALL_START_DATE,
            CALL_START_HOUR,
            CALL_END_TIME,
            CALL_END_DATE,
            CALL_END_HOUR,
            CALL_END_SITE_ID,
            CALL_END_SITE_NAME,
            CALL_END_BLOCK_TYPE,
            CALL_END_BLOCK_NAME,
            CALL_END_RESULT,
            HAS_RECENT_FAILURE,
            IS_TEST_CALL,
            CALL_DURATION,
            CLI,
            DNIS,
            CLUSTER_ID,
            CLUSTER_NAME,
            CTI_FIELDS,
            LAST_MENU_BLOCK_TYPE,
            LAST_MENU_BLOCK_NAME,
            CLI_TYPE,
            SERVER_ID,
            START_CHANNEL,
            START_CHANNEL_CATEGORY
        FROM UTLDB01_DEV_SANDBOX.CXNADM.VW_CALLS_STG
    ),

    STG_2 AS
    (
        SELECT
            IF1.MEDIA_SERVER_IXN_GUID,
            MIN(IRF_USER_DATA_CUST_1.CUSTOM_DATA_1) AS CUSTOM_DATA_1,
            COUNT(DISTINCT IRF_USER_DATA_CUST_1.CUSTOM_DATA_1) AS CUSTOM_DATA_1_CNT
        FROM UTLDB01_DEV_SANDBOX.CUSADM.INTERACTION_FACT IF1
        LEFT JOIN UTLDB01_DEV_SANDBOX.CUSADM.INTERACTION_RESOURCE_FACT IRF
            ON IRF.INTERACTION_ID = IF1.INTERACTION_ID
        LEFT JOIN UTLDB01_DEV_SANDBOX.CUSADM.IRF_USER_DATA_CUST_1
            ON IRF.INTERACTION_RESOURCE_ID =
               IRF_USER_DATA_CUST_1.INTERACTION_RESOURCE_ID
        WHERE IRF_USER_DATA_CUST_1.CUSTOM_DATA_1 IS NOT NULL
        GROUP BY IF1.MEDIA_SERVER_IXN_GUID
    ),

    STG_3 AS
    (
        SELECT

            STG.CALL_ID,
            STG.COMPANY_ID,

            CASE
                WHEN STG.BILL_ACCOUNT_NB IS NULL
                 AND STG_2.CUSTOM_DATA_1_CNT = 1
                THEN STG_2.CUSTOM_DATA_1
                ELSE STG.BILL_ACCOUNT_NB
            END AS BILL_ACCOUNT_NB,

            STG.VOICE_PLATFORM_SESSION_ID,
            STG.VOICE_PLATFORM_FULL_CALL_ID,
            STG.START_SITE_ID,
            STG.START_SITE_NAME,
            STG.CALL_START_TIME,
            STG.CALL_START_DATE,
            STG.CALL_START_HOUR,
            STG.CALL_END_TIME,
            STG.CALL_END_DATE,
            STG.CALL_END_HOUR,
            STG.CALL_END_SITE_ID,
            STG.CALL_END_SITE_NAME,
            STG.CALL_END_BLOCK_TYPE,
            STG.CALL_END_BLOCK_NAME,
            STG.CALL_END_RESULT,
            STG.HAS_RECENT_FAILURE,
            STG.IS_TEST_CALL,
            STG.CALL_DURATION,
            STG.CLI,
            STG.DNIS,
            STG.CLUSTER_ID,
            STG.CLUSTER_NAME,
            STG.CTI_FIELDS,
            STG.LAST_MENU_BLOCK_TYPE,
            STG.LAST_MENU_BLOCK_NAME,
            STG.CLI_TYPE,
            STG.SERVER_ID,
            STG.START_CHANNEL,
            STG.START_CHANNEL_CATEGORY,
            A_D.ACCOUNT_D_ID

        FROM STG

        LEFT JOIN STG_2
            ON STG.VOICE_PLATFORM_FULL_CALL_ID =
               STG_2.MEDIA_SERVER_IXN_GUID

        LEFT JOIN
        (
            SELECT
                BILL_ACCOUNT_NB,
                ACCOUNT_D_ID
            FROM UTLDB01_DEV_SANDBOX.CDWADM.ACCOUNT_D
            WHERE ACTIVE_FLAG='Y'
        ) A_D
            ON STG.BILL_ACCOUNT_NB =
               A_D.BILL_ACCOUNT_NB
    )

    SELECT

        RES.*,

        CALLS.CALLS_ID           AS OUT_CALLS_ID,
        CALLS.MD5_CHECKSUM_VAL   AS OUT_MD5_CHECKSUM_VAL

    FROM STG_3 RES

    LEFT JOIN UTLDB01_DEV_SANDBOX.CXNADM.CALLS CALLS
        ON RES.CALL_ID = CALLS.CALL_ID
       AND RES.COMPANY_ID = CALLS.COMPANY_ID

    WHERE RES.CALL_START_DATE IS NOT NULL
)
---select * from SQ_VW_CALLS_STG;
,

exp_AUDIT AS
(
    SELECT

        SQ.*,

        CURRENT_TIMESTAMP() AS O_EDW_CRTE_TS,
        's_m_CALLS' AS O_EDW_CRTE_NM,

        CURRENT_TIMESTAMP() AS O_EDW_LAST_UPDT_TS,
        's_m_CALLS' AS O_EDW_LAST_UPDT_NM,

        MD5(

            COALESCE(TO_VARCHAR(ACCOUNT_D_ID),'')
            || '~' || COALESCE(BILL_ACCOUNT_NB,'')
            || '~' || COALESCE(VOICE_PLATFORM_SESSION_ID,'')
            || '~' || COALESCE(VOICE_PLATFORM_FULL_CALL_ID,'')
            || '~' || COALESCE(TO_VARCHAR(START_SITE_ID),'')
            || '~' || COALESCE(START_SITE_NAME,'')
            || '~' || COALESCE(TO_VARCHAR(CALL_START_TIME),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_START_DATE),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_START_HOUR),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_TIME),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_DATE),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_HOUR),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_SITE_ID),'')
            || '~' || COALESCE(CALL_END_SITE_NAME,'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_BLOCK_TYPE),'')
            || '~' || COALESCE(CALL_END_BLOCK_NAME,'')
            || '~' || COALESCE(CALL_END_RESULT,'')
            || '~' || COALESCE(TO_VARCHAR(HAS_RECENT_FAILURE),'')
            || '~' || COALESCE(TO_VARCHAR(IS_TEST_CALL),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_DURATION),'')
            || '~' || COALESCE(CLI,'')
            || '~' || COALESCE(DNIS,'')
            || '~' || COALESCE(TO_VARCHAR(CLUSTER_ID),'')
            || '~' || COALESCE(CLUSTER_NAME,'')
            || '~' || COALESCE(CTI_FIELDS,'')
            || '~' || COALESCE(TO_VARCHAR(LAST_MENU_BLOCK_TYPE),'')
            || '~' || COALESCE(LAST_MENU_BLOCK_NAME,'')
            || '~' || COALESCE(TO_VARCHAR(CLI_TYPE),'')
            || '~' || COALESCE(TO_VARCHAR(SERVER_ID),'')
            || '~' || COALESCE(TO_VARCHAR(START_CHANNEL),'')
            || '~' || COALESCE(TO_VARCHAR(START_CHANNEL_CATEGORY),'')

        ) AS O_MD5_CHECKSUM_VAL

    FROM SQ_VW_CALLS_STG SQ
),

RTR_VALID_INSERT AS
(
    SELECT *
    FROM EXP_AUDIT
    WHERE OUT_CALLS_ID IS NULL
),

upd_INS AS
(
    SELECT *
    FROM RTR_VALID_INSERT
)

SELECT
    CALL_ID,
    COMPANY_ID,
    ACCOUNT_D_ID,
    BILL_ACCOUNT_NB,
    O_EDW_CRTE_NM,
    O_EDW_CRTE_TS,
    O_EDW_LAST_UPDT_NM,
    O_EDW_LAST_UPDT_TS,
    VOICE_PLATFORM_SESSION_ID,
    VOICE_PLATFORM_FULL_CALL_ID,
    START_SITE_ID,
    START_SITE_NAME,
    CALL_START_TIME,
    CALL_START_DATE,
    CALL_START_HOUR,
    CALL_END_TIME,
    CALL_END_DATE,
    CALL_END_HOUR,
    CALL_END_SITE_ID,
    CALL_END_SITE_NAME,
    CALL_END_BLOCK_TYPE,
    CALL_END_BLOCK_NAME,
    CALL_END_RESULT,
    HAS_RECENT_FAILURE,
    IS_TEST_CALL,
    CALL_DURATION,
    CLI,
    DNIS,
    CLUSTER_ID,
    CLUSTER_NAME,
    CTI_FIELDS,
    LAST_MENU_BLOCK_TYPE,
    LAST_MENU_BLOCK_NAME,
    CLI_TYPE,
    SERVER_ID,
    START_CHANNEL,
    START_CHANNEL_CATEGORY,
    O_MD5_CHECKSUM_VAL
FROM UPD_INS;

-----====================================================
UPDATE UTLDB01_DEV_SANDBOX.CXNADM.CALLS T
SET
    ACCOUNT_D_ID            = S.ACCOUNT_D_ID,
    BILL_ACCOUNT_NB         = S.BILL_ACCOUNT_NB,
    EDW_LAST_UPDT_NM        = S.O_EDW_LAST_UPDT_NM,
    EDW_LAST_UPDT_TS        = S.O_EDW_LAST_UPDT_TS,
    VOICE_PLATFORM_SESSION_ID = S.VOICE_PLATFORM_SESSION_ID,
    VOICE_PLATFORM_FULL_CALL_ID = S.VOICE_PLATFORM_FULL_CALL_ID,
    START_SITE_ID           = S.START_SITE_ID,
    START_SITE_NAME         = S.START_SITE_NAME,
    CALL_START_TIME         = S.CALL_START_TIME,
    CALL_START_DATE         = S.CALL_START_DATE,
    CALL_START_HOUR         = S.CALL_START_HOUR,
    CALL_END_TIME           = S.CALL_END_TIME,
    CALL_END_DATE           = S.CALL_END_DATE,
    CALL_END_HOUR           = S.CALL_END_HOUR,
    CALL_END_SITE_ID        = S.CALL_END_SITE_ID,
    CALL_END_SITE_NAME      = S.CALL_END_SITE_NAME,
    CALL_END_BLOCK_TYPE     = S.CALL_END_BLOCK_TYPE,
    CALL_END_BLOCK_NAME     = S.CALL_END_BLOCK_NAME,
    CALL_END_RESULT         = S.CALL_END_RESULT,
    HAS_RECENT_FAILURE      = S.HAS_RECENT_FAILURE,
    IS_TEST_CALL            = S.IS_TEST_CALL,
    CALL_DURATION           = S.CALL_DURATION,
    CLI                     = S.CLI,
    DNIS                    = S.DNIS,
    CLUSTER_ID              = S.CLUSTER_ID,
    CLUSTER_NAME            = S.CLUSTER_NAME,
    CTI_FIELDS              = S.CTI_FIELDS,
    LAST_MENU_BLOCK_TYPE    = S.LAST_MENU_BLOCK_TYPE,
    LAST_MENU_BLOCK_NAME    = S.LAST_MENU_BLOCK_NAME,
    CLI_TYPE                = S.CLI_TYPE,
    SERVER_ID               = S.SERVER_ID,
    START_CHANNEL           = S.START_CHANNEL,
    START_CHANNEL_CATEGORY  = S.START_CHANNEL_CATEGORY,
    MD5_CHECKSUM_VAL        = S.O_MD5_CHECKSUM_VAL
FROM (
WITH SQ_VW_CALLS_STG AS
(
    WITH STG AS
    (
        SELECT
            CALL_ID,
            COMPANY_ID,

            REGEXP_SUBSTR(
                LTRIM(
                    REGEXP_SUBSTR(
                        CTI_FIELDS,
                        'var_AccountNumber:[^|]+'
                    ),
                    'var_AccountNumber:'
                ),
                '[^,]+',
                1
            ) AS BILL_ACCOUNT_NB,

            VOICE_PLATFORM_SESSION_ID,
            VOICE_PLATFORM_FULL_CALL_ID,
            START_SITE_ID,
            START_SITE_NAME,
            CALL_START_TIME,
            CALL_START_DATE,
            CALL_START_HOUR,
            CALL_END_TIME,
            CALL_END_DATE,
            CALL_END_HOUR,
            CALL_END_SITE_ID,
            CALL_END_SITE_NAME,
            CALL_END_BLOCK_TYPE,
            CALL_END_BLOCK_NAME,
            CALL_END_RESULT,
            HAS_RECENT_FAILURE,
            IS_TEST_CALL,
            CALL_DURATION,
            CLI,
            DNIS,
            CLUSTER_ID,
            CLUSTER_NAME,
            CTI_FIELDS,
            LAST_MENU_BLOCK_TYPE,
            LAST_MENU_BLOCK_NAME,
            CLI_TYPE,
            SERVER_ID,
            START_CHANNEL,
            START_CHANNEL_CATEGORY
        FROM UTLDB01_DEV_SANDBOX.CXNADM.VW_CALLS_STG
    ),

    STG_2 AS
    (
        SELECT
            IF1.MEDIA_SERVER_IXN_GUID,
            MIN(IRF_USER_DATA_CUST_1.CUSTOM_DATA_1) AS CUSTOM_DATA_1,
            COUNT(DISTINCT IRF_USER_DATA_CUST_1.CUSTOM_DATA_1) AS CUSTOM_DATA_1_CNT
        FROM UTLDB01_DEV_SANDBOX.CUSADM.INTERACTION_FACT IF1
        LEFT JOIN UTLDB01_DEV_SANDBOX.CUSADM.INTERACTION_RESOURCE_FACT IRF
            ON IRF.INTERACTION_ID = IF1.INTERACTION_ID
        LEFT JOIN UTLDB01_DEV_SANDBOX.CUSADM.IRF_USER_DATA_CUST_1
            ON IRF.INTERACTION_RESOURCE_ID =
               IRF_USER_DATA_CUST_1.INTERACTION_RESOURCE_ID
        WHERE IRF_USER_DATA_CUST_1.CUSTOM_DATA_1 IS NOT NULL
        GROUP BY IF1.MEDIA_SERVER_IXN_GUID
    ),

    STG_3 AS
    (
        SELECT

            STG.CALL_ID,
            STG.COMPANY_ID,

            CASE
                WHEN STG.BILL_ACCOUNT_NB IS NULL
                 AND STG_2.CUSTOM_DATA_1_CNT = 1
                THEN STG_2.CUSTOM_DATA_1
                ELSE STG.BILL_ACCOUNT_NB
            END AS BILL_ACCOUNT_NB,

            STG.VOICE_PLATFORM_SESSION_ID,
            STG.VOICE_PLATFORM_FULL_CALL_ID,
            STG.START_SITE_ID,
            STG.START_SITE_NAME,
            STG.CALL_START_TIME,
            STG.CALL_START_DATE,
            STG.CALL_START_HOUR,
            STG.CALL_END_TIME,
            STG.CALL_END_DATE,
            STG.CALL_END_HOUR,
            STG.CALL_END_SITE_ID,
            STG.CALL_END_SITE_NAME,
            STG.CALL_END_BLOCK_TYPE,
            STG.CALL_END_BLOCK_NAME,
            STG.CALL_END_RESULT,
            STG.HAS_RECENT_FAILURE,
            STG.IS_TEST_CALL,
            STG.CALL_DURATION,
            STG.CLI,
            STG.DNIS,
            STG.CLUSTER_ID,
            STG.CLUSTER_NAME,
            STG.CTI_FIELDS,
            STG.LAST_MENU_BLOCK_TYPE,
            STG.LAST_MENU_BLOCK_NAME,
            STG.CLI_TYPE,
            STG.SERVER_ID,
            STG.START_CHANNEL,
            STG.START_CHANNEL_CATEGORY,
            A_D.ACCOUNT_D_ID

        FROM STG

        LEFT JOIN STG_2
            ON STG.VOICE_PLATFORM_FULL_CALL_ID =
               STG_2.MEDIA_SERVER_IXN_GUID

        LEFT JOIN
        (
            SELECT
                BILL_ACCOUNT_NB,
                ACCOUNT_D_ID
            FROM UTLDB01_DEV_SANDBOX.CDWADM.ACCOUNT_D
            WHERE ACTIVE_FLAG='Y'
        ) A_D
            ON STG.BILL_ACCOUNT_NB =
               A_D.BILL_ACCOUNT_NB
    )

    SELECT

        RES.*,

        CALLS.CALLS_ID           AS OUT_CALLS_ID,
        CALLS.MD5_CHECKSUM_VAL   AS OUT_MD5_CHECKSUM_VAL

    FROM STG_3 RES

    LEFT JOIN UTLDB01_DEV_SANDBOX.CXNADM.CALLS CALLS
        ON RES.CALL_ID = CALLS.CALL_ID
       AND RES.COMPANY_ID = CALLS.COMPANY_ID

    WHERE RES.CALL_START_DATE IS NOT NULL
)
---select * from SQ_VW_CALLS_STG;
,

exp_AUDIT AS
(
    SELECT

        SQ.*,

        CURRENT_TIMESTAMP() AS O_EDW_CRTE_TS,
        's_m_CALLS' AS O_EDW_CRTE_NM,

        CURRENT_TIMESTAMP() AS O_EDW_LAST_UPDT_TS,
        's_m_CALLS' AS O_EDW_LAST_UPDT_NM,

        MD5(

            COALESCE(TO_VARCHAR(ACCOUNT_D_ID),'')
            || '~' || COALESCE(BILL_ACCOUNT_NB,'')
            || '~' || COALESCE(VOICE_PLATFORM_SESSION_ID,'')
            || '~' || COALESCE(VOICE_PLATFORM_FULL_CALL_ID,'')
            || '~' || COALESCE(TO_VARCHAR(START_SITE_ID),'')
            || '~' || COALESCE(START_SITE_NAME,'')
            || '~' || COALESCE(TO_VARCHAR(CALL_START_TIME),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_START_DATE),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_START_HOUR),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_TIME),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_DATE),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_HOUR),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_SITE_ID),'')
            || '~' || COALESCE(CALL_END_SITE_NAME,'')
            || '~' || COALESCE(TO_VARCHAR(CALL_END_BLOCK_TYPE),'')
            || '~' || COALESCE(CALL_END_BLOCK_NAME,'')
            || '~' || COALESCE(CALL_END_RESULT,'')
            || '~' || COALESCE(TO_VARCHAR(HAS_RECENT_FAILURE),'')
            || '~' || COALESCE(TO_VARCHAR(IS_TEST_CALL),'')
            || '~' || COALESCE(TO_VARCHAR(CALL_DURATION),'')
            || '~' || COALESCE(CLI,'')
            || '~' || COALESCE(DNIS,'')
            || '~' || COALESCE(TO_VARCHAR(CLUSTER_ID),'')
            || '~' || COALESCE(CLUSTER_NAME,'')
            || '~' || COALESCE(CTI_FIELDS,'')
            || '~' || COALESCE(TO_VARCHAR(LAST_MENU_BLOCK_TYPE),'')
            || '~' || COALESCE(LAST_MENU_BLOCK_NAME,'')
            || '~' || COALESCE(TO_VARCHAR(CLI_TYPE),'')
            || '~' || COALESCE(TO_VARCHAR(SERVER_ID),'')
            || '~' || COALESCE(TO_VARCHAR(START_CHANNEL),'')
            || '~' || COALESCE(TO_VARCHAR(START_CHANNEL_CATEGORY),'')

        ) AS O_MD5_CHECKSUM_VAL

    FROM SQ_VW_CALLS_STG SQ
),

RTR_VALID_UPDATE AS
(
    SELECT *
    FROM EXP_AUDIT
    WHERE OUT_CALLS_ID IS NOT NULL
      AND O_MD5_CHECKSUM_VAL <> OUT_MD5_CHECKSUM_VAL
),
upd_UPD_INS AS
(
    SELECT *
    FROM RTR_VALID_UPDATE
) 
select * from 

UPD_UPD_INS) S
WHERE T.CALLS_ID = S.OUT_CALLS_ID;