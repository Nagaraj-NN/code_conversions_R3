-- =============================================================================
-- Mapping : m_VA_USERS_STG
-- Session : s_m_VA_USERS_STG
-- Pattern : Truncate and reload
-- =============================================================================

-- $DBConnection_Source=CALLCTRP
-- $DBConnection_Target=CXNUSER_UTLDB001

-- Insert(Treat source rows as insert)

-- source tables :
  -- VA_USERS
  -- DB - CALLCTRP, Schema - va_user
  -- UTLDB01_DEV_SANDBOX.COMMON.VA_USERS_TEST(Testing Purpose)

-- Used for testing
-- CREATE OR REPLACE TABLE UTLDB01_DEV_SANDBOX.COMMON.VA_USERS_TEST
-- (
--     USERID                 VARCHAR(50),
--     CC_ID                  VARCHAR(50),
--     FIRSTNAME              VARCHAR(255),
--     LASTNAME               VARCHAR(255),
--     MI                     VARCHAR(50),
--     SUPERVISOR_ID          VARCHAR(50),
--     IS_ACTIVE              VARCHAR(50),
--     PHONE                  VARCHAR(50),
--     POSITION_ID            VARCHAR(50),
--     GROUPID                VARCHAR(50),
--     MB_ID                  VARCHAR(50),
--     CONTRACTOR_AGENCY_ID   VARCHAR(50),
--     CREATEDBY              VARCHAR(100),
--     CREATEDATE             VARCHAR(50),
--     LASTUPDATEBY           VARCHAR(100),
--     LASTUPDATE             VARCHAR(50),
--     ROUTING_PROVIDER       VARCHAR(100),
--     IS_MB_ACTIVE           VARCHAR(50)
-- );

-- target tables :
  -- UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG

--PRESQL
-- call CXNADM.TRUNCATE_TABLES.truncate('VA_USERS_STG')

-- SELECT COUNT(*) FROM UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG;

--INSERT INTO UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG

INSERT INTO UTLDB01_DEV_SANDBOX.CXNADM.VA_USERS_STG
(
    USERID,
    CC_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    FIRSTNAME,
    LASTNAME,
    MI,
    SUPERVISOR_ID,
    IS_ACTIVE,
    PHONE,
    POSITION_ID,
    GROUPID,
    MB_ID,
    CONTRACTOR_AGENCY_ID,
    CREATEDBY,
    CREATEDATE,
    LASTUPDATEBY,
    LASTUPDATE,
    ROUTING_PROVIDER,
    IS_MB_ACTIVE,
    MD5_CHECKSUM_VAL
)

WITH sq_va_users AS
(
    SELECT
        VA_USERS.USERID,
        VA_USERS.CC_ID,
        VA_USERS.FIRSTNAME,
        VA_USERS.LASTNAME,
        VA_USERS.MI,
        VA_USERS.SUPERVISOR_ID,
        VA_USERS.IS_ACTIVE,
        VA_USERS.PHONE,
        VA_USERS.POSITION_ID,
        VA_USERS.GROUPID,
        VA_USERS.MB_ID,
        VA_USERS.CONTRACTOR_AGENCY_ID,
        VA_USERS.CREATEDBY,
        VA_USERS.CREATEDATE,
        VA_USERS.LASTUPDATEBY,
        VA_USERS.LASTUPDATE,
        VA_USERS.ROUTING_PROVIDER,
        VA_USERS.IS_MB_ACTIVE
    FROM VA_USERS VA_USERS
    -- FROM UTLDB01_DEV_SANDBOX.COMMON.VA_USERS_TEST VA_USERS
),

exp_Audit AS
(
    SELECT sq_va_users.*,
        CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
        's_m_VA_USERS_STG'  AS out_EDW_CRTE_NM,
        CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
        's_m_VA_USERS_STG'  AS out_EDW_LAST_UPDT_NM,

        MD5(
              COALESCE(TO_VARCHAR(FIRSTNAME), '')
           || '~'
           || COALESCE(TO_VARCHAR(LASTNAME), '')
           || '~'
           || COALESCE(TO_VARCHAR(MI), '')
           || '~'
           || COALESCE(TO_VARCHAR(SUPERVISOR_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(IS_ACTIVE), '')
           || '~'
           || COALESCE(TO_VARCHAR(PHONE), '')
           || '~'
           || COALESCE(TO_VARCHAR(POSITION_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(GROUPID), '')
           || '~'
           || COALESCE(TO_VARCHAR(MB_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(CONTRACTOR_AGENCY_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(ROUTING_PROVIDER), '')
           || '~'
           || COALESCE(TO_VARCHAR(IS_MB_ACTIVE), '')
        ) AS out_MD5_CHECKSUM_VAL
    FROM sq_va_users
)

SELECT
    USERID,
    CC_ID,
    out_EDW_CRTE_TS,
    out_EDW_CRTE_NM,
    out_EDW_LAST_UPDT_TS,
    out_EDW_LAST_UPDT_NM,
    FIRSTNAME,
    LASTNAME,
    MI,
    SUPERVISOR_ID,
    IS_ACTIVE,
    PHONE,
    POSITION_ID,
    GROUPID,
    MB_ID,
    CONTRACTOR_AGENCY_ID,
    CREATEDBY,
    CREATEDATE,
    LASTUPDATEBY,
    LASTUPDATE,
    ROUTING_PROVIDER,
    IS_MB_ACTIVE,
    out_MD5_CHECKSUM_VAL
FROM exp_Audit;