---pre- sql: call CXNADM.TRUNCATE_TABLES.truncate('VW_CALLS_STG')

INSERT INTO UTLDB01_DEV_SANDBOX.CXNADM.VW_CALLS_STG
(
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    CALL_ID,
    COMPANY_ID,
    VOICE_PLATFORM_SESSION_ID,
    VOICE_PLATFORM_FULL_CALL_ID,
    START_SITE_ID,
    START_SITE_NAME,
    CALL_START_TIME,
    CALL_START_DATE,
    CALL_START_HOUR,
    CALL_END_TIME,
    CALL_END_DATE,
    CALL_END_HOUR,
    CALL_END_SITE_ID,
    CALL_END_SITE_NAME,
    CALL_END_BLOCK_TYPE,
    CALL_END_BLOCK_NAME,
    CALL_END_RESULT,
    HAS_RECENT_FAILURE,
    IS_TEST_CALL,
    CALL_DURATION,
    CLI,
    DNIS,
    CLUSTER_ID,
    CLUSTER_NAME,
    CTI_FIELDS,
    LAST_MENU_BLOCK_TYPE,
    LAST_MENU_BLOCK_NAME,
    CLI_TYPE,
    SERVER_ID,
    START_CHANNEL,
    START_CHANNEL_CATEGORY,
    MD5_CHECKSUM_VAL
)

WITH sq_vw_calls AS
(
    SELECT
        call_id,
        company_id,
        voice_platform_session_id,
        voice_platform_full_call_id,
        start_site_id,
        start_site_name,
        call_start_time,
        call_start_date,
        call_start_hour,
        call_end_time,
        call_end_date,
        call_end_hour,
        call_end_site_id,
        call_end_site_name,
        call_end_block_type,
        call_end_block_name,
        call_end_result,
        has_recent_failure,
        is_test_call,
        call_duration,
        cli,
        dnis,
        cluster_id,
        cluster_name,
        cti_fields,
        last_menu_block_type,
        last_menu_block_name,
        cli_type,
        server_id,
        start_channel,
        start_channel_category
    FROM UTLDB01_DEV_SANDBOX.CXNADM.CALLS ---need to be change VW_CALLS
)
---select * from sq_vw_calls;
,
exp_Audit AS
(
    SELECT

        call_id,
        company_id,
        voice_platform_session_id,
        voice_platform_full_call_id,
        start_site_id,
        start_site_name,
        call_start_time,
        call_start_date,
        call_start_hour,
        call_end_time,
        call_end_date,
        call_end_hour,
        call_end_site_id,
        call_end_site_name,
        call_end_block_type,
        call_end_block_name,
        call_end_result,
        has_recent_failure,
        is_test_call,
        call_duration,
        cli,
        dnis,
        cluster_id,
        cluster_name,
        cti_fields,
        last_menu_block_type,
        last_menu_block_name,
        cli_type,
        server_id,
        start_channel,
        start_channel_category,

        /* Informatica expression:
           $PMSessionName
        */
        's_m_VW_CALLS_STG' AS out_edw_crte_nm,

        /* Informatica expression:
           SESSSTARTTIME
        */
        CURRENT_TIMESTAMP()  AS out_edw_crte_ts,

        's_m_VW_CALLS_STG' AS out_edw_last_updt_nm,

        CURRENT_TIMESTAMP()  AS out_edw_last_updt_ts,

        MD5(
              COALESCE(TO_VARCHAR(voice_platform_session_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(voice_platform_full_call_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_site_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_site_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_start_time),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_start_date),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_start_hour),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_time),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_date),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_hour),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_site_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_site_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_block_type),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_block_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_result),'')
           || '~' ||
              COALESCE(TO_VARCHAR(has_recent_failure),'')
           || '~' ||
              COALESCE(TO_VARCHAR(is_test_call),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_duration),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cli),'')
           || '~' ||
              COALESCE(TO_VARCHAR(dnis),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cluster_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cluster_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cti_fields),'')
           || '~' ||
              COALESCE(TO_VARCHAR(last_menu_block_type),'')
           || '~' ||
              COALESCE(TO_VARCHAR(last_menu_block_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cli_type),'')
           || '~' ||
              COALESCE(TO_VARCHAR(server_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_channel),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_channel_category),'')
        ) AS out_md5_checksum_val

    FROM sq_vw_calls
)

SELECT
    out_edw_crte_ts,
    out_edw_crte_nm,
    out_edw_last_updt_ts,
    out_edw_last_updt_nm,
    call_id,
    company_id,
    voice_platform_session_id,
    voice_platform_full_call_id,
    start_site_id,
    start_site_name,
    call_start_time,
    call_start_date,
    call_start_hour,
    call_end_time,
    call_end_date,
    call_end_hour,
    call_end_site_id,
    call_end_site_name,
    call_end_block_type,
    call_end_block_name,
    call_end_result,
    has_recent_failure,
    is_test_call,
    call_duration,
    cli,
    dnis,
    cluster_id,
    cluster_name,
    cti_fields,
    last_menu_block_type,
    last_menu_block_name,
    cli_type,
    server_id,
    start_channel,
    start_channel_category,
    out_md5_checksum_val
FROM exp_Audit;