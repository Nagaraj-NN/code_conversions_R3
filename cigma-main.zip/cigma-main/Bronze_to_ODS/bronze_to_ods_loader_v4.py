#!/usr/bin/env python3
"""
bronze_to_ods_loader.py
=======================

Generates (and optionally runs) TRUNCATE + INSERT scripts that load a Bronze
Snowflake table into its matching ODS/UTLDB target table.

For every source/target pair the script:
  1. Reads column metadata for both tables from <DB>.INFORMATION_SCHEMA.COLUMNS
     (falls back to DESC TABLE if INFORMATION_SCHEMA returns nothing).
  2. Matches source columns to target columns: exact name -> normalised name
     (nb/nbr/number, cd/code, nm/name, ts/dttm ... are treated as synonyms)
     -> fuzzy name -> positional. Bronze audit columns (icoe_*, aws_extract_dttm,
     dp_*) are ignored unless the target actually has the same column.
  3. Builds a cleansed SELECT: LTRIM/RTRIM, '' -> NULL, TRY_TO_NUMBER /
     TRY_TO_DATE / TRY_TO_TIMESTAMP_NTZ with multiple format attempts, length
     handling against the (smaller) target VARCHAR sizes.
  4. Adds a WHERE clause that drops bad rows: values that failed to convert,
     out-of-range dates (e.g. '22026-01-01'), over-length strings and NULLs
     landing in NOT NULL target columns.
  5. Sets EDW_LAST_UPDT_TS (and any other --now-cols) to CURRENT_TIMESTAMP().
  6. Writes <TARGET_TABLE>.sql (no db.schema prefix) to the output folder.

Failures on one pair are reported and the run continues with the next pair.

Usage
-----
  # single pair
  python bronze_to_ods_loader.py --env PROD \
      --source BRONZE_CUST_CONF_PROD.bronze_macss.mcs_web_alert_hdr \
      --target UTLDB01.UTLUSER.ODS_MCS_WEB_ALERT_HDR \
      --out ./generated_sql

  # batch: csv with header source_table,target_table
  python bronze_to_ods_loader.py --env PROD --pairs table_pairs.csv --out ./generated_sql

  # keep the browser-auth session alive and feed pairs interactively (1 hour)
  python bronze_to_ods_loader.py --env PROD --out ./generated_sql --session

  # also execute the generated script against the target
  python bronze_to_ods_loader.py --env PROD --pairs table_pairs.csv --out ./sql --execute

Config file: snowflake_config.json next to this script (keys QA / DEV / PROD).
"""

from __future__ import annotations

import argparse
import csv
import difflib
import json
import os
import re
import sys
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Sequence, Tuple

try:
    import snowflake.connector  # type: ignore
except Exception:  # pragma: no cover - import guard only
    snowflake = None  # type: ignore


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILENAME = "snowflake_config.json"
CONFIG_ENV_VAR = "BRONZE_ODS_CONFIG"

# Search order when --config is not given:
#   1. $BRONZE_ODS_CONFIG
#   2. ./snowflake_config.json          (folder you run from)
#   3. <script folder>/snowflake_config.json
def default_config_paths() -> List[str]:
    paths = []
    from_env = os.environ.get(CONFIG_ENV_VAR)
    if from_env:
        paths.append(from_env)
    paths.append(os.path.join(os.getcwd(), CONFIG_FILENAME))
    paths.append(os.path.join(SCRIPT_DIR, CONFIG_FILENAME))
    seen, out = set(), []
    for path in paths:
        full = os.path.abspath(path)
        if full not in seen:
            seen.add(full)
            out.append(full)
    return out

# ---------------------------------------------------------------------------
# Defaults you may want to tweak
# ---------------------------------------------------------------------------

# Bronze / CDC audit columns that normally have no counterpart in the ODS table.
DEFAULT_AUDIT_COLUMNS = [
    "ICOE_OP_TYPE",
    "ICOE_OP_TS",
    "ICOE_OFFSET",
    "ICOE_SCN",
    "AWS_EXTRACT_DTTM",
    "DP_UPDATE_USER",
    "DP_INSERT_DTTM",
    "DP_UPDATE_DTTM",
    "DP_INSERT_USER",
]
# Prefix-based audit detection (anything starting with these is treated as audit)
DEFAULT_AUDIT_PREFIXES = ["ICOE_", "DP_", "_HOODIE", "_FIVETRAN"]

# Target columns that are populated by the load itself, not from the source.
DEFAULT_NOW_COLUMNS = ["EDW_LAST_UPDT_TS"]

# Literal strings that mean "no value" in a flat-file extract. Applied only to
# non-string targets, where they can never be legitimate data - in a VARCHAR
# column "N/A" may well be a real value the business wants kept.
DEFAULT_NULL_TOKENS = ["NULL", "N/A", "NA", "NONE", "#N/A", "UNKNOWN"]

# Token synonyms used when comparing slightly different column names.
SYNONYMS = {
    "NBR": "NB", "NUM": "NB", "NUMBER": "NB", "NO": "NB",
    "CODE": "CD",
    "NAME": "NM",
    "FLAG": "FL", "FLG": "FL", "IND": "FL", "INDICATOR": "FL",
    "TEXT": "TX", "TXT": "TX",
    "TIMESTAMP": "TS", "TSTMP": "TS", "TMSTMP": "TS", "DTTM": "TS", "DTM": "TS",
    "DATE": "DT",
    "DESCRIPTION": "DS", "DESC": "DS", "DESCR": "DS",
    "AMOUNT": "AM", "AMT": "AM",
    "QUANTITY": "QT", "QTY": "QT",
    "IDENTIFIER": "ID",
    "EFFECTIVE": "EFF", "EFCT": "EFF", "EFF": "EFF",
    "EXPIRATION": "EXP", "EXPR": "EXP", "EXPIRE": "EXP",
    "ACCOUNT": "ACCT",
    "ADDRESS": "ADDR",
    "UPDATE": "UPDT", "UPDATED": "UPDT",
    "CUSTOMER": "CUST",
    "LAST": "LAST",
}

RULE_TEXT = {
    "CAST": "value could not be converted / does not fit the target precision",
    "SHAPE": "value does not match any accepted numeric / date layout",
    "ROUND": "value would be silently rounded to fit the target scale",
    "RANGE": "date/timestamp outside the accepted year range",
    "LEN": "string longer than the target column",
    "NOTNULL": "NULL or blank landing in a NOT NULL target column",
    "KEY": "NULL or blank in a key column",
}

DATE_FORMATS = [
    "YYYY-MM-DD",
    "MM/DD/YYYY",
    "DD-MON-YYYY",
    "YYYYMMDD",
    "YYYY/MM/DD",
]
TIMESTAMP_FORMATS = [
    "YYYY-MM-DD HH24:MI:SS",
    "YYYY-MM-DD HH24:MI:SS.FF",
    "YYYY-MM-DD\"T\"HH24:MI:SS",
    "YYYY-MM-DD\"T\"HH24:MI:SS.FF",
    "YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"",
    "YYYY-MM-DD\"T\"HH24:MI:SS.FF\"Z\"",
    "YYYY-MM-DD HH24:MI",
    "MM/DD/YYYY HH24:MI:SS",
    "DD-MON-YYYY HH24:MI:SS",
    "YYYYMMDDHH24MISS",
]

# Format token -> regex fragment, longest token first so HH24 wins over HH.
FORMAT_TOKENS = [
    ("YYYY", "[0-9]{4}"),
    ("MON",  "[A-Za-z]{3}"),
    ("HH24", "[0-9]{1,2}"),
    ("HH12", "[0-9]{1,2}"),
    ("TZH",  "[+-][0-9]{2}"),
    ("TZM",  "[0-9]{2}"),
    ("FF9", "[0-9]{1,9}"), ("FF6", "[0-9]{1,6}"), ("FF3", "[0-9]{1,3}"),
    ("FF",   "[0-9]{1,9}"),
    ("YY",   "[0-9]{2}"),
    ("MM",   "[0-9]{1,2}"),
    ("DD",   "[0-9]{1,2}"),
    ("HH",   "[0-9]{1,2}"),
    ("MI",   "[0-9]{1,2}"),
    ("SS",   "[0-9]{1,2}"),
    ("AM",   "[AaPp][Mm]"),
    ("PM",   "[AaPp][Mm]"),
]


def format_to_regex(fmt: str) -> str:
    """Turn a Snowflake date/time format into a shape regex.

    'YYYY-MM-DD' -> '[0-9]{4}[-][0-9]{2}[-][0-9]{2}'. Used as a gate so a value
    that does not even look like the expected layout is rejected before any
    TRY_TO_* runs - which is what stops an all-digit string being silently
    read as seconds since epoch.
    """
    out, i = [], 0
    while i < len(fmt):
        if fmt[i] == '"':                       # quoted literal, e.g. "T"
            j = fmt.index('"', i + 1)
            for ch in fmt[i + 1:j]:
                out.append(ch if ch.isalnum() else "[" + ch + "]")
            i = j + 1
            continue
        for token, frag in FORMAT_TOKENS:
            if fmt.startswith(token, i):
                out.append(frag)
                i += len(token)
                break
        else:
            ch = fmt[i]
            if ch == " ":
                out.append("[[:space:]]+")   # tolerate a double space or a tab
            else:
                out.append(ch if ch.isalnum() else "[" + ch + "]")
            i += 1
    return "".join(out)

STRING_TYPES = {"TEXT", "VARCHAR", "CHAR", "CHARACTER", "STRING"}
NUMBER_TYPES = {"NUMBER", "DECIMAL", "NUMERIC", "INT", "INTEGER", "BIGINT",
                "SMALLINT", "TINYINT", "BYTEINT"}
FLOAT_TYPES = {"FLOAT", "FLOAT4", "FLOAT8", "DOUBLE", "REAL",
               "DOUBLE PRECISION"}
DATE_TYPES = {"DATE"}
TS_TYPES = {"TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "DATETIME",
            "TIMESTAMP"}
BOOL_TYPES = {"BOOLEAN"}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

class Colour:
    RED = "\033[91m"
    YELLOW = "\033[93m"
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    RESET = "\033[0m"

    @classmethod
    def off(cls):
        cls.RED = cls.YELLOW = cls.GREEN = cls.CYAN = cls.RESET = ""


def log(msg: str = "") -> None:
    print(msg, flush=True)


def err(msg: str) -> None:
    print(f"{Colour.RED}{msg}{Colour.RESET}", file=sys.stderr, flush=True)


def warn(msg: str) -> None:
    print(f"{Colour.YELLOW}{msg}{Colour.RESET}", flush=True)


def ok(msg: str) -> None:
    print(f"{Colour.GREEN}{msg}{Colour.RESET}", flush=True)


IDENT_SAFE = re.compile(r"^[A-Z_][A-Z0-9_$]*$")


def quote_ident(name: str, mode: str = "auto") -> str:
    """Quote an identifier only when Snowflake would need it."""
    if mode == "never":
        return name
    if mode == "always" or not IDENT_SAFE.match(name):
        return '"' + name.replace('"', '""') + '"'
    return name


def qualify(db: str, schema: str, table: str, mode: str = "auto") -> str:
    return ".".join(quote_ident(p, mode) for p in (db, schema, table))


def split_table(fqn: str) -> Tuple[str, str, str]:
    parts = [p.strip().strip('"') for p in fqn.strip().split(".")]
    if len(parts) != 3:
        raise ValueError(
            f"Table name must be DB.SCHEMA.TABLE, got: {fqn!r}")
    return parts[0], parts[1], parts[2]


def normalise(name: str) -> str:
    """Uppercase, split on _, map synonyms, drop separators."""
    tokens = re.split(r"[^A-Za-z0-9]+", name.upper())
    out = []
    for tok in tokens:
        if not tok:
            continue
        out.append(SYNONYMS.get(tok, tok))
    return "".join(out)


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

@dataclass
class Column:
    name: str
    ordinal: int
    data_type: str
    char_len: Optional[int] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    nullable: bool = True
    dt_precision: Optional[int] = None

    @property
    def family(self) -> str:
        t = self.data_type.upper()
        if t in STRING_TYPES:
            return "STR"
        if t in NUMBER_TYPES:
            return "NUM"
        if t in FLOAT_TYPES:
            return "FLT"
        if t in DATE_TYPES:
            return "DATE"
        if t in TS_TYPES:
            return "TS"
        if t in BOOL_TYPES:
            return "BOOL"
        return "OTHER"

    @property
    def display_type(self) -> str:
        t = self.data_type.upper()
        if t in STRING_TYPES and self.char_len:
            return f"VARCHAR({self.char_len})"
        if t in NUMBER_TYPES and self.precision is not None:
            return f"NUMBER({self.precision},{self.scale or 0})"
        if t in TS_TYPES and self.dt_precision is not None:
            return f"{t}({self.dt_precision})"
        return t


@dataclass
class Mapping:
    target: Column
    source: Optional[Column]
    how: str                       # exact | normalised | fuzzy | positional | current_timestamp | unmapped
    note: str = ""


@dataclass
class Plan:
    src_db: str
    src_schema: str
    src_table: str
    tgt_db: str
    tgt_schema: str
    tgt_table: str
    mappings: List[Mapping] = field(default_factory=list)
    unused_source: List[Tuple[Column, str]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    key_cols: List[str] = field(default_factory=list)
    src_columns: List[Column] = field(default_factory=list)


TYPE_RE = re.compile(r"^\s*([A-Za-z_ ]+?)\s*(?:\(\s*(\d+)\s*(?:,\s*(\d+)\s*)?\))?\s*$")


def parse_type_string(raw: str):
    """'VARCHAR(320)' -> ('TEXT', 320, None, None, None);
       'NUMBER(38,0)' -> ('NUMBER', None, 38, 0, None);
       'TIMESTAMP_NTZ(6)' -> ('TIMESTAMP_NTZ', None, None, None, 6)."""
    m = TYPE_RE.match(raw or "")
    if not m:
        return (raw or "").upper(), None, None, None, None
    base = m.group(1).strip().upper()
    a = int(m.group(2)) if m.group(2) else None
    b = int(m.group(3)) if m.group(3) else None
    if base in STRING_TYPES:
        return "TEXT", a, None, None, None
    if base in NUMBER_TYPES:
        return "NUMBER", None, a, (b if b is not None else 0), None
    if base in TS_TYPES:
        return base, None, None, None, a
    return base, None, None, None, None


class MetaReader:
    """Reads column metadata, with a per-run cache."""

    def __init__(self, conn_provider):
        self._conn_provider = conn_provider
        self._cache: Dict[Tuple[str, str, str], List[Column]] = {}

    def columns(self, db: str, schema: str, table: str) -> List[Column]:
        key = (db.upper(), schema.upper(), table.upper())
        if key in self._cache:
            return self._cache[key]
        cols = self._from_information_schema(db, schema, table)
        if not cols:
            cols = self._from_desc(db, schema, table)
        if not cols:
            raise RuntimeError(
                f"No columns found for {db}.{schema}.{table} "
                f"(check the name, your role and the warehouse).")
        self._cache[key] = cols
        return cols

    def primary_key(self, db: str, schema: str, table: str) -> List[str]:
        """Target PK columns, in key order. Empty list if none / not visible."""
        fqn = qualify(db, schema, table)
        cur = self._conn_provider().cursor()
        try:
            cur.execute(f"SHOW PRIMARY KEYS IN TABLE {fqn}")
            rows = cur.fetchall()
            headers = [d[0].lower() for d in cur.description]
        except Exception:
            return []
        finally:
            cur.close()
        try:
            i_col = headers.index("column_name")
            i_seq = headers.index("key_sequence")
        except ValueError:
            return []
        return [r[i_col] for r in sorted(rows, key=lambda r: r[i_seq])]

    def _from_information_schema(self, db, schema, table) -> List[Column]:
        sql = f"""
            SELECT COLUMN_NAME,
                   ORDINAL_POSITION,
                   DATA_TYPE,
                   CHARACTER_MAXIMUM_LENGTH,
                   NUMERIC_PRECISION,
                   NUMERIC_SCALE,
                   IS_NULLABLE,
                   DATETIME_PRECISION
              FROM {quote_ident(db.upper())}.INFORMATION_SCHEMA.COLUMNS
             WHERE UPPER(TABLE_SCHEMA) = UPPER(%s)
               AND UPPER(TABLE_NAME)   = UPPER(%s)
             ORDER BY ORDINAL_POSITION
        """
        cur = self._conn_provider().cursor()
        try:
            cur.execute(sql, (schema, table))
            rows = cur.fetchall()
        finally:
            cur.close()
        cols = []
        for r in rows:
            cols.append(Column(
                name=r[0],
                ordinal=int(r[1]),
                data_type=(r[2] or "").upper(),
                char_len=int(r[3]) if r[3] is not None else None,
                precision=int(r[4]) if r[4] is not None else None,
                scale=int(r[5]) if r[5] is not None else None,
                nullable=(str(r[6]).upper() != "NO"),
                dt_precision=int(r[7]) if len(r) > 7 and r[7] is not None else None,
            ))
        return cols

    def _from_desc(self, db, schema, table) -> List[Column]:
        fqn = qualify(db, schema, table)
        cur = self._conn_provider().cursor()
        try:
            cur.execute(f"DESC TABLE {fqn}")
            rows = cur.fetchall()
            headers = [d[0].upper() for d in cur.description]
        except Exception:
            return []
        finally:
            cur.close()
        i_name = headers.index("NAME") if "NAME" in headers else 0
        i_type = headers.index("TYPE") if "TYPE" in headers else 1
        i_null = headers.index("NULL?") if "NULL?" in headers else None
        cols = []
        for pos, r in enumerate(rows, start=1):
            base, clen, prec, scale, dtp = parse_type_string(str(r[i_type]))
            cols.append(Column(
                name=str(r[i_name]),
                ordinal=pos,
                data_type=base,
                char_len=clen,
                precision=prec,
                scale=scale,
                nullable=(str(r[i_null]).upper() != "N") if i_null is not None else True,
                dt_precision=dtp,
            ))
        return cols


# ---------------------------------------------------------------------------
# Column matching
# ---------------------------------------------------------------------------

def is_audit(col: Column, audit_names: Sequence[str], prefixes: Sequence[str]) -> bool:
    n = col.name.upper()
    if n in audit_names:
        return True
    return any(n.startswith(p) for p in prefixes)


def compatible(src: Column, tgt: Column) -> bool:
    fs, ft = src.family, tgt.family
    if fs == ft:
        return True
    if fs == "STR" or ft == "STR":          # strings convert both ways
        return True
    if {fs, ft} <= {"NUM", "FLT"}:
        return True
    if {fs, ft} <= {"DATE", "TS"}:
        return True
    return False


def build_plan(src_fqn: str, tgt_fqn: str,
               src_cols: List[Column], tgt_cols: List[Column],
               opts, key_cols: Optional[List[str]] = None) -> Plan:
    s_db, s_sch, s_tab = split_table(src_fqn)
    t_db, t_sch, t_tab = split_table(tgt_fqn)
    plan = Plan(s_db, s_sch, s_tab, t_db, t_sch, t_tab)
    plan.src_columns = list(src_cols)
    plan.key_cols = [c.upper() for c in (key_cols or [])]
    for c in (opts.key_cols or []):
        if c.upper() not in plan.key_cols:
            plan.key_cols.append(c.upper())

    audit_names = [a.upper() for a in opts.audit_cols]
    audit_prefixes = [p.upper() for p in opts.audit_prefixes]
    now_cols = {c.upper() for c in opts.now_cols}
    overrides = {k.upper(): v for k, v in
                 (opts.overrides.get(t_tab.upper(), {}) or {}).items()}

    src_by_name = {c.name.upper(): c for c in src_cols}
    src_by_norm: Dict[str, List[Column]] = {}
    for c in src_cols:
        src_by_norm.setdefault(normalise(c.name), []).append(c)

    used: set = set()
    mappings: List[Mapping] = []

    def take(c: Column) -> None:
        used.add(c.name.upper())

    for tcol in sorted(tgt_cols, key=lambda c: c.ordinal):
        tname = tcol.name.upper()

        # 1. load-generated columns
        if tname in now_cols:
            mappings.append(Mapping(tcol, None, "current_timestamp"))
            continue

        # 2. explicit override from --overrides
        if tname in overrides:
            sname = overrides[tname].upper()
            scol = src_by_name.get(sname)
            if not scol:
                raise RuntimeError(
                    f"Override for {t_tab}.{tname} points at missing source column {sname}")
            take(scol)
            mappings.append(Mapping(tcol, scol, "override"))
            continue

        # 3. exact name
        scol = src_by_name.get(tname)
        if scol and scol.name.upper() not in used:
            take(scol)
            mappings.append(Mapping(tcol, scol, "exact"))
            continue

        # 4. normalised name (unique candidate only)
        cands = [c for c in src_by_norm.get(normalise(tcol.name), [])
                 if c.name.upper() not in used]
        if len(cands) == 1:
            take(cands[0])
            mappings.append(Mapping(tcol, cands[0], "normalised",
                                    f"{cands[0].name} ~ {tcol.name}"))
            continue
        if len(cands) > 1:
            plan.warnings.append(
                f"{tname}: several source columns normalise the same way "
                f"({', '.join(c.name for c in cands)}) - left unmapped, use --overrides")
            mappings.append(Mapping(tcol, None, "unmapped", "ambiguous normalised match"))
            continue

        mappings.append(Mapping(tcol, None, "unmapped"))

    # 5. fuzzy pass over what is still unmapped
    def free_sources(skip_audit=True) -> List[Column]:
        out = []
        for c in src_cols:
            if c.name.upper() in used:
                continue
            if skip_audit and is_audit(c, audit_names, audit_prefixes):
                continue
            out.append(c)
        return out

    if not opts.no_fuzzy:
        for m in mappings:
            if m.how != "unmapped":
                continue
            pool = free_sources()
            if not pool:
                break
            norm_map = {normalise(c.name): c for c in pool}
            best = difflib.get_close_matches(
                normalise(m.target.name), list(norm_map), n=1, cutoff=opts.fuzzy_cutoff)
            if best:
                cand = norm_map[best[0]]
                if compatible(cand, m.target):
                    take(cand)
                    m.source, m.how = cand, "fuzzy"
                    m.note = (f"{cand.name} ~ {m.target.name} "
                              f"(similarity {difflib.SequenceMatcher(None, best[0], normalise(m.target.name)).ratio():.2f}) - VERIFY")
                    plan.warnings.append(
                        f"{m.target.name}: fuzzy-matched to {cand.name} - please verify")

    # 6. positional pass for the rest
    if not opts.no_positional:
        leftovers = [m for m in mappings if m.how == "unmapped"]
        pool = free_sources()
        for m, cand in zip(sorted(leftovers, key=lambda x: x.target.ordinal),
                           sorted(pool, key=lambda c: c.ordinal)):
            if compatible(cand, m.target):
                take(cand)
                m.source, m.how = cand, "positional"
                m.note = f"matched by column order - VERIFY"
                plan.warnings.append(
                    f"{m.target.name}: matched positionally to {cand.name} - please verify")

    plan.mappings = mappings

    for c in src_cols:
        if c.name.upper() in used:
            continue
        reason = "audit column" if is_audit(c, audit_names, audit_prefixes) else "no target column"
        plan.unused_source.append((c, reason))

    still = [m.target.name for m in mappings if m.how == "unmapped"]
    if still:
        plan.warnings.append(
            "target columns with no source: " + ", ".join(still) +
            " (they will be loaded as NULL / table default)")
    return plan


# ---------------------------------------------------------------------------
# Cleansing expressions
# ---------------------------------------------------------------------------

@dataclass
class Expr:
    """One target column's load logic, split across the two query layers.

    prep  - normalisation done in the first layer (trim, strip separators);
            exposed there as N__<k> so it is computed once and read twice.
    sql   - the conversion, written against {v} which resolves to the prep
            alias, or to the raw source column when there is no prep step.
    """
    sql: str
    prep: Optional[str] = None
    needs_raw: bool = False
    fills_null: bool = False        # expression can never yield NULL
    checks: List[Tuple[str, str]] = field(default_factory=list)


def fits_numeric(src: Column, tgt: Column) -> bool:
    """True when every value of src is representable in tgt (widening cast)."""
    if tgt.family == "FLT":
        return True
    if src.family == "FLT":
        return False
    if src.precision is None or tgt.precision is None:
        return False
    s_scale, t_scale = src.scale or 0, tgt.scale or 0
    src_int_digits = src.precision - s_scale
    tgt_int_digits = tgt.precision - t_scale
    return src_int_digits <= tgt_int_digits and s_scale <= t_scale


def _string_value(ref: str, src: Column, opts=None, null_tokens: bool = False,
                  blank_to_null: bool = True) -> str:
    """Whitespace-trimmed, blank-as-null string form of the source column.

    Snowflake's TRIM() only removes spaces, so tabs / CR / LF / NBSP coming out
    of flat-file loads survive it and then break casts. REGEXP_REPLACE with
    [[:space:]] strips the lot.
    """
    inner = ref if src.family == "STR" else f"TO_VARCHAR({ref})"
    trimmed = f"REGEXP_REPLACE({inner}, '^[[:space:]]+|[[:space:]]+$', '')"
    if opts is not None and getattr(opts, "strip_control", False):
        trimmed = f"REGEXP_REPLACE({trimmed}, '[[:cntrl:]]', '')"
    tokens = getattr(opts, "null_tokens", None) if opts is not None else None
    if null_tokens and tokens:
        # Blank out the null-marker tokens in the same pass, case-insensitively,
        # so the trimmed value is only evaluated once.
        alts = "|".join(_regex_literal(t) for t in tokens)
        trimmed = f"REGEXP_REPLACE({trimmed}, '^({alts})$', '', 1, 0, 'i')"
    if not blank_to_null:
        # '' is a real value in Snowflake and loads into a NOT NULL column.
        # Keeping it matches what the existing PROD pipeline writes today.
        return trimmed
    return f"NULLIF({trimmed}, '')"


def _regex_literal(token: str) -> str:
    """Escape a null-marker token for use inside a regex alternation."""
    out = []
    for ch in token:
        out.append(ch if (ch.isalnum() or ch in "/_- ") else "[" + ch + "]")
    return "".join(out)


def _rejects(opts, kind: str, is_key: bool) -> bool:
    """Should a bad value in this column drop the row, or just become NULL?

    keys      only key columns drop rows; everything else lands as NULL
    standard  bad numerics and bad dates drop the row, anywhere in the table
    strict    everything drops the row
    """
    if is_key or opts.mode == "strict":
        return True
    if opts.mode == "standard":
        return kind in ("numeric", "date")
    return False        # mode == keys


def build_expression(src: Column, tgt: Column, opts, is_key: bool = False) -> Expr:
    ref = f"src.{quote_ident(src.name, opts.quote)}"
    fam = tgt.family

    # ---------------- string target ----------------
    if fam == "STR":
        keep_blank = (opts.blank_strings == "keep")
        prep = _string_value(ref, src, opts, blank_to_null=not keep_blank)
        # A NOT NULL string column can hold '', so a genuine source NULL can be
        # filled rather than costing the whole row. Never done for key columns:
        # a blank key is not usable data.
        fill = (not tgt.nullable and not is_key
                and opts.notnull_strings == "blank")
        body = "{v}"
        if tgt.char_len and (src.char_len is None or src.char_len > tgt.char_len):
            if opts.on_overflow == "truncate":
                body = "LEFT({v}, %d)" % tgt.char_len
            else:
                e = Expr("{v}", prep=prep, needs_raw=True)
                e.checks.append(
                    ("LEN", "({raw} IS NULL OR LENGTH({raw}) <= %d)" % tgt.char_len))
                return e
        if fill:
            return Expr(f"COALESCE({body}, '')", prep=prep, fills_null=True)
        return Expr(body, prep=prep)

    # ---------------- numeric target ----------------
    if fam in ("NUM", "FLT"):
        p = tgt.precision if tgt.precision is not None else 38
        sc = tgt.scale if tgt.scale is not None else 0

        if src.family in ("NUM", "FLT"):
            if fits_numeric(src, tgt):
                return Expr(ref)                      # widening, cannot fail
            # TRY_CAST only accepts strings in Snowflake, so go via TO_VARCHAR.
            conv = (f"TRY_TO_NUMBER({{v}}, {p}, {sc})" if fam == "NUM"
                    else "TRY_TO_DOUBLE({v})")
            e = Expr(conv, prep=f"TO_VARCHAR({ref})", needs_raw=True)
            if _rejects(opts, "numeric", is_key):
                e.checks.append(("CAST", "({raw} IS NULL OR {clean} IS NOT NULL)"))
            return e

        # ---- varchar -> numeric: the case that actually bites ----
        # Normalise only unambiguous noise: currency symbol, thousand
        # separators, and accounting negatives (123.45) -> -123.45.
        base = _string_value(ref, src, opts, null_tokens=True)
        if opts.no_numeric_normalise:
            # Nothing is rewritten: the SHAPE gate below sees exactly what the
            # source holds, so '$1,234.56' is rejected rather than converted.
            prep = base
        else:
            prep = (f"REGEXP_REPLACE(REGEXP_REPLACE({base}, '[$,]', ''), "
                    r"'^[(](.*)[)]$', '-\\1')")
        if fam == "NUM":
            conv = f"TRY_TO_NUMBER({{v}}, {p}, {sc})"
            shape = "^[+-]?[0-9]+([.][0-9]+)?$"
        else:
            conv = "TRY_TO_DOUBLE({v})"
            shape = "^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?$"
        e = Expr(conv, prep=prep, needs_raw=True)
        if _rejects(opts, "numeric", is_key):
            # Explicit gate: anything that is not a clean number drops the row
            # rather than quietly arriving as NULL.
            e.checks.append(("SHAPE",
                             "({raw} IS NULL OR REGEXP_LIKE({raw}, '%s'))" % shape))
            # Catches precision overflow, which passes the shape test.
            e.checks.append(("CAST", "({raw} IS NULL OR {clean} IS NOT NULL)"))
        if fam == "NUM" and opts.reject_rounding:
            e.checks.append(("ROUND",
                             "({raw} IS NULL OR {clean} IS NULL OR "
                             "TRY_TO_NUMBER({raw}, 38, 12) = {clean})"))
        return e

    # ---------------- date / timestamp target ----------------
    if fam in ("DATE", "TS"):
        guard = ("({clean} IS NULL OR YEAR({clean}) BETWEEN %d AND %d)"
                 % (opts.min_year, opts.max_year))
        if src.family in ("DATE", "TS"):
            # date/timestamp -> date/timestamp never raises in Snowflake, but
            # the value itself can still be outside the accepted range.
            sql = ref if src.data_type == tgt.data_type else f"CAST({ref} AS {tgt.display_type})"
            e = Expr(sql)
            # A value that is already a DATE/TIMESTAMP cannot be malformed, so
            # only the strictest mode range-checks it - otherwise a legitimate
            # sentinel date would drop the whole row.
            if opts.mode == "strict" or is_key:
                e.checks.append(("RANGE", guard))
            return e
        if fam == "DATE":
            fn, fmts = "TRY_TO_DATE", list(DATE_FORMATS)
        else:
            fn = ("TRY_TO_TIMESTAMP_NTZ" if tgt.data_type == "TIMESTAMP_NTZ"
                  else "TRY_TO_TIMESTAMP")
            fmts = list(TIMESTAMP_FORMATS) + list(DATE_FORMATS)
        parts = [f"{fn}({{v}}, '{f}')" for f in fmts]
        if opts.allow_auto_date:
            # Snowflake's AUTO parser reads an all-digit string as seconds since
            # epoch, so '20261301' becomes 1970-08-23 instead of failing.
            parts.append(f"{fn}({{v}})")
        conv = "COALESCE(\n            " + ",\n            ".join(parts) + "\n        )"
        e = Expr(conv, prep=_string_value(ref, src, opts, null_tokens=True), needs_raw=True)
        if _rejects(opts, "date", is_key):
            # Shape gate, same idea as the numeric one: the value has to look
            # like one of the accepted layouts before conversion is attempted.
            shape = "|".join(format_to_regex(f) for f in fmts)
            e.checks.append(("SHAPE",
                             "({raw} IS NULL OR REGEXP_LIKE({raw}, '^(%s)$'))" % shape))
            # Catches a well-shaped but impossible value such as 2026-23-23.
            e.checks.append(("CAST", "({raw} IS NULL OR {clean} IS NOT NULL)"))
            e.checks.append(("RANGE", guard))
        return e

    # ---------------- boolean target ----------------
    if fam == "BOOL":
        conv = ("CASE WHEN UPPER({v}) IN ('Y','YES','T','TRUE','1') THEN TRUE\n"
                "             WHEN UPPER({v}) IN ('N','NO','F','FALSE','0') THEN FALSE END")
        e = Expr(conv, prep=_string_value(ref, src, opts, null_tokens=True), needs_raw=True)
        # An unrecognised flag value becomes NULL; it does not drop the row
        # unless this is a key column or you asked for strict mode.
        if opts.mode == "strict" or is_key:
            e.checks.append(("CAST", "({raw} IS NULL OR {clean} IS NOT NULL)"))
        return e

    # ---------------- anything else ----------------
    e = Expr(f"TRY_CAST({{v}} AS {tgt.data_type})",
             prep=f"TO_VARCHAR({ref})", needs_raw=True)
    if opts.mode == "strict" or is_key:
        e.checks.append(("CAST", "({raw} IS NULL OR {clean} IS NOT NULL)"))
    return e


# ---------------------------------------------------------------------------
# SQL rendering
# ---------------------------------------------------------------------------

def render_sql(plan: Plan, opts) -> str:
    q = opts.quote
    src_fqn = qualify(plan.src_db, plan.src_schema, plan.src_table, q)
    tgt_fqn = qualify(plan.tgt_db, plan.tgt_schema, plan.tgt_table, q)

    insert_cols: List[str] = []
    outer_select: List[str] = []
    prep_select: List[str] = []              # layer 1: trim / normalise
    inner_select: List[str] = []             # layer 2: convert
    predicates: List[Tuple[str, str, str]] = []   # (column, rule, predicate)
    prep_idx = 0
    forced_notnull: List[str] = []

    for m in plan.mappings:
        tname = m.target.name
        tq = quote_ident(tname, q)

        if m.how == "current_timestamp":
            insert_cols.append(tq)
            outer_select.append(f"    CURRENT_TIMESTAMP()::{m.target.data_type}"
                                f"{'(6)' if m.target.data_type.startswith('TIMESTAMP') else ''}"
                                f"        AS {tq}")
            continue

        if m.source is None:
            if not m.target.nullable:
                raise RuntimeError(
                    f"{plan.tgt_table}.{tname} is NOT NULL but no source column was matched. "
                    f"Map it with --overrides, or the INSERT will abort at runtime.")
            if opts.skip_unmapped:
                continue
            insert_cols.append(tq)
            outer_select.append(f"    CAST(NULL AS {m.target.display_type})        AS {tq}")
            continue

        is_key = tname in plan.key_cols
        expr = build_expression(m.source, m.target, opts, is_key=is_key)
        insert_cols.append(tq)
        outer_select.append(f"    s.{tq}")

        if expr.prep is not None:
            prep_idx += 1
            n_alias = f"N__{prep_idx}"
            prep_select.append(
                f"        {expr.prep} AS {n_alias}"
                f"   /* {m.source.name} -> {tname} */")
            value_ref = f"p.{n_alias}"
        else:
            value_ref = expr.sql if "{v}" not in expr.sql else expr.sql

        comment = (f"/* {tname:<28} <- {m.source.name:<28} "
                   f"{m.source.display_type} -> {m.target.display_type}"
                   f"{'  [' + m.how + ']' if m.how not in ('exact',) else ''} */")
        body = expr.sql.replace("{v}", value_ref).replace("src.", "p.")
        inner_select.append(f"        {comment}\n        {body} AS {tq}")

        clean_ref = f"s.{tq}"
        raw_ref = None
        if expr.needs_raw:
            raw_alias = f"RAW__{prep_idx}" if expr.prep is not None else None
            if raw_alias:
                inner_select.append(f"        {value_ref} AS {raw_alias}")
                raw_ref = f"s.{raw_alias}"
        for label, chk in expr.checks:
            # Plain replacement, not str.format: the shape regexes contain
            # braces such as [0-9]{4} that format() would try to interpret.
            pred = chk.replace("{raw}", raw_ref or "NULL").replace("{clean}", clean_ref)
            predicates.append((tname, label, pred))

        # A blank string has already become NULL in layer 1, so this one rule
        # covers both '' and a genuine NULL arriving in a column that cannot
        # take one. Key columns are treated as NOT NULL even when the DDL
        # allows NULLs, because a NULL key is never usable data.
        if ((not m.target.nullable or is_key) and not opts.no_notnull_check
                and not expr.fills_null):
            predicates.append((tname, "KEY" if is_key else "NOTNULL",
                               f"{clean_ref} IS NOT NULL"))
            if not is_key:
                forced_notnull.append(tname)

    # ---- dedupe support: pick the column that decides which duplicate wins ----
    dedupe_order = None
    if opts.dedupe and plan.key_cols:
        src_names = {c.name.upper(): c.name for c in plan.src_columns}
        candidates = ([opts.dedupe_order] if opts.dedupe_order else []) + [
            "ICOE_OP_TS", "DP_UPDATE_DTTM", "DP_INSERT_DTTM",
            "AWS_EXTRACT_DTTM", "LAST_UPDT_TS"]
        for cand in candidates:
            if cand and cand.upper() in src_names:
                real = src_names[cand.upper()]
                inner_select.append(
                    f"        p.{quote_ident(real, q)} AS ORD__1"
                    f"   /* dedupe order */")
                dedupe_order = "s.ORD__1 DESC NULLS LAST"
                break
        if dedupe_order is None:
            plan.warnings.append(
                "--dedupe requested but no ordering column found; "
                "which duplicate survives is arbitrary. Pass --dedupe-order.")
            dedupe_order = "1"

    lines: List[str] = []
    a = lines.append

    a("/" + "*" * 76)
    a(f"  Target      : {tgt_fqn}")
    a(f"  Source      : {src_fqn}")
    a(f"  Generated   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} "
      f"by bronze_to_ods_loader.py")
    if opts.dbt:
        a("  Materialised: dbt incremental, merge on the unique_key below.")
        a("                Only new or changed rows are written - no truncate,")
        a("                no full reload.")
    a("")
    a("  Column mapping (target <- source):")
    for m in plan.mappings:
        if m.how == "current_timestamp":
            a(f"    {m.target.name:<30} <- CURRENT_TIMESTAMP()")
        elif m.source is None:
            a(f"    {m.target.name:<30} <- (none) -> NULL")
        else:
            note = f"  [{m.how}]" + (f" {m.note}" if m.note else "")
            a(f"    {m.target.name:<30} <- {m.source.name:<30}{note}")
    if plan.unused_source:
        a("")
        a("  Source columns not loaded:")
        for c, reason in plan.unused_source:
            a(f"    {c.name:<30} ({reason})")
    if plan.warnings:
        a("")
        a("  WARNINGS - review before running:")
        for w in plan.warnings:
            a(f"    ! {w}")
    a("")
    a("  Values rewritten before validation (layer 1)")
    a("    - whitespace trimmed (spaces, tabs, CR/LF)")
    if opts.blank_strings == "keep":
        a("    - string targets: a blank or whitespace-only value stays as '' and is")
        a("      loaded. In Snowflake '' is not NULL, so it satisfies a NOT NULL")
        a("      column - this matches what the current PROD pipeline writes.")
    else:
        a("    - string targets: blank or whitespace-only -> NULL")
    a("    - numeric / date targets: blank -> NULL (they cannot hold '')")
    if opts.notnull_strings == "blank":
        a("    - a real NULL arriving in a NOT NULL string column is loaded as ''")
        a("      rather than dropping the row (never applied to key columns)")
    if opts.null_tokens:
        a("    - treated as NULL in non-string columns: " + ", ".join(opts.null_tokens))
    if not opts.no_numeric_normalise:
        a("    - numeric: currency symbol and thousand separators removed,")
        a("      (123.45) read as -123.45   [--no-numeric-normalise to reject instead]")
    else:
        a("    - numeric: nothing rewritten, values must already be clean numbers")
    a("    - dates/timestamps: nothing rewritten beyond the trim")
    a("")
    a("  Values validated and rejected, never repaired (WHERE clause)")
    a("    - numeric: a REGEXP_LIKE gate; anything that is not a clean number")
    a("      is filtered out rather than coerced")
    a("    - date/timestamp: a REGEXP_LIKE gate checks the value matches")
    a("      one of the accepted layouts, then TRY_TO_* over that format list:")
    a("        " + ", ".join(DATE_FORMATS if not any(
        m.target.family == "TS" for m in plan.mappings)
        else list(TIMESTAMP_FORMATS) + list(DATE_FORMATS)))
    if opts.allow_auto_date:
        a("      AUTO parsing is enabled - it reads all-digit strings as epoch seconds")
    a("    - strings longer than the target: "
      f"{'truncated with LEFT()' if opts.on_overflow == 'truncate' else 'row rejected'}")
    a("")
    a(f"  Mode        : {opts.mode}")
    a({"keys": "                only a NULL/blank key drops a row; "
               "bad values elsewhere land as NULL",
       "standard": "                a NULL/blank key, a bad number or a bad date drops "
                   "the row;\n                other problems land as NULL",
       "strict": "                anything questionable drops the row; "
                 "no value is repaired"}[opts.mode])
    a("")
    if forced_notnull:
        a("  These columns are declared NOT NULL in the target but are not keys, so a")
        a("  NULL still drops the row - Snowflake would otherwise abort the whole")
        a("  insert. Fix the source, or ALTER the column to allow NULLs:")
        a("    " + ", ".join(forced_notnull))
        a("")
    if plan.key_cols:
        a(f"  Key columns : {', '.join(plan.key_cols)}")
        a("    Snowflake does not enforce PRIMARY KEY, so a duplicate or NULL key")
        a("    will NOT abort the insert - it just lands in the table. Blank and")
        a("    NULL keys are rejected below"
          + ("; duplicates are collapsed by the QUALIFY." if opts.dedupe
             else ". Duplicates are NOT removed (use --dedupe)."))
        a("")
    a("  Rows dropped by the WHERE clause")
    for rule in ["SHAPE", "CAST", "RANGE", "LEN", "ROUND", "NOTNULL", "KEY"]:
        cols_hit = sorted({c for c, r, _ in predicates if r == rule})
        if cols_hit:
            a(f"    {rule:<8} {RULE_TEXT[rule]}")
            a(f"             {', '.join(cols_hit)}")
    if not predicates:
        a("    (none - every source column already matches its target type)")
    a("")
    a(f"  Run {plan.tgt_table.upper()}.reject_check.sql first for the counts per rule.")
    a("*" + "*" * 75 + "/")
    a("")

    cte_name = f"{plan.tgt_table.upper()}_SQ"
    if opts.dbt:
        if not plan.key_cols:
            raise RuntimeError(
                f"{plan.tgt_table}: --dbt needs a unique_key but no primary key was "
                "found on the target. Pass --key-cols COL1 COL2, or declare the PK "
                "on the table.")
        keys_literal = ", ".join(f"'{k}'" for k in plan.key_cols)
        a("{{ config(")
        a(f"    database='{plan.tgt_db}',")
        a(f"    schema='{plan.tgt_schema}',")
        a("    materialized='incremental',")
        a(f"    unique_key=[{keys_literal}],")
        a("    incremental_strategy='merge',")
        a("    full_refresh=false,")
        a("    pre_hook=[")
        a(f"        log_model_start(this, '{plan.tgt_table.upper()}{opts.dbt_hook_suffix}')")
        a("    ],")
        a("    post_hook=[")
        a(f"        log_model_end(this, '{plan.tgt_table.upper()}{opts.dbt_hook_suffix}')")
        a("    ]")
        a(") }}")
        a("")
        a(f"WITH {cte_name} AS (")
        a("SELECT")
    else:
        if opts.atomic:
            a("BEGIN TRANSACTION;")
            a("")
            a(f"DELETE FROM {tgt_fqn};      -- DELETE (not TRUNCATE) so the load stays in one transaction")
        else:
            a(f"TRUNCATE TABLE {tgt_fqn};")
        a("")

        a(f"INSERT INTO {tgt_fqn} (")
        a(",\n".join(f"    {c}" for c in insert_cols))
        a(")")
        a("SELECT")
    a(",\n".join(outer_select))
    src_ref = src_fqn
    if opts.dbt:
        source_name = (opts.dbt_source
                       or f"{plan.src_db}_{plan.src_schema}".upper())
        src_ref = "{{ source('%s', '%s') }}" % (source_name, plan.src_table.upper())
    a("FROM (")
    a("    /* layer 2: convert each normalised value to the target type */")
    a("    SELECT")
    a(",\n".join(inner_select))
    a("    FROM (")
    a("        /* layer 1: trim; %s; blank -> NULL for numeric/date targets */"
      % ("blanks kept as '' for string targets" if opts.blank_strings == "keep"
         else "blank -> NULL everywhere"))
    a("        SELECT")
    a("            src.*" + ("," if prep_select else ""))
    a(",\n".join("    " + line for line in prep_select))
    a(f"        FROM {src_ref} src" + (f"   -- {src_fqn}" if opts.dbt else ""))
    if opts.source_filter:
        a(f"        WHERE {opts.source_filter}")
    a("    ) p")
    a(") s")
    if predicates:
        a("WHERE 1 = 1")
        last_col = None
        for col, label, pred in predicates:
            if col != last_col:
                a(f"    /* {col} */")
                last_col = col
            a(f"    AND {pred}{'' if '/*' in pred else '   /* ' + RULE_TEXT[label] + ' */'}")
    if dedupe_order:
        key_refs = ", ".join(f"s.{quote_ident(k, q)}" for k in plan.key_cols)
        a(f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {key_refs}"
          f" ORDER BY {dedupe_order}) = 1")

    if opts.dbt:
        a(")")
        a("")
        _render_dbt_tail(a, plan, opts, cte_name, insert_cols, q)
    else:
        a(";")
        a("")
        if opts.atomic:
            a("COMMIT;")
            a("")

    # Diagnostics: how many rows were dropped and why.
    a("/* ---------------------------------------------------------------")
    if opts.dbt:
        a("   Run it:   dbt run --select %s" % plan.tgt_table.lower())
        a("   Merges only the rows that are new or whose non-key values changed.")
        a("   The target table is never dropped or recreated: full_refresh=false")
        a("   blocks --full-refresh, and the join to {{ this }} means the model")
        a("   errors out if the table is missing instead of creating one.")
    else:
        a("   Row-count check")
        a(f"   SELECT (SELECT COUNT(*) FROM {src_fqn}) AS src_rows,")
        a(f"          (SELECT COUNT(*) FROM {tgt_fqn}) AS tgt_rows;")
    if predicates:
        a("")
        a(f"   Run {plan.tgt_table.upper()}.reject_check.sql first to see how many")
        a("   rows each rule drops and why.")
    a("   --------------------------------------------------------------- */")
    a("")

    reject_sql = render_reject_check(plan, opts, inner_select, prep_select,
                                     predicates, src_fqn, tgt_fqn)
    return "\n".join(lines), reject_sql


def _render_dbt_tail(a, plan, opts, cte_name, insert_cols, q) -> None:
    """Final SELECT: only rows that are new or actually changed."""
    now_cols = {c.upper() for c in opts.now_cols}
    key_set = set(plan.key_cols)
    # Columns worth comparing: not a key, not a load-generated audit column.
    compare = [m.target.name.upper() for m in plan.mappings
               if m.target.name.upper() not in key_set
               and m.target.name.upper() not in now_cols]

    a("SELECT")
    a(",\n".join(f"    SRC.{c}" for c in insert_cols))
    a(f"FROM {cte_name} SRC")
    a("")
    a("-- Compare against what is already in the target and keep only the rows")
    a("-- that are new or whose values changed. No is_incremental() guard: the")
    a("-- target always exists, and if it ever does not this fails loudly rather")
    a("-- than letting dbt create the table with its own inferred DDL.")
    a("LEFT JOIN {{ this }} TGT")
    joins = [f"SRC.{k} = TGT.{k}" for k in plan.key_cols]
    a("    ON  " + "\n    AND ".join(joins))
    a("WHERE")
    a(f"    TGT.{plan.key_cols[0]} IS NULL   /* new row - no match in the target */")
    if compare:
        a("    OR (")
        # DECODE treats NULL as equal to NULL, unlike =, so no NVL wrapper needed.
        conds = [f"DECODE(SRC.{c}, TGT.{c}, 1, 0) = 0" for c in compare]
        a("        " + "\n        OR ".join(conds))
        a("    )")
    a("")


def render_reject_check(plan, opts, inner_select, prep_select, predicates,
                        src_fqn, tgt_fqn) -> Optional[str]:
    """A single query counting, per rule, how many source rows the load drops."""
    if not predicates:
        return None
    lines: List[str] = []
    a = lines.append
    a("/" + "*" * 76)
    a(f"  Reject check for {tgt_fqn}")
    a(f"  Source           {src_fqn}")
    a(f"  Generated        {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    a("")
    a("  Run this BEFORE the load. Every BAD_* column counts the source rows that")
    a("  the corresponding rule in the load script will exclude. TOTAL_REJECTED is")
    a("  the number of rows that will not reach the target.")
    a("*" + "*" * 75 + "/")
    a("")
    a("SELECT")
    a("    COUNT(*) AS SRC_ROWS,")

    all_preds = []
    for col, label, pred in predicates:
        clean = pred.split("/*")[0].strip()
        all_preds.append(clean)
        a(f"    COUNT_IF(NOT ({clean})) AS BAD_{col}__{label},"
          f"   /* {RULE_TEXT[label]} */")
    if plan.key_cols:
        keyexpr = " || '|' || ".join(
            f"COALESCE(TO_VARCHAR(s.{quote_ident(k, opts.quote)}), '~')"
            for k in plan.key_cols)
        a(f"    COUNT(*) - COUNT(DISTINCT {keyexpr}) AS DUPLICATE_KEY_ROWS,"
          "   /* same key more than once - Snowflake will NOT reject these */")
    combined = " AND ".join(f"({p})" for p in all_preds)
    a(f"    COUNT_IF(NOT ({combined})) AS TOTAL_REJECTED,")
    a(f"    COUNT_IF({combined}) AS ROWS_TO_LOAD")
    a("FROM (")
    a("    SELECT")
    a("        p.*,   /* original source columns, so rejected rows can be read */")
    a(",\n".join(inner_select))
    a("    FROM (")
    a("        SELECT")
    a("            src.*" + ("," if prep_select else ""))
    a(",\n".join("    " + line for line in prep_select))
    a(f"        FROM {src_fqn} src")
    if opts.source_filter:
        a(f"        WHERE {opts.source_filter}")
    a("    ) p")
    a(") s;")
    a("")
    a("/* To read the offending rows for one rule, replace the SELECT list above")
    a("   with * and filter on that single rule - the original source columns are")
    a("   carried through, so you see the bad value next to the whole record:")
    a(f"       SELECT * FROM ( ... ) s WHERE NOT ({all_preds[0]}) LIMIT 100;")
    a("*/")
    a("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Connections
# ---------------------------------------------------------------------------

class SessionManager:
    """Holds one connection per environment, reconnecting when it goes stale."""

    def __init__(self, config: dict, ttl_seconds: int = 3600):
        self.config = config
        self.ttl = ttl_seconds
        self._conns: Dict[str, object] = {}
        self._opened: Dict[str, float] = {}

    def get(self, env: str):
        env = env.upper()
        conn = self._conns.get(env)
        if conn is not None:
            age = time.time() - self._opened[env]
            if age < self.ttl and self._alive(conn):
                return conn
            self._close(env)
        return self._open(env)

    def _open(self, env: str):
        if snowflake is None:
            raise RuntimeError(
                "snowflake-connector-python is not installed. "
                "pip install snowflake-connector-python")
        if env not in self.config:
            raise RuntimeError(
                f"Environment {env} not in config. Available: {', '.join(self.config)}")
        params = dict(self.config[env])
        params.setdefault("client_session_keep_alive", True)
        params.setdefault("application", "bronze_to_ods_loader")
        log(f"{Colour.CYAN}Connecting to {env} "
            f"({params.get('account')}) ...{Colour.RESET}")
        conn = snowflake.connector.connect(**params)
        self._conns[env] = conn
        self._opened[env] = time.time()
        ok(f"Connected to {env}.")
        return conn

    @staticmethod
    def _alive(conn) -> bool:
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1")
            cur.fetchone()
            cur.close()
            return True
        except Exception:
            return False

    def heartbeat(self) -> None:
        for env in list(self._conns):
            if not self._alive(self._conns[env]):
                warn(f"Session for {env} dropped - reconnecting.")
                self._close(env)
                self._open(env)

    def _close(self, env: str) -> None:
        try:
            self._conns[env].close()
        except Exception:
            pass
        self._conns.pop(env, None)
        self._opened.pop(env, None)

    def close_all(self) -> None:
        for env in list(self._conns):
            self._close(env)


def load_config(path: Optional[str]) -> dict:
    """Load the connection config, reporting every place that was checked."""
    candidates = [os.path.abspath(path)] if path else default_config_paths()
    for candidate in candidates:
        if os.path.exists(candidate):
            try:
                with open(candidate, "r", encoding="utf-8") as fh:
                    cfg = json.load(fh)
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"{candidate} is not valid JSON: {exc}") from exc
            if not isinstance(cfg, dict) or not cfg:
                raise RuntimeError(
                    f"{candidate} must be an object keyed by environment name, "
                    "e.g. {\"PROD\": { ... }}")
            log(f"{Colour.CYAN}Config: {candidate}{Colour.RESET}")
            return cfg
    raise RuntimeError(
        "Config file not found. Checked:\n  " + "\n  ".join(candidates) +
        f"\nCreate {CONFIG_FILENAME} in one of those folders, or pass --config "
        f"<path>, or set {CONFIG_ENV_VAR}.")


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def process_pair(src_fqn: str, tgt_fqn: str, src_meta: MetaReader,
                 tgt_meta: MetaReader, opts, sessions: Optional[SessionManager]) -> str:
    s_db, s_sch, s_tab = split_table(src_fqn)
    t_db, t_sch, t_tab = split_table(tgt_fqn)

    src_cols = src_meta.columns(s_db, s_sch, s_tab)
    tgt_cols = tgt_meta.columns(t_db, t_sch, t_tab)

    key_cols = []
    if not opts.no_key_detect:
        try:
            key_cols = tgt_meta.primary_key(t_db, t_sch, t_tab)
        except Exception:
            key_cols = []
    plan = build_plan(src_fqn, tgt_fqn, src_cols, tgt_cols, opts, key_cols)
    sql, reject_sql = render_sql(plan, opts)

    os.makedirs(opts.out, exist_ok=True)
    out_path = os.path.join(opts.out, f"{t_tab.upper()}.sql")
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(sql)

    if reject_sql and not opts.no_reject_check:
        chk_path = os.path.join(opts.out, f"{t_tab.upper()}.reject_check.sql")
        with open(chk_path, "w", encoding="utf-8") as fh:
            fh.write(reject_sql)

    mapped = sum(1 for m in plan.mappings if m.source is not None)
    ok(f"  wrote {out_path}  ({mapped}/{len(plan.mappings)} target columns mapped)")
    for w in plan.warnings:
        warn(f"    ! {w}")

    if opts.execute and sessions is not None:
        execute_sql(sql, sessions.get(opts.target_env), tgt_fqn)
    return out_path


def execute_sql(sql: str, conn, tgt_fqn: str) -> None:
    statements = [s.strip() for s in split_statements(sql) if s.strip()]
    cur = conn.cursor()
    try:
        for stmt in statements:
            cur.execute(stmt)
            if stmt.upper().startswith("INSERT"):
                rows = cur.rowcount
                ok(f"    inserted {rows} rows into {tgt_fqn}")
    finally:
        cur.close()


def split_statements(sql: str) -> List[str]:
    """Strip comments and split on ';' (no ';' inside our generated literals)."""
    no_block = re.sub(r"/\*.*?\*/", "", sql, flags=re.S)
    no_line = re.sub(r"--[^\n]*", "", no_block)
    return no_line.split(";")


def read_pairs_csv(path: str) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        sample = fh.read(4096)
        fh.seek(0)
        has_header = "source" in sample.split("\n")[0].lower()
        reader = csv.reader(fh)
        for i, row in enumerate(reader):
            row = [c.strip() for c in row if c is not None and c.strip() != ""]
            if not row or row[0].startswith("#"):
                continue
            if i == 0 and has_header:
                continue
            if len(row) < 2:
                warn(f"  skipping malformed line {i + 1} in {path}: {row}")
                continue
            pairs.append((row[0], row[1]))
    return pairs


def run_batch(pairs: List[Tuple[str, str]], src_meta, tgt_meta, opts, sessions) -> Tuple[int, int]:
    good = bad = 0
    for idx, (s, t) in enumerate(pairs, start=1):
        log(f"\n[{idx}/{len(pairs)}] {s}  ->  {t}")
        try:
            process_pair(s, t, src_meta, tgt_meta, opts, sessions)
            good += 1
        except Exception as exc:                        # keep going on failure
            bad += 1
            err(f"  FAILED {s} -> {t}: {exc}")
            if opts.traceback:
                traceback.print_exc()
    return good, bad


def _parse_command(base_argv: List[str], tokens: List[str]):
    """Re-parse a session command as if it were a fresh command line.

    Startup flags are replayed first, so anything not given on the line keeps
    the value it had at launch; later flags win in argparse, so the line
    overrides them.
    """
    try:
        return parse_args(base_argv + tokens, quiet=True)
    except ValueError as exc:
        warn(f"  {exc}")
        return None
    except SystemExit:
        return None


def interactive_session(src_meta, tgt_meta, opts, sessions) -> None:
    import shlex
    base_argv = [a for a in getattr(opts, "base_argv", []) if a != "--session"]
    deadline = time.time() + opts.session_ttl
    log(f"\n{Colour.CYAN}Session mode - connection stays open for "
        f"{opts.session_ttl // 60} minutes.{Colour.RESET}")
    log("  --source <t> --target <t> [--dbt --out <dir> --mode <m> ...]")
    log("  <source> <target>      shorthand for the above")
    log("  --pairs <file.csv>     run a pairs file   (or: csv <file.csv>)")
    log("  out <path>             change the output folder")
    log("  quit                   exit\n")

    while True:
        remaining = int(deadline - time.time())
        if remaining <= 0:
            warn("Session expired.")
            return
        try:
            line = input(f"[{remaining // 60}m left] > ").strip()
        except (EOFError, KeyboardInterrupt):
            log("")
            return
        if not line:
            continue
        if line.lower() in ("quit", "exit", "q"):
            return

        try:
            tokens = shlex.split(line)
        except ValueError as exc:
            warn(f"Could not read that line: {exc}")
            continue

        # Shorthands kept from the older prompt
        if tokens[0].lower() == "csv" and len(tokens) == 2:
            tokens = ["--pairs", tokens[1]]
        elif tokens[0].lower() == "out" and len(tokens) == 2:
            opts.out = tokens[1]
            base_argv = [a for a in base_argv]           # unchanged
            ok(f"Output folder is now {opts.out}")
            continue
        elif not tokens[0].startswith("-"):
            plain = [t for t in " ".join(tokens).replace(",", " ").split() if t]
            if len(plain) != 2:
                warn("Give: <source> <target>, or use --source ... --target ...")
                continue
            tokens = ["--source", plain[0], "--target", plain[1]]

        cmd = _parse_command(base_argv, tokens)
        if cmd is None:
            continue
        if cmd.env != opts.env:
            warn(f"--env cannot change mid-session (still {opts.env}); "
                 "quit and relaunch to switch environment.")
            cmd.env, cmd.target_env = opts.env, opts.target_env
        cmd.base_argv = base_argv

        pairs: List[Tuple[str, str]] = []
        try:
            if cmd.pairs:
                pairs.extend(read_pairs_csv(cmd.pairs))
            if cmd.source and cmd.target:
                pairs.append((cmd.source, cmd.target))
            elif bool(cmd.source) != bool(cmd.target):
                warn("--source and --target must be given together.")
                continue
            if not pairs:
                warn("Nothing to do - give --source/--target or --pairs.")
                continue
            sessions.heartbeat()
            good, bad = run_batch(pairs, src_meta, tgt_meta, cmd, sessions)
            if len(pairs) > 1 or bad:
                log(f"{good} generated, {bad} failed.")
        except Exception as exc:
            err(f"  FAILED: {exc}")
            if opts.traceback:
                traceback.print_exc()


class _QuietParser(argparse.ArgumentParser):
    """Raises instead of printing usage and exiting - used by session mode."""

    def error(self, message):
        raise ValueError(message)


def parse_args(argv=None, quiet=False):
    parser_cls = _QuietParser if quiet else argparse.ArgumentParser
    p = parser_cls(
        description="Generate cleansed TRUNCATE+INSERT scripts from Bronze into ODS/UTLDB.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--config", default=None,
                   help=f"Path to the connection config. Default: ${CONFIG_ENV_VAR}, "
                        f"then ./{CONFIG_FILENAME}, then the script's own folder")
    p.add_argument("--env", default="PROD", help="Environment key used for the source")
    p.add_argument("--target-env", default=None,
                   help="Environment for the target (defaults to --env)")
    p.add_argument("--source", help="Single source table DB.SCHEMA.TABLE")
    p.add_argument("--target", help="Single target table DB.SCHEMA.TABLE")
    p.add_argument("--pairs", help="CSV of source_table,target_table")
    p.add_argument("--out", default="./generated_sql", help="Output folder for .sql files")
    p.add_argument("--session", action="store_true",
                   help="Keep the session open and accept pairs interactively")
    p.add_argument("--session-ttl", type=int, default=3600,
                   help="Session lifetime in seconds")
    p.add_argument("--execute", action="store_true",
                   help="Also run the generated script against the target")
    p.add_argument("--overrides", help="JSON: {\"TARGET_TABLE\": {\"TGT_COL\": \"src_col\"}}")
    p.add_argument("--audit-cols", nargs="*", default=DEFAULT_AUDIT_COLUMNS,
                   help="Source audit columns to ignore")
    p.add_argument("--audit-prefixes", nargs="*", default=DEFAULT_AUDIT_PREFIXES,
                   help="Source column prefixes treated as audit")
    p.add_argument("--now-cols", nargs="*", default=DEFAULT_NOW_COLUMNS,
                   help="Target columns set to CURRENT_TIMESTAMP()")
    p.add_argument("--on-overflow", choices=["truncate", "reject"], default="truncate",
                   help="What to do when a string is longer than the target column")
    p.add_argument("--mode", choices=["keys", "standard", "strict"],
                   default="standard",
                   help="How much to reject. keys: only rows whose key column is "
                        "NULL/blank; bad values elsewhere land as NULL. standard: "
                        "also reject bad numerics and bad dates anywhere. strict: "
                        "reject everything questionable and stop repairing values.")
    p.add_argument("--strict", action="store_true",
                   help="Shorthand for --mode strict")
    p.add_argument("--blank-strings", choices=["keep", "null"], default="keep",
                   help="What a blank/whitespace-only value becomes in a STRING "
                        "target. keep: trimmed to '' and loaded, matching what "
                        "Snowflake PROD holds today. null: converted to NULL. "
                        "Numeric and date targets always use NULL - they cannot "
                        "hold ''. Forced to null by --mode strict.")
    p.add_argument("--notnull-strings", choices=["reject", "blank"], default=None,
                   help="Override how a genuine NULL in a NOT NULL string column is "
                        "handled. Normally set by --mode: blank for keys/standard, "
                        "reject for strict. Never applied to key columns.")
    p.add_argument("--no-numeric-normalise", action="store_true",
                   help="Do not strip $ or thousand separators and do not read "
                        "(123) as -123; such values are rejected instead")
    p.add_argument("--null-tokens", nargs="*", default=DEFAULT_NULL_TOKENS,
                   help="Literal strings treated as NULL in non-string target columns "
                        "(pass with no values to disable)")
    p.add_argument("--reject-rounding", action="store_true",
                   help="Reject rows whose numeric value would be rounded to fit the target scale")
    p.add_argument("--strip-control", action="store_true",
                   help="Remove control characters from strings instead of keeping them")
    p.add_argument("--allow-auto-date", action="store_true",
                   help="Also try Snowflake's AUTO date parser as a last resort "
                        "(warning: it reads all-digit strings as epoch seconds)")
    p.add_argument("--date-formats", nargs="*", default=None,
                   help="Override the TRY_TO_DATE format list (order matters)")
    p.add_argument("--timestamp-formats", nargs="*", default=None,
                   help="Override the TRY_TO_TIMESTAMP format list (order matters)")
    p.add_argument("--min-year", type=int, default=1900, help="Lowest accepted year")
    p.add_argument("--max-year", type=int, default=9999, help="Highest accepted year")
    p.add_argument("--fuzzy-cutoff", type=float, default=0.86,
                   help="Similarity threshold for fuzzy name matching")
    p.add_argument("--no-fuzzy", action="store_true", help="Disable fuzzy name matching")
    p.add_argument("--no-positional", action="store_true",
                   help="Disable positional fallback matching")
    p.add_argument("--no-reject-check", action="store_true",
                   help="Do not write the companion <TARGET>.reject_check.sql file")
    p.add_argument("--key-cols", nargs="*", default=[],
                   help="Extra target columns to treat as keys (added to the detected PK)")
    p.add_argument("--no-key-detect", action="store_true",
                   help="Do not read the target primary key from Snowflake")
    p.add_argument("--dedupe", action="store_true",
                   help="Keep one row per key using QUALIFY ROW_NUMBER()")
    p.add_argument("--dedupe-order",
                   help="Source column deciding which duplicate wins (latest first)")
    p.add_argument("--no-notnull-check", action="store_true",
                   help="Do not drop rows that are NULL in a NOT NULL target column")
    p.add_argument("--skip-unmapped", action="store_true",
                   help="Leave unmapped target columns out of the INSERT column list")
    p.add_argument("--source-filter", default=None,
                   help="Extra WHERE applied to the source, e.g. \"icoe_op_type <> 'D'\"")
    p.add_argument("--dbt", action="store_true",
                   help="Emit a dbt incremental merge model instead of TRUNCATE + "
                        "INSERT. Only new or changed rows are written.")
    p.add_argument("--dbt-source",
                   help="dbt source name for the bronze table. "
                        "Default: <SOURCE_DB>_<SOURCE_SCHEMA> uppercased")
    p.add_argument("--dbt-hook-suffix", default="_AYS",
                   help="Suffix appended to the table name in the pre/post hooks")
    p.add_argument("--atomic", action="store_true",
                   help="Use DELETE inside a transaction instead of TRUNCATE")
    p.add_argument("--quote", choices=["auto", "always", "never"], default="auto",
                   help="Identifier quoting style")
    p.add_argument("--no-colour", action="store_true", help="Plain terminal output")
    p.add_argument("--traceback", action="store_true", help="Print full tracebacks")
    opts = p.parse_args(argv)

    if opts.no_colour or not sys.stdout.isatty():
        Colour.off()
    if opts.strict:
        opts.mode = "strict"
    if opts.mode == "strict":
        opts.no_numeric_normalise = True
        opts.blank_strings = "null"
        opts.null_tokens = []
        opts.on_overflow = "reject"
    # One decision, not three: the mode sets this unless told otherwise.
    if opts.notnull_strings is None:
        opts.notnull_strings = "reject" if opts.mode == "strict" else "blank"

    global DATE_FORMATS, TIMESTAMP_FORMATS
    if opts.date_formats:
        DATE_FORMATS = list(opts.date_formats)
    if opts.timestamp_formats:
        TIMESTAMP_FORMATS = list(opts.timestamp_formats)
    opts.target_env = (opts.target_env or opts.env).upper()
    opts.env = opts.env.upper()

    # --overrides is a path on the command line; turn it into a dict
    opts.overrides_file = opts.overrides
    opts.overrides = {}
    if opts.overrides_file:
        with open(opts.overrides_file, "r", encoding="utf-8") as fh:
            opts.overrides = json.load(fh)
    return opts


def main(argv=None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    opts = parse_args(argv)
    opts.base_argv = raw_argv

    pairs: List[Tuple[str, str]] = []
    if opts.pairs:
        pairs = read_pairs_csv(opts.pairs)
        log(f"Loaded {len(pairs)} pair(s) from {opts.pairs}")
    if opts.source and opts.target:
        pairs.append((opts.source, opts.target))
    if not pairs and not opts.session:
        err("Nothing to do: give --pairs, or --source/--target, or --session.")
        return 2

    if opts.execute and opts.env != opts.target_env:
        err("--execute needs the source and target in the same account "
            f"(got {opts.env} and {opts.target_env}). Generate the SQL and run it there instead.")
        return 2

    config = load_config(opts.config)
    sessions = SessionManager(config, ttl_seconds=opts.session_ttl)
    src_meta = MetaReader(lambda: sessions.get(opts.env))
    tgt_meta = MetaReader(lambda: sessions.get(opts.target_env))

    rc = 0
    try:
        if pairs:
            good, bad = run_batch(pairs, src_meta, tgt_meta, opts, sessions)
            log("")
            ok(f"Generated {good} script(s) in {os.path.abspath(opts.out)}")
            if bad:
                err(f"{bad} pair(s) failed - see the messages above.")
                rc = 1
        if opts.session:
            # Authenticate before the prompt appears, so the SSO browser tab
            # opens at launch rather than on the first table.
            try:
                sessions.get(opts.env)
                if opts.target_env != opts.env:
                    sessions.get(opts.target_env)
            except Exception as exc:
                err(f"Could not connect to {opts.env}: {exc}")
                return 1
            interactive_session(src_meta, tgt_meta, opts, sessions)
    finally:
        sessions.close_all()
    return rc


if __name__ == "__main__":
    sys.exit(main())
