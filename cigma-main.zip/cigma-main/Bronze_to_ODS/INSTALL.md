# bronze_to_ods_loader — install and setup

Generates cleansed `TRUNCATE` + `INSERT` scripts that load Bronze tables into
their ODS/UTLDB targets, one `.sql` file per target table.

---

## 1. What you need

| | |
|---|---|
| Python | 3.9 – 3.12 (3.13 support depends on your connector version) |
| Packages | `snowflake-connector-python` only — everything else is standard library |
| Network | reach to your Snowflake PrivateLink host, plus PyPI for the one-time install |
| Snowflake | a role that can read `INFORMATION_SCHEMA.COLUMNS` on both the Bronze and the target database |

Check your Python first:

```bash
python --version        # Windows
python3 --version       # macOS / Linux
```

---

## 2. Folder layout

Put all four files in the same folder. The script looks for
`snowflake_config.json` next to itself by default.

```
bronze_to_ods/
├── bronze_to_ods_loader.py     the script
├── snowflake_config.json       connection details  (never commit this)
├── requirements.txt
├── table_pairs.csv             your source,target list
└── generated_sql/              created on first run
```

---

## 3. Create the virtual environment

**Windows (PowerShell)**

```powershell
cd C:\path\to\bronze_to_ods
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks the activate script:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Windows (cmd)**

```cmd
python -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
```

**macOS / Linux**

```bash
cd /path/to/bronze_to_ods
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Behind a corporate proxy, either set the proxy variables first:

```bash
export HTTPS_PROXY=http://proxy.corp.aepsc.com:8080
export HTTP_PROXY=http://proxy.corp.aepsc.com:8080
```

or install from your internal mirror:

```bash
pip install -r requirements.txt --index-url https://<internal-mirror>/simple
```

Confirm the install:

```bash
python -c "import snowflake.connector as sc; print(sc.__version__)"
python bronze_to_ods_loader.py --help
```

---

## 4. The config file

### Where the script looks for it

You do **not** need to pass it on the command line. With no `--config`, the
script checks these in order and uses the first one it finds:

1. `$BRONZE_ODS_CONFIG` — an explicit path in the environment
2. `./snowflake_config.json` — the folder you are running from
3. `<script folder>/snowflake_config.json` — beside `bronze_to_ods_loader.py`

The name matters: it must be exactly `snowflake_config.json` for 2 and 3.
Any other name needs `--config`:

```bash
python bronze_to_ods_loader.py --config ./conf/sf_prod.json --env PROD ...
```

The script prints which file it loaded on every run, so there is no ambiguity
about which credentials were used. If none is found it lists every path it
checked rather than just saying "not found".

Keeping the config beside the script (option 3) is the simplest setup — it
works no matter which folder you run from. Option 2 is useful when one team
shares the script but each person keeps their own connection details. Option 1
suits a scheduled job where the config lives outside the code folder.

### What goes in it

One block per environment; the block name is what you pass to `--env`.

```json
{
    "PROD": {
        "user": "s399089@corp.aepsc.com",
        "account": "americanelectricpower-dpprod",
        "host": "americanelectricpower-dpprod.privatelink.snowflakecomputing.com",
        "warehouse": "DEVELOPER_WH",
        "database": "CRPDB01",
        "schema": "TRIRADM",
        "role": "DP_DW_IT_DEVELOPER",
        "authenticator": "externalbrowser",
        "client_session_keep_alive": true
    }
}
```

| key | notes |
|---|---|
| `account` | account identifier, no `.snowflakecomputing.com` |
| `host` | required for PrivateLink; drop it on a public endpoint |
| `database` / `schema` | session defaults only — the script always uses fully qualified names, so these do not affect which tables it reads |
| `role` | must be able to read `INFORMATION_SCHEMA.COLUMNS` on both databases |
| `authenticator` | `externalbrowser` for SSO. Omit it and add `"password"` for a local/service account |
| `client_session_keep_alive` | leave `true`, especially for `--session` |

Anything valid for `snowflake.connector.connect()` can go in a block —
`passcode`, `private_key_file`, `token`, and so on are passed straight through.

**Two things to check in the sample config**

The `DEV` block originally had neither `authenticator` nor `password`, which
fails at connect time. I set it to `externalbrowser`; switch it to a password
or key-pair if that account is not SSO.

Bronze (`BRONZE_CUST_CONF_PROD`) and the target (`UTLDB01`) must be in the
**same account** for a single run, since one query reads across both. If they
are in different accounts, generate the SQL against the account that holds
Bronze and run the file in the other one. `--execute` refuses a cross-account
run rather than failing halfway.

**Keep it out of source control**

```bash
echo "snowflake_config.json" >> .gitignore
echo ".venv/" >> .gitignore
chmod 600 snowflake_config.json      # macOS / Linux
```

If you ever add a password to this file, use a key-pair or an environment
variable instead — a plaintext password in a repo folder is the usual way
these leak.

---

## 5. First run

```bash
python bronze_to_ods_loader.py --env PROD \
    --source BRONZE_CUST_CONF_PROD.bronze_macss.mcs_web_alert_hdr \
    --target UTLDB01.UTLUSER.ODS_MCS_WEB_ALERT_HDR \
    --out ./generated_sql
```

With `externalbrowser` a browser tab opens for SSO. With the
`secure-local-storage` extra installed the token is cached, so later runs in
the same period reuse it instead of reopening the tab.

You get two files per table:

- `ODS_MCS_WEB_ALERT_HDR.sql` — the load
- `ODS_MCS_WEB_ALERT_HDR.reject_check.sql` — run this **first**; it counts how
  many rows each rule would drop, and why

Batch mode:

```bash
python bronze_to_ods_loader.py --env PROD --pairs table_pairs.csv --out ./generated_sql
```

Session mode keeps one authenticated connection open so you are not sent to the
browser for every table:

```bash
python bronze_to_ods_loader.py --env PROD --session
```

Authentication happens straight away, before the prompt appears. At the prompt
you can type a full command line — any flag the script accepts works, and it
applies to that command only:

```
[59m left] > --source BRONZE_CUST_CONF.bronze_macss.mcs_web_alert_hdr --target UTLDB01.UTLUSER.ODS_MCS_WEB_ALERT_HDR --dbt --out ./models/ods
[58m left] > --pairs ./more_tables.csv --out ./generated_sql
[57m left] > BRONZE_CUST_CONF.bronze_macss.mcs_web_alert_dtl UTLDB01.UTLUSER.ODS_MCS_WEB_ALERT_DTL
[56m left] > quit
```

Flags you passed at launch stay in effect; anything on the line overrides them
for that command. `--env` is the exception — it cannot change mid-session,
since the connection is already open. A bad flag prints one line and leaves the
session running.

`table_pairs.csv`:

```csv
source_table,target_table
BRONZE_CUST_CONF_PROD.bronze_macss.mcs_web_alert_hdr,UTLDB01.UTLUSER.ODS_MCS_WEB_ALERT_HDR
BRONZE_CUST_CONF_PROD.bronze_macss.mcs_web_alert_dtl,UTLDB01.UTLUSER.ODS_MCS_WEB_ALERT_DTL
```

A failing pair prints the error and the run continues with the rest.

---

## 6. Flags you will actually reach for

| flag | why |
|---|---|
| `--mode keys` | reject **only** rows whose key column is NULL/blank; every other bad value lands as NULL |
| `--mode standard` | default — also reject bad numerics and bad dates anywhere in the row |
| `--mode strict` | reject everything questionable and stop repairing values (same as `--strict`) |
| `--blank-strings` / `--notnull-strings` | overrides only — `--mode` already sets both |
| `--on-overflow reject` | drop over-length strings instead of `LEFT()`-truncating them |
| `--dedupe` | one row per key via `QUALIFY` — Snowflake does **not** enforce PK, so CDC duplicates load silently without this |
| `--source-filter "icoe_op_type <> 'D'"` | skip CDC delete records |
| `--date-formats` | set the real format order for a source; the default excludes `DD/MM/YYYY` because it collides with `MM/DD/YYYY` |
| `--overrides map.json` | force a column mapping the matcher got wrong |
| `--dbt` | emit a dbt incremental merge model instead of TRUNCATE + INSERT — only new and changed rows are written |
| `--dbt-source` | dbt source name for the bronze table (default `<SRC_DB>_<SRC_SCHEMA>` uppercased) |
| `--atomic` | `DELETE` inside a transaction instead of `TRUNCATE`, so a failed load does not leave the target empty |
| `--execute` | run the generated SQL immediately (same account only) |

---

## 6a. Choosing a mode

`--mode` decides how much gets thrown away. Start loose, tighten once you know
the data.

| rule | `keys` | `standard` (default) | `strict` |
|---|---|---|---|
| key column NULL/blank | reject | reject | reject |
| non-numeric into a numeric column | NULL | **reject** | reject |
| bad date / timestamp format | NULL | **reject** | reject |
| year outside `--min-year`/`--max-year` | NULL | reject (string sources only) | reject (all) |
| unrecognised boolean flag | NULL | NULL | reject |
| string longer than the target | truncate | truncate | reject |
| value would be rounded | allow | allow | reject |
| currency / `1,234` / `(500)` cleanup | on | on | off |
| `N/A` → NULL | on | on | off |

### Blank strings and NOT NULL columns

In Snowflake `''` is a real zero-length string, **not** NULL — unlike Oracle.
A NOT NULL VARCHAR column accepts `''` happily, which is why the existing PROD
ODS is full of them.

So for **string** targets a blank stays `''` (trimmed) and loads. Only numeric
and date targets turn blank into NULL, because those types cannot hold `''`.
`--blank-strings null` restores the old behaviour; `--mode strict` sets it.

A column declared `NOT NULL` that is **not** a key still rejects the row when
the source value is a genuine NULL, because Snowflake would abort the whole
insert otherwise. Two ways out:

- `--notnull-strings blank` — load `''` instead of dropping the row. Matches
  what PROD holds today. Never applied to key columns.
- fix the source, or `ALTER` the column to allow NULLs.

Either way the script lists those columns by name at the top of the generated
file, so you always know which ones are costing you rows.

If a run rejects far more than expected, run the `.reject_check.sql` file
first. The per-rule counts tell you whether it is one bad column or the whole
table — a huge `BAD_<col>__SHAPE` usually means the source uses a date format
that is not in the list, which `--date-formats` fixes.

## 6b. dbt models

`--dbt` swaps the truncate-and-reload script for an incremental merge model.
Everything above it — column matching, cleansing, the rejection rules, the
mode — is unchanged; only the write strategy differs.

```bash
python bronze_to_ods_loader.py --env PROD --pairs table_pairs.csv \
    --out ./models/ods --dbt
```

The generated model is:

1. a `config()` block — `materialized='incremental'`,
   `incremental_strategy='merge'`, `unique_key` from the target's primary key,
   `full_refresh=false`, and the `log_model_start` / `log_model_end` hooks
2. the cleansing query as a CTE named `<TARGET_TABLE>_SQ`, reading from
   `{{ source(...) }}`
3. a final `SELECT` that joins the CTE to `{{ this }}` and keeps only rows
   that are new or whose non-key values changed

There is no `{% if is_incremental() %}` guard, deliberately. The ODS table
already exists and must never be dropped or recreated. With the guard, a
missing target would make dbt run `CREATE TABLE AS SELECT` and build the table
with its own inferred datatypes — no `VARCHAR(10)`, no NOT NULL, no PK. Without
it, the join to `{{ this }}` simply fails with "object does not exist", which is
the outcome you want. `full_refresh=false` blocks `dbt run --full-refresh` on
top of that.

The comparison uses `DECODE(SRC.COL, TGT.COL, 1, 0) = 0`, which treats NULL as
equal to NULL — unlike `=`, which would mark every NULL row as changed on every
run. Key columns and `EDW_LAST_UPDT_TS` are excluded from the comparison: the
timestamp changes on every run, so including it would make every row look
changed.

`--dbt` requires a unique key. If the target has no declared primary key, pass
`--key-cols COL1 COL2` or the run fails with a clear message rather than
producing a model that merges on nothing.

## 7. Troubleshooting

| symptom | cause / fix |
|---|---|
| `No module named 'snowflake'` | venv not activated, or installed outside it. Re-activate and reinstall. |
| `Config file not found` | the message lists every path checked. Either drop `snowflake_config.json` in one of them or pass `--config`. |
| Wrong environment connected | the run prints `Config: <path>` on the first line — check it picked the file you expected, not one in your current folder |
| `Could not find a version that satisfies...` | proxy or mirror not set — see section 3 |
| Browser tab never opens | headless or locked-down desktop; use key-pair auth instead of `externalbrowser` |
| `250001 Could not connect` | wrong `host` for PrivateLink, or VPN not connected |
| `No columns found for DB.SCHEMA.TABLE` | name is wrong, or the role cannot see it. Bronze names are often lowercase and case-sensitive — copy them exactly from `INFORMATION_SCHEMA`. |
| `... is NOT NULL but no source column was matched` | intentional. The insert would abort at runtime; map the column with `--overrides`. |
| Fuzzy/positional warnings in the header | the matcher guessed. Check those columns before running the SQL. |
| Session expires mid-batch | `--session-ttl` in seconds, default 3600; the script reconnects on a dead connection |

---

## 8. Before running generated SQL in production

1. Run the `.reject_check.sql` file and look at `TOTAL_REJECTED`,
   `ROWS_TO_LOAD` and `DUPLICATE_KEY_ROWS`.
2. Read the mapping block at the top of the `.sql` file. Anything marked
   `[fuzzy]` or `[positional]` was a guess and says `VERIFY`.
3. Confirm the cleansing choices in the header suit the table — especially
   string truncation and whether duplicates need `--dedupe`.
4. The script `TRUNCATE`s the target. Snowflake commits DDL, so a failed
   insert leaves the table empty unless you used `--atomic`. Check Time Travel
   is available on the target before the first production run.
