-- =====================================================================
-- IS END_DATE FROZEN?  -  the one thing JOB_EXECUTION cannot tell us
-- =====================================================================
-- CXNADM_JOB_EXECUTION records that a model ran and how long it took. It
-- never records the WINDOW the model read. So the finding below is still
-- inferred: from the code (update_control_table sets only
-- START_DATE = END_DATE, and the two macros that do advance END_DATE have
-- no callers) and from duration as a stand-in for row counts.
--
-- CXNADM_JOB_CONTROL proves or kills it in one query.
--
-- THE PREDICTION, so it is falsifiable:
--   if END_DATE is frozen, then for every job that has run since its last
--   control refresh, START_DATE = END_DATE exactly, the window is 0
--   seconds wide, and END_DATE sits back on 24-25 Aug while
--   ROW_UPDATE_TIMESTAMP is recent - because the post-hook stamps
--   ROW_UPDATE_TIMESTAMP on every single run while never moving END_DATE.
--
--   A healthy table looks the opposite: END_DATE tracks the last run and
--   the window is roughly the gap between runs.
--
-- SELECT-only. UTLDB01 is the environment the run history came from -
-- swap to UTLDB01_PROD for prod.
-- =====================================================================


-- 1. The whole control table, with the diagnosis on each row.
SELECT
    JOB_NAME,
    AUTOSYS_JOB_NAME,
    START_DATE,
    END_DATE,
    PREV_START_DATE,
    PREV_END_DATE,
    ROW_UPDATE_TIMESTAMP,
    DATEDIFF('second', START_DATE, END_DATE)              AS WINDOW_SECONDS,
    DATEDIFF('hour', END_DATE, ROW_UPDATE_TIMESTAMP)      AS HOURS_END_DATE_IS_STALE,
    CASE
        WHEN START_DATE IS NULL OR END_DATE IS NULL
            THEN 'NULL WINDOW - model reads nothing at all'
        WHEN START_DATE =  END_DATE
            THEN 'EMPTY - START = END, this run loads zero rows'
        WHEN START_DATE >  END_DATE
            THEN 'INVERTED - should never happen'
        WHEN START_DATE = '2008-01-01 00:00:00.000'::TIMESTAMP
            THEN 'AT ANCHOR - next run backfills full history'
        ELSE 'OPEN - ' || DATEDIFF('hour', START_DATE, END_DATE) || 'h of data to read'
    END                                                   AS DIAGNOSIS
FROM UTLDB01.METADATA.CXNADM_JOB_CONTROL
ORDER BY WINDOW_SECONDS, JOB_NAME;
-- 27 rows expected. If most say EMPTY, END_DATE is frozen and the fix is
-- needed before go-live, not after.


-- 2. The decisive one: END_DATE against the model's own last run.
--    This is self-proving - it reads both tables and needs no assumption
--    about when anything was deployed.
WITH LAST_RUN AS (
    SELECT
        JOB_NAME,
        MAX(START_TIMESTAMP)                       AS LAST_RUN_START,
        COUNT(*)                                   AS RUNS,
        COUNT_IF(JOB_STATUS = 'COMPLETED')         AS COMPLETED
    FROM UTLDB01.METADATA.CXNADM_JOB_EXECUTION
    GROUP BY JOB_NAME
)
SELECT
    C.JOB_NAME,
    R.RUNS,
    R.COMPLETED,
    R.LAST_RUN_START,
    C.END_DATE,
    DATEDIFF('hour', C.END_DATE, R.LAST_RUN_START)  AS END_DATE_BEHIND_LAST_RUN_HRS,
    DATEDIFF('second', C.START_DATE, C.END_DATE)    AS WINDOW_SECONDS
FROM UTLDB01.METADATA.CXNADM_JOB_CONTROL C
JOIN LAST_RUN R
  ON R.JOB_NAME = C.JOB_NAME
ORDER BY END_DATE_BEHIND_LAST_RUN_HRS DESC;
-- END_DATE_BEHIND_LAST_RUN_HRS near 0  -> END_DATE is tracking, healthy.
-- Large and growing, while COMPLETED keeps climbing -> frozen. Every one
-- of those completed runs read the same stale window.


-- 3. Has END_DATE moved at all since the row was created?
SELECT
    COUNT(*)                                                AS JOBS,
    COUNT_IF(START_DATE = END_DATE)                         AS EMPTY_WINDOW,
    COUNT_IF(START_DATE IS NULL OR END_DATE IS NULL)        AS NULL_WINDOW,
    COUNT_IF(END_DATE <= ROW_CREATE_TIMESTAMP)              AS END_DATE_NEVER_MOVED,
    COUNT_IF(PREV_END_DATE IS NULL)                         AS NEVER_COMPLETED_A_CYCLE,
    MIN(END_DATE)                                           AS OLDEST_END_DATE,
    MAX(END_DATE)                                           AS NEWEST_END_DATE
FROM UTLDB01.METADATA.CXNADM_JOB_CONTROL;
-- EMPTY_WINDOW = 27 confirms it outright.
-- OLDEST/NEWEST clustering on 24-25 Aug matches the two bursts of long
-- runs in the JOB_EXECUTION history and nothing since.
