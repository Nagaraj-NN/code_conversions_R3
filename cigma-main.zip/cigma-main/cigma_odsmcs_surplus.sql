/* =============================================================================
   ODS_MCS surplus rows: accumulation or duplication?

   12 of our 18 tables hold MORE rows than Bronze, +1.62bn in total. Two are
   almost exactly doubled:

       ODS_MCS_NOTES             145,960,247 -> 287,584,540   +97.03%
       ODS_MCS_DEBIT_ACTIVITY  1,462,542,667 -> 2,858,297,488  +95.43%
       ODS_MCS_BILL_COMPONENT    792,095,928 ->   860,323,749   +8.61%

   Row counts alone cannot tell these two causes apart:

     ACCUMULATION - Bronze is a CDC landing zone with retention; ODS keeps
       history Bronze has purged. Both doubled tables are transactional and
       keyed on an event timestamp, which is the shape that accumulates. Not a
       defect.

     KEY-FORMAT DRIFT - the models trim their key columns
       (REGEXP_REPLACE(x,'^[[:space:]]+|[[:space:]]+$','')). A pre-existing row
       keyed 'AP ' and a new row keyed 'AP' are DIFFERENT merge keys, so the
       merge misses and inserts a second row for the same entity. That is a
       defect, and it doubles a fully pre-loaded table.

   Q1 settles it. A merge on unique_key can never write two rows with the SAME
   key, so any duplicate found after normalising whitespace is drift, not
   accumulation.

   All read-only. Paste results under each.
   ============================================================================= */


/* -----------------------------------------------------------------------------
   Q1  THE DECIDING QUERY - duplicate business keys after normalising whitespace.

     DUP_KEY_GROUPS = 0  -> no drift. The surplus is accumulated history and
                            these models are behaving correctly.
     DUP_KEY_GROUPS > 0  -> drift confirmed. SURPLUS_ROWS is how many rows the
                            merge inserted that should have been updates.

   Runs on the key columns only, so Snowflake prunes to those micro-partitions.
   ----------------------------------------------------------------------------- */
SELECT 'ODS_MCS_NOTES' AS TBL, COUNT(*) AS DUP_KEY_GROUPS, SUM(N) - COUNT(*) AS SURPLUS_ROWS
FROM (
    SELECT TRIM(CO_CD_OWNR) AS K1, CRTN_TS AS K2, COUNT(*) AS N
    FROM UTLDB01.UTLUSER.ODS_MCS_NOTES
    GROUP BY 1, 2
    HAVING COUNT(*) > 1
)
UNION ALL
SELECT 'ODS_MCS_DEBIT_ACTIVITY', COUNT(*), SUM(N) - COUNT(*)
FROM (
    SELECT TRIM(BILL_ACCT_NB) AS K1, TRIM(DIR_TYPE_CD) AS K2,
           PROD_ORDR_NB AS K3, DEBT_TS AS K4, COUNT(*) AS N
    FROM UTLDB01.UTLUSER.ODS_MCS_DEBIT_ACTIVITY
    GROUP BY 1, 2, 3, 4
    HAVING COUNT(*) > 1
)
UNION ALL
SELECT 'ODS_MCS_BILL_COMPONENT', COUNT(*), SUM(N) - COUNT(*)
FROM (
    SELECT TRIM(BILL_ACCT_NB) AS K1, BILL_HEAD_NB AS K2, BILL_COMP_NB AS K3, COUNT(*) AS N
    FROM UTLDB01.UTLUSER.ODS_MCS_BILL_COMPONENT
    GROUP BY 1, 2, 3
    HAVING COUNT(*) > 1
);

-- RESULT Q1:
TBL	DUP_KEY_GROUPS	SURPLUS_ROWS
ODS_MCS_NOTES	318930	2780170
ODS_MCS_DEBIT_ACTIVITY	5891286	12740320
ODS_MCS_BILL_COMPONENT	60895193	61813886

/* -----------------------------------------------------------------------------
   Q2  If Q1 shows drift: is untrimmed whitespace the cause?

   Counts rows whose key column is not equal to its own trimmed value. A
   non-zero count on the older EDW_CRTE_TS cohort and zero on the newer one is
   the drift signature.
   ----------------------------------------------------------------------------- */
SELECT 'ODS_MCS_NOTES' AS TBL,
       COUNT_IF(CO_CD_OWNR <> TRIM(CO_CD_OWNR))                       AS UNTRIMMED_KEY_ROWS,
       COUNT(*)                                                       AS TOTAL_ROWS,
       MIN(EDW_CRTE_TS)                                               AS OLDEST,
       MAX(EDW_CRTE_TS)                                               AS NEWEST
FROM UTLDB01.UTLUSER.ODS_MCS_NOTES
UNION ALL
SELECT 'ODS_MCS_DEBIT_ACTIVITY',
       COUNT_IF(BILL_ACCT_NB <> TRIM(BILL_ACCT_NB)
             OR DIR_TYPE_CD  <> TRIM(DIR_TYPE_CD)),
       COUNT(*), MIN(EDW_CRTE_TS), MAX(EDW_CRTE_TS)
FROM UTLDB01.UTLUSER.ODS_MCS_DEBIT_ACTIVITY;

-- RESULT Q2:


/* -----------------------------------------------------------------------------
   Q3  If Q1 shows NO drift: confirm accumulation by checking whether the ODS
       surplus is simply older than Bronze still holds.

   If ODS covers a wider event-date range than Bronze, the surplus is history
   Bronze has purged and nothing is wrong.
   ----------------------------------------------------------------------------- */
SELECT 'ODS_MCS_DEBIT_ACTIVITY' AS TBL, 'ODS' AS SIDE,
       MIN(DEBT_TS) AS OLDEST_EVENT, MAX(DEBT_TS) AS NEWEST_EVENT, COUNT(*) AS ROWS
FROM UTLDB01.UTLUSER.ODS_MCS_DEBIT_ACTIVITY
UNION ALL
SELECT 'ODS_MCS_DEBIT_ACTIVITY', 'BRONZE',
       MIN("debt_ts"), MAX("debt_ts"), COUNT(*)
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_debit_activity"
UNION ALL
SELECT 'ODS_MCS_NOTES', 'ODS',
       MIN(CRTN_TS), MAX(CRTN_TS), COUNT(*)
FROM UTLDB01.UTLUSER.ODS_MCS_NOTES
UNION ALL
SELECT 'ODS_MCS_NOTES', 'BRONZE',
       MIN("crtn_ts"), MAX("crtn_ts"), COUNT(*)
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_notes";

-- RESULT Q3:
TBL	SIDE	OLDEST_EVENT	NEWEST_EVENT	ROWSSS
ODS_MCS_DEBIT_ACTIVITY	ODS	1909-09-08 00:01:00.080	2026-08-31 09:04:37.646	2858297488
ODS_MCS_DEBIT_ACTIVITY	BRONZE	1909-09-08 00:01:00.080	2026-08-31 11:49:29.577	1462542667
ODS_MCS_NOTES	ODS	1900-01-01 00:09:00.031	2028-07-20 18:30:58.002	287584540
ODS_MCS_NOTES	BRONZE	1900-01-01 00:09:00.031	2028-07-20 18:30:58.002	145960247

/* -----------------------------------------------------------------------------
   READING OF Q1 AND Q3  (2026-09-01)

   Q1 CONFIRMS A REAL DEFECT. The columns it grouped on are exactly each model's
   unique_key:

       ODS_MCS_NOTES           unique_key=['CO_CD_OWNR','CRTN_TS']
       ODS_MCS_DEBIT_ACTIVITY  unique_key=['BILL_ACCT_NB','DIR_TYPE_CD',
                                           'PROD_ORDR_NB','DEBT_TS']
       ODS_MCS_BILL_COMPONENT  unique_key=['BILL_ACCT_NB','BILL_HEAD_NB',
                                           'BILL_COMP_NB']

   So these are duplicate MERGE KEYS, which a merge is not supposed to be able
   to produce:

       ODS_MCS_NOTES              318,930 groups     2,780,170 surplus rows
       ODS_MCS_DEBIT_ACTIVITY   5,891,286 groups    12,740,320 surplus rows
       ODS_MCS_BILL_COMPONENT  60,895,193 groups    61,813,886 surplus rows

   The CURRENT model cannot create these. Each one dedupes the source with
   QUALIFY ROW_NUMBER() PARTITION BY the exact unique_key, dedupes the target
   lookup the same way, and rejects NULL/blank key values before that. The
   duplicates therefore PRE-DATE the current model version - legacy load or an
   earlier model revision.

   They do not raise 100090. Snowflake non-deterministic-merge error fires when
   one TARGET row is matched by MULTIPLE SOURCE rows. Here it is the target that
   holds the duplicates, so one source row matches several target rows and
   Snowflake updates ALL of them. No error, no warning - which is why nothing
   has flagged this. The duplicates are permanent and will never self-heal:
   every run keeps updating every copy.

   Q3 IS INCONCLUSIVE - IT WAS THE WRONG TEST. MIN/MAX are order statistics, and
   both extremes here are sentinel rows present identically on both sides:
   1900-01-01 00:09:00.031, and 2028-07-20 18:30:58.002, which is in the FUTURE
   and therefore bad data. Sentinel rows never change and never purge, so they
   pin both extremes regardless of density in between. The identical ranges do
   NOT rule out accumulation.

   What Q1 does NOT explain is the bulk of the surplus:

       table                    dup-key surplus   total surplus vs Bronze  explained
       ODS_MCS_NOTES               2,780,170           141,624,293           2.0%
       ODS_MCS_DEBIT_ACTIVITY     12,740,320         1,395,754,821           0.9%
       ODS_MCS_BILL_COMPONENT     61,813,886            68,227,821          90.6%

   BILL_COMPONENT is effectively solved: its surplus is duplication.
   NOTES and DEBIT_ACTIVITY are not - those extra rows carry DISTINCT keys, so
   they are either accumulated history Bronze has purged (fine) or something
   else. Q4 and Q5 separate the two.
   ----------------------------------------------------------------------------- */


/* -----------------------------------------------------------------------------
   Q4  DENSITY BY YEAR - the test Q3 should have been.

   Compares row counts per event year on both sides, with the model own reject
   filters applied to Bronze so the comparison is apples to apples.

     ODS ~= Bronze in recent years, ODS >> Bronze in older years
         -> Bronze purges; the surplus is retained history. Not a defect.
     ODS ~= 2x Bronze in EVERY year
         -> systematic duplication across the whole table. Defect.
   ----------------------------------------------------------------------------- */
SELECT 'ODS_MCS_NOTES' AS TBL, 'ODS' AS SIDE, YEAR(CRTN_TS) AS YR, COUNT(*) AS ROW_CT
FROM UTLDB01.UTLUSER.ODS_MCS_NOTES
GROUP BY 1, 2, 3
UNION ALL
SELECT 'ODS_MCS_NOTES', 'BRONZE', YEAR(src."crtn_ts"), COUNT(*)
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_notes" src
WHERE REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') IS NOT NULL
  AND REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') <> ''
  AND src."crtn_ts" IS NOT NULL
  AND YEAR(src."crtn_ts") BETWEEN 1900 AND 9999
  AND src."note_ts" IS NOT NULL
  AND src."last_upd_dt" IS NOT NULL
  AND src."last_updt_ts" IS NOT NULL
GROUP BY 1, 2, 3
ORDER BY YR, SIDE;

-- RESULT Q4:


/* -----------------------------------------------------------------------------
   Q4b  Same for ODS_MCS_DEBIT_ACTIVITY.
   ----------------------------------------------------------------------------- */
SELECT 'ODS_MCS_DEBIT_ACTIVITY' AS TBL, 'ODS' AS SIDE, YEAR(DEBT_TS) AS YR, COUNT(*) AS ROW_CT
FROM UTLDB01.UTLUSER.ODS_MCS_DEBIT_ACTIVITY
GROUP BY 1, 2, 3
UNION ALL
SELECT 'ODS_MCS_DEBIT_ACTIVITY', 'BRONZE', YEAR(src."debt_ts"), COUNT(*)
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_debit_activity" src
WHERE REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') IS NOT NULL
  AND REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') <> ''
  AND REGEXP_REPLACE(src."dir_type_cd", '^[[:space:]]+|[[:space:]]+$', '') IS NOT NULL
  AND REGEXP_REPLACE(src."dir_type_cd", '^[[:space:]]+|[[:space:]]+$', '') <> ''
  AND TRY_TO_NUMBER(REGEXP_REPLACE(TO_VARCHAR(src."prod_ordr_nb"), '^[[:space:]]+|[[:space:]]+$', ''), 5, 0) IS NOT NULL
  AND src."debt_ts" IS NOT NULL
  AND YEAR(src."debt_ts") BETWEEN 1900 AND 9999
  AND src."debt_at" IS NOT NULL
  AND src."remn_debt_at" IS NOT NULL
  AND src."debt_prcs_dt" IS NOT NULL
  AND src."last_updt_ts" IS NOT NULL
GROUP BY 1, 2, 3
ORDER BY YR, SIDE;

-- RESULT Q4b:


/* -----------------------------------------------------------------------------
   Q5  EXACT KEY-SET COMPARISON for ODS_MCS_NOTES. Slower than Q4 but definitive,
       and it answers loss and surplus in one row.

     IN_ODS_NOT_BRONZE  - ODS keys Bronze no longer holds. Large -> accumulation.
     IN_BRONZE_NOT_ODS  - Bronze keys the model never landed. This is REAL LOSS.
     ODS_ROWS - ODS_DISTINCT_KEYS  - restates the Q1 duplication.
   ----------------------------------------------------------------------------- */
WITH BRONZE_ELIGIBLE AS (
    SELECT
        REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS K1,
        src."crtn_ts"                                                      AS K2
    FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_notes" src
    WHERE REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') IS NOT NULL
      AND REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') <> ''
      AND src."crtn_ts" IS NOT NULL
      AND YEAR(src."crtn_ts") BETWEEN 1900 AND 9999
      AND src."note_ts" IS NOT NULL
      AND src."last_upd_dt" IS NOT NULL
      AND src."last_updt_ts" IS NOT NULL
),
ODS_ALL_KEYS AS (
    SELECT CO_CD_OWNR AS K1, CRTN_TS AS K2
    FROM UTLDB01.UTLUSER.ODS_MCS_NOTES
)
SELECT
    (SELECT COUNT(*) FROM BRONZE_ELIGIBLE)                               AS BRONZE_ELIGIBLE_ROWS,
    (SELECT COUNT(*) FROM (SELECT DISTINCT K1, K2 FROM BRONZE_ELIGIBLE)) AS BRONZE_DISTINCT_KEYS,
    (SELECT COUNT(*) FROM ODS_ALL_KEYS)                                  AS ODS_ROWS,
    (SELECT COUNT(*) FROM (SELECT DISTINCT K1, K2 FROM ODS_ALL_KEYS))    AS ODS_DISTINCT_KEYS,
    (SELECT COUNT(*) FROM (SELECT K1, K2 FROM BRONZE_ELIGIBLE
                           MINUS
                           SELECT K1, K2 FROM ODS_ALL_KEYS))             AS IN_BRONZE_NOT_ODS,
    (SELECT COUNT(*) FROM (SELECT K1, K2 FROM ODS_ALL_KEYS
                           MINUS
                           SELECT K1, K2 FROM BRONZE_ELIGIBLE))          AS IN_ODS_NOT_BRONZE;

-- RESULT Q5:
