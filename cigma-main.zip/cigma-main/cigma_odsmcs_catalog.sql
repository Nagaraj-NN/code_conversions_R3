/* =============================================================================
   Catalog pull for the 18 UTLUSER ODS_MCS models: their Bronze sources, their
   UTLUSER targets, and the UTLUSER tables ODS_MCS_PREMISE_EXT reads as lookups.

   HOW TO RUN
     Q1 and Q2 give the column catalog - run each, export as TSV, and
     concatenate both results into ONE file named catalog.tsv. The parser skips
     non-data lines, so headers repeated in the middle are fine.

     Q3 is separate and just as important: it is the only thing that
     distinguishes an unfed NOT NULL key from an auto-generated one.

     Q4 is optional - Bronze vs ODS row counts, useful alongside the schema
     comparison.

   NOTE ON CASE
     The WHERE clauses filter TABLE_SCHEMA exactly, with no UPPER(). Folding
     case would hide the difference between a real uppercase schema and a
     lowercase-quoted one, and that difference decides whether references need
     quoting. Let the returned value tell the truth.
   ============================================================================= */


/* -----------------------------------------------------------------------------
   Q1  BRONZE sources -- 17 MCS_* tables in BRONZE_CUST_CONF_PROD.BRONZE_MACSS
   ----------------------------------------------------------------------------- */
SELECT TABLE_SCHEMA,
       TABLE_NAME,
       ORDINAL_POSITION,
       COLUMN_NAME,
       DATA_TYPE,
       CHARACTER_MAXIMUM_LENGTH,
       NUMERIC_PRECISION,
       NUMERIC_SCALE,
       IS_NULLABLE
FROM BRONZE_CUST_CONF_PROD.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'BRONZE_MACSS'
  AND TABLE_NAME IN (
      'MCS_ADDRESS', 'MCS_BA_GREEN_PWR', 'MCS_BILLABLE_USAGE', 'MCS_BILL_ACCOUNT',
      'MCS_BILL_COMPONENT', 'MCS_BILL_HEADER', 'MCS_BUS_DIR', 'MCS_BUS_PA_CRDT_EX',
      'MCS_CREDIT_SOURCE', 'MCS_CUSTOMER', 'MCS_DEBIT_ACTIVITY', 'MCS_INDICATIV_DATA',
      'MCS_NOTES', 'MCS_PREMISE', 'MCS_TRANS_HIST_HDR', 'MCS_WEB_BILL_ACCT',
      'MCS_WEB_USER'
  )
ORDER BY TABLE_NAME, ORDINAL_POSITION;

TABLE_SCHEMA	TABLE_NAME	ORDINAL_POSITION	COLUMN_NAME	DATA_TYPE	CHARACTER_MAXIMUM_LENGTH	NUMERIC_PRECISION	NUMERIC_SCALE	IS_NULLABLE
bronze_macss	mcs_address	1	co_cd_ownr	TEXT	134217728			NO
bronze_macss	mcs_address	2	addr_id_ad	TEXT	134217728			NO
bronze_macss	mcs_address	3	mail_1_nm	TEXT	134217728			YES
bronze_macss	mcs_address	4	mail_2_nm	TEXT	134217728			YES
bronze_macss	mcs_address	5	mail_1_ad	TEXT	134217728			YES
bronze_macss	mcs_address	6	mail_2_ad	TEXT	134217728			YES
bronze_macss	mcs_address	7	mail_city_ad	TEXT	134217728			YES
bronze_macss	mcs_address	8	state_cd_ad	TEXT	134217728			YES
bronze_macss	mcs_address	9	mail_zip_ad	TEXT	134217728			YES
bronze_macss	mcs_address	10	cari_rte_cd	TEXT	134217728			YES
bronze_macss	mcs_address	11	ovri_srvc_name_fl	TEXT	134217728			YES
bronze_macss	mcs_address	12	delv_pt_cd	TEXT	134217728			YES
bronze_macss	mcs_address	13	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_address	14	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_address	15	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_address	16	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_address	17	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_address	18	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_address	19	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_address	20	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_address	21	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_address	22	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_ba_green_pwr	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_ba_green_pwr	2	gp_efct_dt	DATE				NO
bronze_macss	mcs_ba_green_pwr	3	gp_agrmt_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	4	gp_expr_dt	DATE				YES
bronze_macss	mcs_ba_green_pwr	5	gp_mnth_agrmt_qy	NUMBER		10	0	YES
bronze_macss	mcs_ba_green_pwr	6	schd_mthy_kwh_qy	NUMBER		10	0	YES
bronze_macss	mcs_ba_green_pwr	7	gp_kwh_usag_pc	NUMBER		10	0	YES
bronze_macss	mcs_ba_green_pwr	8	gp_reason_cd	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	9	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	10	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_ba_green_pwr	11	suprt_renew_res_cd	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	12	green_program	TEXT	134217728			NO
bronze_macss	mcs_ba_green_pwr	13	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	14	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_ba_green_pwr	15	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_ba_green_pwr	16	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	17	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_ba_green_pwr	18	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_ba_green_pwr	19	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_ba_green_pwr	20	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_account	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_bill_account	2	bill_chck_digit_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	3	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_bill_account	4	addr_id_ad	TEXT	134217728			YES
bronze_macss	mcs_bill_account	5	acct_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	6	avg_srvc_bill_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	7	bal_due_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	8	bb_estm_at	NUMBER		7	2	YES
bronze_macss	mcs_bill_account	9	dfrr_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	10	mthy_actv_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	11	opnn_mthy_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	12	unpr_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	13	payable_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_account	14	acct_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	15	acct_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	16	bb_estm_mthd_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	17	bill_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	18	coll_hist_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	19	crdt_hist_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	20	jrsd_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	21	life_sppr_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	22	pymn_prfl_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	23	revn_clas_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	24	sic_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	25	spcl_hndl_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	26	spcl_cirm_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	27	emp_assc_co_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	28	emp_cd_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	29	tlph_use_1_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	30	tlph_use_2_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	31	uue_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	32	acct_dispute_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	33	state_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	34	dvsn_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	35	area_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	36	slct_due_day_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	37	dpc_cncl_rev_mo_dt	DATE				YES
bronze_macss	mcs_bill_account	38	turn_off_dt	DATE				YES
bronze_macss	mcs_bill_account	39	turn_on_dt	DATE				YES
bronze_macss	mcs_bill_account	40	ed_dt	DATE				YES
bronze_macss	mcs_bill_account	41	lci_acct_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	42	mail_undl_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	43	out_of_bal_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	44	auto_trf_ba_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_account	45	own_home_ind_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	46	cnsl_bill_grp_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	47	cust_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_account	48	fnnc_cntl_unit_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	49	mos_avg_usg_qy	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	50	ref_dep_ctr_qy	NUMBER		2	0	YES
bronze_macss	mcs_bill_account	51	nfnc_cntl_unit_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	52	old_acct_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_account	53	prem_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_account	54	tlph_1_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	55	tlph_2_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	56	rtrn_chck_hist_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	57	envl_cntr_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	58	addl_blls_qy	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	59	chrg_off_prcs_dt	DATE				YES
bronze_macss	mcs_bill_account	60	dpc_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	61	chrg_off_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	62	ovri_chrg_off_dt	DATE				YES
bronze_macss	mcs_bill_account	63	rtrn_chck_arrs_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	64	asss_pgm_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	65	undlvr_mail_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	66	coll_clas_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	67	undlvr_mail_dt	DATE				YES
bronze_macss	mcs_bill_account	68	car_bill_perd_dt	DATE				YES
bronze_macss	mcs_bill_account	69	schd_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	70	cnta_co_nbr_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	71	edi_bill_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	72	store_id_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_account	73	edi_cust_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	74	life_sppr_expr_dt	DATE				YES
bronze_macss	mcs_bill_account	75	res_bill_ovr_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	76	opted_out_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	77	vend_prog_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	78	risk_level_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	79	risk_score_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_account	80	risk_asgn_dt	DATE				YES
bronze_macss	mcs_bill_account	81	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_bill_account	82	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_account	83	ar_opt_out_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_account	84	summary_bill_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_account	85	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_bill_account	86	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_account	87	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_bill_account	88	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_bill_account	89	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_account	90	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_bill_account	91	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_account	92	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_bill_component	2	bill_head_nb	NUMBER		10	0	NO
bronze_macss	mcs_bill_component	3	bill_comp_nb	NUMBER		10	0	NO
bronze_macss	mcs_bill_component	4	tot_bill_at	NUMBER		11	2	YES
bronze_macss	mcs_bill_component	5	cust_chrg_at	NUMBER		7	2	YES
bronze_macss	mcs_bill_component	6	dmnd_chrg_tot_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_component	7	enrg_chrg_tot_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_component	8	fuel_chrg_tot_at	NUMBER		9	2	YES
bronze_macss	mcs_bill_component	9	misc_chrg_tot_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_component	10	rctv_dmnd_chg_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_component	11	surc_tot_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_component	12	tax_tot_at	NUMBER		8	2	YES
bronze_macss	mcs_bill_component	13	hist_crrc_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	14	tarf_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	15	nmtr_actv_unts_qy	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	16	prrt_fctr_qy	NUMBER		5	4	YES
bronze_macss	mcs_bill_component	17	revn_clas_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	18	bill_perd_from_dt	DATE				YES
bronze_macss	mcs_bill_component	19	bill_perd_to_dt	DATE				YES
bronze_macss	mcs_bill_component	20	orig_bill_comp_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	21	supr_bill_comp_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	22	supr_bill_head_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	23	orig_bill_head_nb	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	24	bill_perd_fr_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	25	bill_perd_to_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	26	prem_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_component	27	tarf_pnt_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_component	28	bill_comp_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	29	bill_comp_dt	DATE				YES
bronze_macss	mcs_bill_component	30	bill_comp_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	31	comp_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	32	smmr_usag_hist_qy	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	33	cumu_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	34	tarf_min_at	NUMBER		7	2	YES
bronze_macss	mcs_bill_component	35	tarf_max_at	NUMBER		7	2	YES
bronze_macss	mcs_bill_component	36	blpm_hist_exist_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_component	37	bb_estm_at	NUMBER		7	2	YES
bronze_macss	mcs_bill_component	38	fnnc_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	39	fnnc_ts_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	40	bb_estm_mthd_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	41	prorate_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_component	42	schd_bill_dt	DATE				YES
bronze_macss	mcs_bill_component	43	dist_chrg_at	NUMBER		11	2	YES
bronze_macss	mcs_bill_component	44	gen_chrg_at	NUMBER		11	2	YES
bronze_macss	mcs_bill_component	45	trans_chrg_at	NUMBER		11	2	YES
bronze_macss	mcs_bill_component	46	tarf_cus_choice_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	47	ptc_rt_value	NUMBER		3	3	YES
bronze_macss	mcs_bill_component	48	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_bill_component	49	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	50	tax_dstc_cd	NUMBER		10	0	YES
bronze_macss	mcs_bill_component	51	comp_on_cycle_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_component	52	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_bill_component	53	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	54	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_bill_component	55	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_bill_component	56	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	57	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_bill_component	58	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_component	59	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_bill_header	2	bill_head_nb	NUMBER		10	0	NO
bronze_macss	mcs_bill_header	3	bill_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_header	4	dpc_calc_tot_at	NUMBER		8	2	YES
bronze_macss	mcs_bill_header	5	mtrd_bill_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_header	6	non_mtrd_tot_at	NUMBER		8	2	YES
bronze_macss	mcs_bill_header	7	bdgt_bill_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	8	spcl_hndl_perf_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	9	addl_blls_qy	NUMBER		10	0	YES
bronze_macss	mcs_bill_header	10	offr_bb_plan_fl	TEXT	134217728			YES
bronze_macss	mcs_bill_header	11	totl_bill_due_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_header	12	cnsl_bill_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	13	excs_crdt_appl_at	NUMBER		8	2	YES
bronze_macss	mcs_bill_header	14	bill_dt	DATE				YES
bronze_macss	mcs_bill_header	15	acct_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bill_header	16	on_cycle_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	17	bill_head_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	18	bill_head_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	19	bill_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	20	bill_due_dt	DATE				YES
bronze_macss	mcs_bill_header	21	bb_estm_at	NUMBER		7	2	YES
bronze_macss	mcs_bill_header	22	edi_bill_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	23	store_id_nb	TEXT	134217728			YES
bronze_macss	mcs_bill_header	24	edi_cust_cd	TEXT	134217728			YES
bronze_macss	mcs_bill_header	25	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_bill_header	26	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	27	edi_identifier_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	28	edi_ack_status	TEXT	134217728			YES
bronze_macss	mcs_bill_header	29	edi_act_date	DATE				YES
bronze_macss	mcs_bill_header	30	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_bill_header	31	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	32	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_bill_header	33	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_bill_header	34	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	35	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_bill_header	36	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bill_header	37	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_billable_usage	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_billable_usage	2	bill_head_nb	NUMBER		10	0	NO
bronze_macss	mcs_billable_usage	3	bill_comp_nb	NUMBER		10	0	NO
bronze_macss	mcs_billable_usage	4	time_of_day_cd	TEXT	134217728			NO
bronze_macss	mcs_billable_usage	5	dmnd_type_cd	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	6	read_cd	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	7	tod_cd_sort_nb	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	8	bill_dmnd_qy	NUMBER		7	1	YES
bronze_macss	mcs_billable_usage	9	bill_kwh_qy	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	10	net_usag_kva_qy	NUMBER		10	3	YES
bronze_macss	mcs_billable_usage	11	net_usag_kvar_qy	NUMBER		10	3	YES
bronze_macss	mcs_billable_usage	12	net_usag_kvarh_qy	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	13	net_usag_kw_qy	NUMBER		10	3	YES
bronze_macss	mcs_billable_usage	14	net_usag_kwh_qy	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	15	net_usag_qhr_qy	NUMBER		10	1	YES
bronze_macss	mcs_billable_usage	16	pwr_fctr_qy	NUMBER		4	1	YES
bronze_macss	mcs_billable_usage	17	pwr_fctr_cnst_qy	NUMBER		7	4	YES
bronze_macss	mcs_billable_usage	18	rctv_dmnd_qy	NUMBER		7	1	YES
bronze_macss	mcs_billable_usage	19	rctv_hors_qy	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	20	usag_nbr_days_qy	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	21	load_fctr_qy	NUMBER		4	1	YES
bronze_macss	mcs_billable_usage	22	hours_used_qy	NUMBER		10	0	YES
bronze_macss	mcs_billable_usage	23	lci_usag_exists_fl	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	24	edi_cntl_nb	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	25	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	26	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_billable_usage	27	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	28	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_billable_usage	29	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_billable_usage	30	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	31	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_billable_usage	32	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_billable_usage	33	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_billable_usage	34	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_dir	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_bus_dir	2	dir_type_cd	TEXT	134217728			NO
bronze_macss	mcs_bus_dir	3	prod_ordr_nb	NUMBER		10	0	NO
bronze_macss	mcs_bus_dir	4	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	5	bal_due_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	6	bsns_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	7	dfrr_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	8	init_pymn_dpmt_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	9	finl_insm_at	NUMBER		9	2	YES
bronze_macss	mcs_bus_dir	10	insm_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	11	tot_insm_bsns_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	12	fnnc_chrg_at	NUMBER		9	2	YES
bronze_macss	mcs_bus_dir	13	unpr_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	14	payable_bal_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_dir	15	bsns_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	16	bsns_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	17	bsns_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	18	freq_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	19	pymn_mthd_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	20	bsns_set_up_dt	DATE				YES
bronze_macss	mcs_bus_dir	21	bill_with_srvc_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	22	annl_prcn_rt_pc	NUMBER		3	1	YES
bronze_macss	mcs_bus_dir	23	insm_qy	NUMBER		10	0	YES
bronze_macss	mcs_bus_dir	24	remn_insm_qy	NUMBER		10	0	YES
bronze_macss	mcs_bus_dir	25	first_insm_due_dt	DATE				YES
bronze_macss	mcs_bus_dir	26	init_pymn_due_dt	DATE				YES
bronze_macss	mcs_bus_dir	27	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	28	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_dir	29	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	30	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_dir	31	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_bus_dir	32	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	33	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_dir	34	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_bus_dir	35	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_dir	36	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_pa_crdt_ex	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_bus_pa_crdt_ex	2	prod_ordr_nb	NUMBER		10	0	NO
bronze_macss	mcs_bus_pa_crdt_ex	3	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	4	pay_arrg_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	5	dflt_pagr_dscn_dt	DATE				YES
bronze_macss	mcs_bus_pa_crdt_ex	6	stat_last_chng_dt	DATE				YES
bronze_macss	mcs_bus_pa_crdt_ex	7	cnfr_lttr_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	8	pay_agrm_agcy_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	9	pay_agrm_bill_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	10	revw_on_dflt_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	11	resn_dele_tx	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	12	cncl_dflt_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	13	pa_resn_crtd_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	14	extn_type_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	15	extn_dt	DATE				YES
bronze_macss	mcs_bus_pa_crdt_ex	16	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	17	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_pa_crdt_ex	18	ipr_status_fl	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	19	ipr_action_cd	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	20	dflt_pagr_remn_at	NUMBER		10	2	YES
bronze_macss	mcs_bus_pa_crdt_ex	21	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	22	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_pa_crdt_ex	23	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_bus_pa_crdt_ex	24	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	25	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_pa_crdt_ex	26	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_bus_pa_crdt_ex	27	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_bus_pa_crdt_ex	28	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_credit_source	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_credit_source	2	crdt_crtn_ts	TIMESTAMP_NTZ				NO
bronze_macss	mcs_credit_source	3	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_credit_source	4	pymn_crdt_at	NUMBER		10	2	YES
bronze_macss	mcs_credit_source	5	appl_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	6	pymn_crdt_sorc_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	7	show_on_bill_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	8	trf_between_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	9	pymn_crdt_dt	DATE				YES
bronze_macss	mcs_credit_source	10	trans_type_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	11	cash_btch_nb	NUMBER		10	0	YES
bronze_macss	mcs_credit_source	12	pymn_seq_nb	NUMBER		10	0	YES
bronze_macss	mcs_credit_source	13	agnt_cmmr_coll_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	14	pymn_cshr_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	15	hist_crrc_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	16	pymn_ind_cd	TEXT	134217728			YES
bronze_macss	mcs_credit_source	17	bill_head_nb	NUMBER		10	0	YES
bronze_macss	mcs_credit_source	18	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_credit_source	19	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_credit_source	20	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_credit_source	21	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_credit_source	22	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_credit_source	23	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_credit_source	24	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_credit_source	25	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_credit_source	26	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_credit_source	27	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_customer	1	cust_nb	TEXT	134217728			NO
bronze_macss	mcs_customer	2	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_customer	3	rsdn_corp_ind_cd	TEXT	134217728			YES
bronze_macss	mcs_customer	4	srvy_sent_dt	DATE				YES
bronze_macss	mcs_customer	5	cust_nm_info_fl	TEXT	134217728			YES
bronze_macss	mcs_customer	6	ownr_agnt_flag_fl	TEXT	134217728			YES
bronze_macss	mcs_customer	7	cust_ss_1_nb	NUMBER		10	0	YES
bronze_macss	mcs_customer	8	cust_ss_2_nb	NUMBER		10	0	YES
bronze_macss	mcs_customer	9	nfnc_cntl_unit_nb	NUMBER		10	0	YES
bronze_macss	mcs_customer	10	crpr_affl_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	11	cust_1st_1_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	12	cust_last_1_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	13	cust_mddl_1_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	14	cust_prfx_1_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	15	cust_sffx_1_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	16	cust_1st_2_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	17	cust_last_2_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	18	cust_mddl_2_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	19	cust_prfx_2_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	20	cust_sffx_2_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	21	cust_envl_ovrr_fl	TEXT	134217728			YES
bronze_macss	mcs_customer	22	crdt_rtng_nb	NUMBER		10	0	YES
bronze_macss	mcs_customer	23	hndbk_sent_dt	DATE				YES
bronze_macss	mcs_customer	24	tax_id	TEXT	134217728			YES
bronze_macss	mcs_customer	25	crdt_rtng_recv_dt	DATE				YES
bronze_macss	mcs_customer	26	energy_dvrsn_fl	TEXT	134217728			YES
bronze_macss	mcs_customer	27	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_customer	28	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_customer	29	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_customer	30	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_customer	31	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_customer	32	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_customer	33	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_customer	34	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_customer	35	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_customer	36	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_debit_activity	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_debit_activity	2	dir_type_cd	TEXT	134217728			NO
bronze_macss	mcs_debit_activity	3	prod_ordr_nb	NUMBER		10	0	NO
bronze_macss	mcs_debit_activity	4	debt_ts	TIMESTAMP_NTZ				NO
bronze_macss	mcs_debit_activity	5	debt_at	NUMBER		10	2	YES
bronze_macss	mcs_debit_activity	6	remn_debt_at	NUMBER		10	2	YES
bronze_macss	mcs_debit_activity	7	bsns_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	8	debt_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	9	hist_crrc_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	10	show_on_bill_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	11	sorc_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	12	bsns_type_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	13	trf_between_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	14	debt_due_dt	DATE				YES
bronze_macss	mcs_debit_activity	15	revn_year_mnth_dt	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	16	age_of_debit_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	17	pagr_prdn_ordr_nb	NUMBER		10	0	YES
bronze_macss	mcs_debit_activity	18	bill_head_nb	NUMBER		10	0	YES
bronze_macss	mcs_debit_activity	19	debt_prcs_dt	DATE				YES
bronze_macss	mcs_debit_activity	20	ar_sort_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	21	elec_bsns_fl	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	22	bill_comp_nb	NUMBER		10	0	YES
bronze_macss	mcs_debit_activity	23	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	24	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_debit_activity	25	rcvr_type_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	26	chrg_off_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	27	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	28	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_debit_activity	29	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_debit_activity	30	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	31	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_debit_activity	32	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_debit_activity	33	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_debit_activity	34	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_indicativ_data	1	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_indicativ_data	2	prem_nb	TEXT	134217728			NO
bronze_macss	mcs_indicativ_data	3	cust_nb	TEXT	134217728			NO
bronze_macss	mcs_indicativ_data	4	name_idnt_cd	TEXT	134217728			NO
bronze_macss	mcs_indicativ_data	5	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	6	state_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	7	jrsd_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	8	dvsn_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	9	area_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	10	ser_half_ind_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	11	serv_city_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	12	serv_hous_nbr_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	13	serv_ptdr_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	14	serv_prdr_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	15	rurl_rte_type_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	16	route_nb_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	17	box_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	18	serv_st_dsgt_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	19	serv_st_name_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	20	serv_unit_dsgt_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	21	serv_unit_nbr_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	22	serv_zip_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	23	acct_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	24	acct_type_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	25	life_sppr_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	26	revn_clas_cd	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	27	st_cd_ad	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	28	tarf_cd	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	29	tlph_use_1_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	30	tlph_use_2_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	31	prem_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	32	acct_clas_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	33	rsdn_corp_ind_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	34	sic_cd	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	35	turn_off_dt	DATE				YES
bronze_macss	mcs_indicativ_data	36	turn_on_dt	DATE				YES
bronze_macss	mcs_indicativ_data	37	lci_acct_fl	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	38	cust_ss_1_nb	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	39	cycl_nb	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	40	mtr_rdg_rte_nb	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	41	old_acct_nb	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	42	tlph_1_nb	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	43	tlph_2_nb	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	44	cust_1st_1_nm	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	45	cust_last_1_nm	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	46	cust_mddl_init_nm	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	47	cust_prfx_1_nm	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	48	cust_sffx_1_nm	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	49	tax_dstc_cd	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	50	cumu_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	51	fnnc_cntl_unit_nb	NUMBER		10	0	YES
bronze_macss	mcs_indicativ_data	52	out_of_bal_fl	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	53	schd_type_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	54	vend_prog_fl	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	55	power_pool_cd	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	56	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	57	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_indicativ_data	58	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	59	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_indicativ_data	60	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_indicativ_data	61	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	62	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_indicativ_data	63	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_indicativ_data	64	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_indicativ_data	65	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	1	co_cd_ownr	TEXT	134217728			NO
bronze_macss	mcs_notes	2	crtn_ts	TIMESTAMP_NTZ				NO
bronze_macss	mcs_notes	3	note_prrt_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	4	note_frmt_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	5	user_idnt_crtd_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	6	user_idnt_updt_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	7	note_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	8	note_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	9	last_upd_dt	DATE				YES
bronze_macss	mcs_notes	10	last_upd_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	11	orgn_conv_id_nm	TEXT	134217728			YES
bronze_macss	mcs_notes	12	note_desc_tx	TEXT	134217728			YES
bronze_macss	mcs_notes	13	bill_acct_nb	TEXT	134217728			YES
bronze_macss	mcs_notes	14	cust_nb	TEXT	134217728			YES
bronze_macss	mcs_notes	15	prem_nb	TEXT	134217728			YES
bronze_macss	mcs_notes	16	state_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	17	dvsn_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	18	area_cd	TEXT	134217728			YES
bronze_macss	mcs_notes	19	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_notes	20	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	21	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_notes	22	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	23	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_notes	24	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_notes	25	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	26	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_notes	27	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_notes	28	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_premise	1	prem_nb	TEXT	134217728			NO
bronze_macss	mcs_premise	2	co_cd_ownr	TEXT	134217728			YES
bronze_macss	mcs_premise	3	ser_half_ind_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	4	serv_city_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	5	serv_hous_nbr_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	6	serv_ptdr_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	7	serv_prdr_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	8	addl_srv_data_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	9	state_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	10	serv_st_name_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	11	serv_st_dsgt_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	12	serv_unit_dsgt_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	13	serv_unit_nbr_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	14	serv_zip_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	15	st_cd_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	16	cari_rte_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	17	irrg_use_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	18	load_area_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	19	reddy_crct_cent_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	20	prem_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	21	srvc_entn_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	22	area_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	23	cumu_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	24	tax_dstc_cd	NUMBER		10	0	YES
bronze_macss	mcs_premise	25	dvsn_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	26	last_rrte_dt	DATE				YES
bronze_macss	mcs_premise	27	nfnc_cntl_unit_nb	NUMBER		10	0	YES
bronze_macss	mcs_premise	28	cycl_nb	NUMBER		10	0	YES
bronze_macss	mcs_premise	29	key_nb	NUMBER		10	0	YES
bronze_macss	mcs_premise	30	mtr_rdg_rte_nb	TEXT	134217728			YES
bronze_macss	mcs_premise	31	oa_agrm_nb	TEXT	134217728			YES
bronze_macss	mcs_premise	32	rdg_seq_nb	NUMBER		10	0	YES
bronze_macss	mcs_premise	33	serv_mail_city_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	34	rurl_rte_type_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	35	route_nb_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	36	box_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	37	mtr_rte_ownr_nb	NUMBER		10	0	YES
bronze_macss	mcs_premise	38	srvc_pole_nb	TEXT	134217728			YES
bronze_macss	mcs_premise	39	trsf_pole_nb	TEXT	134217728			YES
bronze_macss	mcs_premise	40	hsng_ctgy_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	41	sub_area_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	42	delv_pt_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	43	srvc_st_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	44	mail_zip_ad	TEXT	134217728			YES
bronze_macss	mcs_premise	45	power_pool_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	46	mtr_redr_id	TEXT	134217728			YES
bronze_macss	mcs_premise	47	irrg_use_efct_dt	DATE				YES
bronze_macss	mcs_premise	48	prx_verify_dt	DATE				YES
bronze_macss	mcs_premise	49	fips_annex_dt	DATE				YES
bronze_macss	mcs_premise	50	annex_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	51	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_premise	52	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_premise	53	ami_ftprnt_cd	TEXT	134217728			YES
bronze_macss	mcs_premise	54	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_premise	55	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_premise	56	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_premise	57	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_premise	58	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_premise	59	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_premise	60	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_premise	61	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_trans_hist_hdr	1	co_cd_ownr	TEXT	134217728			NO
bronze_macss	mcs_trans_hist_hdr	2	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_trans_hist_hdr	3	cnv_id	TEXT	134217728			NO
bronze_macss	mcs_trans_hist_hdr	4	rvrs_ts_20_ts	TEXT	134217728			NO
bronze_macss	mcs_trans_hist_hdr	5	ordr_nb	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	6	dvsn_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	7	area_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	8	state_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	9	cust_nb	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	10	prem_nb	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	11	cust_cmpn_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	12	ordr_cmpl_dt	DATE				YES
bronze_macss	mcs_trans_hist_hdr	13	ordr_efct_dt	DATE				YES
bronze_macss	mcs_trans_hist_hdr	14	ordr_crtn_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_trans_hist_hdr	15	ordr_func_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	16	ordr_resn_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	17	ordr_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	18	user_id	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	19	scrn_crtn_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	20	rmrk_tx	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	21	last_trns_dt	DATE				YES
bronze_macss	mcs_trans_hist_hdr	22	rvrs_ts_nb	NUMBER		15	0	YES
bronze_macss	mcs_trans_hist_hdr	23	uptr_trmn_id_nb	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	24	trns_at	NUMBER		10	2	YES
bronze_macss	mcs_trans_hist_hdr	25	crdt_coll_actn_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	26	coll_actv_ctgy_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	27	rmrk_4_tx	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	28	tran_hist_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	29	last_tran_updt_nm	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	30	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_trans_hist_hdr	31	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	32	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_trans_hist_hdr	33	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_trans_hist_hdr	34	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	35	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_trans_hist_hdr	36	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_trans_hist_hdr	37	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_trans_hist_hdr	38	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_bill_acct	1	web_id	TEXT	134217728			NO
bronze_macss	mcs_web_bill_acct	2	bill_acct_nb	TEXT	134217728			NO
bronze_macss	mcs_web_bill_acct	3	web_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	4	cust_nb	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	5	msg_tx	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	6	crtn_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_bill_acct	7	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_bill_acct	8	bdhv_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	9	bdhv_consumer_id	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	10	bdhv_tc_cd	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	11	srce_id	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	12	srce_nm	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	13	inhouse_edi_opt_fl	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	14	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	15	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_bill_acct	16	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_web_bill_acct	17	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	18	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_bill_acct	19	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_web_bill_acct	20	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_bill_acct	21	dp_update_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	1	web_id	TEXT	134217728			NO
bronze_macss	mcs_web_user	2	web_pswd	TEXT	134217728			YES
bronze_macss	mcs_web_user	3	web_pswd_hint	TEXT	134217728			YES
bronze_macss	mcs_web_user	4	bill_acct_nb	TEXT	134217728			YES
bronze_macss	mcs_web_user	5	web_email	TEXT	134217728			YES
bronze_macss	mcs_web_user	6	web_reg_key	TEXT	134217728			YES
bronze_macss	mcs_web_user	7	web_rqst_nm	TEXT	134217728			YES
bronze_macss	mcs_web_user	8	web_rqst_ad	TEXT	134217728			YES
bronze_macss	mcs_web_user	9	pswd_rqrd_chg_dt	DATE				YES
bronze_macss	mcs_web_user	10	web_ind	TEXT	134217728			YES
bronze_macss	mcs_web_user	11	web_user_stat_cd	TEXT	134217728			YES
bronze_macss	mcs_web_user	12	web_first_nm	TEXT	134217728			YES
bronze_macss	mcs_web_user	13	web_last_nm	TEXT	134217728			YES
bronze_macss	mcs_web_user	14	web_prefix_nm	TEXT	134217728			YES
bronze_macss	mcs_web_user	15	email_format_cd	TEXT	134217728			YES
bronze_macss	mcs_web_user	16	web_sms	TEXT	134217728			YES
bronze_macss	mcs_web_user	17	sms_quiet_start_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	18	sms_quiet_end_tm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	19	sms_quiet_tz	TEXT	134217728			YES
bronze_macss	mcs_web_user	20	crtn_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	21	last_updt_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	22	web_id_nb	NUMBER		10	0	YES
bronze_macss	mcs_web_user	23	prof_validated_dt	DATE				YES
bronze_macss	mcs_web_user	24	icoe_op_type	TEXT	134217728			YES
bronze_macss	mcs_web_user	25	icoe_op_ts	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	26	icoe_offset	NUMBER		19	0	YES
bronze_macss	mcs_web_user	27	icoe_scn	TEXT	134217728			YES
bronze_macss	mcs_web_user	28	aws_extract_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	29	dp_update_user	TEXT	134217728			YES
bronze_macss	mcs_web_user	30	dp_insert_dttm	TIMESTAMP_NTZ				YES
bronze_macss	mcs_web_user	31	dp_update_dttm	TIMESTAMP_NTZ				YES


/* -----------------------------------------------------------------------------
   Q2  UTLUSER -- the 18 ODS_MCS targets plus the 13 lookup tables
       ODS_MCS_PREMISE_EXT reads but does not build
   ----------------------------------------------------------------------------- */
SELECT TABLE_SCHEMA,
       TABLE_NAME,
       ORDINAL_POSITION,
       COLUMN_NAME,
       DATA_TYPE,
       CHARACTER_MAXIMUM_LENGTH,
       NUMERIC_PRECISION,
       NUMERIC_SCALE,
       IS_NULLABLE
FROM UTLDB01.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'UTLUSER'
  AND TABLE_NAME IN (
      -- targets the 18 models build
      'ODS_MCS_ADDRESS', 'ODS_MCS_BA_GREEN_PWR', 'ODS_MCS_BILLABLE_USAGE',
      'ODS_MCS_BILL_ACCOUNT', 'ODS_MCS_BILL_COMPONENT', 'ODS_MCS_BILL_HEADER',
      'ODS_MCS_BUS_DIR', 'ODS_MCS_BUS_PA_CRDT_EX', 'ODS_MCS_CREDIT_SOURCE',
      'ODS_MCS_CUSTOMER', 'ODS_MCS_DEBIT_ACTIVITY', 'ODS_MCS_INDICATIV_DATA',
      'ODS_MCS_NOTES', 'ODS_MCS_PREMISE', 'ODS_MCS_PREMISE_EXT',
      'ODS_MCS_TRANS_HIST_HDR', 'ODS_MCS_WEB_BILL_ACCT', 'ODS_MCS_WEB_USER',
      -- read by ODS_MCS_PREMISE_EXT, built elsewhere
      'MCS_MCSC0028', 'MCS_MCSC0084', 'MCS_MCSC0231', 'ODS_MCS_ACCT_XREF',
      'ODS_MCS_PREMISE_EQUIP', 'ODS_MCS_SERV_DELIV_ID', 'ODS_MCS_STATN_CIRC_NM',
      'ODS_MCS_STATN_CIRC_XRF', 'ODS_MCS_TARF_PT_BIL_PM', 'ODS_MCS_TARIFF_POINT',
      'ODS_MCS_ZIP_WEATHER', 'ODS_MDS_SERVICE_POINT', 'ODS_TERS_PREM_OMS_XREF'
  )
ORDER BY TABLE_NAME, ORDINAL_POSITION;

TABLE_SCHEMA	TABLE_NAME	ORDINAL_POSITION	COLUMN_NAME	DATA_TYPE	CHARACTER_MAXIMUM_LENGTH	NUMERIC_PRECISION	NUMERIC_SCALE	IS_NULLABLE
UTLUSER	MCS_MCSC0028	1	CODE_TBL_NM	TEXT	8			YES
UTLUSER	MCS_MCSC0028	2	CO_CD_OWNR	TEXT	21			YES
UTLUSER	MCS_MCSC0028	3	STATE_CD	TEXT	21			YES
UTLUSER	MCS_MCSC0028	4	DVSN_CD	TEXT	21			YES
UTLUSER	MCS_MCSC0028	5	AREA_CD	TEXT	21			YES
UTLUSER	MCS_MCSC0028	6	JRSD_CD	TEXT	21			YES
UTLUSER	MCS_MCSC0028	7	JRSD_TX	TEXT	370			YES
UTLUSER	MCS_MCSC0084	1	CODE_TBL_NM	TEXT	8			YES
UTLUSER	MCS_MCSC0084	2	CO_CD_OWNR	TEXT	21			YES
UTLUSER	MCS_MCSC0084	3	REVN_CLASS_CD	TEXT	21			YES
UTLUSER	MCS_MCSC0084	4	REVN_CLAS_DESC_TX	TEXT	370			YES
UTLUSER	MCS_MCSC0084	5	ACCT_CLAS_CD	TEXT	370			YES
UTLUSER	MCS_MCSC0084	6	HTNG_CD	TEXT	370			YES
UTLUSER	MCS_MCSC0084	7	DSM_SRCH_FL	TEXT	370			YES
UTLUSER	MCS_MCSC0231	1	CODE_TBL_NM	TEXT	8			YES
UTLUSER	MCS_MCSC0231	2	CO_CD_OWNR	TEXT	21			YES
UTLUSER	MCS_MCSC0231	3	TAX_DSTC_CD	TEXT	21			YES
UTLUSER	MCS_MCSC0231	4	TAX_DSTC_TX	TEXT	370			YES
UTLUSER	MCS_MCSC0231	5	CNTY_TS	TEXT	370			YES
UTLUSER	MCS_MCSC0231	6	SCHL_DSTC_TX	TEXT	370			YES
UTLUSER	ODS_MCS_ACCT_XREF	1	BILL_ACCT_NB	TEXT	10			NO
UTLUSER	ODS_MCS_ACCT_XREF	2	XREF_TYPE_CD	TEXT	1			NO
UTLUSER	ODS_MCS_ACCT_XREF	3	XREF_EFCT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_ACCT_XREF	4	XREF_EXPR_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_ACCT_XREF	5	XREF_CD	TEXT	8			NO
UTLUSER	ODS_MCS_ACCT_XREF	6	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_ACCT_XREF	7	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_ACCT_XREF	8	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_ADDRESS	1	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_ADDRESS	2	ADDR_ID_AD	TEXT	7			NO
UTLUSER	ODS_MCS_ADDRESS	3	MAIL_1_NM	TEXT	35			NO
UTLUSER	ODS_MCS_ADDRESS	4	MAIL_2_NM	TEXT	35			NO
UTLUSER	ODS_MCS_ADDRESS	5	MAIL_1_AD	TEXT	35			NO
UTLUSER	ODS_MCS_ADDRESS	6	MAIL_2_AD	TEXT	35			NO
UTLUSER	ODS_MCS_ADDRESS	7	MAIL_CITY_AD	TEXT	20			NO
UTLUSER	ODS_MCS_ADDRESS	8	STATE_CD_AD	TEXT	2			NO
UTLUSER	ODS_MCS_ADDRESS	9	MAIL_ZIP_AD	TEXT	10			NO
UTLUSER	ODS_MCS_ADDRESS	10	CARI_RTE_CD	TEXT	4			NO
UTLUSER	ODS_MCS_ADDRESS	11	OVRI_SRVC_NAME_FL	TEXT	1			NO
UTLUSER	ODS_MCS_ADDRESS	12	DELV_PT_CD	TEXT	2			NO
UTLUSER	ODS_MCS_ADDRESS	13	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_ADDRESS	14	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_ADDRESS	15	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BA_GREEN_PWR	1	BILL_ACCT_NB	TEXT	10			NO
UTLUSER	ODS_MCS_BA_GREEN_PWR	2	GP_EFCT_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BA_GREEN_PWR	3	GP_AGRMT_STAT_CD	TEXT	1			YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	4	GP_EXPR_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	5	GP_MNTH_AGRMT_QY	NUMBER		38	0	YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	6	SCHD_MTHY_KWH_QY	NUMBER		38	0	YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	7	GP_KWH_USAG_PC	NUMBER		38	18	YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	8	GP_REASON_CD	TEXT	1			YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	9	LAST_TRAN_UPDT_NM	TEXT	8			YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	10	LAST_UPDT_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	11	SUPRT_RENEW_RES_CD	TEXT	2			YES
UTLUSER	ODS_MCS_BA_GREEN_PWR	12	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILLABLE_USAGE	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	2	BILL_HEAD_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	3	BILL_COMP_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	4	TIME_OF_DAY_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	5	DMND_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	6	READ_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	7	TOD_CD_SORT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	8	BILL_DMND_QY	NUMBER		7	1	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	9	BILL_KWH_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	10	NET_USAG_KVA_QY	NUMBER		10	3	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	11	NET_USAG_KVAR_QY	NUMBER		10	3	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	12	NET_USAG_KVARH_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	13	NET_USAG_KW_QY	NUMBER		10	3	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	14	NET_USAG_KWH_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	15	NET_USAG_QHR_QY	NUMBER		10	1	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	16	PWR_FCTR_QY	NUMBER		4	1	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	17	PWR_FCTR_CNST_QY	NUMBER		7	4	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	18	RCTV_DMND_QY	NUMBER		7	1	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	19	RCTV_HORS_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	20	USAG_NBR_DAYS_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	21	LOAD_FCTR_QY	NUMBER		4	1	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	22	HOURS_USED_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	23	LCI_USAG_EXISTS_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	24	EDI_CNTL_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	25	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	26	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILLABLE_USAGE	27	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	1	BILL_ACCT_NB	TEXT	10			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	2	BILL_CHCK_DIGIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	3	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	4	ADDR_ID_AD	TEXT	7			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	5	ACCT_BAL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	6	AVG_SRVC_BILL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	7	BAL_DUE_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	8	BB_ESTM_AT	NUMBER		7	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	9	DFRR_BAL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	10	MTHY_ACTV_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	11	OPNN_MTHY_BAL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	12	UNPR_BAL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	13	PAYABLE_BAL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	14	ACCT_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	15	ACCT_TYPE_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	16	BB_ESTM_MTHD_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	17	BILL_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	18	COLL_HIST_CD	TEXT	36			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	19	CRDT_HIST_CD	TEXT	36			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	20	JRSD_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	21	LIFE_SPPR_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	22	PYMN_PRFL_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	23	REVN_CLAS_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	24	SIC_CD	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	25	SPCL_HNDL_CD	TEXT	3			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	26	SPCL_CIRM_CD	TEXT	3			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	27	EMP_ASSC_CO_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	28	EMP_CD_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	29	TLPH_USE_1_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	30	TLPH_USE_2_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	31	UUE_TYPE_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	32	ACCT_DISPUTE_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	33	STATE_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	34	DVSN_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	35	AREA_CD	TEXT	3			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	36	SLCT_DUE_DAY_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	37	DPC_CNCL_REV_MO_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	38	TURN_OFF_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	39	TURN_ON_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	40	ED_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	41	LCI_ACCT_FL	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	42	MAIL_UNDL_FL	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	43	OUT_OF_BAL_FL	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	44	AUTO_TRF_BA_NB	TEXT	10			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	45	OWN_HOME_IND_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	46	CNSL_BILL_GRP_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	47	CUST_NB	TEXT	9			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	48	FNNC_CNTL_UNIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	49	MOS_AVG_USG_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	50	REF_DEP_CTR_QY	NUMBER		2	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	51	NFNC_CNTL_UNIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	52	OLD_ACCT_NB	TEXT	13			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	53	PREM_NB	TEXT	9			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	54	TLPH_1_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	55	TLPH_2_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	56	RTRN_CHCK_HIST_CD	TEXT	36			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	57	ENVL_CNTR_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	58	ADDL_BLLS_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	59	CHRG_OFF_PRCS_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	60	DPC_FL	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	61	CHRG_OFF_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	62	OVRI_CHRG_OFF_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	63	RTRN_CHCK_ARRS_CD	TEXT	12			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	64	ASSS_PGM_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	65	UNDLVR_MAIL_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	66	COLL_CLAS_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	67	UNDLVR_MAIL_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	68	CAR_BILL_PERD_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	69	SCHD_TYPE_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	70	CNTA_CO_NBR_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	71	EDI_BILL_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	72	STORE_ID_NB	TEXT	11			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	73	EDI_CUST_CD	TEXT	6			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	74	LIFE_SPPR_EXPR_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	75	RES_BILL_OVR_FL	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	76	OPTED_OUT_CD	TEXT	2			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	77	VEND_PROG_FL	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	78	RISK_LEVEL_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	79	RISK_SCORE_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	80	RISK_ASGN_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BILL_ACCOUNT	81	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	82	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	83	AR_OPT_OUT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_BILL_ACCOUNT	84	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	2	BILL_HEAD_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	3	BILL_COMP_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	4	TOT_BILL_AT	NUMBER		11	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	5	CUST_CHRG_AT	NUMBER		7	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	6	DMND_CHRG_TOT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	7	ENRG_CHRG_TOT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	8	FUEL_CHRG_TOT_AT	NUMBER		9	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	9	MISC_CHRG_TOT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	10	RCTV_DMND_CHG_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	11	SURC_TOT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	12	TAX_TOT_AT	NUMBER		8	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	13	HIST_CRRC_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	14	TARF_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	15	NMTR_ACTV_UNTS_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	16	PRRT_FCTR_QY	NUMBER		5	4	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	17	REVN_CLAS_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	18	BILL_PERD_FROM_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	19	BILL_PERD_TO_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	20	ORIG_BILL_COMP_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	21	SUPR_BILL_COMP_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	22	SUPR_BILL_HEAD_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	23	ORIG_BILL_HEAD_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	24	BILL_PERD_FR_TM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	25	BILL_PERD_TO_TM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	26	PREM_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	27	TARF_PNT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	28	BILL_COMP_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	29	BILL_COMP_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	30	BILL_COMP_TM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	31	COMP_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	32	SMMR_USAG_HIST_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	33	CUMU_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	34	TARF_MIN_AT	NUMBER		7	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	35	TARF_MAX_AT	NUMBER		7	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	36	BLPM_HIST_EXIST_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	37	BB_ESTM_AT	NUMBER		7	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	38	FNNC_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	39	FNNC_TS_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	40	BB_ESTM_MTHD_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	41	PRORATE_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	42	SCHD_BILL_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	43	DIST_CHRG_AT	NUMBER		11	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	44	GEN_CHRG_AT	NUMBER		11	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	45	TRANS_CHRG_AT	NUMBER		11	2	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	46	TARF_CUS_CHOICE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	47	PTC_RT_VALUE	NUMBER		3	3	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	48	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	49	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_COMPONENT	50	TAX_DSTC_CD	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BILL_COMPONENT	51	COMP_ON_CYCLE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_COMPONENT	52	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_HEADER	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	2	BILL_HEAD_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_HEADER	3	BILL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	4	DPC_CALC_TOT_AT	NUMBER		8	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	5	MTRD_BILL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	6	NON_MTRD_TOT_AT	NUMBER		8	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	7	BDGT_BILL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	8	SPCL_HNDL_PERF_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	9	ADDL_BLLS_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_BILL_HEADER	10	OFFR_BB_PLAN_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	11	TOTL_BILL_DUE_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	12	CNSL_BILL_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	13	EXCS_CRDT_APPL_AT	NUMBER		8	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	14	BILL_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_HEADER	15	ACCT_BAL_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	16	ON_CYCLE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	17	BILL_HEAD_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	18	BILL_HEAD_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	19	BILL_TM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	20	BILL_DUE_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_HEADER	21	BB_ESTM_AT	NUMBER		7	2	NO
UTLUSER	ODS_MCS_BILL_HEADER	22	EDI_BILL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	23	STORE_ID_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	24	EDI_CUST_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	25	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BILL_HEADER	26	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BILL_HEADER	27	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BUS_DIR	1	BILL_ACCT_NB	TEXT	10			NO
UTLUSER	ODS_MCS_BUS_DIR	2	PROD_ORDR_NB	NUMBER		38	0	NO
UTLUSER	ODS_MCS_BUS_DIR	3	DIR_TYPE_CD	TEXT	4			NO
UTLUSER	ODS_MCS_BUS_DIR	4	CO_CD_OWNR	TEXT	2			YES
UTLUSER	ODS_MCS_BUS_DIR	5	BAL_DUE_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	6	BSNS_BAL_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	7	DFRR_BAL_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	8	INIT_PYMN_DPMT_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	9	FINL_INSM_AT	NUMBER		9	2	YES
UTLUSER	ODS_MCS_BUS_DIR	10	INSM_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	11	TOT_INSM_BSNS_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	12	FNNC_CHRG_AT	NUMBER		9	2	YES
UTLUSER	ODS_MCS_BUS_DIR	13	UNPR_BAL_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	14	PAYABLE_BAL_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_BUS_DIR	15	BSNS_CD	TEXT	3			YES
UTLUSER	ODS_MCS_BUS_DIR	16	BSNS_STAT_CD	TEXT	1			YES
UTLUSER	ODS_MCS_BUS_DIR	17	BSNS_TYPE_CD	TEXT	2			YES
UTLUSER	ODS_MCS_BUS_DIR	18	FREQ_CD	TEXT	2			YES
UTLUSER	ODS_MCS_BUS_DIR	19	PYMN_MTHD_CD	TEXT	1			YES
UTLUSER	ODS_MCS_BUS_DIR	20	BSNS_SET_UP_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_DIR	21	BILL_WITH_SRVC_FL	TEXT	1			YES
UTLUSER	ODS_MCS_BUS_DIR	22	ANNL_PRCN_RT_PC	NUMBER		3	1	YES
UTLUSER	ODS_MCS_BUS_DIR	23	INSM_QY	NUMBER		38	0	YES
UTLUSER	ODS_MCS_BUS_DIR	24	REMN_INSM_QY	NUMBER		38	0	YES
UTLUSER	ODS_MCS_BUS_DIR	25	FIRST_INSM_DUE_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_DIR	26	INIT_PYMN_DUE_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_DIR	27	LAST_TRAN_UPDT_NM	TEXT	8			YES
UTLUSER	ODS_MCS_BUS_DIR	28	LAST_UPDT_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_DIR	29	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	2	PROD_ORDR_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	3	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	4	PAY_ARRG_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	5	DFLT_PAGR_DSCN_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	6	STAT_LAST_CHNG_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	7	CNFR_LTTR_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	8	PAY_AGRM_AGCY_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	9	PAY_AGRM_BILL_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	10	REVW_ON_DFLT_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	11	RESN_DELE_TX	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	12	CNCL_DFLT_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	13	PA_RESN_CRTD_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	14	EXTN_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	15	EXTN_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	16	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	17	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	18	IPR_STATUS_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	19	IPR_ACTION_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	20	DFLT_PAGR_REMN_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	21	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	2	CRDT_CRTN_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	3	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	4	PYMN_CRDT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	5	APPL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	6	PYMN_CRDT_SORC_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	7	SHOW_ON_BILL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	8	TRF_BETWEEN_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	9	PYMN_CRDT_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	10	TRANS_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	11	CASH_BTCH_NB	NUMBER		38	0	NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	12	PYMN_SEQ_NB	NUMBER		38	0	NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	13	AGNT_CMMR_COLL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	14	PYMN_CSHR_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	15	HIST_CRRC_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	16	PYMN_IND_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	17	BILL_HEAD_NB	NUMBER		38	0	NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	18	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	19	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_CREDIT_SOURCE	20	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_CUSTOMER	1	CUST_NB	TEXT	9			NO
UTLUSER	ODS_MCS_CUSTOMER	2	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_CUSTOMER	3	RSDN_CORP_IND_CD	TEXT	1			NO
UTLUSER	ODS_MCS_CUSTOMER	4	SRVY_SENT_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_CUSTOMER	5	CUST_NM_INFO_FL	TEXT	1			NO
UTLUSER	ODS_MCS_CUSTOMER	6	OWNR_AGNT_FLAG_FL	TEXT	1			NO
UTLUSER	ODS_MCS_CUSTOMER	7	NFNC_CNTL_UNIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_CUSTOMER	8	CRPR_AFFL_NM	TEXT	20			NO
UTLUSER	ODS_MCS_CUSTOMER	9	CUST_1ST_1_NM	TEXT	35			NO
UTLUSER	ODS_MCS_CUSTOMER	10	CUST_LAST_1_NM	TEXT	35			NO
UTLUSER	ODS_MCS_CUSTOMER	11	CUST_MDDL_1_NM	TEXT	20			NO
UTLUSER	ODS_MCS_CUSTOMER	12	CUST_PRFX_1_NM	TEXT	4			NO
UTLUSER	ODS_MCS_CUSTOMER	13	CUST_SFFX_1_NM	TEXT	3			NO
UTLUSER	ODS_MCS_CUSTOMER	14	CUST_1ST_2_NM	TEXT	20			NO
UTLUSER	ODS_MCS_CUSTOMER	15	CUST_LAST_2_NM	TEXT	20			NO
UTLUSER	ODS_MCS_CUSTOMER	16	CUST_MDDL_2_NM	TEXT	20			NO
UTLUSER	ODS_MCS_CUSTOMER	17	CUST_PRFX_2_NM	TEXT	4			NO
UTLUSER	ODS_MCS_CUSTOMER	18	CUST_SFFX_2_NM	TEXT	3			NO
UTLUSER	ODS_MCS_CUSTOMER	19	CUST_ENVL_OVRR_FL	TEXT	1			NO
UTLUSER	ODS_MCS_CUSTOMER	20	CRDT_RTNG_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_CUSTOMER	21	HNDBK_SENT_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_CUSTOMER	22	TAX_ID	TEXT	9			NO
UTLUSER	ODS_MCS_CUSTOMER	23	CRDT_RTNG_RECV_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_CUSTOMER	24	ENERGY_DVRSN_FL	TEXT	1			NO
UTLUSER	ODS_MCS_CUSTOMER	25	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_CUSTOMER	26	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_CUSTOMER	27	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	2	DIR_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	3	PROD_ORDR_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	4	DEBT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	5	DEBT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	6	REMN_DEBT_AT	NUMBER		10	2	NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	7	BSNS_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	8	DEBT_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	9	HIST_CRRC_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	10	SHOW_ON_BILL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	11	SORC_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	12	BSNS_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	13	TRF_BETWEEN_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	14	DEBT_DUE_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	15	REVN_YEAR_MNTH_DT	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	16	AGE_OF_DEBIT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	17	PAGR_PRDN_ORDR_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	18	BILL_HEAD_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	19	DEBT_PRCS_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	20	AR_SORT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	21	ELEC_BSNS_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	22	BILL_COMP_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	23	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	24	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	25	RCVR_TYPE_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	26	CHRG_OFF_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	27	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_INDICATIV_DATA	1	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	2	PREM_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	3	CUST_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	4	NAME_IDNT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	5	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	6	STATE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	7	JRSD_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	8	DVSN_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	9	AREA_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	10	SER_HALF_IND_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	11	SERV_CITY_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	12	SERV_HOUS_NBR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	13	SERV_PTDR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	14	SERV_PRDR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	15	RURL_RTE_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	16	ROUTE_NB_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	17	BOX_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	18	SERV_ST_DSGT_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	19	SERV_ST_NAME_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	20	SERV_UNIT_DSGT_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	21	SERV_UNIT_NBR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	22	SERV_ZIP_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	23	ACCT_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	24	ACCT_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	25	LIFE_SPPR_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	26	REVN_CLAS_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	27	ST_CD_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	28	TARF_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	29	TLPH_USE_1_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	30	TLPH_USE_2_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	31	PREM_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	32	ACCT_CLAS_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	33	RSDN_CORP_IND_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	34	SIC_CD	NUMBER		10	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	35	TURN_OFF_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_INDICATIV_DATA	36	TURN_ON_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_INDICATIV_DATA	37	LCI_ACCT_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	38	CYCL_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	39	MTR_RDG_RTE_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	40	OLD_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	41	TLPH_1_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	42	TLPH_2_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	43	CUST_1ST_1_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	44	CUST_LAST_1_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	45	CUST_MDDL_INIT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	46	CUST_PRFX_1_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	47	CUST_SFFX_1_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	48	TAX_DSTC_CD	NUMBER		10	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	49	CUMU_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	50	FNNC_CNTL_UNIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_INDICATIV_DATA	51	OUT_OF_BAL_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	52	SCHD_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	53	VEND_PROG_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	54	POWER_POOL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	55	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_INDICATIV_DATA	56	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_INDICATIV_DATA	57	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_NOTES	1	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	2	CRTN_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_NOTES	3	NOTE_PRRT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	4	NOTE_FRMT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	5	USER_IDNT_CRTD_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	6	USER_IDNT_UPDT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	7	NOTE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	8	NOTE_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_NOTES	9	LAST_UPD_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_NOTES	10	LAST_UPD_TM	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	11	ORGN_CONV_ID_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	12	NOTE_DESC_TX	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	13	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	14	CUST_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	15	PREM_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	16	STATE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	17	DVSN_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	18	AREA_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	19	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_NOTES	20	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_NOTES	21	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_PREMISE	1	PREM_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	2	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	3	SER_HALF_IND_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	4	SERV_CITY_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	5	SERV_HOUS_NBR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	6	SERV_PTDR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	7	SERV_PRDR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	8	ADDL_SRV_DATA_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	9	STATE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	10	SERV_ST_NAME_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	11	SERV_ST_DSGT_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	12	SERV_UNIT_DSGT_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	13	SERV_UNIT_NBR_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	14	SERV_ZIP_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	15	ST_CD_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	16	CARI_RTE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	17	IRRG_USE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	18	LOAD_AREA_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	19	REDDY_CRCT_CENT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	20	PREM_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	21	SRVC_ENTN_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	22	AREA_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	23	CUMU_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	24	TAX_DSTC_CD	NUMBER		10	0	NO
UTLUSER	ODS_MCS_PREMISE	25	DVSN_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	26	LAST_RRTE_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE	27	NFNC_CNTL_UNIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_PREMISE	28	CYCL_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_PREMISE	29	KEY_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_PREMISE	30	MTR_RDG_RTE_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	31	OA_AGRM_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	32	RDG_SEQ_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_PREMISE	33	SERV_MAIL_CITY_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	34	RURL_RTE_TYPE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	35	ROUTE_NB_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	36	BOX_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	37	MTR_RTE_OWNR_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_PREMISE	38	SRVC_POLE_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	39	TRSF_POLE_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	40	HSNG_CTGY_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	41	SUB_AREA_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	42	DELV_PT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	43	SRVC_ST_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	44	MAIL_ZIP_AD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	45	POWER_POOL_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	46	MTR_REDR_ID	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	47	IRRG_USE_EFCT_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE	48	PRX_VERIFY_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE	49	FIPS_ANNEX_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE	50	ANNEX_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	51	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	52	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_PREMISE	53	AMI_FTPRNT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_PREMISE	54	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	1	PREM_NB	TEXT	9			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	2	NANO_4_TS	NUMBER		5	0	NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	3	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	4	EQPM_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	5	EQPM_SUB_TYP_CD	TEXT	2			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	6	EQPM_TYPE_CD	TEXT	2			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	7	EQPM_PHS_CD	TEXT	1			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	8	INST_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE_EQUIP	9	EQPM_LEAS_FNNC_CD	TEXT	1			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	10	EQPM_WRRN_FL	TEXT	1			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	11	EQPM_SZ_QY	NUMBER		6	1	NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	12	EQPM_GEN_TYP_CD	TEXT	3			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	13	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	14	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_PREMISE_EQUIP	15	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_PREMISE_EXT	1	PREM_ID	TEXT	13			NO
UTLUSER	ODS_MCS_PREMISE_EXT	2	PREM_NB	TEXT	9			NO
UTLUSER	ODS_MCS_PREMISE_EXT	3	TARF_PNT_NB	TEXT	4			YES
UTLUSER	ODS_MCS_PREMISE_EXT	4	TARF_CD	NUMBER		38	18	YES
UTLUSER	ODS_MCS_PREMISE_EXT	5	PRMR_TARF_FL	TEXT	4			YES
UTLUSER	ODS_MCS_PREMISE_EXT	6	TARF_PT_STAT_CD	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	7	TYPE_OF_SRVC_CD	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	8	JURISDICTION_CD	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	9	FRST_TURN_ON_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE_EXT	10	LAST_TURN_OFF_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE_EXT	11	SRVC_ADDR_1_NM	TEXT	50			YES
UTLUSER	ODS_MCS_PREMISE_EXT	12	SRVC_ADDR_2_NM	TEXT	50			YES
UTLUSER	ODS_MCS_PREMISE_EXT	13	SRVC_ADDR_3_NM	TEXT	50			YES
UTLUSER	ODS_MCS_PREMISE_EXT	14	SRVC_ADDR_4_NM	TEXT	50			YES
UTLUSER	ODS_MCS_PREMISE_EXT	15	SRVC_ADDR_5_NM	TEXT	50			YES
UTLUSER	ODS_MCS_PREMISE_EXT	16	COUNTY_CD	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	17	COUNTY_NM	TEXT	50			YES
UTLUSER	ODS_MCS_PREMISE_EXT	18	HEAT_TYP_CD	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	19	HEAT_SRC_FUEL_TYP_CD	TEXT	25			YES
UTLUSER	ODS_MCS_PREMISE_EXT	20	OWN_HOME_FL	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	21	SEASONAL_FL	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	22	BKUP_GEN_FL	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	23	CO_GEN_FL	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	24	NAICS_CD	TEXT	10			YES
UTLUSER	ODS_MCS_PREMISE_EXT	25	CURR_BILL_ACCT_NB	TEXT	10			YES
UTLUSER	ODS_MCS_PREMISE_EXT	26	CURR_BILL_ACCT_ID	TEXT	14			YES
UTLUSER	ODS_MCS_PREMISE_EXT	27	CURR_CUST_NM	TEXT	70			YES
UTLUSER	ODS_MCS_PREMISE_EXT	28	CURR_ACCT_CLS_CD	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	29	CURR_RVN_CLS_CD	NUMBER		5	0	YES
UTLUSER	ODS_MCS_PREMISE_EXT	30	PR12MO_KWH_MSR	NUMBER		15	3	YES
UTLUSER	ODS_MCS_PREMISE_EXT	31	PR12MO_MAX_DMND_MSR	NUMBER		10	3	YES
UTLUSER	ODS_MCS_PREMISE_EXT	32	WTHR_STN_CD	TEXT	5			YES
UTLUSER	ODS_MCS_PREMISE_EXT	33	DSTRBD_GEN_IND_CD	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	34	DSTRBD_GEN_TYP_CD	TEXT	3			YES
UTLUSER	ODS_MCS_PREMISE_EXT	35	DSTRBD_GEN_INSTL_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE_EXT	36	DSTRBD_GEN_CAPCTY_NB	NUMBER		6	1	YES
UTLUSER	ODS_MCS_PREMISE_EXT	37	ENRGY_DVRN_FL	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	38	ENRGY_DVRN_CD	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	39	ENRGY_DVRN_DT	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	40	CURR_ENRGY_EFNCY_PRTCPNT_FL	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	41	CURR_ENRGY_EFNCY_PGM_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_PREMISE_EXT	42	CURR_ENRGY_EFNCY_PGM_CD	TEXT	2			YES
UTLUSER	ODS_MCS_PREMISE_EXT	43	LATITUDE_NB	TEXT	12			YES
UTLUSER	ODS_MCS_PREMISE_EXT	44	LONGITUDE_NB	TEXT	12			YES
UTLUSER	ODS_MCS_PREMISE_EXT	45	OMS_AREA_NB	TEXT	4			YES
UTLUSER	ODS_MCS_PREMISE_EXT	46	CIRCUIT_NB	TEXT	7			YES
UTLUSER	ODS_MCS_PREMISE_EXT	47	STATION_NB	TEXT	6			YES
UTLUSER	ODS_MCS_PREMISE_EXT	48	CIRCUIT_NM	TEXT	35			YES
UTLUSER	ODS_MCS_PREMISE_EXT	49	STATION_NM	TEXT	35			YES
UTLUSER	ODS_MCS_PREMISE_EXT	50	CMSG_MTR_MULT_CD	TEXT	1			YES
UTLUSER	ODS_MCS_PREMISE_EXT	51	EEDR_FL	TEXT	1			NO
UTLUSER	ODS_MCS_PREMISE_EXT	52	ESI_ID	TEXT	30			YES
UTLUSER	ODS_MCS_PREMISE_EXT	53	PROFILE_ID	TEXT	30			YES
UTLUSER	ODS_MCS_PREMISE_EXT	54	MD5_TX	TEXT	36			YES
UTLUSER	ODS_MCS_PREMISE_EXT	55	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_SERV_DELIV_ID	1	PREM_NB	TEXT	9			NO
UTLUSER	ODS_MCS_SERV_DELIV_ID	2	SERV_DLVR_ID	TEXT	10			NO
UTLUSER	ODS_MCS_SERV_DELIV_ID	3	TARF_PNT_NB	TEXT	4			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	4	MNDTY_DATA_TX	TEXT	2			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	5	DOE_NB	TEXT	5			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	6	BLOK_SDI_CD	TEXT	1			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	7	RES_LOAD_IND_OVRD_ID	TEXT	1			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	8	PROFILE_ID	TEXT	30			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	9	LOC_TYP_CD	TEXT	10			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	10	LAST_TRAN_UPDT_NM	TEXT	8			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	11	LAST_UPDT_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	12	MKT_PRVSN_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	13	LOAD_BUS_ID	TEXT	40			YES
UTLUSER	ODS_MCS_SERV_DELIV_ID	14	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	1	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	2	STATION_NB	TEXT	6			NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	3	CIRCUIT_NB	TEXT	7			NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	4	STATION_NM	TEXT	35			NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	5	CIRCUIT_NM	TEXT	35			NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	6	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_STATN_CIRC_NM	7	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_STATN_CIRC_XRF	1	PREM_NB	TEXT	9			NO
UTLUSER	ODS_MCS_STATN_CIRC_XRF	2	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_STATN_CIRC_XRF	3	STATION_NB	TEXT	6			NO
UTLUSER	ODS_MCS_STATN_CIRC_XRF	4	CIRCUIT_NB	TEXT	7			NO
UTLUSER	ODS_MCS_STATN_CIRC_XRF	5	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_STATN_CIRC_XRF	6	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	1	PREM_NB	TEXT	9			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	2	TARF_PNT_NB	TEXT	4			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	3	EFCT_BIL_PARM_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	4	CO_CD_OWNR	TEXT	2			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	5	EQPM_ADJS_FLAG_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	6	OFPK_FRNC_LOAD_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	7	OTHR_SORC_ENRG_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	8	EXPR_BIL_PARM_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	9	CMSG_MTR_MULT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	10	RSDN_SRVC_MULT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	11	ELEC_DMND_PROV_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	12	SCHL_ROOM_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	13	SQUR_FEET_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	14	SEPA_KW_CRDT_QY	NUMBER		6	1	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	15	HI_DMND_RT_IND_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	16	SEPR_MTRG_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	17	SEPA_KWH_CRDT_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	18	EMP_ASSC_CO_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	19	EMP_CD_CD	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	20	DMND_CHRG_LOAD_CD	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	21	ESTM_PERMISSION_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	22	DMND_CHCK_PNT_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	23	PRORATE_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	24	LWR_DMND_RATE_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	25	USE_HI_KW_KVA_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	26	USE_HI_KVAR_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	27	USE_HI_REACT_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	28	LOCAL_TAX_ADJ_RT	NUMBER		6	6	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	29	DLY_DMND_RDR_KW_QY	NUMBER		7	1	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	30	UNMT_SRVC_MULT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	31	SUPP_INTR_BILL_QY	NUMBER		10	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	32	BILL_PARM_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	33	ADDL_TRFM_CAP_QY	NUMBER		7	1	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	34	DSM_SRCH_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	35	OFF_PEAK_KW_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	36	TOD_DISC_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	37	THREE_LVL_CMM_CD	TEXT	2			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	38	PWR_FCTR_PLTY_FL	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	39	ENRG_ADJ_FCTR_QY	NUMBER		14	7	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	40	DMND_ADJ_FCTR_QY	NUMBER		14	7	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	41	MIN_ADJ_FCTR_QY	NUMBER		14	7	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	42	CIAC_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	43	DLC_PGM_CD	TEXT	1			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	44	DLC_UNIT_QY	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	45	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	46	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	47	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARIFF_POINT	1	PREM_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	2	TARF_PNT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	3	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	4	TARF_CD	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARIFF_POINT	5	PRMR_TARF_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	6	NFNC_CNTL_UNIT_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARIFF_POINT	7	ENGN_NB	NUMBER		5	0	NO
UTLUSER	ODS_MCS_TARIFF_POINT	8	TYPE_OF_SRVC_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	9	STATE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	10	TARF_PT_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	11	DLVR_VOLT_QY	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	12	DLVR_VOLT_2_QY	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	13	PHASE_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	14	PHASE_2_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	15	RCNCLD_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARIFF_POINT	16	RCNCLD_STAT_CD	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	17	PUR_CMPL_DT	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARIFF_POINT	18	PUR_ERR_FL	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	19	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MCS_TARIFF_POINT	20	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TARIFF_POINT	21	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TRANS_HIST_HDR	1	CO_CD_OWNR	TEXT	16777216			NO
UTLUSER	ODS_MCS_TRANS_HIST_HDR	2	BILL_ACCT_NB	TEXT	16777216			NO
UTLUSER	ODS_MCS_TRANS_HIST_HDR	3	CNV_ID	TEXT	16777216			NO
UTLUSER	ODS_MCS_TRANS_HIST_HDR	4	RVRS_TS_20_TX	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	5	TS_20_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_TRANS_HIST_HDR	6	ORDR_NB	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	7	DVSN_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	8	AREA_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	9	STATE_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	10	CUST_NB	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	11	PREM_NB	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	12	CUST_CMPN_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	13	ORDR_CMPL_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	14	ORDR_EFCT_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	15	ORDR_CRTN_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	16	ORDR_FUNC_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	17	ORDR_RESN_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	18	ORDR_STAT_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	19	USER_ID	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	20	SCRN_CRTN_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	21	RMRK_TX	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	22	LAST_TRNS_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	23	RVRS_TS_NB	NUMBER		15	0	YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	24	TS_NB	NUMBER		15	0	YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	25	UPTR_TRMN_ID_NB	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	26	TRNS_AT	NUMBER		10	2	YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	27	CRDT_COLL_ACTN_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	28	COLL_ACTV_CTGY_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	29	RMRK_4_TX	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	30	TRAN_HIST_STAT_CD	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	31	LAST_TRAN_UPDT_NM	TEXT	16777216			YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	32	LAST_UPDT_TS	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_TRANS_HIST_HDR	33	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	1	WEB_ID	TEXT	320			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	2	BILL_ACCT_NB	TEXT	10			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	3	WEB_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	4	CUST_NB	TEXT	9			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	5	MSG_TX	TEXT	75			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	6	CRTN_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	7	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	8	BDHV_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	9	BDHV_CONSUMER_ID	TEXT	32			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	10	BDHV_TC_CD	TEXT	1			NO
UTLUSER	ODS_MCS_WEB_BILL_ACCT	11	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_WEB_USER	1	WEB_ID	TEXT	512			NO
UTLUSER	ODS_MCS_WEB_USER	2	WEB_PSWD	TEXT	12			NO
UTLUSER	ODS_MCS_WEB_USER	3	WEB_PSWD_HINT	TEXT	50			NO
UTLUSER	ODS_MCS_WEB_USER	4	BILL_ACCT_NB	TEXT	10			NO
UTLUSER	ODS_MCS_WEB_USER	5	WEB_EMAIL	TEXT	100			NO
UTLUSER	ODS_MCS_WEB_USER	6	WEB_REG_KEY	TEXT	12			NO
UTLUSER	ODS_MCS_WEB_USER	7	WEB_RQST_NM	TEXT	70			NO
UTLUSER	ODS_MCS_WEB_USER	8	WEB_RQST_AD	TEXT	100			NO
UTLUSER	ODS_MCS_WEB_USER	9	PSWD_RQRD_CHG_DT	TIMESTAMP_NTZ				YES
UTLUSER	ODS_MCS_WEB_USER	10	WEB_IND	TEXT	10			NO
UTLUSER	ODS_MCS_WEB_USER	11	WEB_USER_STAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_WEB_USER	12	WEB_FIRST_NM	TEXT	35			NO
UTLUSER	ODS_MCS_WEB_USER	13	WEB_LAST_NM	TEXT	35			NO
UTLUSER	ODS_MCS_WEB_USER	14	WEB_PREFIX_NM	TEXT	4			NO
UTLUSER	ODS_MCS_WEB_USER	15	EMAIL_FORMAT_CD	TEXT	1			NO
UTLUSER	ODS_MCS_WEB_USER	16	WEB_SMS	TEXT	256			NO
UTLUSER	ODS_MCS_WEB_USER	17	SMS_QUIET_START_TM	TEXT	8			YES
UTLUSER	ODS_MCS_WEB_USER	18	SMS_QUIET_END_TM	TEXT	8			YES
UTLUSER	ODS_MCS_WEB_USER	19	SMS_QUIET_TZ	TEXT	3			NO
UTLUSER	ODS_MCS_WEB_USER	20	CRTN_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_WEB_USER	21	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_WEB_USER	22	WEB_ID_NB	NUMBER		10	0	NO
UTLUSER	ODS_MCS_WEB_USER	23	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_ZIP_WEATHER	1	SERV_ZIP_AD	TEXT	10			NO
UTLUSER	ODS_MCS_ZIP_WEATHER	2	POWER_POOL_CD	TEXT	1			NO
UTLUSER	ODS_MCS_ZIP_WEATHER	3	WTHR_ZONE_CD	TEXT	5			NO
UTLUSER	ODS_MCS_ZIP_WEATHER	4	LOAD_BUS_ID	TEXT	40			NO
UTLUSER	ODS_MCS_ZIP_WEATHER	5	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_MCS_ZIP_WEATHER	6	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MCS_ZIP_WEATHER	7	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MDS_SERVICE_POINT	1	PREM_NB	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	2	SRVC_PNT_NM	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	3	LAST_TRAN_UPDT_NM	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	4	BSNS_MSG_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	5	LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_MDS_SERVICE_POINT	6	ADDL_INFO_1	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	7	ADDL_INFO_2	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	8	MTR_LOC_IND	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	9	INST_INSP_DATE	NUMBER		8	0	NO
UTLUSER	ODS_MDS_SERVICE_POINT	10	EMP_SER_NBR	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	11	MTR_CBNT_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	12	XFMR_CBNT_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	13	INST_CABL_FT	NUMBER		4	0	NO
UTLUSER	ODS_MDS_SERVICE_POINT	14	COMB_CONN_RATIO	NUMBER		7	2	NO
UTLUSER	ODS_MDS_SERVICE_POINT	15	PULSE_SPLITTER_CNT	NUMBER		2	0	NO
UTLUSER	ODS_MDS_SERVICE_POINT	16	TRND_CNT	NUMBER		2	0	NO
UTLUSER	ODS_MDS_SERVICE_POINT	17	KVA_CAP	NUMBER		6	0	NO
UTLUSER	ODS_MDS_SERVICE_POINT	18	UNGRND_IND	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	19	TYPE_OF_SRVC_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	20	GL_ACCT_NBR	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	21	SITE_NBR	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	22	SOCKET_AMPACITY	NUMBER		3	0	NO
UTLUSER	ODS_MDS_SERVICE_POINT	23	NETWORK_NBR	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	24	NODE	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	25	WATT_IRON_LOSS_D	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	26	WATT_IRON_LOSS_R	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	27	WATT_COPPER_LOSS_D	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	28	WATT_COPPER_LOSS_R	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	29	VAR_IRON_LOSS_D	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	30	VAR_IRON_LOSS_R	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	31	VAR_COPPER_LOSS_D	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	32	VAR_COPPER_LOSS_R	NUMBER		6	4	NO
UTLUSER	ODS_MDS_SERVICE_POINT	33	INTERVAL_DATA	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	34	REMOTE_READ	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	35	READ_TYPE	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	36	CARRIER	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	37	METER_PHONE_NBR	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	38	DIAL_IN	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	39	CALL_TIME	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	40	CUST_XFMR_SER_NBR	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	41	CUST_CONTACTS_FL	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	42	INTRVL_DATA_USE_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	43	PHONE_NBR_OWNR_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	44	CHOICE_PD_UPGRADE	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	45	IDR_RESN_CD	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	46	GPS_LATITUDE_TX	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	47	GPS_LONGITUDE_TX	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	48	CEAS_ID	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	49	LAST_UPDT_ID	TEXT	16777216			NO
UTLUSER	ODS_MDS_SERVICE_POINT	50	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_TERS_PREM_OMS_XREF	1	PREM_NB	TEXT	9			NO
UTLUSER	ODS_TERS_PREM_OMS_XREF	2	OMS_AREA	TEXT	4			NO
UTLUSER	ODS_TERS_PREM_OMS_XREF	3	LAST_TRAN_UPDT_NM	TEXT	8			NO
UTLUSER	ODS_TERS_PREM_OMS_XREF	4	LAST_UPDATE_TS	TIMESTAMP_NTZ				NO
UTLUSER	ODS_TERS_PREM_OMS_XREF	5	TRSF_POLE_NB	TEXT	15			NO
UTLUSER	ODS_TERS_PREM_OMS_XREF	6	EDW_LAST_UPDT_TS	TIMESTAMP_NTZ				NO


/* -----------------------------------------------------------------------------
   Q3  Identity / default columns on the UTLUSER targets.

   Without this, a NOT NULL column the model never populates is indistinguishable
   from one Snowflake fills in automatically. Export separately as
   identity.tsv - do NOT concatenate into catalog.tsv.
   ----------------------------------------------------------------------------- */
SELECT TABLE_SCHEMA,
       TABLE_NAME,
       COLUMN_NAME,
       IS_NULLABLE,
       COLUMN_DEFAULT,
       IS_IDENTITY,
       IDENTITY_START,
       IDENTITY_INCREMENT
FROM UTLDB01.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'UTLUSER'
  AND TABLE_NAME LIKE 'ODS_MCS%'
  AND (IS_IDENTITY = 'YES' OR COLUMN_DEFAULT IS NOT NULL OR IS_NULLABLE = 'NO')
ORDER BY TABLE_NAME, COLUMN_NAME;


TABLE_SCHEMA	TABLE_NAME	COLUMN_NAME	IS_NULLABLE	COLUMN_DEFAULT	IS_IDENTITY	IDENTITY_START	IDENTITY_INCREMENT
UTLUSER	ODS_MCS_ACCT_TAXES	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	TAX_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	TAX_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	TAX_EXMP_1_PC	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	TAX_EXMP_FORM_NB	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	TAX_EXMP_MAN_FL	NO		NO		
UTLUSER	ODS_MCS_ACCT_TAXES	TAX_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_ACCT_XREF	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_ACCT_XREF	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_ACCT_XREF	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_ACCT_XREF	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_ACCT_XREF	XREF_CD	NO		NO		
UTLUSER	ODS_MCS_ACCT_XREF	XREF_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_ACCT_XREF	XREF_EXPR_TS	YES	SYSTEM$NULL_TO_TIMESTAMP_NTZ(null)	NO		
UTLUSER	ODS_MCS_ACCT_XREF	XREF_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	ADDR_ID_AD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	CARI_RTE_CD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	DELV_PT_CD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_ADDRESS	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	MAIL_1_AD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	MAIL_1_NM	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	MAIL_2_AD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	MAIL_2_NM	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	MAIL_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	MAIL_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	OVRI_SRVC_NAME_FL	NO		NO		
UTLUSER	ODS_MCS_ADDRESS	STATE_CD_AD	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	BASE_AT	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	EQUA_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	TOT_EVENT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_BILL_HST	TOT_OPTOUT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	EVENT_ID	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	EVENT_START_DT	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	EVENT_START_TM	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	EVENT_ID	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	EVENT_START_DT	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	EVENT_START_TM	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_DTL_BKUP	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	DEVC_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	DLC_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BA_DLC_DEVC_HDR	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_BA_GREEN_PWR	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BA_GREEN_PWR	GP_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	BILL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	BILL_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	DMND_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	EDI_CNTL_NB	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	HOURS_USED_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	LCI_USAG_EXISTS_FL	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	LOAD_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	NET_USAG_KVARH_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	NET_USAG_KVAR_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	NET_USAG_KVA_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	NET_USAG_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	NET_USAG_KW_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	NET_USAG_QHR_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	PWR_FCTR_CNST_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	PWR_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	RCTV_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	RCTV_HORS_QY	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	READ_CD	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	TIME_OF_DAY_CD	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	TOD_CD_SORT_NB	NO		NO		
UTLUSER	ODS_MCS_BILLABLE_USAGE	USAG_NBR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ACCT_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ACCT_DISPUTE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ACCT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ACCT_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ADDL_BLLS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ADDR_ID_AD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	AR_OPT_OUT_CD	NO	' '	NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ASSS_PGM_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	AUTO_TRF_BA_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	AVG_SRVC_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	BAL_DUE_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	BB_ESTM_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	BILL_CHCK_DIGIT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	BILL_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	CHRG_OFF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	CNSL_BILL_GRP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	CNTA_CO_NBR_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	COLL_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	COLL_HIST_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	CRDT_HIST_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	DFRR_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	DPC_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	EDI_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	EDI_CUST_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	EMP_ASSC_CO_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	EMP_CD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	ENVL_CNTR_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	FNNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	LCI_ACCT_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	LIFE_SPPR_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	MAIL_UNDL_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	MOS_AVG_USG_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	MTHY_ACTV_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	NFNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	OLD_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	OPNN_MTHY_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	OPTED_OUT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	OUT_OF_BAL_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	OWN_HOME_IND_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	PAYABLE_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	PYMN_PRFL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	REF_DEP_CTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	RES_BILL_OVR_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	RISK_LEVEL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	RISK_SCORE_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	RTRN_CHCK_ARRS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	RTRN_CHCK_HIST_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	SCHD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	SIC_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	SLCT_DUE_DAY_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	SPCL_CIRM_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	SPCL_HNDL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	STORE_ID_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	TLPH_2_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	TLPH_USE_1_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	TLPH_USE_2_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	UNDLVR_MAIL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	UNPR_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	UUE_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT	VEND_PROG_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT_EXT	BILL_ACCT_ID	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT_EXT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT_EXT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT_EXT	EEDR_FL	NO	'Y'	NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT_EXT	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_ACCOUNT_EXT	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BB_ESTM_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_COMP_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_COMP_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_COMP_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_PERD_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_PERD_FR_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BILL_PERD_TO_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	BLPM_HIST_EXIST_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	COMP_ON_CYCLE_CD	NO	' '	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	COMP_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	CUST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	DIST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	DMND_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	ENRG_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	FNNC_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	FNNC_TS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	FUEL_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	GEN_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	MISC_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	NMTR_ACTV_UNTS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	ORIG_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	ORIG_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	PRORATE_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	PRRT_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	PTC_RT_VALUE	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	RCTV_DMND_CHG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	SCHD_BILL_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	SMMR_USAG_HIST_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	SUPR_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	SUPR_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	SURC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TARF_CUS_CHOICE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TARF_MAX_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TARF_MIN_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TAX_DSTC_CD	NO	0	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TAX_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TOT_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT	TRANS_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BB_ESTM_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_COMP_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_COMP_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_COMP_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_PERD_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_PERD_FR_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BILL_PERD_TO_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	BLPM_HIST_EXIST_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	COMP_ON_CYCLE_CD	NO	' '	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	COMP_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	CUST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	DIST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	DMND_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	ENRG_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	FNNC_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	FNNC_TS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	FUEL_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	GEN_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	MISC_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	NMTR_ACTV_UNTS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	ORIG_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	ORIG_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	PRORATE_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	PRRT_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	PTC_RT_VALUE	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	RCTV_DMND_CHG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	SCHD_BILL_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	SMMR_USAG_HIST_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	SUPR_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	SUPR_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	SURC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TARF_CUS_CHOICE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TARF_MAX_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TARF_MIN_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TAX_DSTC_CD	NO	0	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TAX_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TOT_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_JBA	TRANS_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BB_ESTM_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_COMP_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_COMP_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_COMP_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_PERD_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_PERD_FR_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BILL_PERD_TO_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	BLPM_HIST_EXIST_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	COMP_ON_CYCLE_CD	NO	' '	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	COMP_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	CUST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	DIST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	DMND_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	ENRG_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	FNNC_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	FNNC_TS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	FUEL_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	GEN_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	MISC_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	NMTR_ACTV_UNTS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	ORIG_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	ORIG_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	PRORATE_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	PRRT_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	PTC_RT_VALUE	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	RCTV_DMND_CHG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	SCHD_BILL_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	SMMR_USAG_HIST_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	SUPR_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	SUPR_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	SURC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TARF_CUS_CHOICE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TARF_MAX_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TARF_MIN_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TAX_DSTC_CD	NO	0	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TAX_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TOT_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_SAVE	TRANS_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BB_ESTM_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_COMP_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_COMP_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_COMP_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_PERD_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_PERD_FR_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BILL_PERD_TO_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	BLPM_HIST_EXIST_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	COMP_ON_CYCLE_CD	NO	' '	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	COMP_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	CUST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	DIST_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	DMND_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	ENRG_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	FNNC_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	FNNC_TS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	FUEL_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	GEN_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	MISC_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	NMTR_ACTV_UNTS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	ORIG_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	ORIG_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	PRORATE_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	PRRT_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	PTC_RT_VALUE	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	RCTV_DMND_CHG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	SCHD_BILL_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	SMMR_USAG_HIST_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	SUPR_BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	SUPR_BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	SURC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TARF_CUS_CHOICE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TARF_MAX_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TARF_MIN_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TAX_DSTC_CD	NO	0	NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TAX_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TOT_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_COMPONENT_TEMP	TRANS_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	ACCT_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	ADDL_BLLS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BDGT_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_DUE_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_HEAD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_HEAD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	BILL_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	CNSL_BILL_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	DPC_CALC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	EDI_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	EDI_CUST_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BILL_HEADER	EXCS_CRDT_APPL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	MTRD_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	NON_MTRD_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	OFFR_BB_PLAN_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	ON_CYCLE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	SPCL_HNDL_PERF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	STORE_ID_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER	TOTL_BILL_DUE_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	ACCT_BAL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	ADDL_BLLS_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BB_ESTM_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BDGT_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_DUE_DT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_HEAD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_HEAD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	BILL_TM	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	CNSL_BILL_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	DPC_CALC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	EDI_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	EDI_CUST_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	EXCS_CRDT_APPL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	MTRD_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	NON_MTRD_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	OFFR_BB_PLAN_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	ON_CYCLE_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	SPCL_HNDL_PERF_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	STORE_ID_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_HEADER_TEMP	TOTL_BILL_DUE_AT	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	ADDL_TRFM_CAP_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	BKUP_SRVC_LVL_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CGEN_KWH_OFPK_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CGEN_KWH_ONPK_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CGEN_KW_OFPK_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CGEN_KW_ONPK_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CIAC_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CMSG_MTR_MULT_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	CURT_BILL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DLC_PGM_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DLC_UNIT_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DLY_DMND_RDR_KW_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DMND_ADJ_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DMND_CHCK_PNT_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DMND_CHRG_LOAD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	DSM_SRCH_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	EFCT_BIL_PARM_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	ELCR_FERR_USG_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	ELCR_TAX_CRDT_RT	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	ELEC_DMND_PROV_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	EMP_ASSC_CO_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	EMP_CD_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	ENRG_ADJ_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	EQPM_ADJS_FLAG_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	ESTM_PERMISSION_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	EST_HIST_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	HEAT_PUMP_KW_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	HI_DMND_RT_IND_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	LOCAL_TAX_ADJ_RT	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	LWR_DMND_RATE_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	MIN_ADJ_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	OFF_PEAK_KW_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	OFPK_FRNC_LOAD_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	OTHR_SORC_ENRG_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	PRORATE_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	PWR_FCTR_PLTY_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	RSDN_SRVC_MULT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	SCHL_ROOM_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	SEPA_KWH_CRDT_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	SEPA_KW_CRDT_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	SEPR_MTRG_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	SQUR_FEET_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	SUPP_INTR_BILL_QY	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	THREE_LVL_CMM_CD	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	TOD_DISC_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	UNMT_SRVC_MULT_NB	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	USE_HI_KVAR_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	USE_HI_KW_KVA_FL	NO		NO		
UTLUSER	ODS_MCS_BILL_PARM_HIST	USE_HI_REACT_FL	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	BASE_AT	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	CNDT_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	EQTN_CD	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	EQUA_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	LINE_OF_BUS_CD	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	STEP_RATE	NO		NO		
UTLUSER	ODS_MCS_BIL_COMP_DTL	TAX_EXMP_REVN_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	ASSS_AUTH_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	ASSS_DISC_PCT_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	ASSS_DISC_RATE_RT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	ASSS_EFCT_RVMN_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	ASSS_EXPR_RVMN_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	ASSS_REMN_AUTH_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_ACTV_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_DCMN_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_LOAD_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_PGM_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_SETUP_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	PYMN_ASSS_STAT_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	RMRK_TX	NO		NO		
UTLUSER	ODS_MCS_BUS_ASST_PROG	VENDOR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_ACTV	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_ACTV	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_ACTV	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_BB_ACTV	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_ACCM_DFRR_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_ANNV_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_BDGT_BLLD_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_CHG_USE_5_YR_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_CHG_USE_YR_1_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_CHG_USE_YR_2_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_CHNG_RESN_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_CHNG_RESN_TX	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_INIT_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_MSG_ISSUED_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_OVRI_AUT_CHG_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_OVRI_RMVL_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_OVR_CHG_HIST_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_OVR_RMV_HST_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BB_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	CHG_USE_YR_3_5_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	CUR_BB_REVW_TYP_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_BB_HEADER	RFND_EXCS_CRDT_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_DIR	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DIR	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_DIR	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	ACCM_ITRS_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	CRDT_CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DPST_ACTV_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DPST_ACTV_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DPST_ACTV_RFND_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DPST_ACTV_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DPST_PYMN_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DPST_RFND_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	FR_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_DPST_ACTV	TO_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	CNCL_DFLT_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	CNFR_LTTR_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	DFLT_PAGR_REMN_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	EXTN_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	IPR_ACTION_CD	NO	'N'	NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	IPR_STATUS_FL	NO	'N'	NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	PAY_AGRM_AGCY_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	PAY_AGRM_BILL_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	PAY_ARRG_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	PA_RESN_CRTD_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	RESN_DELE_TX	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	REVW_ON_DFLT_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX	STAT_LAST_CHNG_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	CNCL_DFLT_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	CNFR_LTTR_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	DFLT_PAGR_REMN_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	EXTN_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	IPR_ACTION_CD	NO	'N'	NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	IPR_STATUS_FL	NO	'N'	NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	PAY_AGRM_AGCY_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	PAY_AGRM_BILL_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	PAY_ARRG_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	PA_RESN_CRTD_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	RESN_DELE_TX	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	REVW_ON_DFLT_FL	NO		NO		
UTLUSER	ODS_MCS_BUS_PA_CRDT_EX_TEMP	STAT_LAST_CHNG_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	BB_DFRR_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PIP_ACTV_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PIP_ACTV_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PIP_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PIP_BILL_AT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PIP_DFRR_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PRE_PIP_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	RECVRD_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_ACTV	UNRECVRD_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	ARR_CRDT_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	BB_ANNV_MO_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	CLIENT_ID	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	CRDT_ARREARAGE_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	FR_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HEAP_FUEL_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HEAP_HSEHLD_QY	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HEAP_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HEAP_POVERTY_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HEAP_RCVD_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HEAT_SRC_TYP_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	HSHLD_SZ_QY	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	INACTV_RSN_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	LAST_MO_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	LAST_RCOVRD_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_BB_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_EFCTV_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_SETUP_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PIP_STAT_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	POST_PIPP_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PRE_PIP_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	RECOVERED_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	REVERIFY_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	THREE_MO_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	TOT_HSHLD_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	TO_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HDR	UNRECOVERED_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	ARR_CRDT_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	BB_ANNV_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	CLIENT_ID	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	DISPUTE_EXPR_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HEAP_FUEL_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HEAP_HSEHLD_QY	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HEAP_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HEAP_POVERTY_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HEAP_RECV_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HEAT_SORC_TYPE	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	HSEHLD_SIZE_QY	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	INACT_REAS_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	LAST_MONTH_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_ACTV_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_BB_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_ORIG_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_PC	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_SETUP_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PIP_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	POST_PIPP_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	REVERIF_DT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	THREE_MNTH_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_BUS_PIP_HIST	TOT_HSEHLD_INCM_AT	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	CLDR_DT	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	CLDR_MNTH_YR_DT_NB	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	DAY_OF_WK_TX	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CALENDAR	SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	TYPE_OF_DAY_CD	NO		NO		
UTLUSER	ODS_MCS_CALENDAR	WORK_DAY_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_CONTACT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_CONTACT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CDT_CONTACT	EMAIL_ADDRESS	NO		NO		
UTLUSER	ODS_MCS_CDT_CONTACT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CDT_CONTACT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CDT_CONTACT	TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_CONTACT	TLPH_2_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	BILL_RSPNS_AGR_LVL	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	DELIV_TYPE_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	DIST_ZONE_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	ESP_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	GOVT_AGG_GRP_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	LBLTY_EFCT_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	LBLTY_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	MDCH_SERV_DELIV_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	READ_FREQ	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	READ_IND_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	REGISTRATION_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	SYS_END_TS	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	SYS_ID_TS	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_DELIV	SYS_START_TS	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	BA_REG_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	CERT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	COMPANY_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	CONTACT_NM	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	DIST_ZONE_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	DP_BUYS_RECV_FL	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	DUN_BRAD_ID_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	ESP_BUYS_RECV_FL	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	FAX_1_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	JRSD_DESC	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	JRSD_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	LDC_CERT_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	MAIL_1_AD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	MAIL_2_AD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	MAIL_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	MAIL_ZIP_4_AD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	MAIL_ZIP_5_AD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	MZO_CERT_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	NOTIF_METH_ORDR_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	NOTIF_METH_OUT_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	OPT_EXCPT_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	PROV_EFCT_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	PROV_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	REGISTRATION_ID	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	RESN_LEFT_MKT_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	RTL_SERV_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	SERV_PROV_NM	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	STATE_CD_AD	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	STATE_CERT_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_CDT_SERV_PROV	WEB_ADDR_AD	NO		NO		
UTLUSER	ODS_MCS_CLOSE_ORDR	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CLOSE_ORDR	ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	CNJ_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	CNSL_BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	CNSL_BILL_GRP_NB	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	CNSL_BILL_ID_NB	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	CNSL_BILL_PRT_CD	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	CNSL_DEL_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CNSL_BILL_DTL	LST_CNSL_BIL_HD_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	ACCT_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	BILL_CYCL_REV_DT	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	CANCEL_RSN_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ACTV_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ACTV_CTGY_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ACTV_DT	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ACTV_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ACTV_PROC_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ACTV_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_CUST_CNTC_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	COLL_ORDR_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	CORRS_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	CRDT_COLL_ACTN_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	CRDT_REVIEW_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	DFRR_PYMN_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	DISC_PAST_DUE_AT	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	DN_DPST_QUOTE_AT	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	DSCN_NOTC_SENT_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	EMOT_INCP_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	FLD_WORK_PERF_TM	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	MDC_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	MENT_INCP_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	MISC_COLL_AMT_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	MISC_COLL_AT	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	MTR_RDG_RTE_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	ORDR_RESN_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	OVER_65_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	PHONE_CONTACT_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	PHYS_INCP_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	PRSN_CNTC_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	PYMN_PLAN_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	RISK_LEVEL_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	THRD_PRTY_NOTFC_FL	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	TOTL_DSCN_AT	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	TRIP_NB	NO		NO		
UTLUSER	ODS_MCS_COLL_ACTIVITY	USER_IDNT_CD	NO		NO		
UTLUSER	ODS_MCS_COLL_ORDR	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_COLL_ORDR	ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	BSNS_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	CRDT_CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	DEBT_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	PYMN_CRDT_AT	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	REVN_YEAR_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	SORC_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_ACTV	TRF_WITHIN_FL	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	AGNT_CMMR_COLL_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	APPL_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	CASH_BTCH_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	CRDT_CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	PYMN_CRDT_AT	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	PYMN_CRDT_DT	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	PYMN_CRDT_SORC_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	PYMN_CSHR_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	PYMN_IND_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	PYMN_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	SHOW_ON_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	TRANS_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE	TRF_BETWEEN_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	AGNT_CMMR_COLL_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	APPL_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	CASH_BTCH_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	CRDT_CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	PYMN_CRDT_AT	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	PYMN_CRDT_DT	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	PYMN_CRDT_SORC_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	PYMN_CSHR_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	PYMN_IND_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	PYMN_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	SHOW_ON_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	TRANS_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_CREDIT_SOURCE_T	TRF_BETWEEN_CD	NO		NO		
UTLUSER	ODS_MCS_CRITICAL_CARE	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_CRITICAL_CARE	CC_EFF_DT	NO		NO		
UTLUSER	ODS_MCS_CRITICAL_CARE	CRITICAL_CARE_CD	NO		NO		
UTLUSER	ODS_MCS_CRITICAL_CARE	CRITICAL_CARE_ID	NO		NO		
UTLUSER	ODS_MCS_CRITICAL_CARE	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CRITICAL_CARE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CRDT_RTNG_NB	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CRPR_AFFL_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_1ST_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_1ST_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_ENVL_OVRR_FL	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_LAST_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_LAST_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_MDDL_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_MDDL_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_NM_INFO_FL	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_PRFX_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_PRFX_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_SFFX_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	CUST_SFFX_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_CUSTOMER	ENERGY_DVRSN_FL	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	NFNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	OWNR_AGNT_FLAG_FL	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	RSDN_CORP_IND_CD	NO		NO		
UTLUSER	ODS_MCS_CUSTOMER	TAX_ID	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	BUS_OWNR_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	BUS_OWNR_MAIL_AD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	BUS_OWNR_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	BUS_OWNR_ST_AD_CD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	BUS_OWNR_TLPH_NB	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	BUS_OWNR_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	CORP_STATUS_CD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	CUST_VLNRBL_FL	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	DRV_LIC_1_NB	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	DRV_LIC_1_ST_CD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	DRV_LIC_2_NB	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	DRV_LIC_2_ST_CD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	EMPLOYER_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	EMPLOYER_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	FAM_MBR_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	FAM_MBR_MAIL_AD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	FAM_MBR_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	FAM_MBR_ST_AD_CD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	FAM_MBR_TLPH_NB	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	FAM_MBR_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	OCCUPATION_1_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	OCCUPATION_2_NM	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	SNR_CTZN_FL	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	WORK_TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_CUST_COLL_INFO	WORK_TLPH_2_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	AGE_OF_DEBIT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	AR_SORT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	BSNS_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	BSNS_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	CHRG_OFF_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	DEBT_PRCS_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	DEBT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	DEBT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	ELEC_BSNS_FL	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	PAGR_PRDN_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	REMN_DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	REVN_YEAR_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	SHOW_ON_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	SORC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY	TRF_BETWEEN_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	AGE_OF_DEBIT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	AR_SORT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	BSNS_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	BSNS_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	CHRG_OFF_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	DEBT_PRCS_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	DEBT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	DEBT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	ELEC_BSNS_FL	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	PAGR_PRDN_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	REMN_DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	REVN_YEAR_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	SHOW_ON_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	SORC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_OLD	TRF_BETWEEN_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	AGE_OF_DEBIT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	AR_SORT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	BSNS_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	BSNS_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	CHRG_OFF_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	DEBT_PRCS_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	DEBT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	DEBT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	ELEC_BSNS_FL	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	PAGR_PRDN_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	REMN_DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	REVN_YEAR_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	SHOW_ON_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	SORC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_TEMP	TRF_BETWEEN_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	AGE_OF_DEBIT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	AR_SORT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	BSNS_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	BSNS_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	CHRG_OFF_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	DEBT_PRCS_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	DEBT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	ELEC_BSNS_FL	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	PAGR_PRDN_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	REMN_DEBT_AT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	REVN_YEAR_MNTH_DT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	SHOW_ON_BILL_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	SORC_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACTIVITY_WH	TRF_BETWEEN_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH	DEBT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH	DUP_COUNT	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH_FIXIT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH_FIXIT	DEBT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH_FIXIT	DIR_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH_FIXIT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEBIT_ACT_WMH_FIXIT	PROD_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	BILL_PERD_DT	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	BILL_PERD_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	BILL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	COOL_DEGR_DAYS_AVG	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	COOL_DEGR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	HTNG_DEGR_DAYS_AVG	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	HTNG_DEGR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	SUB_AREA_CD	NO		NO		
UTLUSER	ODS_MCS_DEGR_DAYS_ESTM	TYPE_OF_WTHR_CD	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	COLLECTION_DT	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	COLLECTION_TM	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	MFR_CD	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	QOS_DELTA_QY	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	QOS_QY	NO		NO		
UTLUSER	ODS_MCS_DEVC_QOS	QOS_TYP_CD	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	AGG_ID_NB	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	AGG_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	AGG_START_DT	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	AGG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_AGG	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	PGRM_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	PGRM_SUB_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	PGRM_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_GEN_PGRM_PARM	SRVC_PNT_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	ACCT_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	ACCT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	ACCT_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	BOX_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUST_1ST_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUST_LAST_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUST_MDDL_INIT_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUST_PRFX_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CUST_SFFX_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	FNNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	LCI_ACCT_FL	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	LIFE_SPPR_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	MTR_RDG_RTE_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	NAME_IDNT_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	OLD_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	OUT_OF_BAL_FL	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	POWER_POOL_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	PREM_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	ROUTE_NB_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	RSDN_CORP_IND_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	RURL_RTE_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SCHD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_HOUS_NBR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_PRDR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_PTDR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_ST_DSGT_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_ST_NAME_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_UNIT_DSGT_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_UNIT_NBR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SERV_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SER_HALF_IND_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	SIC_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	ST_CD_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	TAX_DSTC_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	TLPH_2_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	TLPH_USE_1_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	TLPH_USE_2_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA	VEND_PROG_FL	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	ACCT_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	ACCT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	ACCT_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	BOX_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUST_1ST_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUST_LAST_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUST_MDDL_INIT_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUST_PRFX_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CUST_SFFX_1_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	FNNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	LCI_ACCT_FL	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	LIFE_SPPR_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	MTR_RDG_RTE_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	NAME_IDNT_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	OLD_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	OUT_OF_BAL_FL	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	POWER_POOL_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	PREM_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	REVN_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	ROUTE_NB_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	RSDN_CORP_IND_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	RURL_RTE_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SCHD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_HOUS_NBR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_PRDR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_PTDR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_ST_DSGT_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_ST_NAME_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_UNIT_DSGT_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_UNIT_NBR_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SERV_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SER_HALF_IND_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	SIC_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	ST_CD_AD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	TAX_DSTC_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	TLPH_2_NB	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	TLPH_USE_1_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	TLPH_USE_2_CD	NO		NO		
UTLUSER	ODS_MCS_INDICATIV_DATA_ORACLE	VEND_PROG_FL	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	CORR_LTR_CD	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	DLF_CRTD_FL	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	DLVRY_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	DLVRY_MTHD_TX	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	DOC_ID	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_LETTER_HEADER	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	LETR_CRTN_BY_NM	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	LETR_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_LETTER_HEADER	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	AMI_RQST_CRTR_NM	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	AMI_RQST_ID	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	AMI_RQST_MSG_TX	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	AMI_RQST_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	AMI_RQST_TYPE_NM	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	MFR_CD	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MDM_AMI_RQST	RQST_EVENT_TS	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	BILL_CNST	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_METERED_USAGE	EST_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	EST_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	INST_KIND_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTRD_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTR_CNDT_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTR_RDG_NOT_RD_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	MTR_USAG_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	READ_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_EXP_DT	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_EXP_TM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_NBR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE	USAG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	BILL_CNST	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	EST_MTHD_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	EST_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	INST_KIND_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTRD_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTR_CNDT_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTR_RDG_NOT_RD_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	MTR_USAG_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	READ_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_EXP_DT	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_EXP_TM	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_NBR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_METERED_USAGE_TEMP	USAG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	BILL_CNST	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	DIAL_CNT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	FULL_SCAL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	INST_KIND_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MFR_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_CNDT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_EXP_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_EXP_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_SRCE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_RDG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	MTR_READ_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	RDG_USED_TO_BIL_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	RD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	READ_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	MTR_RDG_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	MTR_RDG_CD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_CODES	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	BILL_CNST	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	DIAL_CNT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	FULL_SCAL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	INST_KIND_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MFR_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_CNDT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_EXP_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_EXP_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_SRCE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_RDG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	MTR_READ_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	RDG_USED_TO_BIL_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	RD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	READ_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	BILL_CNST	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	DIAL_CNT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	FULL_SCAL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	INST_KIND_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MFR_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_CNDT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_EXP_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_EXP_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_SRCE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_RDG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	MTR_READ_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	RDG_USED_TO_BIL_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	RD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	READ_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_HOLD_TEMP	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	BILL_CNST	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	DEVC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	DIAL_CNT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	FULL_SCAL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	HIST_CRRC_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	INST_KIND_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MFR_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MFR_DEVC_SER_NBR	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_CNDT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_EXP_DT	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_EXP_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_QY	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_SRCE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_RDG_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	MTR_READ_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	RDG_USED_TO_BIL_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	RD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	READ_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEMP	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	MTR_RDG_TX	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	MTR_RDG_TX_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_MTR_RDG_TEXT	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_NOTES	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_NOTES	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_NOTES	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_NOTES	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_NOTES	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_NOTES	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_NOTES	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_NOTES	LAST_UPD_DT	NO		NO		
UTLUSER	ODS_MCS_NOTES	LAST_UPD_TM	NO		NO		
UTLUSER	ODS_MCS_NOTES	NOTE_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	NOTE_DESC_TX	NO		NO		
UTLUSER	ODS_MCS_NOTES	NOTE_FRMT_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	NOTE_PRRT_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	NOTE_TS	NO		NO		
UTLUSER	ODS_MCS_NOTES	ORGN_CONV_ID_NM	NO		NO		
UTLUSER	ODS_MCS_NOTES	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_NOTES	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	USER_IDNT_CRTD_CD	NO		NO		
UTLUSER	ODS_MCS_NOTES	USER_IDNT_UPDT_CD	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	BILL_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	ENRG_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	LINE_OF_BUS_CD	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	MSTM_SIZE_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NBR_OF_POLS_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NB_POLE_RISER_CNCT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_INST_DT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_OVH_POLE_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_OVH_SPAN_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_REMV_DT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_TIMG_CD	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NMTR_UNDR_SPAN_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	NON_MTRD_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	OL_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	OL_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	POLE_DESC_CD	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	POLE_TYP_MNTG_CD	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	SRVC_POLE_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	SURC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	TOT_FCLT_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	TOT_OVH_SPAN_FT_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	TOT_UNDR_CRCT_NB	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	USAG_NBR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_OL_BIL_HIST	USAG_STRT_DT	NO		NO		
UTLUSER	ODS_MCS_OPEN_ORDR	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_OPEN_ORDR	ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	EFCT_BIL_PARM_TS	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	FAC_CHRG_AT	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	MSTM_SIZE_NB	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NBR_OF_POLS_QY	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NB_POLE_RISER_CNCT	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NMTR_INST_DT	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NMTR_OVH_POLE_QY	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NMTR_OVH_SPAN_QY	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NMTR_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NMTR_TIMG_CD	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	NMTR_UNDR_SPAN_QY	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	OL_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	POLE_DESC_CD	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	POLE_TYP_MNTG_CD	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	SRVC_POLE_NB	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	TOT_OVH_SPAN_FT_QY	NO		NO		
UTLUSER	ODS_MCS_OTDR_LGHT_BLPM	TOT_UNDR_CRCT_NB	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	ADDR_ID_AD	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	CUST_CNTC_NM	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_OWNER_AGENT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_AGRM_BEG_DT	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_AGRM_CRTN_DT	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_AGRM_DT	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_AGRM_END_DT	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_AGRM_NB	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_AGRM_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_DN_NTFY_RQST_FL	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	OA_UNIT_CNT_QY	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	TLPH_1_NB	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	TLPH_2_NB	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	TLPH_USE_1_CD	NO		NO		
UTLUSER	ODS_MCS_OWNER_AGENT	TLPH_USE_2_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	ADDL_SRV_DATA_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	AMI_FTPRNT_CD	NO	' '	NO		
UTLUSER	ODS_MCS_PREMISE	ANNEX_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	BOX_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	CARI_RTE_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_PREMISE	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	DELV_PT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREMISE	HSNG_CTGY_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	IRRG_USE_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	KEY_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PREMISE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PREMISE	LOAD_AREA_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	MAIL_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	MTR_RDG_RTE_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	MTR_REDR_ID	NO		NO		
UTLUSER	ODS_MCS_PREMISE	MTR_RTE_OWNR_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	NFNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	OA_AGRM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	POWER_POOL_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	PREM_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	RDG_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	REDDY_CRCT_CENT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	ROUTE_NB_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	RURL_RTE_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_HOUS_NBR_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_MAIL_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_PRDR_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_PTDR_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_ST_DSGT_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_ST_NAME_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_UNIT_DSGT_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_UNIT_NBR_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SERV_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SER_HALF_IND_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SRVC_ENTN_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SRVC_POLE_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SRVC_ST_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	ST_CD_AD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	SUB_AREA_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	TAX_DSTC_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE	TRSF_POLE_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	ANNL_BASE_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	ANNL_COOL_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	ANNL_HTNG_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	BLDR_NAME_NM	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	CIAC_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	LOAD_RSCH_FLAG_FL	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	NBR_OF_UNTS_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	NUCLEAR_10MILE_FL	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	POOL_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	POWER_FCTR_PC_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	PWR_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	SQUR_FEET_MKT_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	STRC_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	TOT1_CONN_LOAD_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	TOT1_DMND_LOAD_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	TOT3_CONN_LOAD_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	TOT3_DMND_LOAD_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	WATR_WELL_FL	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DEMOGR	YEAR_STRC_CMPL_DT	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DIR	DIRECTIONS_TX	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DIR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREMISE_DIR	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DIR	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PREMISE_DIR	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_GEN_TYP_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_LEAS_FNNC_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_PHS_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_SUB_TYP_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_SZ_QY	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	EQPM_WRRN_FL	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	NANO_4_TS	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EQUIP	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREMISE_EXT	EEDR_FL	NO	'Y'	NO		
UTLUSER	ODS_MCS_PREMISE_EXT	PREM_ID	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	EEDR_FL	NO	'Y'	NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	PREM_ID	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	PRMR_TARF_FL	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	TARF_PT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_PREMISE_EXT_DEL20210522	TYPE_OF_SRVC_CD	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	ASSC_CUST_NM	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	ASSC_PGM_PREM_AD	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	AUDIT_PGM_RMRK_TX	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	AUDT_PGM_FILE_CD	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	ENRG_AUDT_CD	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	PREM_CUST_CD	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_PREM_AUDT_PGRM	SPCL_PGM_CD	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	BILL_CYCL_REV_DT	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	CLDR_DT	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	CYCL_ROW_TYPE_NB	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	PRCS_SCHD_OVRI_FL	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	SCHD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	BILL_CYCL_REV_DT	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	CLDR_DT	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	CYCL_NB	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	CYCL_ROW_TYPE_NB	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	EDW_LAST_UPDT_TS	NO	CURRENT_TIMESTAMP()	NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	PRCS_SCHD_OVRI_FL	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	SCHD_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_PROCESSING_SCH_TEMP	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_RECON_DS_ORDR	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_RECON_DS_ORDR	ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	BSNS_UNIT_CD	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	FLAG	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	LINE_OF_BUS_CD	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	MD5_CHECKSUM_VAL	NO		NO		
UTLUSER	ODS_MCS_REV_BSNS_UNIT	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	AREA_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	AREA_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	CITY_LIMIT_IND_FL	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	CNTY_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	COMU_CD_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	COUNTY_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	CO_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	DISTRICT_NAME	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	DVSN_AREA_COMBO_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	DVSN_AREA_COMBO_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	DVSN_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	DVSN_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	GEO_ID	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	GROSS_RCPT_POP_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	LOAD_AREA_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	MTR_RDG_RTE_NB	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	POWER_POOL_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	POWER_POOL_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	REGION_NAME	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	REV_JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	SCHL_DSTC_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	SUB_AREA_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	TAX_DSTC_CD	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	TAX_DSTC_TX	NO		NO		
UTLUSER	ODS_MCS_REV_GEO	VERTEX_GEO_CD	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	INFO_CATEGORY	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	INFO_TYPE	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	INFO_VALUE	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	LAST_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	MDCH_SERV_DELIV_ID	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	RPM_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_RPM_SDI_INFO	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	ADVN_ORIG_AT	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	ADVN_PYMN_CSTR_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	AID_CNSN_AGRM_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	CNCL_NOTF_PERD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	CONT_CAP_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	CONT_MIN_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	EDR_NEW_CUST_FL	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	EDR_OPTION_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	EDR_TOD_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	EFCT_BIL_PARM_TS	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	HGHS_PRV_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	HI_PRV_DMND_OFP_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	HPBD_CHNG_RESN_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	INTER_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	INTER_POWER_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	MIN_BILL_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	MIN_DMND_RIDE_FL	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	MULTI_PLANT_EXP_FL	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	OFP_CONT_CAP_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	ORG_CONT_CAP_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	RE_NBR_OF_MOS_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	RMRK_TX	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	RURL_EXTN_MIN_AT	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	RURL_LINE_EXTN_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	RURL_LINE_SBEX_FL	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SPCL_ADDITIONS_AT	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SPCL_ADDITIONS_AT2	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SPCL_ADDN_CHRG_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SPCL_ADDN_CHRG_CD2	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SPCL_MIN_AT	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SPCL_MIN_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	SRVC_CONT_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	T1_OFFP_MAX_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	T1_ONP_MAX_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	T2_OFFP_MAX_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	T2_ONP_MAX_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	T3_OFFP_MAX_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	T3_ONP_MAX_DMD_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	TIER1_CNTR_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	TIER2_CNTR_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	TIER3_CNTR_QY	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	TRANS_MTRD_KW_CD	NO		NO		
UTLUSER	ODS_MCS_SERVICE_CNTRCT	TRANS_MTRD_KW_QY	NO		NO		
UTLUSER	ODS_MCS_SERV_DELIV_ID	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_SERV_DELIV_ID	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_SERV_DELIV_ID	SERV_DLVR_ID	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	DEVC_RGST_ID	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	MTR_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	MTR_RDG_DT	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	MTR_RDG_TM	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_SO_MTR_RDG	TIME_AM_PM_CD	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT	SRVC_AGRM_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT	SRVC_AGRM_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	LST_BIL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	LST_BIL_PERD_TO_TM	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	SRVC_AGRM_EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	SRVC_AGRM_EFCT_TM	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	SRVC_AGRM_EXPR_DT	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	SRVC_AGRM_EXPR_TM	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	SRVC_AGRM_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_SRVC_AGREEMENT_BKUP	TYPE_OF_SRVC_CD	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	CIRCUIT_NB	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	CIRCUIT_NM	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	STATION_NB	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_NM	STATION_NM	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_XRF	CIRCUIT_NB	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_XRF	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_XRF	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_STATN_CIRC_XRF	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_XRF	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_STATN_CIRC_XRF	STATION_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	DAYS_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	LINE_OF_BUS_CD	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	NMTR_FIXED_KWH_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	NMTR_PRRT_FACT_QY	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LGHT_ACTV_CD	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LGHT_CD	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LGHT_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LGHT_RT_AT	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LGHT_RT_NB	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LT_ACT_UNITS_QY	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	ST_LT_BILL_AT	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_ST_LT_BIL_HIST	WORK_ORDR_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	ADDL_TRFM_CAP_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	BILL_PARM_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	CIAC_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	CMSG_MTR_MULT_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DLC_PGM_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DLC_UNIT_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DLY_DMND_RDR_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DMND_ADJ_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DMND_CHCK_PNT_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DMND_CHRG_LOAD_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	DSM_SRCH_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	EFCT_BIL_PARM_TS	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	ELEC_DMND_PROV_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	EMP_ASSC_CO_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	EMP_CD_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	ENRG_ADJ_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	EQPM_ADJS_FLAG_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	ESTM_PERMISSION_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	HI_DMND_RT_IND_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	LOCAL_TAX_ADJ_RT	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	LWR_DMND_RATE_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	MIN_ADJ_FCTR_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	OFF_PEAK_KW_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	OFPK_FRNC_LOAD_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	OTHR_SORC_ENRG_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	PRORATE_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	PWR_FCTR_PLTY_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	RSDN_SRVC_MULT_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	SCHL_ROOM_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	SEPA_KWH_CRDT_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	SEPA_KW_CRDT_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	SEPR_MTRG_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	SQUR_FEET_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	SUPP_INTR_BILL_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	THREE_LVL_CMM_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	TOD_DISC_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	UNMT_SRVC_MULT_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	USE_HI_KVAR_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	USE_HI_KW_KVA_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_PM	USE_HI_REACT_FL	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	BILL_PERD_FROM_DT	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	BILL_PERD_TO_DT	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	BKUP_SRVC_LVL_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CGEN_KWH_OFPK_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CGEN_KWH_ONPK_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CGEN_KW_OFPK_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CGEN_KW_ONPK_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CTC_LI_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CTC_LI_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CTC_STBY_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CTC_STBY_NFM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	CURT_BILL_DMND_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	ELCR_FERR_USG_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	ELCR_TAX_CRDT_RT	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	EM_LI_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	EM_LI_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	EM_STBY_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	EM_STBY_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	EST_HIST_USAG_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	GP_BILLED_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	GP_MTH_USE_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	GP_RSRVD_ACCT_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	HEAT_PUMP_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	SUB_USE_KVARH_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	SUB_USE_KVAR_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	SUB_USE_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	SUB_USE_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC2_LI_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC2_LI_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC2_STBY_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC2_STBY_NFM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC3_LI_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC3_LI_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC3_STBY_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC3_STBY_NFM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC_LI_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC_LI_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC_STBY_FRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_BIL_QY	TC_STBY_NFRM_KW_QY	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	TARF_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_TARF_PT_TARIFF	TYPE_OF_SRVC_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	DLVR_VOLT_2_QY	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	DLVR_VOLT_QY	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_TARIFF_POINT	ENGN_NB	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	NFNC_CNTL_UNIT_NB	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	PHASE_2_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	PHASE_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	PREM_NB	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	PRMR_TARF_FL	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	PUR_CMPL_DT	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	PUR_ERR_FL	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	RCNCLD_DT	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	RCNCLD_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	TARF_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	TARF_PNT_NB	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	TARF_PT_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_TARIFF_POINT	TYPE_OF_SRVC_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	TAX_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	TAX_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	TAX_EXMP_1_PC	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	TAX_EXMP_FORM_NB	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	TAX_EXMP_MAN_FL	NO		NO		
UTLUSER	ODS_MCS_TAX_EXEMPTION	TAX_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	ALT_APLY_TAX_TO_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	ALT_MLTP_COND	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	ALT_TAX_MLTP_RT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	ANNX_PRPR_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	APPLY_TAX_TO_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	CNTY_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	CUMU_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	MAX_TAX_AT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	MIN_TAX_AT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	PLTC_SBDV_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	SERV_CITY_AD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAXRT_EFCT_PRRT_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAXRT_EXPR_PRRT_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_BASE_1_AT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_BASE_1_QY	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_BASE_2_AT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_BASE_2_QY	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_BASE_3_AT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_BASE_3_QY	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_CLAS_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_MLTP_1_RT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_MLTP_2_RT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_MLTP_3_RT	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_OL_FL	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_PERD_FREQ_CD	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_RT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_TAX_RATE	TAX_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_TOD_SORT_CD	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_TRANS_HIST_DTL	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_DTL	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_TRANS_HIST_DTL	RVRS_TS_NB	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_DTL	SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_DTL	UPTR_TRMN_ID_NB	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_HDR	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_HDR	CNV_ID	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_HDR	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_TRANS_HIST_HDR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_TRANS_HIST_HDR	TS_20_TS	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	BILL_COMP_NB	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	BILL_HEAD_NB	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	BILL_KWH_QY	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	ENRG_CHRG_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	LINE_OF_BUS_CD	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	NMTR_ACTV_UNTS_QY	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	NMTR_INST_DT	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	NMTR_KWH_UNIT_QY	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	NMTR_REMV_DT	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	NMTR_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	SRVC_POLE_NB	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	SURC_TOT_AT	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	UNMT_OCCR_NB	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	UNMT_SRVC_CD	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	USAG_NBR_DAYS_QY	NO		NO		
UTLUSER	ODS_MCS_UNMT_BILL_HIST	USAG_STRT_DT	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	CODE_TBL_SEC_FL	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	CONV_SEC_FL	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	EDW_LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	FLAG	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	MD5_CHECKSUM_VAL	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	OWN_AUTH_CREATE_CD	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	OWN_AUTH_DELETE_CD	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	OWN_AUTH_READ_CD	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	OWN_AUTH_UPDATE_CD	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	STAT_OF_DATA_CD	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	USER_CLASS_CD	NO		NO		
UTLUSER	ODS_MCS_USER_CLASS	USER_CLAS_DESC_TX	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	CANCEL_RQST_CD	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	EFCT_DT	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	JRSD_CD	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	PLAN_CD	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	PLAN_FILE_NB	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	PLAN_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_VENDOR_PLAN	PLAN_TYPE_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	ALRT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	CATEGORY_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	CATEGORY_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	COMMENTS_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	SOURCE_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_CATG	SOURCE_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	ALRT_DAYS_ADV_NOTIFY	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	ALRT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	ALRT_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	CONTACT_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	EVENT_SUB_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	SRCE_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	SRCE_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	SUB_TYPE_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_DTL	WEB_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	ALRT_CONTACT_OPT_FL	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	ALRT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	ALRT_REMARK_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	ALRT_TC_VERSION	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	COMM_CHANNEL_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	CONTACT_CONFIRM_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	CONTACT_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	EMAIL_FORMAT_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	SRCE_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	SRCE_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	WEB_FIRST_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	WEB_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	WEB_LAST_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HDR	WEB_PRFX_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST	ALRT_CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST	CONTACT_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST	EDW_LAST_UPDT_TS	YES	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST	MSG_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	ALRT_CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	ALRT_STATUS_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	BATCH_FILE_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	BATCH_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	CONTACT_CARRIER_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	CONTACT_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	EVENT_SUB_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	JOB_RUN_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	LAST_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	MESSAGE_TEXT	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	MSG_SEQ_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	MSG_TRACK_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	ROW_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	SEND_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	SESSION_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	SMS_KEYWORD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	SMS_SUB_KEYWORD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	TRAN_DELIVER_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	TRAN_REMARKS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	VENDOR_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_HST_BKP	WEB_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	ALRT_ATTR_VALUE	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	ALRT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	CATEGORY_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	COMMENTS_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	COMM_CHANNEL_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	CO_CD_OWNR	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	OPER_CO_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	STATE_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	SUB_CATG_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	VENDOR_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_PGRM	VENDOR_PGRM_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	ALRT_ATTR_VALUE	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	ALRT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	HASH_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	REASON_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	SRCE_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	SRCE_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	VENDOR_PGRM_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_SUBS	WEB_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	ALRT_EFCT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	COMMENTS_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	CRYPTO_KEY_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	CRYPTO_VECT_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	SOURCE_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	SOURCE_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	VENDOR_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_ALERT_VNDR	VENDOR_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	BDHV_CONSUMER_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	BDHV_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	BDHV_TC_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	CUST_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	MSG_TX	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	WEB_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_BILL_ACCT	WEB_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	BILL_ACCT_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	CRTN_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_WEB_USER	EMAIL_FORMAT_CD	NO	'H'	NO		
UTLUSER	ODS_MCS_WEB_USER	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	SMS_QUIET_TZ	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_EMAIL	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_FIRST_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_ID	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_ID_NB	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_IND	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_LAST_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_PREFIX_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_PSWD	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_PSWD_HINT	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_REG_KEY	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_RQST_AD	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_RQST_NM	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_SMS	NO		NO		
UTLUSER	ODS_MCS_WEB_USER	WEB_USER_STAT_CD	NO		NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	EDW_LAST_UPDT_TS	NO	CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(6))	NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	LAST_TRAN_UPDT_NM	NO		NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	LAST_UPDT_TS	NO		NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	LOAD_BUS_ID	NO		NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	POWER_POOL_CD	NO		NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	SERV_ZIP_AD	NO		NO		
UTLUSER	ODS_MCS_ZIP_WEATHER	WTHR_ZONE_CD	NO		NO		


/* -----------------------------------------------------------------------------
   Q4  OPTIONAL -- Bronze vs ODS row counts, one row per pair.

   Reads metadata only (INFORMATION_SCHEMA.TABLES.ROW_COUNT), so it is cheap and
   does not scan the tables. Snowflake keeps ROW_COUNT current for real tables.
   ----------------------------------------------------------------------------- */
WITH bronze AS (
    SELECT TABLE_NAME, ROW_COUNT, BYTES, LAST_ALTERED
    FROM BRONZE_CUST_CONF_PROD.INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA = 'BRONZE_MACSS'
      AND TABLE_NAME LIKE 'MCS_%'
),
ods AS (
    SELECT TABLE_NAME, ROW_COUNT, BYTES, LAST_ALTERED
    FROM UTLDB01.INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA = 'UTLUSER'
      AND TABLE_NAME LIKE 'ODS_MCS_%'
)
SELECT b.TABLE_NAME              AS BRONZE_TABLE,
       o.TABLE_NAME              AS ODS_TABLE,
       b.ROW_COUNT               AS BRONZE_ROWS,
       o.ROW_COUNT               AS ODS_ROWS,
       o.ROW_COUNT - b.ROW_COUNT AS DIFF,
       b.LAST_ALTERED            AS BRONZE_LAST_ALTERED,
       o.LAST_ALTERED            AS ODS_LAST_ALTERED
FROM bronze b
FULL OUTER JOIN ods o
    ON o.TABLE_NAME = 'ODS_' || b.TABLE_NAME
ORDER BY COALESCE(b.TABLE_NAME, o.TABLE_NAME);

BRONZE_TABLE	ODS_TABLE	BRONZE_ROWS	ODS_ROWS	ROW_COUNT_DIFF	BRONZE_BYTES	ODS_BYTES	BRONZE_LAST_ALTERED	ODS_LAST_ALTERED	VALIDATION_STATUS
mcs_acct_taxes	ODS_MCS_ACCT_TAXES	7950989	0	-7950989	92131992	0	2026-07-28 16:18:03.280 -0700	2026-07-30 13:36:45.205 -0700	ROW COUNT MISMATCH
mcs_acct_xref	ODS_MCS_ACCT_XREF	9020394	0	-9020394	227871925	0	2026-08-31 09:09:31.776 -0700	2026-07-30 13:36:45.193 -0700	ROW COUNT MISMATCH
mcs_address	ODS_MCS_ADDRESS	11266152	0	-11266152	1163420986	0	2026-08-31 09:08:43.613 -0700	2026-07-30 13:36:45.442 -0700	ROW COUNT MISMATCH
mcs_ba_csa		9835521			1044140538		2026-08-31 09:25:14.209 -0700		MISSING IN ODS
mcs_ba_dlc_bill_hst	ODS_MCS_BA_DLC_BILL_HST	873455	0	-873455	12992061	0	2026-08-31 09:03:25.314 -0700	2026-07-30 13:36:45.247 -0700	ROW COUNT MISMATCH
mcs_ba_dlc_devc_dtl	ODS_MCS_BA_DLC_DEVC_DTL	92894	0	-92894	1423729	0	2026-07-28 16:17:52.110 -0700	2026-07-30 13:36:45.515 -0700	ROW COUNT MISMATCH
mcs_ba_dlc_devc_hdr	ODS_MCS_BA_DLC_DEVC_HDR	44880	0	-44880	1482227	0	2026-07-28 16:17:59.606 -0700	2026-07-30 13:36:45.453 -0700	ROW COUNT MISMATCH
mcs_ba_green_pwr	ODS_MCS_BA_GREEN_PWR	13328	0	-13328	2438805	0	2026-08-31 09:03:37.615 -0700	2026-07-30 13:36:45.543 -0700	ROW COUNT MISMATCH
mcs_billable_usage	ODS_MCS_BILLABLE_USAGE	799405731	795279137	-4126594	25847187243	17582656512	2026-08-31 09:29:29.139 -0700	2026-08-11 10:52:06.832 -0700	ROW COUNT MISMATCH
mcs_bill_account	ODS_MCS_BILL_ACCOUNT	22241168	0	-22241168	71379403793	0	2026-08-31 09:13:15.137 -0700	2026-07-30 13:36:45.519 -0700	ROW COUNT MISMATCH
mcs_bill_component	ODS_MCS_BILL_COMPONENT	792095928	788020607	-4075321	61764378483	43530631680	2026-08-31 09:41:27.611 -0700	2026-08-11 10:47:19.485 -0700	ROW COUNT MISMATCH
mcs_bill_header	ODS_MCS_BILL_HEADER	760645200	756714476	-3930724	53192603409	21487989248	2026-08-31 09:47:26.925 -0700	2026-08-11 10:43:59.510 -0700	ROW COUNT MISMATCH
mcs_bill_parm_hist	ODS_MCS_BILL_PARM_HIST	144543563	0	-144543563	4106661473	0	2026-08-31 09:12:31.348 -0700	2026-07-30 13:36:46.038 -0700	ROW COUNT MISMATCH
mcs_bil_comp_dtl	ODS_MCS_BIL_COMP_DTL	10123864032	0	-10123864032	94874633771	0	2026-07-28 16:17:52.422 -0700	2026-07-30 13:36:45.935 -0700	ROW COUNT MISMATCH
mcs_bus_asst_prog	ODS_MCS_BUS_ASST_PROG	5350163	0	-5350163	200807102	0	2026-08-31 09:04:00.980 -0700	2026-07-30 13:36:45.771 -0700	ROW COUNT MISMATCH
mcs_bus_bb_actv	ODS_MCS_BUS_BB_ACTV	177936819	0	-177936819	8561890629	0	2026-08-31 10:04:29.825 -0700	2026-07-30 13:36:45.717 -0700	ROW COUNT MISMATCH
mcs_bus_bb_header	ODS_MCS_BUS_BB_HEADER	3443511	0	-3443511	1274795192	0	2026-08-31 09:10:59.554 -0700	2026-07-30 13:36:46.105 -0700	ROW COUNT MISMATCH
mcs_bus_dir	ODS_MCS_BUS_DIR	224479359	0	-224479359	37546237366	0	2026-08-31 10:21:18.524 -0700	2026-07-30 13:36:45.708 -0700	ROW COUNT MISMATCH
mcs_bus_dpst_actv	ODS_MCS_BUS_DPST_ACTV	23493021	0	-23493021	1298706999	0	2026-08-31 09:05:38.754 -0700	2026-07-30 13:36:46.110 -0700	ROW COUNT MISMATCH
mcs_bus_pa_crdt_ex	ODS_MCS_BUS_PA_CRDT_EX	23584990	23506189	-78801	1086388781	492042240	2026-08-31 09:16:44.207 -0700	2026-08-11 10:37:39.010 -0700	ROW COUNT MISMATCH
mcs_bus_pip_actv	ODS_MCS_BUS_PIP_ACTV	41598718	0	-41598718	1961706848	0	2026-08-31 09:16:28.306 -0700	2026-07-30 13:36:40.994 -0700	ROW COUNT MISMATCH
mcs_bus_pip_hdr	ODS_MCS_BUS_PIP_HDR	1342342	0	-1342342	248564823	0	2026-08-31 09:11:57.181 -0700	2026-07-30 13:36:45.847 -0700	ROW COUNT MISMATCH
mcs_bus_pip_hist	ODS_MCS_BUS_PIP_HIST	8224368	0	-8224368	462627517	0	2026-08-31 09:10:56.514 -0700	2026-07-30 13:36:45.883 -0700	ROW COUNT MISMATCH
mcs_calendar	ODS_MCS_CALENDAR	146469	146469	0	929008	914432	2026-08-31 07:31:18.171 -0700	2026-08-11 10:36:17.989 -0700	MATCHED
mcs_cci_trnfr_actv		169129995			29982641537		2026-08-31 10:04:02.661 -0700		MISSING IN ODS
mcs_cdt_contact	ODS_MCS_CDT_CONTACT	130451	0	-130451	16029873	0	2026-08-31 09:11:00.356 -0700	2026-07-30 13:36:45.832 -0700	ROW COUNT MISMATCH
mcs_cdt_serv_deliv	ODS_MCS_CDT_SERV_DELIV	17405310	0	-17405310	1652545605	0	2026-08-31 09:03:52.952 -0700	2026-07-30 13:36:41.205 -0700	ROW COUNT MISMATCH
mcs_cdt_serv_prov	ODS_MCS_CDT_SERV_PROV	1528	0	-1528	4569464	0	2026-08-31 09:08:51.711 -0700	2026-07-30 13:36:41.127 -0700	ROW COUNT MISMATCH
mcs_checkless_pay		2090352			469821949		2026-08-31 09:24:47.936 -0700		MISSING IN ODS
mcs_close_ordr	ODS_MCS_CLOSE_ORDR	670871	0	-670871	893680363	0	2026-08-31 09:12:03.856 -0700	2026-07-30 13:36:40.837 -0700	ROW COUNT MISMATCH
mcs_cnj_bill_hist		173941			3466987		2026-08-31 09:04:40.620 -0700		MISSING IN ODS
mcs_cnsl_bill_dtl	ODS_MCS_CNSL_BILL_DTL	84309	0	-84309	124500129	0	2026-08-31 09:11:28.933 -0700	2026-07-30 13:36:41.497 -0700	ROW COUNT MISMATCH
mcs_code_tables		571638			15315970		2026-08-31 07:31:48.269 -0700		MISSING IN ODS
mcs_coll_activity	ODS_MCS_COLL_ACTIVITY	184593665	183383293	-1210372	14519545374	7291668992	2026-08-31 10:20:09.180 -0700	2026-08-11 10:49:14.207 -0700	ROW COUNT MISMATCH
mcs_coll_ordr	ODS_MCS_COLL_ORDR	32614077	32477355	-136722	1104061773	624906240	2026-08-31 09:17:25.364 -0700	2026-08-11 10:37:01.310 -0700	ROW COUNT MISMATCH
mcs_condition_hist		43872695			1157387388		2026-08-31 09:18:27.717 -0700		MISSING IN ODS
mcs_credit_actv	ODS_MCS_CREDIT_ACTV	2735583390	2725509741	-10073649	97814490824	63224024064	2026-08-31 09:52:31.935 -0700	2026-08-11 11:03:51.538 -0700	ROW COUNT MISMATCH
mcs_credit_source	ODS_MCS_CREDIT_SOURCE	1304949998	1299618416	-5331582	58474835818	33984898560	2026-08-31 10:23:56.168 -0700	2026-08-11 11:03:26.183 -0700	ROW COUNT MISMATCH
mcs_critical_care	ODS_MCS_CRITICAL_CARE	37314	0	-37314	3819436	0	2026-08-31 09:11:38.296 -0700	2026-07-30 13:36:41.381 -0700	ROW COUNT MISMATCH
mcs_customer	ODS_MCS_CUSTOMER	16155146	16088874	-66272	1240893258	490818048	2026-08-31 09:08:49.548 -0700	2026-08-06 10:08:43.790 -0700	ROW COUNT MISMATCH
mcs_cust_coll_info	ODS_MCS_CUST_COLL_INFO	8667463	0	-8667463	6808397141	0	2026-08-31 09:23:42.076 -0700	2026-07-30 13:36:41.902 -0700	ROW COUNT MISMATCH
mcs_cust_log		253967132			67171951911		2026-08-31 07:25:36.482 -0700		MISSING IN ODS
mcs_debit_activity	ODS_MCS_DEBIT_ACTIVITY	1462542667	0	-1462542667	37137198928	0	2026-08-31 09:35:02.312 -0700	2026-08-11 10:37:04.027 -0700	ROW COUNT MISMATCH
mcs_degr_days_estm	ODS_MCS_DEGR_DAYS_ESTM	427227	0	-427227	12640427	0	2026-08-31 09:11:37.080 -0700	2026-07-30 13:36:41.774 -0700	ROW COUNT MISMATCH
mcs_devc_qos	ODS_MCS_DEVC_QOS	36639650	0	-36639650	1400938050	0	2026-08-31 09:19:38.713 -0700	2026-07-30 13:36:42.329 -0700	ROW COUNT MISMATCH
mcs_gen_pgrm_agg	ODS_MCS_GEN_PGRM_AGG	1932	1932	0	1941745	35328	2026-08-31 09:05:28.683 -0700	2026-08-30 15:00:47.285 -0700	MATCHED
mcs_gen_pgrm_parm	ODS_MCS_GEN_PGRM_PARM	34563	34552	-11	4166846	723968	2026-08-31 09:05:09.033 -0700	2026-08-30 15:00:47.613 -0700	ROW COUNT MISMATCH
mcs_indicativ_data	ODS_MCS_INDICATIV_DATA	25412892	25311084	-101808	62829839380	1853878272	2026-08-31 09:29:42.659 -0700	2026-08-11 11:05:22.777 -0700	ROW COUNT MISMATCH
mcs_letter_header	ODS_MCS_LETTER_HEADER	37628657	0	-37628657	2091293456	0	2026-08-31 09:19:02.131 -0700	2026-07-30 13:36:42.543 -0700	ROW COUNT MISMATCH
mcs_mdm_ami_rqst	ODS_MCS_MDM_AMI_RQST	3763533	3154637	-608896	13625618812	218912256	2026-08-31 09:14:55.582 -0700	2026-08-11 11:07:18.320 -0700	ROW COUNT MISMATCH
mcs_metered_usage	ODS_MCS_METERED_USAGE	276353883	271685465	-4668418	21397716393	6775180800	2026-08-31 09:39:24.723 -0700	2026-08-11 11:08:17.381 -0700	ROW COUNT MISMATCH
mcs_meter_point		6855857			169419452		2026-08-31 09:09:33.245 -0700		MISSING IN ODS
mcs_mtr_rdg	ODS_MCS_MTR_RDG	280091474	275378893	-4712581	30511389608	7051932672	2026-08-31 09:46:27.837 -0700	2026-08-11 11:11:13.761 -0700	ROW COUNT MISMATCH
mcs_mtr_rdg_codes	ODS_MCS_MTR_RDG_CODES	14059541	11312575	-2746966	352178309	290961408	2026-08-31 09:14:01.899 -0700	2026-08-06 10:16:07.720 -0700	ROW COUNT MISMATCH
mcs_mtr_rdg_hold	ODS_MCS_MTR_RDG_HOLD	1135834744	0	-1135834744	29877216786	0	2026-08-31 10:14:20.230 -0700	2026-08-12 10:59:46.063 -0700	ROW COUNT MISMATCH
mcs_mtr_rdg_text	ODS_MCS_MTR_RDG_TEXT	4915880	0	-4915880	182557598	0	2026-08-31 09:15:28.623 -0700	2026-07-30 13:36:42.882 -0700	ROW COUNT MISMATCH
mcs_notes	ODS_MCS_NOTES	145960247	143563619	-2396628	25304967682	5291985408	2026-08-31 09:39:55.923 -0700	2026-08-11 11:10:15.887 -0700	ROW COUNT MISMATCH
mcs_oa_history		723030			22505167		2026-08-31 09:24:49.323 -0700		MISSING IN ODS
mcs_ol_bil_hist	ODS_MCS_OL_BIL_HIST	94529623	0	-94529623	3632459611	0	2026-08-31 09:03:42.641 -0700	2026-07-30 13:36:43.512 -0700	ROW COUNT MISMATCH
mcs_open_ordr	ODS_MCS_OPEN_ORDR	395816	0	-395816	405278558	0	2026-08-31 09:14:33.899 -0700	2026-07-30 13:36:43.562 -0700	ROW COUNT MISMATCH
mcs_opt_out		110266			2545942		2026-08-31 09:05:17.479 -0700		MISSING IN ODS
mcs_otdr_lght_blpm	ODS_MCS_OTDR_LGHT_BLPM	3901535	0	-3901535	140104897	0	2026-08-31 09:14:21.115 -0700	2026-07-30 13:36:43.338 -0700	ROW COUNT MISMATCH
mcs_owner_agent	ODS_MCS_OWNER_AGENT	41570	0	-41570	11947302	0	2026-08-31 09:07:57.272 -0700	2026-07-30 13:36:43.689 -0700	ROW COUNT MISMATCH
mcs_premise	ODS_MCS_PREMISE	7620039	7613828	-6211	3133699699	529073152	2026-08-31 09:07:41.754 -0700	2026-08-11 11:10:54.863 -0700	ROW COUNT MISMATCH
mcs_premise_demogr	ODS_MCS_PREMISE_DEMOGR	7221504	7213859	-7645	98177366	183012352	2026-08-31 09:14:35.369 -0700	2026-08-06 10:17:09.480 -0700	ROW COUNT MISMATCH
mcs_premise_dir	ODS_MCS_PREMISE_DIR	6676133	6666900	-9233	962639315	353876992	2026-08-31 09:14:10.146 -0700	2026-08-06 10:18:08.451 -0700	ROW COUNT MISMATCH
mcs_premise_equip	ODS_MCS_PREMISE_EQUIP	6077699	6027456	-50243	169232534	128782848	2026-08-31 09:05:19.908 -0700	2026-08-06 10:19:15.036 -0700	ROW COUNT MISMATCH
mcs_prem_audt_pgrm	ODS_MCS_PREM_AUDT_PGRM	230808	0	-230808	8473767	0	2026-07-28 16:18:06.382 -0700	2026-07-30 13:36:44.314 -0700	ROW COUNT MISMATCH
mcs_processing_sch	ODS_MCS_PROCESSING_SCH	2080635	2080635	0	19217518	23335936	2026-07-28 16:18:10.114 -0700	2026-08-11 11:11:03.902 -0700	MATCHED
mcs_process_date		77			1946150		2026-08-31 09:23:33.993 -0700		MISSING IN ODS
mcs_rates		626703			5033564		2026-08-31 09:04:32.529 -0700		MISSING IN ODS
mcs_recon_ds_ordr	ODS_MCS_RECON_DS_ORDR	705981	0	-705981	467290211	0	2026-08-31 09:14:54.049 -0700	2026-07-30 13:36:44.734 -0700	ROW COUNT MISMATCH
mcs_rev_acct		42303584			984491048		2026-08-31 09:24:46.508 -0700		MISSING IN ODS
mcs_rev_bill_to		471578			9635849		2026-08-31 09:24:35.503 -0700		MISSING IN ODS
mcs_rev_bsns_unit	ODS_MCS_REV_BSNS_UNIT	18	0	-18	85137	0	2026-07-28 16:18:11.923 -0700	2026-07-30 13:36:44.592 -0700	ROW COUNT MISMATCH
mcs_rev_date		15443			1990868		2026-08-31 09:24:03.596 -0700		MISSING IN ODS
mcs_rev_ferc		18			1811597		2026-08-31 09:23:37.665 -0700		MISSING IN ODS
mcs_rev_ferc_prod		25			1796537		2026-08-31 09:23:51.951 -0700		MISSING IN ODS
mcs_rev_geo	ODS_MCS_REV_GEO	77632	0	-77632	244250496	0	2026-08-31 09:14:48.695 -0700	2026-07-30 13:36:44.529 -0700	ROW COUNT MISMATCH
mcs_rev_source		111834			10107994		2026-08-31 09:24:05.128 -0700		MISSING IN ODS
mcs_rev_tariff		8225116			530744443		2026-08-31 09:13:34.701 -0700		MISSING IN ODS
mcs_rev_trans_fact		3932355014			37713399598		2026-08-31 07:39:29.797 -0700		MISSING IN ODS
mcs_rpm_sdi_info	ODS_MCS_RPM_SDI_INFO	94078482	0	-94078482	570804938	0	2026-08-31 09:05:06.663 -0700	2026-07-30 13:36:44.848 -0700	ROW COUNT MISMATCH
mcs_service_cntrct	ODS_MCS_SERVICE_CNTRCT	1810154	0	-1810154	68020436	0	2026-08-31 09:03:53.570 -0700	2026-07-30 13:36:44.592 -0700	ROW COUNT MISMATCH
mcs_serv_deliv_id	ODS_MCS_SERV_DELIV_ID	5011639	5006705	-4934	147885724	138989568	2026-08-31 09:08:47.212 -0700	2026-08-06 10:20:15.313 -0700	ROW COUNT MISMATCH
mcs_so_mtr_rdg	ODS_MCS_SO_MTR_RDG	1901378	0	-1901378	2202994616	0	2026-08-31 09:15:58.180 -0700	2026-07-30 13:36:44.787 -0700	ROW COUNT MISMATCH
mcs_srvc_agreement	ODS_MCS_SRVC_AGREEMENT	20683428	0	-20683428	11816878064	0	2026-08-31 09:15:37.717 -0700	2026-07-30 13:36:44.754 -0700	ROW COUNT MISMATCH
mcs_staging_triggr		3			1760287		2026-08-31 09:23:50.257 -0700		MISSING IN ODS
mcs_statn_circ_nm	ODS_MCS_STATN_CIRC_NM	8519	8517	-2	44201264	149504	2026-08-31 09:14:51.151 -0700	2026-08-06 10:20:18.271 -0700	ROW COUNT MISMATCH
mcs_statn_circ_xrf	ODS_MCS_STATN_CIRC_XRF	6722616	6712292	-10324	15440603318	49535488	2026-08-31 09:08:36.922 -0700	2026-08-06 10:21:00.308 -0700	ROW COUNT MISMATCH
mcs_street_cd		305779			12898849		2026-08-31 09:24:20.810 -0700		MISSING IN ODS
mcs_st_lt_bil_hist	ODS_MCS_ST_LT_BIL_HIST	3509591	0	-3509591	84658182	0	2026-08-31 09:04:38.562 -0700	2026-07-30 13:36:45.073 -0700	ROW COUNT MISMATCH
mcs_st_lt_rates		43892			303967		2026-07-28 16:17:47.825 -0700		MISSING IN ODS
mcs_surcharge		52111			3319538		2026-08-31 09:06:41.833 -0700		MISSING IN ODS
mcs_tarf_pt_bil_pm	ODS_MCS_TARF_PT_BIL_PM	7389802	7366667	-23135	253024772	236070912	2026-08-31 09:16:23.923 -0700	2026-08-06 10:22:42.806 -0700	ROW COUNT MISMATCH
mcs_tarf_pt_bil_qy	ODS_MCS_TARF_PT_BIL_QY	449608	0	-449608	52905054	0	2026-08-31 09:04:57.081 -0700	2026-07-30 13:36:45.092 -0700	ROW COUNT MISMATCH
mcs_tarf_pt_tariff	ODS_MCS_TARF_PT_TARIFF	31845927	0	-31845927	703517297	0	2026-08-31 09:11:43.191 -0700	2026-07-30 13:36:44.975 -0700	ROW COUNT MISMATCH
mcs_tarf_strc_dtl		1086358			4782323		2026-07-28 16:18:07.806 -0700		MISSING IN ODS
mcs_tarf_strc_hdr		37420			420134		2026-07-28 16:18:00.390 -0700		MISSING IN ODS
mcs_tariff_point	ODS_MCS_TARIFF_POINT	7586384	7580362	-6022	7292093298	128652800	2026-08-31 09:08:08.399 -0700	2026-08-11 11:11:21.619 -0700	ROW COUNT MISMATCH
mcs_tax_exemption	ODS_MCS_TAX_EXEMPTION	351804	0	-351804	9777856	0	2026-08-31 09:05:18.428 -0700	2026-07-30 13:36:44.966 -0700	ROW COUNT MISMATCH
mcs_tax_rate	ODS_MCS_TAX_RATE	3164	0	-3164	275741	0	2026-07-28 16:17:57.700 -0700	2026-07-30 13:36:45.008 -0700	ROW COUNT MISMATCH
mcs_tax_rule		1349			148983		2026-07-28 16:18:06.064 -0700		MISSING IN ODS
mcs_tod_sort_cd	ODS_MCS_TOD_SORT_CD	146	0	-146	5285	0	2026-08-31 07:31:29.707 -0700	2026-07-30 13:36:44.981 -0700	ROW COUNT MISMATCH
mcs_trans_hist_dtl	ODS_MCS_TRANS_HIST_DTL	41811311	0	-41811311	137303719996	0	2026-08-31 09:21:01.723 -0700	2026-07-30 13:36:45.024 -0700	ROW COUNT MISMATCH
mcs_trans_hist_hdr	ODS_MCS_TRANS_HIST_HDR	442692114	434165979	-8526135	95973797180	20720441344	2026-08-31 09:54:56.493 -0700	2026-08-11 11:17:30.001 -0700	ROW COUNT MISMATCH
mcs_unmt_bill_hist	ODS_MCS_UNMT_BILL_HIST	452622	0	-452622	30968186	0	2026-08-31 09:05:16.532 -0700	2026-07-30 13:36:45.303 -0700	ROW COUNT MISMATCH
mcs_user_class	ODS_MCS_USER_CLASS	72	0	-72	113008	0	2026-07-28 16:18:04.283 -0700	2026-07-30 13:36:45.303 -0700	ROW COUNT MISMATCH
mcs_user_parms		31107			4874691		2026-08-31 09:24:18.213 -0700		MISSING IN ODS
mcs_vendor_plan	ODS_MCS_VENDOR_PLAN	662536	0	-662536	24449449	0	2026-08-31 09:15:31.352 -0700	2026-07-30 13:36:45.286 -0700	ROW COUNT MISMATCH
mcs_web_alert_catg	ODS_MCS_WEB_ALERT_CATG	8	0	-8	106287	0	2026-07-28 16:18:03.342 -0700	2026-07-30 13:36:45.341 -0700	ROW COUNT MISMATCH
mcs_web_alert_dtl	ODS_MCS_WEB_ALERT_DTL	25885256	0	-25885256	7114092315	0	2026-08-31 09:21:21.074 -0700	2026-07-30 13:36:45.349 -0700	ROW COUNT MISMATCH
mcs_web_alert_hdr	ODS_MCS_WEB_ALERT_HDR	16715975	0	-16715975	4983112744	0	2026-08-31 09:17:31.457 -0700	2026-07-30 13:36:45.319 -0700	ROW COUNT MISMATCH
mcs_web_alert_hst	ODS_MCS_WEB_ALERT_HST	156212298	0	-156212298	52776706733	0	2026-08-31 10:33:09.016 -0700	2026-07-30 13:36:45.180 -0700	ROW COUNT MISMATCH
mcs_web_alert_pgrm	ODS_MCS_WEB_ALERT_PGRM	76	0	-76	139997	0	2026-07-28 16:18:05.386 -0700	2026-07-30 13:36:45.205 -0700	ROW COUNT MISMATCH
mcs_web_alert_subs	ODS_MCS_WEB_ALERT_SUBS	823446	0	-823446	37642709	0	2026-08-31 09:15:18.998 -0700	2026-07-30 13:36:45.194 -0700	ROW COUNT MISMATCH
mcs_web_alert_vndr	ODS_MCS_WEB_ALERT_VNDR	4	0	-4	152854	0	2026-07-28 16:18:06.408 -0700	2026-07-30 13:36:45.247 -0700	ROW COUNT MISMATCH
mcs_web_bill_acct	ODS_MCS_WEB_BILL_ACCT	8622658	0	-8622658	1535135286	0	2026-08-31 09:16:46.068 -0700	2026-07-30 13:36:45.227 -0700	ROW COUNT MISMATCH
mcs_web_user	ODS_MCS_WEB_USER	6141589	6138712	-2877	2203173936	377684480	2026-08-31 09:23:36.003 -0700	2026-08-06 10:26:07.540 -0700	ROW COUNT MISMATCH
mcs_zip_weather	ODS_MCS_ZIP_WEATHER	2504	0	-2504	109290	0	2026-07-28 16:18:08.090 -0700	2026-07-30 13:36:45.450 -0700	ROW COUNT MISMATCH
	ODS_MCS_BA_DLC_DEVC_DTL_BKUP		0			0		2026-07-30 13:36:45.471 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT		0			0		2026-08-31 08:01:24.356 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_96							2026-08-31 08:00:39.654 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_96_TEMP		0			0		2026-08-31 08:00:38.909 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_AP							2026-08-31 08:00:39.608 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_AP_TEMP		0			0		2026-08-31 08:00:38.899 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_IM							2026-08-31 08:01:24.654 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_IM_TEMP		0			0		2026-08-31 08:01:23.915 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_OH							2026-08-31 08:00:50.091 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_OH_TEMP		0			0		2026-08-31 08:00:47.416 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_PSO							2026-08-31 08:00:40.898 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_PSO_TEMP		0			0		2026-08-31 08:00:40.083 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_TX1							2026-08-31 08:00:39.623 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_TX1_TEMP		0			0		2026-08-31 08:00:38.899 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_TX2							2026-08-31 08:01:19.418 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_ACCOUNT_EXT_TX2_TEMP		0			0		2026-08-31 08:01:18.633 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_COMPONENT_JBA		0			0		2026-07-30 13:36:45.427 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_COMPONENT_SAVE		0			0		2026-07-30 13:36:45.651 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_COMPONENT_TEMP		0			0		2026-07-30 13:36:45.601 -0700	MISSING IN BRONZE
	ODS_MCS_BILL_HEADER_TEMP		0			0		2026-07-30 13:36:46.050 -0700	MISSING IN BRONZE
	ODS_MCS_BUS_PA_CRDT_EX_TEMP		0			0		2026-07-30 13:36:45.909 -0700	MISSING IN BRONZE
	ODS_MCS_CODE_TBLS		571325			3761664		2026-08-11 10:36:44.666 -0700	MISSING IN BRONZE
	ODS_MCS_CREDIT_ACTV_EXT		0			0		2026-07-30 13:36:41.231 -0700	MISSING IN BRONZE
	ODS_MCS_CREDIT_SOURCE_T		0			0		2026-07-30 13:36:41.343 -0700	MISSING IN BRONZE
	ODS_MCS_DEBIT_ACTIVITY_OLD		0			0		2026-07-30 13:36:41.920 -0700	MISSING IN BRONZE
	ODS_MCS_DEBIT_ACTIVITY_TEMP		0			0		2026-07-30 13:36:41.619 -0700	MISSING IN BRONZE
	ODS_MCS_DEBIT_ACTIVITY_WH		0			0		2026-07-30 13:36:42.006 -0700	MISSING IN BRONZE
	ODS_MCS_DEBIT_ACT_WMH		0			0		2026-07-30 13:36:41.688 -0700	MISSING IN BRONZE
	ODS_MCS_DEBIT_ACT_WMH_FIXIT		0			0		2026-07-30 13:36:41.705 -0700	MISSING IN BRONZE
	ODS_MCS_GEN_PGRM_PARM_ORACLE		0			0		2026-07-30 13:36:42.204 -0700	MISSING IN BRONZE
	ODS_MCS_INDICATIV_DATA_ORACLE		0			0		2026-07-30 13:36:42.457 -0700	MISSING IN BRONZE
	ODS_MCS_METERED_USAGE_TEMP		0			0		2026-07-30 13:36:42.573 -0700	MISSING IN BRONZE
	ODS_MCS_MTR_RDG_HOLD_TEMP		0			0		2026-07-30 13:36:43.131 -0700	MISSING IN BRONZE
	ODS_MCS_MTR_RDG_TEMP		0			0		2026-07-30 13:36:42.897 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT		7580302			504559616		2026-08-31 08:49:52.847 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_01							2026-08-31 08:49:53.217 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_01_TEMP		0			0		2026-08-31 08:49:45.038 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_96							2026-08-31 08:49:52.472 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_96_TEMP		42			59904		2026-08-31 08:49:43.802 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_AP							2026-08-31 08:48:52.789 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_AP_TEMP		526			186880		2026-08-31 08:48:45.026 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_DEL20210522		0			0		2026-07-30 13:36:44.458 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_IM							2026-08-31 08:47:08.032 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_IM_TEMP		892			215040		2026-08-31 08:46:58.627 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_OH							2026-08-31 08:46:04.431 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_OH_TEMP		122			125952		2026-08-31 08:45:52.594 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_PSO							2026-08-31 08:48:59.729 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_PSO_TEMP		13			26112		2026-08-31 08:48:46.588 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_TX1							2026-08-31 08:47:56.275 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_TX1_TEMP		0			0		2026-08-31 08:47:55.293 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_TX2							2026-08-31 08:46:50.516 -0700	MISSING IN BRONZE
	ODS_MCS_PREMISE_EXT_TX2_TEMP		0			0		2026-08-31 08:46:49.404 -0700	MISSING IN BRONZE
	ODS_MCS_PROCESSING_SCH_TEMP		0			0		2026-07-30 13:36:44.742 -0700	MISSING IN BRONZE
	ODS_MCS_SRVC_AGREEMENT_BKUP		0			0		2026-07-30 13:36:45.037 -0700	MISSING IN BRONZE
	ODS_MCS_WEB_ALERT_HST_BKP		0			0		2026-07-30 13:36:45.349 -0700	MISSING IN BRONZE
