/* =============================================================================
   CALLCTR_AGENT_D  --  diagnosing the 252-row mismatch
   spec : validated_sql/m_CALLCTR_AGENT_D.sql
   model: models/CDWADM/CALLCTR_AGENT_D.sql
   All read-only. Paste each result under its query.
   ============================================================================= */


/* -----------------------------------------------------------------------------
   Q1  Do any values exceed the widths the model casts them to?

   The spec contains ZERO casts. The model adds 15. Caps applied by the model:
       CC_ID          VARCHAR(10)     <-- lookup join key
       USERID         VARCHAR(255)    <-- lookup join key
       FIRSTNAME      VARCHAR(100)
       LASTNAME       VARCHAR(100)
       SUPERVISOR_ID  VARCHAR(50)
       PHONE          VARCHAR(50)
       IS_ACTIVE      VARCHAR(4)

   Snowflake truncates SILENTLY on CAST to a narrower VARCHAR. If CC_ID or
   USERID is truncated on write, the next run's lookup compares the full source
   value against the truncated stored value, misses, and routes the row to
   INSERT again -- every run, forever.

   Any number below its cap in the comment = that cast is safe.
   ----------------------------------------------------------------------------- */
SELECT MAX(LENGTH(CC_ID))                  AS CC_ID_LEN,      -- cap 10
       MAX(LENGTH(USERID))                 AS USERID_LEN,     -- cap 255
       MAX(LENGTH(FIRSTNAME))              AS FN_LEN,         -- cap 100
       MAX(LENGTH(LASTNAME))               AS LN_LEN,         -- cap 100
       MAX(LENGTH(SUPERVISOR_ID))          AS SUP_LEN,        -- cap 50
       MAX(LENGTH(PHONE))                  AS PH_LEN,         -- cap 50
       MAX(LENGTH(TO_VARCHAR(IS_ACTIVE)))  AS ACTIVE_LEN      -- cap 4
FROM UTLDB01.CXNADM.VA_USERS_STG;

-- RESULT Q1:
CC_ID_LEN	USERID_LEN	FN_LEN	LN_LEN	SUP_LEN	PH_LEN	ACTIVE_LEN
2	9	13	20	7	8	1



/* -----------------------------------------------------------------------------
   Q2  Has the target accumulated duplicate natural keys?

   (AGENT_USER_ID, CC_ID) is the natural key -- it is what the lookup joins on.
   Duplicates here are the fingerprint of repeated re-inserts: the lookup keeps
   missing, so the same agent is inserted again with a fresh surrogate id.

   SURPLUS_ROWS is how many rows beyond one-per-key the table is carrying.
   ----------------------------------------------------------------------------- */
SELECT COUNT(*)          AS DUP_KEY_GROUPS,
       SUM(N) - COUNT(*) AS SURPLUS_ROWS
FROM (
    SELECT AGENT_USER_ID, CC_ID, COUNT(*) AS N
    FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
    GROUP BY 1, 2
    HAVING COUNT(*) > 1
);

-- RESULT Q2:
DUP_KEY_GROUPS	SURPLUS_ROWS
13	13


/* -----------------------------------------------------------------------------
   Q2b  If Q2 is non-zero: the worst offenders, to eyeball what got mangled.
   ----------------------------------------------------------------------------- */
SELECT AGENT_USER_ID,
       CC_ID,
       COUNT(*)                           AS N,
       MIN(CALLCTR_AGENT_D_ID)            AS FIRST_ID,
       MAX(CALLCTR_AGENT_D_ID)            AS LAST_ID,
       MIN(EDW_CRTE_TS)                   AS FIRST_LOADED,
       MAX(EDW_CRTE_TS)                   AS LAST_LOADED
FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
GROUP BY 1, 2
HAVING COUNT(*) > 1
ORDER BY N DESC, AGENT_USER_ID
LIMIT 50;

-- RESULT Q2b:
AGENT_USER_ID	CC_ID	N	FIRST_ID	LAST_ID	FIRST_LOADED	LAST_LOADED
GPPROC11	-999	2	210	211	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
GPPROC12	-999	2	212	213	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPNS01	-999	2	828	829	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPNS02	-999	2	830	831	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPNS03	-999	2	832	833	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPNS04	-999	2	834	835	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPNS05	-999	2	836	837	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPNS06	-999	2	838	839	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPPROC1	-999	2	840	841	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
SPPROC9	-999	2	855	856	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
TUHQ17	-999	2	939	940	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
s365981	-999	2	3063	3064	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542
s379670	-999	2	3661	3662	2026-08-18 12:22:45.542	2026-08-18 12:22:45.542



/* -----------------------------------------------------------------------------
   Q3  Which DIRECTION are the 252?

   Rebuilds the spec's source set exactly as validated_sql defines it -- RANK()
   with no tiebreaker, UNION (not UNION ALL), the VUS anti-join -- then compares
   its natural keys against what is actually sitting in CALLCTR_AGENT_D.

   Reading the result:
     IN_TARGET_NOT_SPEC high  -> re-insert churn; Q1/Q2 say why
     IN_SPEC_NOT_TARGET high  -> the model is dropping rows we have not found yet
     both non-zero            -> key mismatch: same agent stored under a mangled key
     TARGET_ROWS >> SPEC_ROWS -> historical drift from earlier buggy runs; the
                                 table needs a clean reload before any comparison
                                 is meaningful
   ----------------------------------------------------------------------------- */
WITH spec_src AS (

    SELECT USERID, CC_ID, FIRSTNAME, LASTNAME, SUPERVISOR_ID, IS_ACTIVE, PHONE
    FROM UTLDB01.CXNADM.VA_USERS_STG

    UNION

    SELECT RES.USERID,
           COALESCE(VUS.CC_ID, '-999'),
           RES.FIRSTNAME,
           RES.LASTNAME,
           COALESCE(VUS.SUPERVISOR_ID, '_'),
           COALESCE(VUS.IS_ACTIVE, -999),
           COALESCE(VUS.PHONE, 'DEFAULT')
    FROM (
        SELECT *
        FROM (
            SELECT EMPLOYEE_ID      AS USERID,
                   AGENT_FIRST_NAME AS FIRSTNAME,
                   AGENT_LAST_NAME  AS LASTNAME,
                   RANK() OVER (PARTITION BY EMPLOYEE_ID
                                ORDER BY GMT_END_TIME DESC) AS latest
            FROM UTLDB01.CUSADM.RESOURCE_
            WHERE UPPER(RESOURCE_TYPE) = UPPER('AGENT')
        ) F
        WHERE F.latest = 1
    ) RES
    LEFT JOIN UTLDB01.CXNADM.VA_USERS_STG VUS
        ON VUS.USERID = RES.USERID
    WHERE VUS.USERID IS NULL
),

spec_final AS (
    SELECT s.USERID, s.CC_ID
    FROM spec_src s
    LEFT JOIN UTLDB01.CDWADM.CALLCTR_AGENCY_D CAD
        ON CAD.CALLCTR_CD = s.CC_ID
)

SELECT
    (SELECT COUNT(*) FROM spec_final)                     AS SPEC_ROWS,
    (SELECT COUNT(*) FROM UTLDB01.CDWADM.CALLCTR_AGENT_D) AS TARGET_ROWS,
    (SELECT COUNT(*) FROM (
        SELECT USERID, CC_ID FROM spec_final
        MINUS
        SELECT AGENT_USER_ID, CC_ID FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
    ))                                                    AS IN_SPEC_NOT_TARGET,
    (SELECT COUNT(*) FROM (
        SELECT AGENT_USER_ID, CC_ID FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
        MINUS
        SELECT USERID, CC_ID FROM spec_final
    ))                                                    AS IN_TARGET_NOT_SPEC;

-- RESULT Q3:
SPEC_ROWS	TARGET_ROWS	IN_SPEC_NOT_TARGET	IN_TARGET_NOT_SPEC
11861	12208	0	338



/* -----------------------------------------------------------------------------
   Q4  Sample the actual mismatched keys, both directions, so the rows can be
       eyeballed against the source. Run after Q3.
   ----------------------------------------------------------------------------- */
WITH spec_src AS (

    SELECT USERID, CC_ID, FIRSTNAME, LASTNAME, SUPERVISOR_ID, IS_ACTIVE, PHONE
    FROM UTLDB01.CXNADM.VA_USERS_STG

    UNION

    SELECT RES.USERID,
           COALESCE(VUS.CC_ID, '-999'),
           RES.FIRSTNAME,
           RES.LASTNAME,
           COALESCE(VUS.SUPERVISOR_ID, '_'),
           COALESCE(VUS.IS_ACTIVE, -999),
           COALESCE(VUS.PHONE, 'DEFAULT')
    FROM (
        SELECT *
        FROM (
            SELECT EMPLOYEE_ID      AS USERID,
                   AGENT_FIRST_NAME AS FIRSTNAME,
                   AGENT_LAST_NAME  AS LASTNAME,
                   RANK() OVER (PARTITION BY EMPLOYEE_ID
                                ORDER BY GMT_END_TIME DESC) AS latest
            FROM UTLDB01.CUSADM.RESOURCE_
            WHERE UPPER(RESOURCE_TYPE) = UPPER('AGENT')
        ) F
        WHERE F.latest = 1
    ) RES
    LEFT JOIN UTLDB01.CXNADM.VA_USERS_STG VUS
        ON VUS.USERID = RES.USERID
    WHERE VUS.USERID IS NULL
),

spec_final AS (
    SELECT s.USERID, s.CC_ID
    FROM spec_src s
    LEFT JOIN UTLDB01.CDWADM.CALLCTR_AGENCY_D CAD
        ON CAD.CALLCTR_CD = s.CC_ID
)

SELECT 'IN_SPEC_NOT_TARGET' AS SIDE, USERID AS AGENT_USER_ID, CC_ID
FROM (
    SELECT USERID, CC_ID FROM spec_final
    MINUS
    SELECT AGENT_USER_ID, CC_ID FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
)
UNION ALL
SELECT 'IN_TARGET_NOT_SPEC' AS SIDE, AGENT_USER_ID, CC_ID
FROM (
    SELECT AGENT_USER_ID, CC_ID FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
    MINUS
    SELECT USERID, CC_ID FROM spec_final
)
ORDER BY SIDE, AGENT_USER_ID
LIMIT 100;

-- RESULT Q4:
SIDE	AGENT_USER_ID	CC_ID
IN_TARGET_NOT_SPEC	A008961	02
IN_TARGET_NOT_SPEC	A030906	10
IN_TARGET_NOT_SPEC	A040819	02
IN_TARGET_NOT_SPEC	A065807	02
IN_TARGET_NOT_SPEC	A084725	02
IN_TARGET_NOT_SPEC	A103777	02
IN_TARGET_NOT_SPEC	A112044	02
IN_TARGET_NOT_SPEC	A136667	02
IN_TARGET_NOT_SPEC	A147292	02
IN_TARGET_NOT_SPEC	A155676	02
IN_TARGET_NOT_SPEC	A155838	02
IN_TARGET_NOT_SPEC	A156128	02
IN_TARGET_NOT_SPEC	A167206	02
IN_TARGET_NOT_SPEC	A169106	02
IN_TARGET_NOT_SPEC	A174013	02
IN_TARGET_NOT_SPEC	A192164	02
IN_TARGET_NOT_SPEC	A201319	02
IN_TARGET_NOT_SPEC	A544147	02
IN_TARGET_NOT_SPEC	A659389	10
IN_TARGET_NOT_SPEC	C000355	94
IN_TARGET_NOT_SPEC	C001080	94
IN_TARGET_NOT_SPEC	C002908	94
IN_TARGET_NOT_SPEC	C031359	10
IN_TARGET_NOT_SPEC	CCONU63	94
IN_TARGET_NOT_SPEC	CTSO316	94
IN_TARGET_NOT_SPEC	CTSO597	94
IN_TARGET_NOT_SPEC	CTSOH99	94
IN_TARGET_NOT_SPEC	I001749	04
IN_TARGET_NOT_SPEC	I004280	04
IN_TARGET_NOT_SPEC	K001819	02
IN_TARGET_NOT_SPEC	K001822	03
IN_TARGET_NOT_SPEC	K107175	02
IN_TARGET_NOT_SPEC	P000222	95
IN_TARGET_NOT_SPEC	P000268	75
IN_TARGET_NOT_SPEC	P000594	95
IN_TARGET_NOT_SPEC	P001099	75
IN_TARGET_NOT_SPEC	P002161	95
IN_TARGET_NOT_SPEC	P015839	10
IN_TARGET_NOT_SPEC	P047580	10
IN_TARGET_NOT_SPEC	P389064	04
IN_TARGET_NOT_SPEC	P890801	-999
IN_TARGET_NOT_SPEC	P996108	95
IN_TARGET_NOT_SPEC	P996108	75
IN_TARGET_NOT_SPEC	PCONT75	-999
IN_TARGET_NOT_SPEC	PCONV05	75
IN_TARGET_NOT_SPEC	POLS136	95
IN_TARGET_NOT_SPEC	POLS357	95
IN_TARGET_NOT_SPEC	PTSO213	95
IN_TARGET_NOT_SPEC	PTSO398	95
IN_TARGET_NOT_SPEC	PTSO398	75
IN_TARGET_NOT_SPEC	S000742	76
IN_TARGET_NOT_SPEC	S001094	76
IN_TARGET_NOT_SPEC	S001094	96
IN_TARGET_NOT_SPEC	S001095	96
IN_TARGET_NOT_SPEC	S001157	96
IN_TARGET_NOT_SPEC	S001543	10
IN_TARGET_NOT_SPEC	S001563	96
IN_TARGET_NOT_SPEC	S001837	03
IN_TARGET_NOT_SPEC	S002003	10
IN_TARGET_NOT_SPEC	S002259	96
IN_TARGET_NOT_SPEC	S002626	02
IN_TARGET_NOT_SPEC	S004007	04
IN_TARGET_NOT_SPEC	S005099	10
IN_TARGET_NOT_SPEC	S005412	02
IN_TARGET_NOT_SPEC	S005434	10
IN_TARGET_NOT_SPEC	S005908	02
IN_TARGET_NOT_SPEC	S005909	02
IN_TARGET_NOT_SPEC	S005988	02
IN_TARGET_NOT_SPEC	S005990	02
IN_TARGET_NOT_SPEC	S005995	02
IN_TARGET_NOT_SPEC	S006036	02
IN_TARGET_NOT_SPEC	S006042	02
IN_TARGET_NOT_SPEC	S006043	02
IN_TARGET_NOT_SPEC	S006077	10
IN_TARGET_NOT_SPEC	S006101	02
IN_TARGET_NOT_SPEC	S006102	03
IN_TARGET_NOT_SPEC	S006102	02
IN_TARGET_NOT_SPEC	S006111	02
IN_TARGET_NOT_SPEC	S006112	02
IN_TARGET_NOT_SPEC	S006113	02
IN_TARGET_NOT_SPEC	S006177	10
IN_TARGET_NOT_SPEC	S006354	02
IN_TARGET_NOT_SPEC	S006356	02
IN_TARGET_NOT_SPEC	S006357	02
IN_TARGET_NOT_SPEC	S006358	02
IN_TARGET_NOT_SPEC	S006372	02
IN_TARGET_NOT_SPEC	S006409	02
IN_TARGET_NOT_SPEC	S006502	10
IN_TARGET_NOT_SPEC	S006503	10
IN_TARGET_NOT_SPEC	S006553	03
IN_TARGET_NOT_SPEC	S006553	02
IN_TARGET_NOT_SPEC	S006554	02
IN_TARGET_NOT_SPEC	S006555	02
IN_TARGET_NOT_SPEC	S006556	02
IN_TARGET_NOT_SPEC	S006580	02
IN_TARGET_NOT_SPEC	S006727	02
IN_TARGET_NOT_SPEC	S006823	02
IN_TARGET_NOT_SPEC	S007043	02
IN_TARGET_NOT_SPEC	S007044	02
IN_TARGET_NOT_SPEC	S007045	02



/* -----------------------------------------------------------------------------
   Q5  Does CALLCTR_AGENCY_D fan the join out?

   Both spec and model do  LEFT JOIN CALLCTR_AGENCY_D ON CALLCTR_CD = CC_ID.
   Duplicate CALLCTR_CD multiplies every matching agent row on BOTH sides, so it
   cannot by itself explain a spec-vs-model gap -- but it inflates the absolute
   counts the tester is comparing, so rule it in or out.
   ----------------------------------------------------------------------------- */
SELECT COUNT(*)          AS DUP_CD_GROUPS,
       SUM(N) - COUNT(*) AS SURPLUS_AGENCY_ROWS
FROM (
    SELECT CALLCTR_CD, COUNT(*) AS N
    FROM UTLDB01.CDWADM.CALLCTR_AGENCY_D
    GROUP BY 1
    HAVING COUNT(*) > 1
);

-- RESULT Q5:
DUP_CD_GROUPS	SURPLUS_AGENCY_ROWS
0	


/* -----------------------------------------------------------------------------
   Q6  Are the 338 IN_TARGET_NOT_SPEC rows HISTORY or FRESH BREAKAGE?

   Neither the spec nor the model deletes: m_CALLCTR_AGENT_D is INSERT+UPDATE
   only. So an agent who drops out of VA_USERS / RESOURCE_ stays in the
   dimension permanently. That is correct behaviour, not a defect.

   This buckets the 338 by the day they were created.

   Reading the result:
     all on OLD dates  -> pure history. Not a model defect. The tester is
                          comparing today's source snapshot against an
                          accumulating dimension; the correct comparison is
                          IN_SPEC_NOT_TARGET, which is already 0.
     any on the LATEST run date -> the model inserted keys this run that the
                          source does not contain. That IS a defect and I keep
                          digging.
   ----------------------------------------------------------------------------- */
WITH spec_src AS (

    SELECT USERID, CC_ID, FIRSTNAME, LASTNAME, SUPERVISOR_ID, IS_ACTIVE, PHONE
    FROM UTLDB01.CXNADM.VA_USERS_STG

    UNION

    SELECT RES.USERID,
           COALESCE(VUS.CC_ID, '-999'),
           RES.FIRSTNAME,
           RES.LASTNAME,
           COALESCE(VUS.SUPERVISOR_ID, '_'),
           COALESCE(VUS.IS_ACTIVE, -999),
           COALESCE(VUS.PHONE, 'DEFAULT')
    FROM (
        SELECT *
        FROM (
            SELECT EMPLOYEE_ID      AS USERID,
                   AGENT_FIRST_NAME AS FIRSTNAME,
                   AGENT_LAST_NAME  AS LASTNAME,
                   RANK() OVER (PARTITION BY EMPLOYEE_ID
                                ORDER BY GMT_END_TIME DESC) AS latest
            FROM UTLDB01.CUSADM.RESOURCE_
            WHERE UPPER(RESOURCE_TYPE) = UPPER('AGENT')
        ) F
        WHERE F.latest = 1
    ) RES
    LEFT JOIN UTLDB01.CXNADM.VA_USERS_STG VUS
        ON VUS.USERID = RES.USERID
    WHERE VUS.USERID IS NULL
),

spec_final AS (
    SELECT s.USERID, s.CC_ID
    FROM spec_src s
    LEFT JOIN UTLDB01.CDWADM.CALLCTR_AGENCY_D CAD
        ON CAD.CALLCTR_CD = s.CC_ID
)

SELECT TO_DATE(T.EDW_CRTE_TS) AS CREATED_ON,
       COUNT(*)               AS ORPHAN_ROWS
FROM UTLDB01.CDWADM.CALLCTR_AGENT_D T
WHERE (T.AGENT_USER_ID, T.CC_ID) IN (
        SELECT AGENT_USER_ID, CC_ID FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
        MINUS
        SELECT USERID, CC_ID FROM spec_final
      )
GROUP BY 1
ORDER BY 1 DESC;

-- RESULT Q6:
CREATED_ON	ORPHAN_ROWS
2026-08-19	300
2026-08-18	38


/* -----------------------------------------------------------------------------
   Q6b  For contrast: the created-on profile of the WHOLE table, so Q6 can be
        read against it (is the latest run date present at all?).
   ----------------------------------------------------------------------------- */
SELECT TO_DATE(EDW_CRTE_TS) AS CREATED_ON,
       COUNT(*)             AS ROWS_LOADED
FROM UTLDB01.CDWADM.CALLCTR_AGENT_D
GROUP BY 1
ORDER BY 1 DESC;

-- RESULT Q6b:
CREATED_ON	ROWS_LOADED
2026-08-29	4069
2026-08-25	8
2026-08-19	3105
2026-08-18	5026
