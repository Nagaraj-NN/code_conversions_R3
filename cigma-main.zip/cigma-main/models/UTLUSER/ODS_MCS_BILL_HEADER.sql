{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'BILL_HEAD_NB'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILL_HEADER')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILL_HEADER')
    ]
) }}

WITH ODS_MCS_BILL_HEADER_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.BILL_HEAD_NB,
    s.BILL_AT,
    s.DPC_CALC_TOT_AT,
    s.MTRD_BILL_AT,
    s.NON_MTRD_TOT_AT,
    s.BDGT_BILL_CD,
    s.SPCL_HNDL_PERF_CD,
    s.ADDL_BLLS_QY,
    s.OFFR_BB_PLAN_FL,
    s.TOTL_BILL_DUE_AT,
    s.CNSL_BILL_STAT_CD,
    s.EXCS_CRDT_APPL_AT,
    s.BILL_DT,
    s.ACCT_BAL_AT,
    s.ON_CYCLE_CD,
    s.BILL_HEAD_TYPE_CD,
    s.BILL_HEAD_STAT_CD,
    s.BILL_TM,
    s.BILL_DUE_DT,
    s.BB_ESTM_AT,
    s.EDI_BILL_CD,
    s.STORE_ID_NB,
    s.EDI_CUST_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS BILL_ACCT_NB,
        /* BILL_HEAD_NB                 <- bill_head_nb                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__2, 5, 0) AS BILL_HEAD_NB,
        p.N__2 AS RAW__2,
        /* BILL_AT                      <- bill_at                      NUMBER(10,2) -> NUMBER(10,2) */
        p."bill_at" AS BILL_AT,
        /* DPC_CALC_TOT_AT              <- dpc_calc_tot_at              NUMBER(8,2) -> NUMBER(8,2) */
        p."dpc_calc_tot_at" AS DPC_CALC_TOT_AT,
        /* MTRD_BILL_AT                 <- mtrd_bill_at                 NUMBER(10,2) -> NUMBER(10,2) */
        p."mtrd_bill_at" AS MTRD_BILL_AT,
        /* NON_MTRD_TOT_AT              <- non_mtrd_tot_at              NUMBER(8,2) -> NUMBER(8,2) */
        p."non_mtrd_tot_at" AS NON_MTRD_TOT_AT,
        /* BDGT_BILL_CD                 <- bdgt_bill_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__3, 16777216), '') AS BDGT_BILL_CD,
        /* SPCL_HNDL_PERF_CD            <- spcl_hndl_perf_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__4, 16777216), '') AS SPCL_HNDL_PERF_CD,
        /* ADDL_BLLS_QY                 <- addl_blls_qy                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__5, 5, 0) AS ADDL_BLLS_QY,
        p.N__5 AS RAW__5,
        /* OFFR_BB_PLAN_FL              <- offr_bb_plan_fl              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS OFFR_BB_PLAN_FL,
        /* TOTL_BILL_DUE_AT             <- totl_bill_due_at             NUMBER(10,2) -> NUMBER(10,2) */
        p."totl_bill_due_at" AS TOTL_BILL_DUE_AT,
        /* CNSL_BILL_STAT_CD            <- cnsl_bill_stat_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS CNSL_BILL_STAT_CD,
        /* EXCS_CRDT_APPL_AT            <- excs_crdt_appl_at            NUMBER(8,2) -> NUMBER(8,2) */
        p."excs_crdt_appl_at" AS EXCS_CRDT_APPL_AT,
        /* BILL_DT                      <- bill_dt                      DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."bill_dt" AS TIMESTAMP_NTZ(9)) AS BILL_DT,
        /* ACCT_BAL_AT                  <- acct_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."acct_bal_at" AS ACCT_BAL_AT,
        /* ON_CYCLE_CD                  <- on_cycle_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS ON_CYCLE_CD,
        /* BILL_HEAD_TYPE_CD            <- bill_head_type_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS BILL_HEAD_TYPE_CD,
        /* BILL_HEAD_STAT_CD            <- bill_head_stat_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS BILL_HEAD_STAT_CD,
        /* BILL_TM                      <- bill_tm                      TIMESTAMP_NTZ(6) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS BILL_TM,
        /* BILL_DUE_DT                  <- bill_due_dt                  DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."bill_due_dt" AS TIMESTAMP_NTZ(9)) AS BILL_DUE_DT,
        /* BB_ESTM_AT                   <- bb_estm_at                   NUMBER(7,2) -> NUMBER(7,2) */
        p."bb_estm_at" AS BB_ESTM_AT,
        /* EDI_BILL_CD                  <- edi_bill_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS EDI_BILL_CD,
        /* STORE_ID_NB                  <- store_id_nb                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__13, 16777216), '') AS STORE_ID_NB,
        /* EDI_CUST_CD                  <- edi_cust_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__14, 16777216), '') AS EDI_CUST_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__15, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            TO_VARCHAR(src."bill_head_nb") AS N__2   /* bill_head_nb -> BILL_HEAD_NB */,
            REGEXP_REPLACE(src."bdgt_bill_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* bdgt_bill_cd -> BDGT_BILL_CD */,
            REGEXP_REPLACE(src."spcl_hndl_perf_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* spcl_hndl_perf_cd -> SPCL_HNDL_PERF_CD */,
            TO_VARCHAR(src."addl_blls_qy") AS N__5   /* addl_blls_qy -> ADDL_BLLS_QY */,
            REGEXP_REPLACE(src."offr_bb_plan_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* offr_bb_plan_fl -> OFFR_BB_PLAN_FL */,
            REGEXP_REPLACE(src."cnsl_bill_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* cnsl_bill_stat_cd -> CNSL_BILL_STAT_CD */,
            REGEXP_REPLACE(src."on_cycle_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* on_cycle_cd -> ON_CYCLE_CD */,
            REGEXP_REPLACE(src."bill_head_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* bill_head_type_cd -> BILL_HEAD_TYPE_CD */,
            REGEXP_REPLACE(src."bill_head_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* bill_head_stat_cd -> BILL_HEAD_STAT_CD */,
            REGEXP_REPLACE(TO_VARCHAR(src."bill_tm"), '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* bill_tm -> BILL_TM */,
            REGEXP_REPLACE(src."edi_bill_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* edi_bill_cd -> EDI_BILL_CD */,
            REGEXP_REPLACE(src."store_id_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* store_id_nb -> STORE_ID_NB */,
            REGEXP_REPLACE(src."edi_cust_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* edi_cust_cd -> EDI_CUST_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_BILL_HEADER') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_bill_header"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* BILL_HEAD_NB */
    AND (s.RAW__2 IS NULL OR s.BILL_HEAD_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.BILL_HEAD_NB IS NOT NULL   /* NULL or blank in a key column */
    /* BILL_AT */
    AND s.BILL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* DPC_CALC_TOT_AT */
    AND s.DPC_CALC_TOT_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* MTRD_BILL_AT */
    AND s.MTRD_BILL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NON_MTRD_TOT_AT */
    AND s.NON_MTRD_TOT_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* ADDL_BLLS_QY */
    AND (s.RAW__5 IS NULL OR s.ADDL_BLLS_QY IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.ADDL_BLLS_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TOTL_BILL_DUE_AT */
    AND s.TOTL_BILL_DUE_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* EXCS_CRDT_APPL_AT */
    AND s.EXCS_CRDT_APPL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_DT */
    AND s.BILL_DT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* ACCT_BAL_AT */
    AND s.ACCT_BAL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_DUE_DT */
    AND s.BILL_DUE_DT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BB_ESTM_AT */
    AND s.BB_ESTM_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.BILL_HEAD_NB
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.BILL_HEAD_NB,
    SRC.BILL_AT,
    SRC.DPC_CALC_TOT_AT,
    SRC.MTRD_BILL_AT,
    SRC.NON_MTRD_TOT_AT,
    SRC.BDGT_BILL_CD,
    SRC.SPCL_HNDL_PERF_CD,
    SRC.ADDL_BLLS_QY,
    SRC.OFFR_BB_PLAN_FL,
    SRC.TOTL_BILL_DUE_AT,
    SRC.CNSL_BILL_STAT_CD,
    SRC.EXCS_CRDT_APPL_AT,
    SRC.BILL_DT,
    SRC.ACCT_BAL_AT,
    SRC.ON_CYCLE_CD,
    SRC.BILL_HEAD_TYPE_CD,
    SRC.BILL_HEAD_STAT_CD,
    SRC.BILL_TM,
    SRC.BILL_DUE_DT,
    SRC.BB_ESTM_AT,
    SRC.EDI_BILL_CD,
    SRC.STORE_ID_NB,
    SRC.EDI_CUST_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_BILL_HEADER_SQ SRC
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BILL_HEADER') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, BILL_HEAD_NB
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.BILL_HEAD_NB = TGT.BILL_HEAD_NB
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.BILL_AT, TGT.BILL_AT, 1, 0) = 0
        OR DECODE(SRC.DPC_CALC_TOT_AT, TGT.DPC_CALC_TOT_AT, 1, 0) = 0
        OR DECODE(SRC.MTRD_BILL_AT, TGT.MTRD_BILL_AT, 1, 0) = 0
        OR DECODE(SRC.NON_MTRD_TOT_AT, TGT.NON_MTRD_TOT_AT, 1, 0) = 0
        OR DECODE(SRC.BDGT_BILL_CD, TGT.BDGT_BILL_CD, 1, 0) = 0
        OR DECODE(SRC.SPCL_HNDL_PERF_CD, TGT.SPCL_HNDL_PERF_CD, 1, 0) = 0
        OR DECODE(SRC.ADDL_BLLS_QY, TGT.ADDL_BLLS_QY, 1, 0) = 0
        OR DECODE(SRC.OFFR_BB_PLAN_FL, TGT.OFFR_BB_PLAN_FL, 1, 0) = 0
        OR DECODE(SRC.TOTL_BILL_DUE_AT, TGT.TOTL_BILL_DUE_AT, 1, 0) = 0
        OR DECODE(SRC.CNSL_BILL_STAT_CD, TGT.CNSL_BILL_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.EXCS_CRDT_APPL_AT, TGT.EXCS_CRDT_APPL_AT, 1, 0) = 0
        OR DECODE(SRC.BILL_DT, TGT.BILL_DT, 1, 0) = 0
        OR DECODE(SRC.ACCT_BAL_AT, TGT.ACCT_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.ON_CYCLE_CD, TGT.ON_CYCLE_CD, 1, 0) = 0
        OR DECODE(SRC.BILL_HEAD_TYPE_CD, TGT.BILL_HEAD_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.BILL_HEAD_STAT_CD, TGT.BILL_HEAD_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.BILL_TM, TGT.BILL_TM, 1, 0) = 0
        OR DECODE(SRC.BILL_DUE_DT, TGT.BILL_DUE_DT, 1, 0) = 0
        OR DECODE(SRC.BB_ESTM_AT, TGT.BB_ESTM_AT, 1, 0) = 0
        OR DECODE(SRC.EDI_BILL_CD, TGT.EDI_BILL_CD, 1, 0) = 0
        OR DECODE(SRC.STORE_ID_NB, TGT.STORE_ID_NB, 1, 0) = 0
        OR DECODE(SRC.EDI_CUST_CD, TGT.EDI_CUST_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )


