

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'PREM_NB', 'CUST_NB', 'NAME_IDNT_CD'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_INDICATIV_DATA')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_INDICATIV_DATA')
    ]
) }}

WITH ODS_MCS_INDICATIV_DATA_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.PREM_NB,
    s.CUST_NB,
    s.NAME_IDNT_CD,
    s.CO_CD_OWNR,
    s.STATE_CD,
    s.JRSD_CD,
    s.DVSN_CD,
    s.AREA_CD,
    s.SER_HALF_IND_AD,
    s.SERV_CITY_AD,
    s.SERV_HOUS_NBR_AD,
    s.SERV_PTDR_AD,
    s.SERV_PRDR_AD,
    s.RURL_RTE_TYPE_CD,
    s.ROUTE_NB_AD,
    s.BOX_AD,
    s.SERV_ST_DSGT_AD,
    s.SERV_ST_NAME_AD,
    s.SERV_UNIT_DSGT_AD,
    s.SERV_UNIT_NBR_AD,
    s.SERV_ZIP_AD,
    s.ACCT_STAT_CD,
    s.ACCT_TYPE_CD,
    s.LIFE_SPPR_CD,
    s.REVN_CLAS_CD,
    s.ST_CD_AD,
    s.TARF_CD,
    s.TLPH_USE_1_CD,
    s.TLPH_USE_2_CD,
    s.PREM_STAT_CD,
    s.ACCT_CLAS_CD,
    s.RSDN_CORP_IND_CD,
    s.SIC_CD,
    s.TURN_OFF_DT,
    s.TURN_ON_DT,
    s.LCI_ACCT_FL,
    s.CYCL_NB,
    s.MTR_RDG_RTE_NB,
    s.OLD_ACCT_NB,
    s.TLPH_1_NB,
    s.TLPH_2_NB,
    s.CUST_1ST_1_NM,
    s.CUST_LAST_1_NM,
    s.CUST_MDDL_INIT_NM,
    s.CUST_PRFX_1_NM,
    s.CUST_SFFX_1_NM,
    s.TAX_DSTC_CD,
    s.CUMU_CD,
    s.FNNC_CNTL_UNIT_NB,
    s.OUT_OF_BAL_FL,
    s.SCHD_TYPE_CD,
    s.VEND_PROG_FL,
    s.POWER_POOL_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS BILL_ACCT_NB,
        /* PREM_NB                      <- prem_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__2, 16777216) AS PREM_NB,
        /* CUST_NB                      <- cust_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__3, 16777216) AS CUST_NB,
        /* NAME_IDNT_CD                 <- name_idnt_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__4, 16777216) AS NAME_IDNT_CD,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS CO_CD_OWNR,
        /* STATE_CD                     <- state_cd                     VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS STATE_CD,
        /* JRSD_CD                      <- jrsd_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS JRSD_CD,
        /* DVSN_CD                      <- dvsn_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS DVSN_CD,
        /* AREA_CD                      <- area_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS AREA_CD,
        /* SER_HALF_IND_AD              <- ser_half_ind_ad              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS SER_HALF_IND_AD,
        /* SERV_CITY_AD                 <- serv_city_ad                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS SERV_CITY_AD,
        /* SERV_HOUS_NBR_AD             <- serv_hous_nbr_ad             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS SERV_HOUS_NBR_AD,
        /* SERV_PTDR_AD                 <- serv_ptdr_ad                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__13, 16777216), '') AS SERV_PTDR_AD,
        /* SERV_PRDR_AD                 <- serv_prdr_ad                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__14, 16777216), '') AS SERV_PRDR_AD,
        /* RURL_RTE_TYPE_CD             <- rurl_rte_type_cd             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__15, 16777216), '') AS RURL_RTE_TYPE_CD,
        /* ROUTE_NB_AD                  <- route_nb_ad                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__16, 16777216), '') AS ROUTE_NB_AD,
        /* BOX_AD                       <- box_ad                       VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__17, 16777216), '') AS BOX_AD,
        /* SERV_ST_DSGT_AD              <- serv_st_dsgt_ad              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__18, 16777216), '') AS SERV_ST_DSGT_AD,
        /* SERV_ST_NAME_AD              <- serv_st_name_ad              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__19, 16777216), '') AS SERV_ST_NAME_AD,
        /* SERV_UNIT_DSGT_AD            <- serv_unit_dsgt_ad            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__20, 16777216), '') AS SERV_UNIT_DSGT_AD,
        /* SERV_UNIT_NBR_AD             <- serv_unit_nbr_ad             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__21, 16777216), '') AS SERV_UNIT_NBR_AD,
        /* SERV_ZIP_AD                  <- serv_zip_ad                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__22, 16777216), '') AS SERV_ZIP_AD,
        /* ACCT_STAT_CD                 <- acct_stat_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__23, 16777216), '') AS ACCT_STAT_CD,
        /* ACCT_TYPE_CD                 <- acct_type_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__24, 16777216), '') AS ACCT_TYPE_CD,
        /* LIFE_SPPR_CD                 <- life_sppr_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__25, 16777216), '') AS LIFE_SPPR_CD,
        /* REVN_CLAS_CD                 <- revn_clas_cd                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__26, 5, 0) AS REVN_CLAS_CD,
        p.N__26 AS RAW__26,
        /* ST_CD_AD                     <- st_cd_ad                     VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__27, 16777216), '') AS ST_CD_AD,
        /* TARF_CD                      <- tarf_cd                      NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__28, 5, 0) AS TARF_CD,
        p.N__28 AS RAW__28,
        /* TLPH_USE_1_CD                <- tlph_use_1_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__29, 16777216), '') AS TLPH_USE_1_CD,
        /* TLPH_USE_2_CD                <- tlph_use_2_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__30, 16777216), '') AS TLPH_USE_2_CD,
        /* PREM_STAT_CD                 <- prem_stat_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__31, 16777216), '') AS PREM_STAT_CD,
        /* ACCT_CLAS_CD                 <- acct_clas_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__32, 16777216), '') AS ACCT_CLAS_CD,
        /* RSDN_CORP_IND_CD             <- rsdn_corp_ind_cd             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__33, 16777216), '') AS RSDN_CORP_IND_CD,
        /* SIC_CD                       <- sic_cd                       NUMBER(10,0) -> NUMBER(10,0) */
        p."sic_cd" AS SIC_CD,
        /* TURN_OFF_DT                  <- turn_off_dt                  DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."turn_off_dt" AS TIMESTAMP_NTZ(9)) AS TURN_OFF_DT,
        /* TURN_ON_DT                   <- turn_on_dt                   DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."turn_on_dt" AS TIMESTAMP_NTZ(9)) AS TURN_ON_DT,
        /* LCI_ACCT_FL                  <- lci_acct_fl                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__34, 16777216), '') AS LCI_ACCT_FL,
        /* CYCL_NB                      <- cycl_nb                      NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__35, 5, 0) AS CYCL_NB,
        p.N__35 AS RAW__35,
        /* MTR_RDG_RTE_NB               <- mtr_rdg_rte_nb               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__36, 16777216), '') AS MTR_RDG_RTE_NB,
        /* OLD_ACCT_NB                  <- old_acct_nb                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__37, 16777216), '') AS OLD_ACCT_NB,
        /* TLPH_1_NB                    <- tlph_1_nb                    NUMBER(10,0) -> NUMBER(10,0) */
        p."tlph_1_nb" AS TLPH_1_NB,
        /* TLPH_2_NB                    <- tlph_2_nb                    NUMBER(10,0) -> NUMBER(10,0) */
        p."tlph_2_nb" AS TLPH_2_NB,
        /* CUST_1ST_1_NM                <- cust_1st_1_nm                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__38, 16777216), '') AS CUST_1ST_1_NM,
        /* CUST_LAST_1_NM               <- cust_last_1_nm               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__39, 16777216), '') AS CUST_LAST_1_NM,
        /* CUST_MDDL_INIT_NM            <- cust_mddl_init_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__40, 16777216), '') AS CUST_MDDL_INIT_NM,
        /* CUST_PRFX_1_NM               <- cust_prfx_1_nm               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__41, 16777216), '') AS CUST_PRFX_1_NM,
        /* CUST_SFFX_1_NM               <- cust_sffx_1_nm               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__42, 16777216), '') AS CUST_SFFX_1_NM,
        /* TAX_DSTC_CD                  <- tax_dstc_cd                  NUMBER(10,0) -> NUMBER(10,0) */
        p."tax_dstc_cd" AS TAX_DSTC_CD,
        /* CUMU_CD                      <- cumu_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__43, 16777216), '') AS CUMU_CD,
        /* FNNC_CNTL_UNIT_NB            <- fnnc_cntl_unit_nb            NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__44, 5, 0) AS FNNC_CNTL_UNIT_NB,
        p.N__44 AS RAW__44,
        /* OUT_OF_BAL_FL                <- out_of_bal_fl                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__45, 16777216), '') AS OUT_OF_BAL_FL,
        /* SCHD_TYPE_CD                 <- schd_type_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__46, 16777216), '') AS SCHD_TYPE_CD,
        /* VEND_PROG_FL                 <- vend_prog_fl                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__47, 16777216), '') AS VEND_PROG_FL,
        /* POWER_POOL_CD                <- power_pool_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__48, 16777216), '') AS POWER_POOL_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__49, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."prem_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* prem_nb -> PREM_NB */,
            REGEXP_REPLACE(src."cust_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* cust_nb -> CUST_NB */,
            REGEXP_REPLACE(src."name_idnt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* name_idnt_cd -> NAME_IDNT_CD */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."state_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* state_cd -> STATE_CD */,
            REGEXP_REPLACE(src."jrsd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* jrsd_cd -> JRSD_CD */,
            REGEXP_REPLACE(src."dvsn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* dvsn_cd -> DVSN_CD */,
            REGEXP_REPLACE(src."area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* area_cd -> AREA_CD */,
            REGEXP_REPLACE(src."ser_half_ind_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* ser_half_ind_ad -> SER_HALF_IND_AD */,
            REGEXP_REPLACE(src."serv_city_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* serv_city_ad -> SERV_CITY_AD */,
            REGEXP_REPLACE(src."serv_hous_nbr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* serv_hous_nbr_ad -> SERV_HOUS_NBR_AD */,
            REGEXP_REPLACE(src."serv_ptdr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* serv_ptdr_ad -> SERV_PTDR_AD */,
            REGEXP_REPLACE(src."serv_prdr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* serv_prdr_ad -> SERV_PRDR_AD */,
            REGEXP_REPLACE(src."rurl_rte_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* rurl_rte_type_cd -> RURL_RTE_TYPE_CD */,
            REGEXP_REPLACE(src."route_nb_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* route_nb_ad -> ROUTE_NB_AD */,
            REGEXP_REPLACE(src."box_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__17   /* box_ad -> BOX_AD */,
            REGEXP_REPLACE(src."serv_st_dsgt_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* serv_st_dsgt_ad -> SERV_ST_DSGT_AD */,
            REGEXP_REPLACE(src."serv_st_name_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__19   /* serv_st_name_ad -> SERV_ST_NAME_AD */,
            REGEXP_REPLACE(src."serv_unit_dsgt_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__20   /* serv_unit_dsgt_ad -> SERV_UNIT_DSGT_AD */,
            REGEXP_REPLACE(src."serv_unit_nbr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__21   /* serv_unit_nbr_ad -> SERV_UNIT_NBR_AD */,
            REGEXP_REPLACE(src."serv_zip_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__22   /* serv_zip_ad -> SERV_ZIP_AD */,
            REGEXP_REPLACE(src."acct_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__23   /* acct_stat_cd -> ACCT_STAT_CD */,
            REGEXP_REPLACE(src."acct_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__24   /* acct_type_cd -> ACCT_TYPE_CD */,
            REGEXP_REPLACE(src."life_sppr_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__25   /* life_sppr_cd -> LIFE_SPPR_CD */,
            TO_VARCHAR(src."revn_clas_cd") AS N__26   /* revn_clas_cd -> REVN_CLAS_CD */,
            REGEXP_REPLACE(src."st_cd_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__27   /* st_cd_ad -> ST_CD_AD */,
            TO_VARCHAR(src."tarf_cd") AS N__28   /* tarf_cd -> TARF_CD */,
            REGEXP_REPLACE(src."tlph_use_1_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__29   /* tlph_use_1_cd -> TLPH_USE_1_CD */,
            REGEXP_REPLACE(src."tlph_use_2_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__30   /* tlph_use_2_cd -> TLPH_USE_2_CD */,
            REGEXP_REPLACE(src."prem_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__31   /* prem_stat_cd -> PREM_STAT_CD */,
            REGEXP_REPLACE(src."acct_clas_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__32   /* acct_clas_cd -> ACCT_CLAS_CD */,
            REGEXP_REPLACE(src."rsdn_corp_ind_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__33   /* rsdn_corp_ind_cd -> RSDN_CORP_IND_CD */,
            REGEXP_REPLACE(src."lci_acct_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__34   /* lci_acct_fl -> LCI_ACCT_FL */,
            TO_VARCHAR(src."cycl_nb") AS N__35   /* cycl_nb -> CYCL_NB */,
            REGEXP_REPLACE(src."mtr_rdg_rte_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__36   /* mtr_rdg_rte_nb -> MTR_RDG_RTE_NB */,
            REGEXP_REPLACE(src."old_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__37   /* old_acct_nb -> OLD_ACCT_NB */,
            REGEXP_REPLACE(src."cust_1st_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__38   /* cust_1st_1_nm -> CUST_1ST_1_NM */,
            REGEXP_REPLACE(src."cust_last_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__39   /* cust_last_1_nm -> CUST_LAST_1_NM */,
            REGEXP_REPLACE(src."cust_mddl_init_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__40   /* cust_mddl_init_nm -> CUST_MDDL_INIT_NM */,
            REGEXP_REPLACE(src."cust_prfx_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__41   /* cust_prfx_1_nm -> CUST_PRFX_1_NM */,
            REGEXP_REPLACE(src."cust_sffx_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__42   /* cust_sffx_1_nm -> CUST_SFFX_1_NM */,
            REGEXP_REPLACE(src."cumu_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__43   /* cumu_cd -> CUMU_CD */,
            TO_VARCHAR(src."fnnc_cntl_unit_nb") AS N__44   /* fnnc_cntl_unit_nb -> FNNC_CNTL_UNIT_NB */,
            REGEXP_REPLACE(src."out_of_bal_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__45   /* out_of_bal_fl -> OUT_OF_BAL_FL */,
            REGEXP_REPLACE(src."schd_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__46   /* schd_type_cd -> SCHD_TYPE_CD */,
            REGEXP_REPLACE(src."vend_prog_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__47   /* vend_prog_fl -> VEND_PROG_FL */,
            REGEXP_REPLACE(src."power_pool_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__48   /* power_pool_cd -> POWER_POOL_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__49   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_INDICATIV_DATA') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_indicativ_data"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* PREM_NB */
    AND (s.PREM_NB IS NOT NULL AND s.PREM_NB <> '')   /* NULL or blank in a key column */
    /* CUST_NB */
    AND (s.CUST_NB IS NOT NULL AND s.CUST_NB <> '')   /* NULL or blank in a key column */
    /* NAME_IDNT_CD */
    AND (s.NAME_IDNT_CD IS NOT NULL AND s.NAME_IDNT_CD <> '')   /* NULL or blank in a key column */
    /* REVN_CLAS_CD */
    AND (s.RAW__26 IS NULL OR s.REVN_CLAS_CD IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.REVN_CLAS_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TARF_CD */
    AND (s.RAW__28 IS NULL OR s.TARF_CD IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.TARF_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* SIC_CD */
    AND s.SIC_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* CYCL_NB */
    AND (s.RAW__35 IS NULL OR s.CYCL_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.CYCL_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TLPH_1_NB */
    AND s.TLPH_1_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TLPH_2_NB */
    AND s.TLPH_2_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TAX_DSTC_CD */
    AND s.TAX_DSTC_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* FNNC_CNTL_UNIT_NB */
    AND (s.RAW__44 IS NULL OR s.FNNC_CNTL_UNIT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.FNNC_CNTL_UNIT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.PREM_NB, s.CUST_NB, s.NAME_IDNT_CD
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.PREM_NB,
    SRC.CUST_NB,
    SRC.NAME_IDNT_CD,
    SRC.CO_CD_OWNR,
    SRC.STATE_CD,
    SRC.JRSD_CD,
    SRC.DVSN_CD,
    SRC.AREA_CD,
    SRC.SER_HALF_IND_AD,
    SRC.SERV_CITY_AD,
    SRC.SERV_HOUS_NBR_AD,
    SRC.SERV_PTDR_AD,
    SRC.SERV_PRDR_AD,
    SRC.RURL_RTE_TYPE_CD,
    SRC.ROUTE_NB_AD,
    SRC.BOX_AD,
    SRC.SERV_ST_DSGT_AD,
    SRC.SERV_ST_NAME_AD,
    SRC.SERV_UNIT_DSGT_AD,
    SRC.SERV_UNIT_NBR_AD,
    SRC.SERV_ZIP_AD,
    SRC.ACCT_STAT_CD,
    SRC.ACCT_TYPE_CD,
    SRC.LIFE_SPPR_CD,
    SRC.REVN_CLAS_CD,
    SRC.ST_CD_AD,
    SRC.TARF_CD,
    SRC.TLPH_USE_1_CD,
    SRC.TLPH_USE_2_CD,
    SRC.PREM_STAT_CD,
    SRC.ACCT_CLAS_CD,
    SRC.RSDN_CORP_IND_CD,
    SRC.SIC_CD,
    SRC.TURN_OFF_DT,
    SRC.TURN_ON_DT,
    SRC.LCI_ACCT_FL,
    SRC.CYCL_NB,
    SRC.MTR_RDG_RTE_NB,
    SRC.OLD_ACCT_NB,
    SRC.TLPH_1_NB,
    SRC.TLPH_2_NB,
    SRC.CUST_1ST_1_NM,
    SRC.CUST_LAST_1_NM,
    SRC.CUST_MDDL_INIT_NM,
    SRC.CUST_PRFX_1_NM,
    SRC.CUST_SFFX_1_NM,
    SRC.TAX_DSTC_CD,
    SRC.CUMU_CD,
    SRC.FNNC_CNTL_UNIT_NB,
    SRC.OUT_OF_BAL_FL,
    SRC.SCHD_TYPE_CD,
    SRC.VEND_PROG_FL,
    SRC.POWER_POOL_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_INDICATIV_DATA_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_INDICATIV_DATA') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, PREM_NB, CUST_NB, NAME_IDNT_CD
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.PREM_NB = TGT.PREM_NB
    AND SRC.CUST_NB = TGT.CUST_NB
    AND SRC.NAME_IDNT_CD = TGT.NAME_IDNT_CD
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.STATE_CD, TGT.STATE_CD, 1, 0) = 0
        OR DECODE(SRC.JRSD_CD, TGT.JRSD_CD, 1, 0) = 0
        OR DECODE(SRC.DVSN_CD, TGT.DVSN_CD, 1, 0) = 0
        OR DECODE(SRC.AREA_CD, TGT.AREA_CD, 1, 0) = 0
        OR DECODE(SRC.SER_HALF_IND_AD, TGT.SER_HALF_IND_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_CITY_AD, TGT.SERV_CITY_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_HOUS_NBR_AD, TGT.SERV_HOUS_NBR_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_PTDR_AD, TGT.SERV_PTDR_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_PRDR_AD, TGT.SERV_PRDR_AD, 1, 0) = 0
        OR DECODE(SRC.RURL_RTE_TYPE_CD, TGT.RURL_RTE_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.ROUTE_NB_AD, TGT.ROUTE_NB_AD, 1, 0) = 0
        OR DECODE(SRC.BOX_AD, TGT.BOX_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_ST_DSGT_AD, TGT.SERV_ST_DSGT_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_ST_NAME_AD, TGT.SERV_ST_NAME_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_UNIT_DSGT_AD, TGT.SERV_UNIT_DSGT_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_UNIT_NBR_AD, TGT.SERV_UNIT_NBR_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_ZIP_AD, TGT.SERV_ZIP_AD, 1, 0) = 0
        OR DECODE(SRC.ACCT_STAT_CD, TGT.ACCT_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.ACCT_TYPE_CD, TGT.ACCT_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.LIFE_SPPR_CD, TGT.LIFE_SPPR_CD, 1, 0) = 0
        OR DECODE(SRC.REVN_CLAS_CD, TGT.REVN_CLAS_CD, 1, 0) = 0
        OR DECODE(SRC.ST_CD_AD, TGT.ST_CD_AD, 1, 0) = 0
        OR DECODE(SRC.TARF_CD, TGT.TARF_CD, 1, 0) = 0
        OR DECODE(SRC.TLPH_USE_1_CD, TGT.TLPH_USE_1_CD, 1, 0) = 0
        OR DECODE(SRC.TLPH_USE_2_CD, TGT.TLPH_USE_2_CD, 1, 0) = 0
        OR DECODE(SRC.PREM_STAT_CD, TGT.PREM_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.ACCT_CLAS_CD, TGT.ACCT_CLAS_CD, 1, 0) = 0
        OR DECODE(SRC.RSDN_CORP_IND_CD, TGT.RSDN_CORP_IND_CD, 1, 0) = 0
        OR DECODE(SRC.SIC_CD, TGT.SIC_CD, 1, 0) = 0
        OR DECODE(SRC.TURN_OFF_DT, TGT.TURN_OFF_DT, 1, 0) = 0
        OR DECODE(SRC.TURN_ON_DT, TGT.TURN_ON_DT, 1, 0) = 0
        OR DECODE(SRC.LCI_ACCT_FL, TGT.LCI_ACCT_FL, 1, 0) = 0
        OR DECODE(SRC.CYCL_NB, TGT.CYCL_NB, 1, 0) = 0
        OR DECODE(SRC.MTR_RDG_RTE_NB, TGT.MTR_RDG_RTE_NB, 1, 0) = 0
        OR DECODE(SRC.OLD_ACCT_NB, TGT.OLD_ACCT_NB, 1, 0) = 0
        OR DECODE(SRC.TLPH_1_NB, TGT.TLPH_1_NB, 1, 0) = 0
        OR DECODE(SRC.TLPH_2_NB, TGT.TLPH_2_NB, 1, 0) = 0
        OR DECODE(SRC.CUST_1ST_1_NM, TGT.CUST_1ST_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_LAST_1_NM, TGT.CUST_LAST_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_MDDL_INIT_NM, TGT.CUST_MDDL_INIT_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_PRFX_1_NM, TGT.CUST_PRFX_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_SFFX_1_NM, TGT.CUST_SFFX_1_NM, 1, 0) = 0
        OR DECODE(SRC.TAX_DSTC_CD, TGT.TAX_DSTC_CD, 1, 0) = 0
        OR DECODE(SRC.CUMU_CD, TGT.CUMU_CD, 1, 0) = 0
        OR DECODE(SRC.FNNC_CNTL_UNIT_NB, TGT.FNNC_CNTL_UNIT_NB, 1, 0) = 0
        OR DECODE(SRC.OUT_OF_BAL_FL, TGT.OUT_OF_BAL_FL, 1, 0) = 0
        OR DECODE(SRC.SCHD_TYPE_CD, TGT.SCHD_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.VEND_PROG_FL, TGT.VEND_PROG_FL, 1, 0) = 0
        OR DECODE(SRC.POWER_POOL_CD, TGT.POWER_POOL_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )


