{{ config(
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['CO_CD_OWNR', 'BILL_ACCT_NB', 'CNV_ID', 'TS_20_TS'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_TRANS_HIST_HDR')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_TRANS_HIST_HDR')
    ]
) }}

WITH ODS_MCS_TRANS_HIST_HDR_SQ AS (
SELECT
    s.CO_CD_OWNR,
    s.BILL_ACCT_NB,
    s.CNV_ID,
    s.RVRS_TS_20_TX,
    s.TS_20_TS,
    s.ORDR_NB,
    s.DVSN_CD,
    s.AREA_CD,
    s.STATE_CD,
    s.CUST_NB,
    s.PREM_NB,
    s.CUST_CMPN_CD,
    s.ORDR_CMPL_DT,
    s.ORDR_EFCT_DT,
    s.ORDR_CRTN_TS,
    s.ORDR_FUNC_CD,
    s.ORDR_RESN_CD,
    s.ORDR_STAT_CD,
    s.USER_ID,
    s.SCRN_CRTN_CD,
    s.RMRK_TX,
    s.LAST_TRNS_DT,
    s.RVRS_TS_NB,
    s.TS_NB,
    s.UPTR_TRMN_ID_NB,
    s.TRNS_AT,
    s.CRDT_COLL_ACTN_CD,
    s.COLL_ACTV_CTGY_CD,
    s.RMRK_4_TX,
    s.TRAN_HIST_STAT_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS CO_CD_OWNR,
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__2, 16777216) AS BILL_ACCT_NB,
        /* CNV_ID                       <- cnv_id                       VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__3, 16777216) AS CNV_ID,
        /* RVRS_TS_20_TX                <- rvrs_ts_20_ts                VARCHAR(134217728) -> VARCHAR(16777216)  [override] */
        LEFT(p.N__4, 16777216) AS RVRS_TS_20_TX,
        /* TS_20_TS                     <- rvrs_ts_20_ts                VARCHAR(134217728) -> TIMESTAMP_NTZ(6)  [override, reversed] */
        TRY_TO_TIMESTAMP_NTZ(
                   SUBSTR(p.N__5,  1, 4) || '-' || SUBSTR(p.N__5,  5, 2) || '-' || SUBSTR(p.N__5,  7, 2)
            || ' ' || SUBSTR(p.N__5,  9, 2) || ':' || SUBSTR(p.N__5, 11, 2) || ':' || SUBSTR(p.N__5, 13, 2)
            || '.' || SUBSTR(p.N__5, 15, 6),
            'YYYY-MM-DD HH24:MI:SS.FF'
        ) AS TS_20_TS,
        p.N__5 AS RAW__5,
        /* ORDR_NB                      <- ordr_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__6, 16777216) AS ORDR_NB,
        /* DVSN_CD                      <- dvsn_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__7, 16777216) AS DVSN_CD,
        /* AREA_CD                      <- area_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__8, 16777216) AS AREA_CD,
        /* STATE_CD                     <- state_cd                     VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__9, 16777216) AS STATE_CD,
        /* CUST_NB                      <- cust_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__10, 16777216) AS CUST_NB,
        /* PREM_NB                      <- prem_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__11, 16777216) AS PREM_NB,
        /* CUST_CMPN_CD                 <- cust_cmpn_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__12, 16777216) AS CUST_CMPN_CD,
        /* ORDR_CMPL_DT                 <- ordr_cmpl_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."ordr_cmpl_dt" AS TIMESTAMP_NTZ(9)) AS ORDR_CMPL_DT,
        /* ORDR_EFCT_DT                 <- ordr_efct_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."ordr_efct_dt" AS TIMESTAMP_NTZ(9)) AS ORDR_EFCT_DT,
        /* ORDR_CRTN_TS                 <- ordr_crtn_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."ordr_crtn_ts" AS ORDR_CRTN_TS,
        /* ORDR_FUNC_CD                 <- ordr_func_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__13, 16777216) AS ORDR_FUNC_CD,
        /* ORDR_RESN_CD                 <- ordr_resn_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__14, 16777216) AS ORDR_RESN_CD,
        /* ORDR_STAT_CD                 <- ordr_stat_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__15, 16777216) AS ORDR_STAT_CD,
        /* USER_ID                      <- user_id                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__16, 16777216) AS USER_ID,
        /* SCRN_CRTN_CD                 <- scrn_crtn_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__17, 16777216) AS SCRN_CRTN_CD,
        /* RMRK_TX                      <- rmrk_tx                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__18, 16777216) AS RMRK_TX,
        /* LAST_TRNS_DT                 <- last_trns_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."last_trns_dt" AS TIMESTAMP_NTZ(9)) AS LAST_TRNS_DT,
        /* RVRS_TS_NB                   <- rvrs_ts_nb                   NUMBER(15,0) -> NUMBER(15,0) */
        p."rvrs_ts_nb" AS RVRS_TS_NB,
        /* TS_NB                        <- rvrs_ts_nb                   NUMBER(15,0) -> NUMBER(15,0)  [override, reversed] */
        TRY_TO_NUMBER(REVERSE(TO_VARCHAR(p."rvrs_ts_nb"))) AS TS_NB,
        /* UPTR_TRMN_ID_NB              <- uptr_trmn_id_nb              VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__19, 16777216) AS UPTR_TRMN_ID_NB,
        /* TRNS_AT                      <- trns_at                      NUMBER(10,2) -> NUMBER(10,2) */
        p."trns_at" AS TRNS_AT,
        /* CRDT_COLL_ACTN_CD            <- crdt_coll_actn_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__20, 16777216) AS CRDT_COLL_ACTN_CD,
        /* COLL_ACTV_CTGY_CD            <- coll_actv_ctgy_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__21, 16777216) AS COLL_ACTV_CTGY_CD,
        /* RMRK_4_TX                    <- rmrk_4_tx                    VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__22, 16777216) AS RMRK_4_TX,
        /* TRAN_HIST_STAT_CD            <- tran_hist_stat_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__23, 16777216) AS TRAN_HIST_STAT_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__24, 16777216) AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."cnv_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* cnv_id -> CNV_ID */,
            REGEXP_REPLACE(src."rvrs_ts_20_ts", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* rvrs_ts_20_ts -> RVRS_TS_20_TX */,
            REVERSE(NULLIF(REGEXP_REPLACE(REGEXP_REPLACE(src."rvrs_ts_20_ts", '^[[:space:]]+|[[:space:]]+$', ''), '^(NULL|N/A|NA|NONE|[#]N/A|UNKNOWN)$', '', 1, 0, 'i'), '')) AS N__5   /* rvrs_ts_20_ts -> TS_20_TS: reversed, the digits run backwards in the source */,
            REGEXP_REPLACE(src."ordr_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* ordr_nb -> ORDR_NB */,
            REGEXP_REPLACE(src."dvsn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* dvsn_cd -> DVSN_CD */,
            REGEXP_REPLACE(src."area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* area_cd -> AREA_CD */,
            REGEXP_REPLACE(src."state_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* state_cd -> STATE_CD */,
            REGEXP_REPLACE(src."cust_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* cust_nb -> CUST_NB */,
            REGEXP_REPLACE(src."prem_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* prem_nb -> PREM_NB */,
            REGEXP_REPLACE(src."cust_cmpn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* cust_cmpn_cd -> CUST_CMPN_CD */,
            REGEXP_REPLACE(src."ordr_func_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* ordr_func_cd -> ORDR_FUNC_CD */,
            REGEXP_REPLACE(src."ordr_resn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* ordr_resn_cd -> ORDR_RESN_CD */,
            REGEXP_REPLACE(src."ordr_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* ordr_stat_cd -> ORDR_STAT_CD */,
            REGEXP_REPLACE(src."user_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* user_id -> USER_ID */,
            REGEXP_REPLACE(src."scrn_crtn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__17   /* scrn_crtn_cd -> SCRN_CRTN_CD */,
            REGEXP_REPLACE(src."rmrk_tx", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* rmrk_tx -> RMRK_TX */,
            REGEXP_REPLACE(src."uptr_trmn_id_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__19   /* uptr_trmn_id_nb -> UPTR_TRMN_ID_NB */,
            REGEXP_REPLACE(src."crdt_coll_actn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__20   /* crdt_coll_actn_cd -> CRDT_COLL_ACTN_CD */,
            REGEXP_REPLACE(src."coll_actv_ctgy_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__21   /* coll_actv_ctgy_cd -> COLL_ACTV_CTGY_CD */,
            REGEXP_REPLACE(src."rmrk_4_tx", '^[[:space:]]+|[[:space:]]+$', '') AS N__22   /* rmrk_4_tx -> RMRK_4_TX */,
            REGEXP_REPLACE(src."tran_hist_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__23   /* tran_hist_stat_cd -> TRAN_HIST_STAT_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__24   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_TRANS_HIST_HDR') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_trans_hist_hdr"
    ) p
) s
WHERE 1 = 1
    /* CO_CD_OWNR */
    AND s.CO_CD_OWNR IS NOT NULL   /* NULL or blank in a key column */
    /* BILL_ACCT_NB */
    AND s.BILL_ACCT_NB IS NOT NULL   /* NULL or blank in a key column */
    /* CNV_ID */
    AND s.CNV_ID IS NOT NULL   /* NULL or blank in a key column */
    /* TS_20_TS */
    AND (s.RAW__5 IS NULL OR REGEXP_LIKE(s.RAW__5, '^[0-9]{20}$'))   /* reversed rvrs_ts_20_ts must be exactly 20 digits */
    AND (s.RAW__5 IS NULL OR s.TS_20_TS IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND (s.TS_20_TS IS NULL OR YEAR(s.TS_20_TS) BETWEEN 1900 AND 9999)   /* date/timestamp outside the accepted year range */
    AND s.TS_20_TS IS NOT NULL   /* NULL or blank in a key column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.CO_CD_OWNR, s.BILL_ACCT_NB, s.CNV_ID, s.TS_20_TS
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.CO_CD_OWNR,
    SRC.BILL_ACCT_NB,
    SRC.CNV_ID,
    SRC.RVRS_TS_20_TX,
    SRC.TS_20_TS,
    SRC.ORDR_NB,
    SRC.DVSN_CD,
    SRC.AREA_CD,
    SRC.STATE_CD,
    SRC.CUST_NB,
    SRC.PREM_NB,
    SRC.CUST_CMPN_CD,
    SRC.ORDR_CMPL_DT,
    SRC.ORDR_EFCT_DT,
    SRC.ORDR_CRTN_TS,
    SRC.ORDR_FUNC_CD,
    SRC.ORDR_RESN_CD,
    SRC.ORDR_STAT_CD,
    SRC.USER_ID,
    SRC.SCRN_CRTN_CD,
    SRC.RMRK_TX,
    SRC.LAST_TRNS_DT,
    SRC.RVRS_TS_NB,
    SRC.TS_NB,
    SRC.UPTR_TRMN_ID_NB,
    SRC.TRNS_AT,
    SRC.CRDT_COLL_ACTN_CD,
    SRC.COLL_ACTV_CTGY_CD,
    SRC.RMRK_4_TX,
    SRC.TRAN_HIST_STAT_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_TRANS_HIST_HDR_SQ SRC
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_TRANS_HIST_HDR') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY CO_CD_OWNR, BILL_ACCT_NB, CNV_ID, TS_20_TS
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.CO_CD_OWNR = TGT.CO_CD_OWNR
    AND SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.CNV_ID = TGT.CNV_ID
    AND SRC.TS_20_TS = TGT.TS_20_TS
WHERE
    TGT.CO_CD_OWNR IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.RVRS_TS_20_TX, TGT.RVRS_TS_20_TX, 1, 0) = 0
        OR DECODE(SRC.ORDR_NB, TGT.ORDR_NB, 1, 0) = 0
        OR DECODE(SRC.DVSN_CD, TGT.DVSN_CD, 1, 0) = 0
        OR DECODE(SRC.AREA_CD, TGT.AREA_CD, 1, 0) = 0
        OR DECODE(SRC.STATE_CD, TGT.STATE_CD, 1, 0) = 0
        OR DECODE(SRC.CUST_NB, TGT.CUST_NB, 1, 0) = 0
        OR DECODE(SRC.PREM_NB, TGT.PREM_NB, 1, 0) = 0
        OR DECODE(SRC.CUST_CMPN_CD, TGT.CUST_CMPN_CD, 1, 0) = 0
        OR DECODE(SRC.ORDR_CMPL_DT, TGT.ORDR_CMPL_DT, 1, 0) = 0
        OR DECODE(SRC.ORDR_EFCT_DT, TGT.ORDR_EFCT_DT, 1, 0) = 0
        OR DECODE(SRC.ORDR_CRTN_TS, TGT.ORDR_CRTN_TS, 1, 0) = 0
        OR DECODE(SRC.ORDR_FUNC_CD, TGT.ORDR_FUNC_CD, 1, 0) = 0
        OR DECODE(SRC.ORDR_RESN_CD, TGT.ORDR_RESN_CD, 1, 0) = 0
        OR DECODE(SRC.ORDR_STAT_CD, TGT.ORDR_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.USER_ID, TGT.USER_ID, 1, 0) = 0
        OR DECODE(SRC.SCRN_CRTN_CD, TGT.SCRN_CRTN_CD, 1, 0) = 0
        OR DECODE(SRC.RMRK_TX, TGT.RMRK_TX, 1, 0) = 0
        OR DECODE(SRC.LAST_TRNS_DT, TGT.LAST_TRNS_DT, 1, 0) = 0
        OR DECODE(SRC.RVRS_TS_NB, TGT.RVRS_TS_NB, 1, 0) = 0
        OR DECODE(SRC.TS_NB, TGT.TS_NB, 1, 0) = 0
        OR DECODE(SRC.UPTR_TRMN_ID_NB, TGT.UPTR_TRMN_ID_NB, 1, 0) = 0
        OR DECODE(SRC.TRNS_AT, TGT.TRNS_AT, 1, 0) = 0
        OR DECODE(SRC.CRDT_COLL_ACTN_CD, TGT.CRDT_COLL_ACTN_CD, 1, 0) = 0
        OR DECODE(SRC.COLL_ACTV_CTGY_CD, TGT.COLL_ACTV_CTGY_CD, 1, 0) = 0
        OR DECODE(SRC.RMRK_4_TX, TGT.RMRK_4_TX, 1, 0) = 0
        OR DECODE(SRC.TRAN_HIST_STAT_CD, TGT.TRAN_HIST_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )
