
{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['WEB_ID', 'BILL_ACCT_NB'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_WEB_BILL_ACCT')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_WEB_BILL_ACCT')
    ]
) }}

WITH ODS_MCS_WEB_BILL_ACCT_SQ AS (
SELECT
    s.WEB_ID,
    s.BILL_ACCT_NB,
    s.WEB_STAT_CD,
    s.CUST_NB,
    s.MSG_TX,
    s.CRTN_TS,
    s.LAST_UPDT_TS,
    s.BDHV_STAT_CD,
    s.BDHV_CONSUMER_ID,
    s.BDHV_TC_CD,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* WEB_ID                       <- web_id                       VARCHAR(134217728) -> VARCHAR(320) */
        LEFT(p.N__1, 320) AS WEB_ID,
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(10) */
        LEFT(p.N__2, 10) AS BILL_ACCT_NB,
        /* WEB_STAT_CD                  <- web_stat_cd                  VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__3, 1), '') AS WEB_STAT_CD,
        /* CUST_NB                      <- cust_nb                      VARCHAR(134217728) -> VARCHAR(9) */
        COALESCE(LEFT(p.N__4, 9), '') AS CUST_NB,
        /* MSG_TX                       <- msg_tx                       VARCHAR(134217728) -> VARCHAR(75) */
        COALESCE(LEFT(p.N__5, 75), '') AS MSG_TX,
        /* CRTN_TS                      <- crtn_ts                      TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."crtn_ts" AS CRTN_TS,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* BDHV_STAT_CD                 <- bdhv_stat_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__6, 1), '') AS BDHV_STAT_CD,
        /* BDHV_CONSUMER_ID             <- bdhv_consumer_id             VARCHAR(134217728) -> VARCHAR(32) */
        COALESCE(LEFT(p.N__7, 32), '') AS BDHV_CONSUMER_ID,
        /* BDHV_TC_CD                   <- bdhv_tc_cd                   VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__8, 1), '') AS BDHV_TC_CD
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."web_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* web_id -> WEB_ID */,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."web_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* web_stat_cd -> WEB_STAT_CD */,
            REGEXP_REPLACE(src."cust_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* cust_nb -> CUST_NB */,
            REGEXP_REPLACE(src."msg_tx", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* msg_tx -> MSG_TX */,
            REGEXP_REPLACE(src."bdhv_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* bdhv_stat_cd -> BDHV_STAT_CD */,
            REGEXP_REPLACE(src."bdhv_consumer_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* bdhv_consumer_id -> BDHV_CONSUMER_ID */,
            REGEXP_REPLACE(src."bdhv_tc_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* bdhv_tc_cd -> BDHV_TC_CD */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_WEB_BILL_ACCT') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_web_bill_acct"
    ) p
) s
WHERE 1 = 1
    /* WEB_ID */
    AND (s.WEB_ID IS NOT NULL AND s.WEB_ID <> '')   /* NULL or blank in a key column */
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* CRTN_TS */
    AND s.CRTN_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.WEB_ID, s.BILL_ACCT_NB
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.WEB_ID,
    SRC.BILL_ACCT_NB,
    SRC.WEB_STAT_CD,
    SRC.CUST_NB,
    SRC.MSG_TX,
    SRC.CRTN_TS,
    SRC.LAST_UPDT_TS,
    SRC.BDHV_STAT_CD,
    SRC.BDHV_CONSUMER_ID,
    SRC.BDHV_TC_CD,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_WEB_BILL_ACCT_SQ SRC


LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_WEB_BILL_ACCT') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY WEB_ID, BILL_ACCT_NB
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.WEB_ID = TGT.WEB_ID
    AND SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
WHERE
    TGT.WEB_ID IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.WEB_STAT_CD, TGT.WEB_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.CUST_NB, TGT.CUST_NB, 1, 0) = 0
        OR DECODE(SRC.MSG_TX, TGT.MSG_TX, 1, 0) = 0
        OR DECODE(SRC.CRTN_TS, TGT.CRTN_TS, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.BDHV_STAT_CD, TGT.BDHV_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.BDHV_CONSUMER_ID, TGT.BDHV_CONSUMER_ID, 1, 0) = 0
        OR DECODE(SRC.BDHV_TC_CD, TGT.BDHV_TC_CD, 1, 0) = 0
    )


