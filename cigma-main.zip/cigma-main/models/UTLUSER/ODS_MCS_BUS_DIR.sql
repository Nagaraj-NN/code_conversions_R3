

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'PROD_ORDR_NB', 'DIR_TYPE_CD'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BUS_DIR')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BUS_DIR')
    ]
) }}

WITH ODS_MCS_BUS_DIR_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.PROD_ORDR_NB,
    s.DIR_TYPE_CD,
    s.CO_CD_OWNR,
    s.BAL_DUE_AT,
    s.BSNS_BAL_AT,
    s.DFRR_BAL_AT,
    s.INIT_PYMN_DPMT_AT,
    s.FINL_INSM_AT,
    s.INSM_AT,
    s.TOT_INSM_BSNS_AT,
    s.FNNC_CHRG_AT,
    s.UNPR_BAL_AT,
    s.PAYABLE_BAL_AT,
    s.BSNS_CD,
    s.BSNS_STAT_CD,
    s.BSNS_TYPE_CD,
    s.FREQ_CD,
    s.PYMN_MTHD_CD,
    s.BSNS_SET_UP_DT,
    s.BILL_WITH_SRVC_FL,
    s.ANNL_PRCN_RT_PC,
    s.INSM_QY,
    s.REMN_INSM_QY,
    s.FIRST_INSM_DUE_DT,
    s.INIT_PYMN_DUE_DT,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(10) */
        LEFT(p.N__1, 10) AS BILL_ACCT_NB,
        /* PROD_ORDR_NB                 <- prod_ordr_nb                 NUMBER(10,0) -> NUMBER(38,0) */
        p."prod_ordr_nb" AS PROD_ORDR_NB,
        /* DIR_TYPE_CD                  <- dir_type_cd                  VARCHAR(134217728) -> VARCHAR(4) */
        LEFT(p.N__2, 4) AS DIR_TYPE_CD,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(2) */
        LEFT(p.N__3, 2) AS CO_CD_OWNR,
        /* BAL_DUE_AT                   <- bal_due_at                   NUMBER(10,2) -> NUMBER(10,2) */
        p."bal_due_at" AS BAL_DUE_AT,
        /* BSNS_BAL_AT                  <- bsns_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."bsns_bal_at" AS BSNS_BAL_AT,
        /* DFRR_BAL_AT                  <- dfrr_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."dfrr_bal_at" AS DFRR_BAL_AT,
        /* INIT_PYMN_DPMT_AT            <- init_pymn_dpmt_at            NUMBER(10,2) -> NUMBER(10,2) */
        p."init_pymn_dpmt_at" AS INIT_PYMN_DPMT_AT,
        /* FINL_INSM_AT                 <- finl_insm_at                 NUMBER(9,2) -> NUMBER(9,2) */
        p."finl_insm_at" AS FINL_INSM_AT,
        /* INSM_AT                      <- insm_at                      NUMBER(10,2) -> NUMBER(10,2) */
        p."insm_at" AS INSM_AT,
        /* TOT_INSM_BSNS_AT             <- tot_insm_bsns_at             NUMBER(10,2) -> NUMBER(10,2) */
        p."tot_insm_bsns_at" AS TOT_INSM_BSNS_AT,
        /* FNNC_CHRG_AT                 <- fnnc_chrg_at                 NUMBER(9,2) -> NUMBER(9,2) */
        p."fnnc_chrg_at" AS FNNC_CHRG_AT,
        /* UNPR_BAL_AT                  <- unpr_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."unpr_bal_at" AS UNPR_BAL_AT,
        /* PAYABLE_BAL_AT               <- payable_bal_at               NUMBER(10,2) -> NUMBER(10,2) */
        p."payable_bal_at" AS PAYABLE_BAL_AT,
        /* BSNS_CD                      <- bsns_cd                      VARCHAR(134217728) -> VARCHAR(3) */
        LEFT(p.N__4, 3) AS BSNS_CD,
        /* BSNS_STAT_CD                 <- bsns_stat_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        LEFT(p.N__5, 1) AS BSNS_STAT_CD,
        /* BSNS_TYPE_CD                 <- bsns_type_cd                 VARCHAR(134217728) -> VARCHAR(2) */
        LEFT(p.N__6, 2) AS BSNS_TYPE_CD,
        /* FREQ_CD                      <- freq_cd                      VARCHAR(134217728) -> VARCHAR(2) */
        LEFT(p.N__7, 2) AS FREQ_CD,
        /* PYMN_MTHD_CD                 <- pymn_mthd_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        LEFT(p.N__8, 1) AS PYMN_MTHD_CD,
        /* BSNS_SET_UP_DT               <- bsns_set_up_dt               DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."bsns_set_up_dt" AS TIMESTAMP_NTZ(9)) AS BSNS_SET_UP_DT,
        /* BILL_WITH_SRVC_FL            <- bill_with_srvc_fl            VARCHAR(134217728) -> VARCHAR(1) */
        LEFT(p.N__9, 1) AS BILL_WITH_SRVC_FL,
        /* ANNL_PRCN_RT_PC              <- annl_prcn_rt_pc              NUMBER(3,1) -> NUMBER(3,1) */
        p."annl_prcn_rt_pc" AS ANNL_PRCN_RT_PC,
        /* INSM_QY                      <- insm_qy                      NUMBER(10,0) -> NUMBER(38,0) */
        p."insm_qy" AS INSM_QY,
        /* REMN_INSM_QY                 <- remn_insm_qy                 NUMBER(10,0) -> NUMBER(38,0) */
        p."remn_insm_qy" AS REMN_INSM_QY,
        /* FIRST_INSM_DUE_DT            <- first_insm_due_dt            DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."first_insm_due_dt" AS TIMESTAMP_NTZ(9)) AS FIRST_INSM_DUE_DT,
        /* INIT_PYMN_DUE_DT             <- init_pymn_due_dt             DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."init_pymn_due_dt" AS TIMESTAMP_NTZ(9)) AS INIT_PYMN_DUE_DT,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(8) */
        LEFT(p.N__10, 8) AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(9) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."dir_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* dir_type_cd -> DIR_TYPE_CD */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."bsns_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* bsns_cd -> BSNS_CD */,
            REGEXP_REPLACE(src."bsns_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* bsns_stat_cd -> BSNS_STAT_CD */,
            REGEXP_REPLACE(src."bsns_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* bsns_type_cd -> BSNS_TYPE_CD */,
            REGEXP_REPLACE(src."freq_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* freq_cd -> FREQ_CD */,
            REGEXP_REPLACE(src."pymn_mthd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* pymn_mthd_cd -> PYMN_MTHD_CD */,
            REGEXP_REPLACE(src."bill_with_srvc_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* bill_with_srvc_fl -> BILL_WITH_SRVC_FL */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_BUS_DIR') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_bus_dir"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* PROD_ORDR_NB */
    AND s.PROD_ORDR_NB IS NOT NULL   /* NULL or blank in a key column */
    /* DIR_TYPE_CD */
    AND (s.DIR_TYPE_CD IS NOT NULL AND s.DIR_TYPE_CD <> '')   /* NULL or blank in a key column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.PROD_ORDR_NB, s.DIR_TYPE_CD
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.PROD_ORDR_NB,
    SRC.DIR_TYPE_CD,
    SRC.CO_CD_OWNR,
    SRC.BAL_DUE_AT,
    SRC.BSNS_BAL_AT,
    SRC.DFRR_BAL_AT,
    SRC.INIT_PYMN_DPMT_AT,
    SRC.FINL_INSM_AT,
    SRC.INSM_AT,
    SRC.TOT_INSM_BSNS_AT,
    SRC.FNNC_CHRG_AT,
    SRC.UNPR_BAL_AT,
    SRC.PAYABLE_BAL_AT,
    SRC.BSNS_CD,
    SRC.BSNS_STAT_CD,
    SRC.BSNS_TYPE_CD,
    SRC.FREQ_CD,
    SRC.PYMN_MTHD_CD,
    SRC.BSNS_SET_UP_DT,
    SRC.BILL_WITH_SRVC_FL,
    SRC.ANNL_PRCN_RT_PC,
    SRC.INSM_QY,
    SRC.REMN_INSM_QY,
    SRC.FIRST_INSM_DUE_DT,
    SRC.INIT_PYMN_DUE_DT,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_BUS_DIR_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BUS_DIR') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, PROD_ORDR_NB, DIR_TYPE_CD
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.PROD_ORDR_NB = TGT.PROD_ORDR_NB
    AND SRC.DIR_TYPE_CD = TGT.DIR_TYPE_CD
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.BAL_DUE_AT, TGT.BAL_DUE_AT, 1, 0) = 0
        OR DECODE(SRC.BSNS_BAL_AT, TGT.BSNS_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.DFRR_BAL_AT, TGT.DFRR_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.INIT_PYMN_DPMT_AT, TGT.INIT_PYMN_DPMT_AT, 1, 0) = 0
        OR DECODE(SRC.FINL_INSM_AT, TGT.FINL_INSM_AT, 1, 0) = 0
        OR DECODE(SRC.INSM_AT, TGT.INSM_AT, 1, 0) = 0
        OR DECODE(SRC.TOT_INSM_BSNS_AT, TGT.TOT_INSM_BSNS_AT, 1, 0) = 0
        OR DECODE(SRC.FNNC_CHRG_AT, TGT.FNNC_CHRG_AT, 1, 0) = 0
        OR DECODE(SRC.UNPR_BAL_AT, TGT.UNPR_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.PAYABLE_BAL_AT, TGT.PAYABLE_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.BSNS_CD, TGT.BSNS_CD, 1, 0) = 0
        OR DECODE(SRC.BSNS_STAT_CD, TGT.BSNS_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.BSNS_TYPE_CD, TGT.BSNS_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.FREQ_CD, TGT.FREQ_CD, 1, 0) = 0
        OR DECODE(SRC.PYMN_MTHD_CD, TGT.PYMN_MTHD_CD, 1, 0) = 0
        OR DECODE(SRC.BSNS_SET_UP_DT, TGT.BSNS_SET_UP_DT, 1, 0) = 0
        OR DECODE(SRC.BILL_WITH_SRVC_FL, TGT.BILL_WITH_SRVC_FL, 1, 0) = 0
        OR DECODE(SRC.ANNL_PRCN_RT_PC, TGT.ANNL_PRCN_RT_PC, 1, 0) = 0
        OR DECODE(SRC.INSM_QY, TGT.INSM_QY, 1, 0) = 0
        OR DECODE(SRC.REMN_INSM_QY, TGT.REMN_INSM_QY, 1, 0) = 0
        OR DECODE(SRC.FIRST_INSM_DUE_DT, TGT.FIRST_INSM_DUE_DT, 1, 0) = 0
        OR DECODE(SRC.INIT_PYMN_DUE_DT, TGT.INIT_PYMN_DUE_DT, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )


