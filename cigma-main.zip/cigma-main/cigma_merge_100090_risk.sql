/* =============================================================================
   PARTY_D and PARTY_CONTACT_D -- Snowflake 100090 exposure on the post-hook MERGE

   WHY THIS MATTERS
   Both models use RANK() to pick a "latest" row. RANK() gives EVERY tied row
   the value 1, so WHERE RNK = 1 keeps all of them. The SELECT DISTINCT that
   follows only collapses rows identical in every column -- tied rows whose
   names or emails differ survive as separate rows carrying the SAME natural key.

   Both then resolve that natural key to a surrogate id via the target lookup,
   and both merge ON that surrogate id. Neither model has any final dedupe
   (QUALIFY count = 0 in both).

   Result: two source rows resolving to one target row.
       -> Snowflake 100090 "Duplicate row detected during DML action"
       -> the model FAILS, AUTOSYS reports failure, downstream is skipped.

   This fires only when the party ALREADY EXISTS in the target, so the first
   prod run is safe and every run after it is exposed.

   Not a spec deviation -- validated_sql uses RANK() too. It is a live defect
   in both, inherited from the mapping.

   Evidence ties really occur here: CUSADM.RESOURCE_ has 18 tied GMT_END_TIME
   rows, which is what the CALLCTR_AGENT_D 18-row gap turned out to be.

   All queries read-only. Paste results under each.
   ============================================================================= */


/* -----------------------------------------------------------------------------
   Q1  PARTY_D -- how many CUST_NB have tied CRTN_TS with differing names?
       These are the rows that will collide on the merge.
       Ordered by only ONE column (CRTN_TS DESC), so tie probability is highest.
   ----------------------------------------------------------------------------- */
WITH W1 AS (
    SELECT WEB.CUST_NB,
           WUSER.WEB_PREFIX_NM,
           WUSER.WEB_FIRST_NM,
           WUSER.WEB_LAST_NM,
           WUSER.CRTN_TS,
           RANK() OVER (PARTITION BY WEB.CUST_NB
                        ORDER BY WUSER.CRTN_TS DESC) AS RNK
    FROM UTLDB01.UTLUSER.ODS_MCS_WEB_BILL_ACCT WEB
    INNER JOIN UTLDB01.UTLUSER.ODS_MCS_WEB_USER WUSER
        ON WEB.WEB_ID = WUSER.WEB_ID
    WHERE WEB.CUST_NB NOT IN (
        SELECT DISTINCT CUST_NB FROM UTLDB01.UTLUSER.ODS_MCS_CUSTOMER
        WHERE TRIM(CUST_1ST_2_NM) IS NOT NULL)
      AND TRIM(WUSER.WEB_LAST_NM) IS NOT NULL
)
SELECT COUNT(*) AS COLLIDING_CUST_NB
FROM (
    SELECT CUST_NB
    FROM W1
    WHERE RNK = 1
    GROUP BY CUST_NB
    -- DISTINCT collapses identical rows; >1 distinct name tuple = collision
    HAVING COUNT(DISTINCT COALESCE(WEB_PREFIX_NM,'') || '|' ||
                          COALESCE(WEB_FIRST_NM,'')  || '|' ||
                          COALESCE(WEB_LAST_NM,'')) > 1
);

-- RESULT Q1:


/* -----------------------------------------------------------------------------
   Q1b  Of those, how many ALREADY EXIST in PARTY_D as PARTY_TYPE_CD = 'W1'?
        Only these actually raise 100090 -- a colliding key that is new just
        inserts twice (wrong, but no error).
   ----------------------------------------------------------------------------- */
WITH W1 AS (
    SELECT WEB.CUST_NB,
           WUSER.WEB_PREFIX_NM, WUSER.WEB_FIRST_NM, WUSER.WEB_LAST_NM,
           RANK() OVER (PARTITION BY WEB.CUST_NB
                        ORDER BY WUSER.CRTN_TS DESC) AS RNK
    FROM UTLDB01.UTLUSER.ODS_MCS_WEB_BILL_ACCT WEB
    INNER JOIN UTLDB01.UTLUSER.ODS_MCS_WEB_USER WUSER
        ON WEB.WEB_ID = WUSER.WEB_ID
    WHERE WEB.CUST_NB NOT IN (
        SELECT DISTINCT CUST_NB FROM UTLDB01.UTLUSER.ODS_MCS_CUSTOMER
        WHERE TRIM(CUST_1ST_2_NM) IS NOT NULL)
      AND TRIM(WUSER.WEB_LAST_NM) IS NOT NULL
),
COLLIDING AS (
    SELECT CUST_NB
    FROM W1 WHERE RNK = 1
    GROUP BY CUST_NB
    HAVING COUNT(DISTINCT COALESCE(WEB_PREFIX_NM,'') || '|' ||
                          COALESCE(WEB_FIRST_NM,'')  || '|' ||
                          COALESCE(WEB_LAST_NM,'')) > 1
)
SELECT COUNT(*) AS WILL_RAISE_100090
FROM COLLIDING C
JOIN UTLDB01.CDWADM.PARTY_D P
  ON P.PARTY_ID = C.CUST_NB
 AND P.PARTY_SOURCE_CD = 'M'
 AND P.PARTY_TYPE_CD   = 'W1';

-- RESULT Q1b:


/* -----------------------------------------------------------------------------
   Q2  PARTY_CONTACT_D -- same shape. Ordered by three columns
       (BILL_ACCT_NB, CRTN_TS DESC, WEB_EMAIL DESC) so ties are rarer, but the
       DISTINCT includes WEB_FIRST_NM / WEB_LAST_NM, which are NOT in the
       ORDER BY -- so two rows agreeing on all three sort keys but differing in
       name still both survive.
   ----------------------------------------------------------------------------- */
WITH R AS (
    SELECT BILL_ACCT_NB, WEB_FIRST_NM, WEB_LAST_NM, WEB_EMAIL, CRTN_TS,
           RANK() OVER (PARTITION BY BILL_ACCT_NB
                        ORDER BY BILL_ACCT_NB, CRTN_TS DESC, WEB_EMAIL DESC) AS RNK
    FROM UTLDB01.UTLUSER.ODS_MCS_WEB_USER
)
SELECT COUNT(*) AS COLLIDING_BILL_ACCT_NB
FROM (
    SELECT BILL_ACCT_NB
    FROM R WHERE RNK = 1
    GROUP BY BILL_ACCT_NB
    HAVING COUNT(DISTINCT COALESCE(WEB_FIRST_NM,'') || '|' ||
                          COALESCE(WEB_LAST_NM,'')) > 1
);

-- RESULT Q2:


/* -----------------------------------------------------------------------------
   Q3  Do PARTY_D / PARTY_CONTACT_D already hold duplicate natural keys?
       If yes, the target lookup ALSO fans out and the problem compounds every
       run regardless of source ties.
   ----------------------------------------------------------------------------- */
SELECT 'PARTY_D' AS TBL, COUNT(*) AS DUP_KEY_GROUPS, SUM(N) - COUNT(*) AS SURPLUS_ROWS
FROM (SELECT PARTY_ID, PARTY_SOURCE_CD, PARTY_TYPE_CD, COUNT(*) AS N
      FROM UTLDB01.CDWADM.PARTY_D GROUP BY 1,2,3 HAVING COUNT(*) > 1)
UNION ALL
SELECT 'PARTY_CONTACT_D', COUNT(*), SUM(N) - COUNT(*)
FROM (SELECT PARTY_D_ID, BILL_ACCOUNT_NB, COUNT(*) AS N
      FROM UTLDB01.CDWADM.PARTY_CONTACT_D GROUP BY 1,2 HAVING COUNT(*) > 1);

-- RESULT Q3:
