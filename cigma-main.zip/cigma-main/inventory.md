# Model Inventory

One row per dbt model: the tables it reads as a **source** (driving a FROM),
the tables it only **looks up** (joined / IN / EXISTS / scalar subquery), the
tables its **hooks** write to or read, and the **target** table it loads.

Databases resolve through `{{ target.database }}`; schema names are shown.
Bronze sources resolve to `BRONZE_CUST_INT`.

| Model | Mapping | Load type | Sources (FROM) | Lookups (JOIN / IN / EXISTS) | Hook tables | Target |
|---|---|---|---|---|---|---|
| `ACCOUNT_D` | m_ACCOUNT_D | table + UPDATE post-hook (terminate) + INSERT post-hook (new version) | `CDWADM.ACCOUNT_D`<br>`UTLUSER.ODS_MCS_BILL_ACCOUNT` | `UTLUSER.ODS_MCS_PREMISE`<br>`UTLUSER.ODS_MCS_PREMISE_EXT` | `CDWADM.ACCOUNT_D` | `CDWADM.ACCOUNT_D` |
| `ACCOUNT_D_DEL` | m_ACCOUNT_D_DEL | view + UPDATE post-hook | `CDWADM.ACCOUNT_D`<br>`UTLUSER.ODS_MCS_BILL_ACCOUNT` | `UTLUSER.ODS_MCS_PREMISE`<br>`UTLUSER.ODS_MCS_PREMISE_EXT` | `CDWADM.ACCOUNT_D` | `CDWADM.ACCOUNT_D` |
| `CALLCTR_AGENCY_D` | m_CALLCTR_AGENCY_D | incremental / merge (insert + update) | `CXNADM.CALLCENTER_STG`<br>`(self)` | - | - | `CDWADM.CALLCTR_AGENCY_D` |
| `CALLCTR_AGENT_D` | m_CALLCTR_AGENT_D | incremental / merge (insert + update) | `CUSADM.RESOURCE_`<br>`CXNADM.VA_USERS_STG`<br>`(self)` | `CDWADM.CALLCTR_AGENCY_D` | - | `CDWADM.CALLCTR_AGENT_D` |
| `PARTY_CONTACT_D` | m_PARTY_CONTACT_D | view + MERGE post-hook | `CDWADM.ACCOUNT_D`<br>`CDWADM.PARTY_CONTACT_D`<br>`CDWADM.PARTY_D`<br>`UTLUSER.ODS_MCS_ADDRESS`<br>`UTLUSER.ODS_MCS_BILL_ACCOUNT`<br>`UTLUSER.ODS_MCS_INDICATIV_DATA`<br>`UTLUSER.ODS_MCS_WEB_USER` | - | `CDWADM.PARTY_CONTACT_D` | `CDWADM.PARTY_CONTACT_D` |
| `PARTY_D` | m_PARTY_D | view + MERGE post-hook (insert / update) | `CDWADM.PARTY_D`<br>`UTLUSER.ODS_MCS_CUSTOMER`<br>`UTLUSER.ODS_MCS_WEB_BILL_ACCT` | `UTLUSER.ODS_MCS_WEB_USER` | `CDWADM.PARTY_D` | `CDWADM.PARTY_D` |
| `PARTY_D_VO1` | m_PARTY_D_VO1 | view + MERGE post-hook (insert / update / logical delete) | `CDWADM.PARTY_D`<br>`CRMADM.ODS_ACCT_HIERARCHY` | - | `CDWADM.PARTY_D` | `CDWADM.PARTY_D` |
| `ACCOUNT_TENURE_D` | m_ACCOUNT_TENURE_D | incremental / append (truncate + reload) | `CDWADM.ACCOUNT_D`<br>`(self)` | - | - | `CXNADM.ACCOUNT_TENURE_D` |
| `AG2_I_SESS_STATE_DAY_STG` | m_AG2_I_SESS_STATE_DAY_STG | incremental / append (truncate + reload) | `(self)` | `CXNADM.ODS_GSYS_DATE_TIME` | - | `CXNADM.AG2_I_SESS_STATE_DAY_STG` |
| `AG2_QUEUE_DAY_STG` | m_AG2_QUEUE_DAY_STG | incremental / append (truncate + reload) | `CXNADM.ODS_AG2_QUEUE_DAY`<br>`METADATA.CXNADM_JOB_CONTROL` | `CXNADM.ODS_GSYS_DATE_TIME` | - | `CXNADM.AG2_QUEUE_DAY_STG` |
| `AGENT_CHAT_SPECIALIST_JAR_F_INCR` | m_AGENT_CHAT_SPECIALIST_JAR_F_INCR | incremental / append | `CDWADM.ACCOUNT_D`<br>`CUSADM.INTERACTION_RESOURCE_FACT`<br>`CUSADM.RESOURCE_`<br>`CXNADM.CALLS`<br>`METADATA.CXNADM_JOB_CONTROL`<br>`(self)` | `CUSADM.INTERACTION_FACT`<br>`CUSADM.IRF_USER_DATA_CUST_1`<br>`CXNADM.BILLING_F` | - | `CXNADM.AGENT_CHAT_SPECIALIST_JAR_F` |
| `ARRANGEMENTS_EXTENSIONS_F` | m_ARRANGEMENTS_EXTENSIONS_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CXNADM.CALLS`<br>`CXNADM.CALL_EVENTS`<br>`CXNADM.WEB_EVENT_LOGS`<br>`UTLUSER.ODS_MCS_BUS_DIR`<br>`UTLUSER.ODS_MCS_BUS_PA_CRDT_EX`<br>`UTLUSER.ODS_MCS_NOTES`<br>`UTLUSER.ODS_MCS_TRANS_HIST_HDR`<br>`(self)` | - | - | `CXNADM.ARRANGEMENTS_EXTENSIONS_F` |
| `ARREARS_F` | m_ARREARS_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`UTLUSER.ODS_MCS_DEBIT_ACTIVITY`<br>`(self)` | - | - | `CXNADM.ARREARS_F` |
| `ATT_SCDALL_STG` | m_ATT_SCDALL_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.ATTDAILYCALLREPORT` | - | - | `CXNADM.ATT_SCDALL_STG` |
| `BILLING_F` | m_BILLING_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`UTLUSER.ODS_MCS_BILLABLE_USAGE`<br>`UTLUSER.ODS_MCS_BILL_COMPONENT`<br>`UTLUSER.ODS_MCS_BILL_HEADER`<br>`(self)` | - | - | `CXNADM.BILLING_F` |
| `CALLCENTER_STG` | m_CALLCENTER_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.CALLCENTER` | - | - | `CXNADM.CALLCENTER_STG` |
| `CALLS` | m_calls | incremental / merge (insert + update) | `CDWADM.ACCOUNT_D`<br>`CUSADM.INTERACTION_FACT`<br>`CXNADM.VW_CALLS_STG`<br>`(self)` | `CUSADM.INTERACTION_RESOURCE_FACT`<br>`CUSADM.IRF_USER_DATA_CUST_1` | - | `CXNADM.CALLS` |
| `CALL_EVENTS` | m_CALL_EVENTS | incremental / append | `CXNADM.CALLS`<br>`(self)` | `CDWADM.CALL_EVENT_D` | - | `CXNADM.CALL_EVENTS` |
| `CALL_HISTORY_F` | m_CALL_HISTORY_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CUSADM.INTERACTION_FACT`<br>`CUSADM.INTERACTION_RESOURCE_FACT`<br>`CXNADM.CALLS`<br>`CXNADM.CALL_INTENTS`<br>`CXNADM.ODS_TECHNICAL_DESCRIPTOR`<br>`(self)` | `CUSADM.IRF_USER_DATA_CUST_1`<br>`CXNADM.CALL_EVENTS` | - | `CXNADM.CALL_HISTORY_F` |
| `CALL_INTENTS` | m_CALL_INTENTS | incremental / append | `CXNADM.CALLS`<br>`(self)` | - | - | `CXNADM.CALL_INTENTS` |
| `CIVR_V2D_DA_JAR_F` | m_CIVR_V2D_DA_JAR_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CXNADM.CALLS`<br>`(self)` | `CDWADM.CALL_EVENT_D`<br>`CXNADM.CALL_EVENTS` | - | `CXNADM.CIVR_V2D_DA_JAR_F` |
| `DIGITAL_ASSISTANT_EVENT_F` | m_DIGITAL_ASSISTANT_EVENT_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CUSADM.INTERACTION_FACT`<br>`CXNADM.CALLS`<br>`CXNADM.CALL_INTENTS`<br>`(self)` | `CUSADM.INTERACTION_RESOURCE_FACT`<br>`CXNADM.CALL_EVENTS` | - | `CXNADM.DIGITAL_ASSISTANT_EVENT_F` |
| `GROUP_STG` | m_GROUP_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.GROUP_` | - | - | `CXNADM.GROUP_STG` |
| `INTERACTION_TYPE_STG` | m_INTERACTION_TYPE_STG | incremental / append (truncate + reload) | `CXNADM.ODS_INTERACTION_TYPE` | - | - | `CXNADM.INTERACTION_TYPE_STG` |
| `IRF_USER_DATA_CUST_2_STG` | m_IRF_USER_DATA_CUST_2_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.IRF_USER_DATA_CUST_2`<br>`METADATA.CXNADM_JOB_CONTROL` | `BRONZE_CALLCENTRE.DATE_TIME` | - | `CXNADM.IRF_USER_DATA_CUST_2_STG` |
| `JAR_F` | m_JAR_F | incremental / append (truncate + reload) | `CXNADM.AGENT_CHAT_SPECIALIST_JAR_F`<br>`CXNADM.CIVR_V2D_DA_JAR_F`<br>`CXNADM.WEB_JAR_F` | - | - | `CXNADM.JAR_F` |
| `KPI_METRIC_F` | m_KPI_METRIC_F | view + MERGE post-hook (upsert) | `CXNADM.KPI_METRIC_F`<br>`CXNADM.KPI_METRIC_F_STG` | `CDWADM.COMPANY_D`<br>`CDWADM.KPI_METRIC_D`<br>`CXNADM.ODS_GSYS_DATE_TIME` | `CXNADM.KPI_METRIC_F`<br>`CXNADM.KPI_METRIC_F_STG` | `CXNADM.KPI_METRIC_F` |
| `KPI_METRIC_F_STG` | m_KPI_METRIC_F_STG_INS_AGT | incremental / append + TRUNCATE pre-hook (IS the target) | `CUSADM.INTERACTION_FACT`<br>`CXNADM.ODS_VW_CALLS` | `CUSADM.INTERACTION_RESOURCE_FACT`<br>`CUSADM.IRF_USER_DATA_CUST_1`<br>`CUSADM.RESOURCE_`<br>`CXNADM.ODS_GSYS_DATE_TIME`<br>`CXNADM.ODS_INTERACTION_TYPE`<br>`CXNADM.ODS_MEDIA_TYPE` | - | `CXNADM.KPI_METRIC_F_STG` |
| `KPI_METRIC_F_STG_INS_DA_V2D` | m_KPI_METRIC_F_STG_INS_DA_V2D | table + TRUNCATE pre-hook and INSERT post-hook on the target | `CXNADM.ODS_VW_CALLS` | - | `CXNADM.KPI_METRIC_F_STG` | `CXNADM.KPI_METRIC_F_STG` |
| `KPI_METRIC_F_STG_INS_DA_WEB` | m_KPI_METRIC_F_STG | table + TRUNCATE pre-hook and INSERT post-hook on the target | `CXNADM.ODS_VW_CALLS`<br>`CXNADM.WEB_EVENT_LOGS` | - | `CXNADM.KPI_METRIC_F_STG` | `CXNADM.KPI_METRIC_F_STG` |
| `KPI_METRIC_F_STG_INS_IVR` | m_KPI_METRIC_F_STG | table + TRUNCATE pre-hook and INSERT post-hook on the target | `CXNADM.ODS_VW_CALLS` | - | `CXNADM.KPI_METRIC_F_STG` | `CXNADM.KPI_METRIC_F_STG` |
| `MEDIA_TYPE_STG` | m_MEDIA_TYPE_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.MEDIA_TYPE`<br>`METADATA.CXNADM_JOB_CONTROL` | `BRONZE_CALLCENTRE.CTL_AUDIT_LOG` | - | `CXNADM.MEDIA_TYPE_STG` |
| `ODS_AG2_I_SESS_STATE_DAY` | m_ODS_AG2_I_SESS_STATE_DAY | incremental / merge (insert + update) | `CXNADM.AG2_I_SESS_STATE_DAY_STG`<br>`(self)` | - | - | `CXNADM.ODS_AG2_I_SESS_STATE_DAY` |
| `ODS_AG2_QUEUE_DAY` | m_ODS_AG2_QUEUE_DAY | incremental / merge (insert + update) | `CXNADM.AG2_QUEUE_DAY_STG`<br>`(self)` | - | - | `CXNADM.ODS_AG2_QUEUE_DAY` |
| `ODS_CALLCENTER` | m_ODS_CALLCENTER | view + MERGE post-hook | `CXNADM.CALLCENTER_STG`<br>`CXNADM.ODS_CALLCENTER` | - | `CXNADM.ODS_CALLCENTER` | `CXNADM.ODS_CALLCENTER` |
| `ODS_CUST_LOG_EVENTS_INS` | m_ODS_CUST_LOG_EVENTS_INS | incremental / append | `UTLUSER.LOG_EVNTS_STG`<br>`(self)` | - | - | `CXNADM.ODS_CUST_LOG_EVENTS` |
| `ODS_GROUP` | m_ODS_GROUP | incremental / merge (insert + update) | `CXNADM.GROUP_STG`<br>`(self)` | - | - | `CXNADM.ODS_GROUP` |
| `ODS_GSYS_DATE_TIME` | m_ODS_GSYS_DATE_TIME | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.DATE_TIME` | - | - | `CXNADM.ODS_GSYS_DATE_TIME` |
| `ODS_INTERACTION_TYPE` | m_ODS_INTERACTION_TYPE | incremental / merge (insert + update) | `CXNADM.INTERACTION_TYPE_STG`<br>`(self)` | - | - | `CXNADM.ODS_INTERACTION_TYPE` |
| `ODS_IRF_USER_DATA_CUST_2` | m_ODS_IRF_USER_DATA_CUST_2 | incremental / merge (insert + update) | `CXNADM.IRF_USER_DATA_CUST_2_STG`<br>`(self)` | - | - | `CXNADM.ODS_IRF_USER_DATA_CUST_2` |
| `ODS_MEDIA_TYPE` | m_ODS_MEDIA_TYPE | incremental / merge (insert + update) | `CXNADM.MEDIA_TYPE_STG`<br>`(self)` | - | - | `CXNADM.ODS_MEDIA_TYPE` |
| `ODS_RESOURCE_GROUP_COMBINATION` | m_ODS_RESOURCE_GROUP_COMBINATION | incremental / merge | `CXNADM.RESOURCE_GROUP_COMBINATION_STG`<br>`(self)` | - | - | `CXNADM.ODS_RESOURCE_GROUP_COMBINATION` |
| `ODS_ROUTING_TARGET` | m_ODS_ROUTING_TARGET | incremental / merge (insert + update) | `CXNADM.ROUTING_TARGET_STG`<br>`(self)` | - | - | `CXNADM.ODS_ROUTING_TARGET` |
| `ODS_SM_RES_SESSION_FACT_GI2` | m_ODS_SM_RES_SESSION_FACT_GI2 | incremental / merge (insert + update) | `CXNADM.SM_RES_SESSION_FACT_GI2_STG`<br>`(self)` | - | - | `CXNADM.ODS_SM_RES_SESSION_FACT_GI2` |
| `ODS_TECHNICAL_DESCRIPTOR` | m_ODS_TECHNICAL_DESCRIPTOR | incremental / merge (insert + update) | `CXNADM.TECHNICAL_DESCRIPTOR_STG`<br>`(self)` | - | - | `CXNADM.ODS_TECHNICAL_DESCRIPTOR` |
| `ODS_TENANT` | m_ODS_TENANT | incremental / merge (insert + update) | `CXNADM.TENANT_STG`<br>`(self)` | - | - | `CXNADM.ODS_TENANT` |
| `ODS_VA_USERS` | m_ODS_VA_USERS | incremental / merge | `CXNADM.VA_USERS_STG`<br>`(self)` | - | - | `CXNADM.ODS_VA_USERS` |
| `ODS_VW_CALLS` | m_ODS_VW_CALLS | incremental / merge (insert + update) | `CXNADM.VW_CALLS_STG`<br>`(self)` | - | - | `CXNADM.ODS_VW_CALLS` |
| `PARTY_ACCOUNT_RELATIONSHIP_F` | m_PARTY_ACCOUNT_RELATIONSHIP_F | incremental / merge | `CDWADM.PARTY_D`<br>`UTLUSER.ODS_MCS_INDICATIV_DATA`<br>`(self)` | - | - | `CXNADM.PARTY_ACCOUNT_RELATIONSHIP_F` |
| `PARTY_PREFERENCE_F` | m_PARTY_PREFERENCE_F | incremental / merge (insert + update) | `CDWADM.ACCOUNT_D`<br>`CSGADM.CDAP_CUST_CMPRHNSV`<br>`CXNADM.WEB_EVENT_LOGS`<br>`(self)` | - | - | `CXNADM.PARTY_PREFERENCE_F` |
| `PAYMENT_F` | m_PAYMENT_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CXNADM.CALLS`<br>`CXNADM.CALL_EVENTS`<br>`UTLUSER.ODS_MCS_CREDIT_SOURCE`<br>`(self)` | - | - | `CXNADM.PAYMENT_F` |
| `PROGRAM_ENROLLMENT_F` | m_PROGRAM_ENROLLMENT_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CSGADM.AEP_ACCOUNT_DIM`<br>`UTLUSER.ODS_MCS_BA_GREEN_PWR`<br>`(self)` | `CSGADM.AEP_PGM_DIM`<br>`CSGADM.AEP_PGM_FACT`<br>`CSGADM.AEP_PGM_PL_FACT` | - | `CXNADM.PROGRAM_ENROLLMENT_F` |
| `RESOURCE_GROUP_COMBINATION_STG` | m_RESOURCE_GROUP_COMBINATION_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.RESOURCE_GROUP_COMBINATION` | - | - | `CXNADM.RESOURCE_GROUP_COMBINATION_STG` |
| `ROUTING_TARGET_STG` | m_ROUTING_TARGET_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.ROUTING_TARGET` | `BRONZE_CALLCENTRE.CTL_AUDIT_LOG` | - | `CXNADM.ROUTING_TARGET_STG` |
| `SM_RES_SESSION_FACT_GI2_STG` | m_SM_RES_SESSION_FACT_GI2_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.SM_RES_SESSION_FACT_GI2` | `BRONZE_CALLCENTRE.DATE_TIME` | - | `CXNADM.SM_RES_SESSION_FACT_GI2_STG` |
| `TECHNICAL_DESCRIPTOR_STG` | m_TECHNICAL_DESCRIPTOR_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.TECHNICAL_DESCRIPTOR` | `BRONZE_CALLCENTRE.CTL_AUDIT_LOG` | - | `CXNADM.TECHNICAL_DESCRIPTOR_STG` |
| `TENANT_STG` | m_TENANT_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.TENANT` | - | - | `CXNADM.TENANT_STG` |
| `VA_USERS_STG` | m_VA_USERS_STG | incremental / append (truncate + reload) | `BRONZE_CALLCENTRE.VA_USERS` | - | - | `CXNADM.VA_USERS_STG` |
| `VW_CALLS_STG` | m_VW_CALLS_STG | incremental / append (truncate + reload) | `CXNADM.CALLS` | - | - | `CXNADM.VW_CALLS_STG` |
| `WEB_EVENT_INTERACTION_F` | m_WEB_EVENT_INTERACTION_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CXNADM.WEB_EVENT_LOGS`<br>`UTLUSER.ODS_MCS_WEB_BILL_ACCT`<br>`(self)` | `UTLUSER.ODS_MCS_WEB_USER` | - | `CXNADM.WEB_EVENT_INTERACTION_F` |
| `WEB_EVENT_LOGS` | m_WEB_EVENT_LOGS | incremental / append | `UTLUSER.LOG_EVNTS_STG` | `CDWADM.ACCOUNT_D` | - | `CXNADM.WEB_EVENT_LOGS` |
| `WEB_JAR_F` | m_WEB_JAR_F | incremental / append | `CDWADM.ACCOUNT_D`<br>`CXNADM.WEB_EVENT_LOGS`<br>`(self)` | - | - | `CXNADM.WEB_JAR_F` |

## Summary

| | Count |
|---|---|
| Models | 62 |
| CXNADM | 55 |
| CDWADM | 7 |
| Models reading their own target (`{{ this }}`) | 34 |
| Models applying DML through hooks | 10 |
| Distinct source tables referenced | 81 |
