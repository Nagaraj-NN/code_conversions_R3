/* =============================================================================
   Reject-filter loss per ODS_MCS model.

   Bronze vs ODS row counts cannot separate filter loss from load lag: Bronze
   was last altered 2026-08-31, the three loaded ODS tables on 2026-08-11.
   These count, per column, how many Bronze rows the model's OWN reject
   predicates discard. ~0 means that column is not the culprit; millions mean
   it is.

   Observed gaps to explain:
     mcs_billable_usage   799,405,731 -> 795,279,137   -4,126,594
     mcs_bill_component   792,095,928 -> 788,020,607   -4,075,321
     mcs_bill_header      760,645,200 -> 756,714,476   -3,930,724

   Those three come first. ODS_MCS_PREMISE_EXT is excluded: it is
   Informatica-converted and reads 15 ODS tables, not one Bronze table.
   ============================================================================= */

/* ODS_MCS_BILLABLE_USAGE   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_billable_usage"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("bill_comp_nb" IS NULL)                                      AS "BILL_COMP_NB",
    COUNT_IF("bill_dmnd_qy" IS NULL)                                      AS "BILL_DMND_QY",
    COUNT_IF("bill_head_nb" IS NULL)                                      AS "BILL_HEAD_NB",
    COUNT_IF("bill_kwh_qy" IS NULL)                                       AS "BILL_KWH_QY",
    COUNT_IF("hours_used_qy" IS NULL)                                     AS "HOURS_USED_QY",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("load_fctr_qy" IS NULL)                                      AS "LOAD_FCTR_QY",
    COUNT_IF("net_usag_kvarh_qy" IS NULL)                                 AS "NET_USAG_KVARH_QY",
    COUNT_IF("net_usag_kvar_qy" IS NULL)                                  AS "NET_USAG_KVAR_QY",
    COUNT_IF("net_usag_kva_qy" IS NULL)                                   AS "NET_USAG_KVA_QY",
    COUNT_IF("net_usag_kwh_qy" IS NULL)                                   AS "NET_USAG_KWH_QY",
    COUNT_IF("net_usag_kw_qy" IS NULL)                                    AS "NET_USAG_KW_QY",
    COUNT_IF("net_usag_qhr_qy" IS NULL)                                   AS "NET_USAG_QHR_QY",
    COUNT_IF("pwr_fctr_cnst_qy" IS NULL)                                  AS "PWR_FCTR_CNST_QY",
    COUNT_IF("pwr_fctr_qy" IS NULL)                                       AS "PWR_FCTR_QY",
    COUNT_IF("rctv_dmnd_qy" IS NULL)                                      AS "RCTV_DMND_QY",
    COUNT_IF("rctv_hors_qy" IS NULL)                                      AS "RCTV_HORS_QY",
    COUNT_IF("time_of_day_cd" IS NULL OR TRIM("time_of_day_cd") = '')     AS "TIME_OF_DAY_CD",
    COUNT_IF("tod_cd_sort_nb" IS NULL)                                    AS "TOD_CD_SORT_NB",
    COUNT_IF("usag_nbr_days_qy" IS NULL)                                  AS "USAG_NBR_DAYS_QY"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_billable_usage";
BRONZE_ROWS	BILL_ACCT_NB	BILL_COMP_NB	BILL_DMND_QY	BILL_HEAD_NB	BILL_KWH_QY	HOURS_USED_QY	LAST_UPDT_TS	LOAD_FCTR_QY	NET_USAG_KVARH_QY	NET_USAG_KVAR_QY	NET_USAG_KVA_QY	NET_USAG_KWH_QY	NET_USAG_KW_QY	NET_USAG_QHR_QY	PWR_FCTR_CNST_QY	PWR_FCTR_QY	RCTV_DMND_QY	RCTV_HORS_QY	TIME_OF_DAY_CD	TOD_CD_SORT_NB	USAG_NBR_DAYS_QY
799405731	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	29	0	0


/* ODS_MCS_BILL_COMPONENT   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bill_component"
   rows each reject predicate discards. key cols drop blank too.
   not counted (derived, no direct Bronze column): BILL_ACCT_NB, BILL_COMP_DT, BILL_COMP_NB, BILL_HEAD_NB, BILL_PERD_FROM_DT, BILL_PERD_TO_DT, FNNC_TS, LAST_UPDT_TS, ORIG_BILL_COMP_NB, ORIG_BILL_HEAD_NB, REVN_CLAS_CD, SCHD_BILL_DT, SUPR_BILL_COMP_NB, SUPR_BILL_HEAD_NB, TARF_CD
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bb_estm_at" IS NULL)                                        AS "BB_ESTM_AT",
    COUNT_IF("cust_chrg_at" IS NULL)                                      AS "CUST_CHRG_AT",
    COUNT_IF("dist_chrg_at" IS NULL)                                      AS "DIST_CHRG_AT",
    COUNT_IF("dmnd_chrg_tot_at" IS NULL)                                  AS "DMND_CHRG_TOT_AT",
    COUNT_IF("enrg_chrg_tot_at" IS NULL)                                  AS "ENRG_CHRG_TOT_AT",
    COUNT_IF("fuel_chrg_tot_at" IS NULL)                                  AS "FUEL_CHRG_TOT_AT",
    COUNT_IF("gen_chrg_at" IS NULL)                                       AS "GEN_CHRG_AT",
    COUNT_IF("misc_chrg_tot_at" IS NULL)                                  AS "MISC_CHRG_TOT_AT",
    COUNT_IF("nmtr_actv_unts_qy" IS NULL)                                 AS "NMTR_ACTV_UNTS_QY",
    COUNT_IF("prrt_fctr_qy" IS NULL)                                      AS "PRRT_FCTR_QY",
    COUNT_IF("ptc_rt_value" IS NULL)                                      AS "PTC_RT_VALUE",
    COUNT_IF("rctv_dmnd_chg_at" IS NULL)                                  AS "RCTV_DMND_CHG_AT",
    COUNT_IF("smmr_usag_hist_qy" IS NULL)                                 AS "SMMR_USAG_HIST_QY",
    COUNT_IF("surc_tot_at" IS NULL)                                       AS "SURC_TOT_AT",
    COUNT_IF("tarf_max_at" IS NULL)                                       AS "TARF_MAX_AT",
    COUNT_IF("tarf_min_at" IS NULL)                                       AS "TARF_MIN_AT",
    COUNT_IF("tax_tot_at" IS NULL)                                        AS "TAX_TOT_AT",
    COUNT_IF("tot_bill_at" IS NULL)                                       AS "TOT_BILL_AT",
    COUNT_IF("trans_chrg_at" IS NULL)                                     AS "TRANS_CHRG_AT"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bill_component";
BRONZE_ROWS	BB_ESTM_AT	CUST_CHRG_AT	DIST_CHRG_AT	DMND_CHRG_TOT_AT	ENRG_CHRG_TOT_AT	FUEL_CHRG_TOT_AT	GEN_CHRG_AT	MISC_CHRG_TOT_AT	NMTR_ACTV_UNTS_QY	PRRT_FCTR_QY	PTC_RT_VALUE	RCTV_DMND_CHG_AT	SMMR_USAG_HIST_QY	SURC_TOT_AT	TARF_MAX_AT	TARF_MIN_AT	TAX_TOT_AT	TOT_BILL_AT	TRANS_CHRG_AT
792095928	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0

/* ODS_MCS_BILL_HEADER   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bill_header"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("acct_bal_at" IS NULL)                                       AS "ACCT_BAL_AT",
    COUNT_IF("addl_blls_qy" IS NULL)                                      AS "ADDL_BLLS_QY",
    COUNT_IF("bb_estm_at" IS NULL)                                        AS "BB_ESTM_AT",
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("bill_at" IS NULL)                                           AS "BILL_AT",
    COUNT_IF("bill_dt" IS NULL)                                           AS "BILL_DT",
    COUNT_IF("bill_due_dt" IS NULL)                                       AS "BILL_DUE_DT",
    COUNT_IF("bill_head_nb" IS NULL)                                      AS "BILL_HEAD_NB",
    COUNT_IF("dpc_calc_tot_at" IS NULL)                                   AS "DPC_CALC_TOT_AT",
    COUNT_IF("excs_crdt_appl_at" IS NULL)                                 AS "EXCS_CRDT_APPL_AT",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("mtrd_bill_at" IS NULL)                                      AS "MTRD_BILL_AT",
    COUNT_IF("non_mtrd_tot_at" IS NULL)                                   AS "NON_MTRD_TOT_AT",
    COUNT_IF("totl_bill_due_at" IS NULL)                                  AS "TOTL_BILL_DUE_AT"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bill_header";
BRONZE_ROWS	ACCT_BAL_AT	ADDL_BLLS_QY	BB_ESTM_AT	BILL_ACCT_NB	BILL_AT	BILL_DT	BILL_DUE_DT	BILL_HEAD_NB	DPC_CALC_TOT_AT	EXCS_CRDT_APPL_AT	LAST_UPDT_TS	MTRD_BILL_AT	NON_MTRD_TOT_AT	TOTL_BILL_DUE_AT
760645200	0	0	0	0	0	0	0	0	0	0	0	0	0	0


/* ODS_MCS_ADDRESS   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_address"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("addr_id_ad" IS NULL OR TRIM("addr_id_ad") = '')             AS "ADDR_ID_AD",
    COUNT_IF("co_cd_ownr" IS NULL OR TRIM("co_cd_ownr") = '')             AS "CO_CD_OWNR",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_address";
BRONZE_ROWS	ADDR_ID_AD	CO_CD_OWNR	LAST_UPDT_TS
11266152	0	0	0


/* ODS_MCS_BA_GREEN_PWR   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_ba_green_pwr"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("gp_efct_dt" IS NULL)                                        AS "GP_EFCT_DT"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_ba_green_pwr";
BRONZE_ROWS	BILL_ACCT_NB	GP_EFCT_DT
13328	0	0

/* ODS_MCS_BILL_ACCOUNT   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bill_account"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("acct_bal_at" IS NULL)                                       AS "ACCT_BAL_AT",
    COUNT_IF("addl_blls_qy" IS NULL)                                      AS "ADDL_BLLS_QY",
    COUNT_IF("avg_srvc_bill_at" IS NULL)                                  AS "AVG_SRVC_BILL_AT",
    COUNT_IF("bal_due_at" IS NULL)                                        AS "BAL_DUE_AT",
    COUNT_IF("bb_estm_at" IS NULL)                                        AS "BB_ESTM_AT",
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("bill_chck_digit_nb" IS NULL)                                AS "BILL_CHCK_DIGIT_NB",
    COUNT_IF("cnsl_bill_grp_nb" IS NULL)                                  AS "CNSL_BILL_GRP_NB",
    COUNT_IF("dfrr_bal_at" IS NULL)                                       AS "DFRR_BAL_AT",
    COUNT_IF("emp_assc_co_cd" IS NULL)                                    AS "EMP_ASSC_CO_CD",
    COUNT_IF("fnnc_cntl_unit_nb" IS NULL)                                 AS "FNNC_CNTL_UNIT_NB",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("mos_avg_usg_qy" IS NULL)                                    AS "MOS_AVG_USG_QY",
    COUNT_IF("mthy_actv_at" IS NULL)                                      AS "MTHY_ACTV_AT",
    COUNT_IF("nfnc_cntl_unit_nb" IS NULL)                                 AS "NFNC_CNTL_UNIT_NB",
    COUNT_IF("opnn_mthy_bal_at" IS NULL)                                  AS "OPNN_MTHY_BAL_AT",
    COUNT_IF("payable_bal_at" IS NULL)                                    AS "PAYABLE_BAL_AT",
    COUNT_IF("pymn_prfl_cd" IS NULL)                                      AS "PYMN_PRFL_CD",
    COUNT_IF("ref_dep_ctr_qy" IS NULL)                                    AS "REF_DEP_CTR_QY",
    COUNT_IF("revn_clas_cd" IS NULL)                                      AS "REVN_CLAS_CD",
    COUNT_IF("risk_score_nb" IS NULL)                                     AS "RISK_SCORE_NB",
    COUNT_IF("sic_cd" IS NULL)                                            AS "SIC_CD",
    COUNT_IF("slct_due_day_nb" IS NULL)                                   AS "SLCT_DUE_DAY_NB",
    COUNT_IF("tlph_1_nb" IS NULL)                                         AS "TLPH_1_NB",
    COUNT_IF("tlph_2_nb" IS NULL)                                         AS "TLPH_2_NB",
    COUNT_IF("unpr_bal_at" IS NULL)                                       AS "UNPR_BAL_AT"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bill_account";
BRONZE_ROWS	ACCT_BAL_AT	ADDL_BLLS_QY	AVG_SRVC_BILL_AT	BAL_DUE_AT	BB_ESTM_AT	BILL_ACCT_NB	BILL_CHCK_DIGIT_NB	CNSL_BILL_GRP_NB	DFRR_BAL_AT	EMP_ASSC_CO_CD	FNNC_CNTL_UNIT_NB	LAST_UPDT_TS	MOS_AVG_USG_QY	MTHY_ACTV_AT	NFNC_CNTL_UNIT_NB	OPNN_MTHY_BAL_AT	PAYABLE_BAL_AT	PYMN_PRFL_CD	REF_DEP_CTR_QY	REVN_CLAS_CD	RISK_SCORE_NB	SIC_CD	SLCT_DUE_DAY_NB	TLPH_1_NB	TLPH_2_NB	UNPR_BAL_AT
22241168	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0


/* ODS_MCS_BUS_DIR   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bus_dir"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("dir_type_cd" IS NULL OR TRIM("dir_type_cd") = '')           AS "DIR_TYPE_CD",
    COUNT_IF("prod_ordr_nb" IS NULL)                                      AS "PROD_ORDR_NB"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bus_dir";
BRONZE_ROWS	BILL_ACCT_NB	DIR_TYPE_CD	PROD_ORDR_NB
224479359	0	0	0


/* ODS_MCS_BUS_PA_CRDT_EX   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bus_pa_crdt_ex"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("dflt_pagr_remn_at" IS NULL)                                 AS "DFLT_PAGR_REMN_AT",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("prod_ordr_nb" IS NULL)                                      AS "PROD_ORDR_NB",
    COUNT_IF("stat_last_chng_dt" IS NULL)                                 AS "STAT_LAST_CHNG_DT"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_bus_pa_crdt_ex";
BRONZE_ROWS	BILL_ACCT_NB	DFLT_PAGR_REMN_AT	LAST_UPDT_TS	PROD_ORDR_NB	STAT_LAST_CHNG_DT
23584990	0	0	0	0	0

/* ODS_MCS_CREDIT_SOURCE   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_credit_source"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("bill_head_nb" IS NULL)                                      AS "BILL_HEAD_NB",
    COUNT_IF("cash_btch_nb" IS NULL)                                      AS "CASH_BTCH_NB",
    COUNT_IF("crdt_crtn_ts" IS NULL)                                      AS "CRDT_CRTN_TS",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("pymn_crdt_at" IS NULL)                                      AS "PYMN_CRDT_AT",
    COUNT_IF("pymn_crdt_dt" IS NULL)                                      AS "PYMN_CRDT_DT",
    COUNT_IF("pymn_seq_nb" IS NULL)                                       AS "PYMN_SEQ_NB"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_credit_source";
BRONZE_ROWS	BILL_ACCT_NB	BILL_HEAD_NB	CASH_BTCH_NB	CRDT_CRTN_TS	LAST_UPDT_TS	PYMN_CRDT_AT	PYMN_CRDT_DT	PYMN_SEQ_NB
1304949998	0	0	0	0	0	0	0	0

/* ODS_MCS_CUSTOMER   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_customer"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("crdt_rtng_nb" IS NULL)                                      AS "CRDT_RTNG_NB",
    COUNT_IF("cust_nb" IS NULL OR TRIM("cust_nb") = '')                   AS "CUST_NB",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("nfnc_cntl_unit_nb" IS NULL)                                 AS "NFNC_CNTL_UNIT_NB"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_customer";
BRONZE_ROWS	CRDT_RTNG_NB	CUST_NB	LAST_UPDT_TS	NFNC_CNTL_UNIT_NB
16155146	0	0	0	0


/* ODS_MCS_DEBIT_ACTIVITY   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_debit_activity"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("bill_comp_nb" IS NULL)                                      AS "BILL_COMP_NB",
    COUNT_IF("bill_head_nb" IS NULL)                                      AS "BILL_HEAD_NB",
    COUNT_IF("debt_at" IS NULL)                                           AS "DEBT_AT",
    COUNT_IF("debt_prcs_dt" IS NULL)                                      AS "DEBT_PRCS_DT",
    COUNT_IF("debt_ts" IS NULL)                                           AS "DEBT_TS",
    COUNT_IF("dir_type_cd" IS NULL OR TRIM("dir_type_cd") = '')           AS "DIR_TYPE_CD",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("pagr_prdn_ordr_nb" IS NULL)                                 AS "PAGR_PRDN_ORDR_NB",
    COUNT_IF("prod_ordr_nb" IS NULL)                                      AS "PROD_ORDR_NB",
    COUNT_IF("remn_debt_at" IS NULL)                                      AS "REMN_DEBT_AT"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_debit_activity";
BRONZE_ROWS	BILL_ACCT_NB	BILL_COMP_NB	BILL_HEAD_NB	DEBT_AT	DEBT_PRCS_DT	DEBT_TS	DIR_TYPE_CD	LAST_UPDT_TS	PAGR_PRDN_ORDR_NB	PROD_ORDR_NB	REMN_DEBT_AT
1462542667	0	0	0	0	0	0	0	0	0	0	0


/* ODS_MCS_INDICATIV_DATA   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_indicativ_data"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("cust_nb" IS NULL OR TRIM("cust_nb") = '')                   AS "CUST_NB",
    COUNT_IF("cycl_nb" IS NULL)                                           AS "CYCL_NB",
    COUNT_IF("fnnc_cntl_unit_nb" IS NULL)                                 AS "FNNC_CNTL_UNIT_NB",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("name_idnt_cd" IS NULL OR TRIM("name_idnt_cd") = '')         AS "NAME_IDNT_CD",
    COUNT_IF("prem_nb" IS NULL OR TRIM("prem_nb") = '')                   AS "PREM_NB",
    COUNT_IF("revn_clas_cd" IS NULL)                                      AS "REVN_CLAS_CD",
    COUNT_IF("sic_cd" IS NULL)                                            AS "SIC_CD",
    COUNT_IF("tarf_cd" IS NULL)                                           AS "TARF_CD",
    COUNT_IF("tax_dstc_cd" IS NULL)                                       AS "TAX_DSTC_CD",
    COUNT_IF("tlph_1_nb" IS NULL)                                         AS "TLPH_1_NB",
    COUNT_IF("tlph_2_nb" IS NULL)                                         AS "TLPH_2_NB"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_indicativ_data";
BRONZE_ROWS	BILL_ACCT_NB	CUST_NB	CYCL_NB	FNNC_CNTL_UNIT_NB	LAST_UPDT_TS	NAME_IDNT_CD	PREM_NB	REVN_CLAS_CD	SIC_CD	TARF_CD	TAX_DSTC_CD	TLPH_1_NB	TLPH_2_NB
25412892	0	0	0	0	0	0	1664834	0	0	0	0	0	0


/* ODS_MCS_NOTES   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_notes"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("co_cd_ownr" IS NULL OR TRIM("co_cd_ownr") = '')             AS "CO_CD_OWNR",
    COUNT_IF("crtn_ts" IS NULL)                                           AS "CRTN_TS",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("last_upd_dt" IS NULL)                                       AS "LAST_UPD_DT",
    COUNT_IF("note_ts" IS NULL)                                           AS "NOTE_TS"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_notes";
BRONZE_ROWS	CO_CD_OWNR	CRTN_TS	LAST_UPDT_TS	LAST_UPD_DT	NOTE_TS
145960247	0	0	0	0	0


/* ODS_MCS_PREMISE   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_premise"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("cycl_nb" IS NULL)                                           AS "CYCL_NB",
    COUNT_IF("key_nb" IS NULL)                                            AS "KEY_NB",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("mtr_rte_ownr_nb" IS NULL)                                   AS "MTR_RTE_OWNR_NB",
    COUNT_IF("nfnc_cntl_unit_nb" IS NULL)                                 AS "NFNC_CNTL_UNIT_NB",
    COUNT_IF("prem_nb" IS NULL OR TRIM("prem_nb") = '')                   AS "PREM_NB",
    COUNT_IF("rdg_seq_nb" IS NULL)                                        AS "RDG_SEQ_NB",
    COUNT_IF("tax_dstc_cd" IS NULL)                                       AS "TAX_DSTC_CD"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_premise";
BRONZE_ROWS	CO_CD_OWNR	CRTN_TS	LAST_UPDT_TS	LAST_UPD_DT	NOTE_TS
145960247	0	0	0	0	0


/* ODS_MCS_TRANS_HIST_HDR   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_trans_hist_hdr"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL)                                      AS "BILL_ACCT_NB",
    COUNT_IF("cnv_id" IS NULL)                                            AS "CNV_ID",
    COUNT_IF("co_cd_ownr" IS NULL)                                        AS "CO_CD_OWNR",
    COUNT_IF("rvrs_ts_20_ts" IS NULL)                                     AS "TS_20_TS"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_trans_hist_hdr";
BRONZE_ROWS	BILL_ACCT_NB	CNV_ID	CO_CD_OWNR	TS_20_TS
442692114	0	0	0	0


/* ODS_MCS_WEB_BILL_ACCT   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_web_bill_acct"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("bill_acct_nb" IS NULL OR TRIM("bill_acct_nb") = '')         AS "BILL_ACCT_NB",
    COUNT_IF("crtn_ts" IS NULL)                                           AS "CRTN_TS",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("web_id" IS NULL OR TRIM("web_id") = '')                     AS "WEB_ID"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_web_bill_acct";
BRONZE_ROWS	BILL_ACCT_NB	CRTN_TS	LAST_UPDT_TS	WEB_ID
8622658	0	0	0	0


/* ODS_MCS_WEB_USER   <- BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_web_user"
   rows each reject predicate discards. key cols drop blank too.
*/
SELECT COUNT(*) AS BRONZE_ROWS,
    COUNT_IF("crtn_ts" IS NULL)                                           AS "CRTN_TS",
    COUNT_IF("last_updt_ts" IS NULL)                                      AS "LAST_UPDT_TS",
    COUNT_IF("web_id" IS NULL OR TRIM("web_id") = '')                     AS "WEB_ID",
    COUNT_IF("web_id_nb" IS NULL)                                         AS "WEB_ID_NB"
FROM BRONZE_CUST_CONF_PROD."bronze_macss"."mcs_web_user";

BRONZE_ROWS	CRTN_TS	LAST_UPDT_TS	WEB_ID	WEB_ID_NB
6141589	0	0	0	0
