-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_MART_AUDIT
-- MAPPING           : m_ps_z_ci_est_f00_audit      (statement 1 of 4)
-- SESSION           : s_m_ps_z_ci_est_f00_audit
-- SOURCE FILE       : wkf_LOAD_CI_MART_AUDIT.sql (lines 23-33)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_EPM_AUDIT
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_EST_F00_AUDIT_ASYS
-- MATERIALIZATION   : incremental (append-only, no unique_key)
--
-- All FOUR statements in this workflow write PS_Z_EPM_AUDIT, and only one DBT
-- model can own a table. Statement 1 is this model; statements 2-4 run as
-- post_hooks in their original order, which also preserves the two documented
-- branch orderings:
--     CI_EST_F00 (stmt 1)         -> CI_EST_FACT (stmt 3)
--     PS_PROJ_RES_ACT_VW (stmt 2) -> PS_Z_CI_BALANCES (stmt 4)
--
--   post_hook : m_ps_z_balances_vw_audit  (stmt 2) inserts the ACTUAL src row
--               m_ps_z_ci_est_fact_audit  (stmt 3) fills ESTIMATE dest totals
--               m_ps_z_ci_balances_audit  (stmt 4) fills ACTUAL dest totals
-- ============================================================

{{ config(
    schema='EPMADM',
    materialized='incremental',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_EST_F00_AUDIT_ASYS')
    ],
    post_hook=[
        "INSERT INTO {{ this }}
(TABLE_NAME, LEDGER, RUN_DT, Z_SRC_AMOUNT, Z_DEST_AMOUNT, Z_SRC_QUANTITY, Z_DEST_QUANTITY)
SELECT
    'CI_BALANCES' AS TABLE_NAME,
    'ACTUAL' AS LEDGER,
    CURRENT_TIMESTAMP() AS RUN_DT,
    NVL(SUM(bal_vw.RESOURCE_AMOUNT),0) AS Z_SRC_AMOUNT,
    0 AS Z_DEST_AMOUNT,
    0 AS Z_SRC_QUANTITY,
    0 AS Z_DEST_QUANTITY
FROM {{ source('CRPDB01_BOEPMMRT', 'PS_PROJ_RES_ACT_VW') }} bal_vw,
     {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }} ci_proj_dim
WHERE bal_vw.ACCOUNTING_PERIOD BETWEEN 1 AND 12
AND bal_vw.LEDGER = 'ACTUAL'
AND bal_vw.PROJECT_ID = ci_proj_dim.PROJECT_ID
AND bal_vw.FISCAL_YEAR >= 2005
AND bal_vw.DEPTID <> '11617'
AND bal_vw.ACCOUNT IN ('1070000', '1070001', '1080005', '1070910','1070920','1070005','1240025','1210003')
AND bal_vw.ANALYSIS_TYPE IN (SELECT ANALYSIS_TYPE
                               FROM {{ source('CRPDB01_EPMADM', 'PS_PROJ_ANGRP_D00') }}
                               WHERE ANALYSIS_GROUP IN ('RPACT','RALAB','RASCB','RAICB','RASTR','RARDD','RABLD','RAJNT','RACMF','RAMSC'))",
                               
        "UPDATE {{ this }}
SET Z_DEST_AMOUNT = src.Z_DEST_AMOUNT,
    Z_DEST_QUANTITY = src.Z_DEST_QUANTITY
FROM (SELECT
          COUNT(*) AS Z_DEST_QUANTITY,
          SUM(PS_Z_CI_EST_FACT.AMOUNT) AS Z_DEST_AMOUNT,
          'CI_EST_FACT' AS TABLE_NAME
      FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_EST_FACT') }}) src
WHERE PS_Z_EPM_AUDIT.TABLE_NAME = src.TABLE_NAME
AND PS_Z_EPM_AUDIT.LEDGER = 'ESTIMATE'
AND PS_Z_EPM_AUDIT.RUN_DT = (SELECT MAX(RUN_DT)
                               FROM {{ this }}
                               WHERE TABLE_NAME = 'CI_EST_FACT')",
        "UPDATE {{this}}
        SET Z_DEST_AMOUNT = src.Z_DEST_AMOUNT,
    Z_DEST_QUANTITY = src.Z_DEST_QUANTITY
FROM (SELECT
          SUM(ci_bal.Z_ACT_USD) AS Z_DEST_AMOUNT,
          0 AS Z_DEST_QUANTITY,
          'CI_BALANCES' AS TABLE_NAME
      FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_BALANCES') }} ci_bal
      WHERE ci_bal.FISCAL_YEAR >= 2005
      AND ci_bal.DEPTID <> '11617') src
WHERE PS_Z_EPM_AUDIT.TABLE_NAME = src.TABLE_NAME
AND PS_Z_EPM_AUDIT.LEDGER = 'ACTUAL'
AND PS_Z_EPM_AUDIT.RUN_DT = (SELECT MAX(RUN_DT)
                               FROM {{ this }}
                               WHERE TABLE_NAME = 'CI_BALANCES')",
        log_model_end(this, 'M_PS_Z_CI_EST_F00_AUDIT_ASYS')
    ]
) }}

-- Projects exactly the INSERT column list, in order.
SELECT
    'CI_EST_FACT' AS TABLE_NAME,
    'ESTIMATE' AS LEDGER,
    CURRENT_TIMESTAMP() AS RUN_DT,
    SUM(PS_Z_CI_EST_F00.AMOUNT) AS Z_SRC_AMOUNT,
    0 AS Z_DEST_AMOUNT,
    COUNT(*) AS Z_SRC_QUANTITY,
    0 AS Z_DEST_QUANTITY
FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_EST_F00') }}  --CRPDB01.EPMADM.PS_Z_CI_EST_F00
