-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_TRANSMISSION_PROJECTS
-- MAPPING           : m_ps_z_ci_td_asset_dim_ins   (statement 3 of 9)
-- SOURCE FILE       : wkf_LOAD_CI_TRANSMISSION_PROJECTS.sql (lines 46-52)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_TD_ASSET_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_TD_ASSET_DIM_INS_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : Z_IKW_E_CODE, Z_IKW_EQUIP_REVISION
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['Z_IKW_E_CODE', 'Z_IKW_EQUIP_REVISION'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_TD_ASSET_DIM_INS_ASYS')
    ],
    post_hook=[
        log_model_end(this, 'M_PS_Z_CI_TD_ASSET_DIM_INS_ASYS')
    ]
) }}

WITH FINAL_SOURCE AS
(
SELECT Z_IKW_ECODE Z_IKW_E_CODE,
Z_IKW_EQUIP_REV Z_IKW_EQUIP_REVISION,Z_IKW_FACILITY Z_IKW_FACILITY_CD,
Z_IKW_EQUIP_NAME Z_IKW_EQUIP_NM,Z_IKW_ASSET_LOC Z_IKW_ASSET_LOC_CD,Z_IKW_VOLTAGE Z_IKW_VOLTG_TX,
Z_BENEFIT_LOC,
Z_IKW_EQUIP_NAME||' - '||Z_IKW_VOLTAGE||' - '||Z_BENEFIT_LOC||' - '||Z_IKW_ASSET_LOC ASSET_TX,
Z_IKW_EQUP_NUM Z_IKW_EQUP_NB,
Z_IKW_STATUS Z_IKW_STATUS_TX,
CURRENT_TIMESTAMP() DTTM_STAMP
FROM {{ source('BRONZE_PS', 'PS_Z_CILI_IKW_ASST') }}   --CRPDB01.EPMADM.PS_Z_CILI_IKW_ASST
WHERE Z_IKW_STATUS='ACTIVE' 
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    Z_IKW_E_CODE,
    Z_IKW_EQUIP_REVISION,
    Z_IKW_FACILITY_CD,
    Z_IKW_EQUIP_NM,
    Z_IKW_ASSET_LOC_CD,
    Z_IKW_VOLTG_TX,
    Z_BENEFIT_LOC,
    ASSET_TX,
    Z_IKW_EQUP_NB,
    Z_IKW_STATUS_TX,
    DTTM_STAMP
FROM FINAL_SOURCE
