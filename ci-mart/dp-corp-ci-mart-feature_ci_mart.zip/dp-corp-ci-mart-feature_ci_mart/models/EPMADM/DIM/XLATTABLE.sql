-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_TRANSMISSION_PROJECTS
-- MAPPING           : D81_XLATTABLE                (statement 1 of 9)
-- SOURCE FILE       : wkf_LOAD_CI_TRANSMISSION_PROJECTS.sql (lines 28-38)
-- TARGET TABLE      : CRPDB01.EPMADM.XLATTABLE
-- AUTOSYS_JOB_NAME  : D81_XLATTABLE_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : FIELDNAME, LANGUAGE_CD, FIELDVALUE, EFFDT
-- POST_HOOK         : d81_xlattable_psxlatitem     (statement 2 - syncs PSXLATITEM)
--
-- Statement 2 is attached as a post_hook rather than modelled, because
-- stmt 1 reads PSXLATITEM and stmt 2 writes it from XLATTABLE - a DAG cycle.
--
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['FIELDNAME', 'LANGUAGE_CD', 'FIELDVALUE', 'EFFDT'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'D81_XLATTABLE_ASYS')
    ],
    post_hook=[
        d81_xlattable_psxlatitem(this),
        log_model_end(this, 'D81_XLATTABLE_ASYS')
    ]
) }}

WITH FINAL_SOURCE AS
(
SELECT D.FIELDNAME,' ' LANGUAGE_CD,I.FIELDVALUE,I.EFFDT,D.VERSION,I.EFF_STATUS,I.XLATLONGNAME,I.XLATSHORTNAME,I.LASTUPDDTTM,I.LASTUPDOPRID
FROM {{ source('BRONZE_PS', 'PSXLATDEFN') }} D  --CRPDB01.EPMADM.PSXLATDEFN
JOIN {{ source('CRPDB01_EPMADM', 'PSXLATITEM') }} I   --CRPDB01.EPMADM.PSXLATITEM
ON D.FIELDNAME=I.FIELDNAME  
WHERE I.FIELDNAME IN ('Z_ALLOC_TYPE','Z_TRANS_TYPE','Z_CI_COST_CATG','Z_CI_COST_TYPE','Z_PLAN_ID_TYPE','Z_GRNFLD_OR_EXST','Z_REG_OPR','Z_DES_OPR','Z_ROW_LAND_AQ','Z_ENV',
'Z_GEN','Z_DIS','Z_REM_RET','Z_STN_CIP_CER','Z_CCN_OR_ECCNCECPN','Z_NERC_COM_REQ','Z_MET_REQ','Z_FB_OPGW_RQ','Z_TELCOM_CHL_REQ','Z_BUL_PER_REQ',
'Z_TP_AG_RQ','Z_CN_EX_AN_CIAC_SP','Z_NW_TEC_INV','Z_NW_ST_RE_NW_TEC','Z_OTH_STD','Z_OUT_REQ','Z_LO_LE_TM_MAT_REQ','Z_MOB_TNS_REQ','Z_OL_ADD_REM',
'Z_METERING','Z_TELECOM','Z_RISK_TYPE','Z_IMPACT','Z_PROBABILITY','Z_PRIORITY','Z_PROJECT_DRIVER','Z_DTL_RISKLVL','Z_RISK_LVL')
QUALIFY I.EFFDT=MAX(I.EFFDT) OVER(PARTITION BY I.FIELDNAME,I.FIELDVALUE)
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    FIELDNAME,
    LANGUAGE_CD,
    FIELDVALUE,
    EFFDT,
    VERSION,
    EFF_STATUS,
    XLATLONGNAME,
    XLATSHORTNAME,
    LASTUPDDTTM,
    LASTUPDOPRID
FROM FINAL_SOURCE
