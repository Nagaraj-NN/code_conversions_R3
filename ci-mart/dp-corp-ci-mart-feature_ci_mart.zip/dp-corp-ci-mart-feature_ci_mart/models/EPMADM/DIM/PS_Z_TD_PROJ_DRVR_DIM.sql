-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_TRANSMISSION_PROJECTS
-- MAPPING           : m_ps_z_ci_td_proj_driver_dim_ins  (statement 7 of 9)
-- SOURCE FILE       : wkf_LOAD_CI_TRANSMISSION_PROJECTS.sql (lines 72-76)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_TD_PROJ_DRVR_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_TD_PROJ_DRIVER_DIM_INS_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : Z_PLAN_ID_TYPE_CD, BUSINESS_UNIT, PROJECT_ID, Z_PROJ_DRVR_CD
-- DEPENDS ON        : d81_xlattable (XLATTABLE lookup)
-- POST_HOOK         : m_ps_z_job_control_upd_dttm    (statement 8)
--                     m_ps_z_job_control_upd_status  (statement 9)
--
-- This is the final MERGE of the workflow, so it carries the two PS_Z_JOB_CONTROL
-- updates as post_hooks, preserving the original 7 -> 8 -> 9 statement order.
-- See README_CONVERSION.md for how to guarantee this model runs last.
--
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['Z_PLAN_ID_TYPE_CD', 'BUSINESS_UNIT', 'PROJECT_ID', 'Z_PROJ_DRVR_CD'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_TD_PROJ_DRIVER_DIM_INS_ASYS')
    ],
    post_hook=[
       "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_JOB_CONTROL') }}
SET LAST_RUN_FROM_DTTM=LAST_RUN_TO_DTTM,LAST_RUN_TO_DTTM=CURRENT_TIMESTAMP(),STATUS='R'
WHERE JOBID='CI_PB_LOG' AND STATUS='C'",
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_JOB_CONTROL') }}
SET STATUS='C'
WHERE JOBID='CI_PB_LOG' AND STATUS='R'",
        log_model_end(this, 'M_PS_Z_CI_TD_PROJ_DRIVER_DIM_INS_ASYS')
    ]
) }}

WITH FINAL_SOURCE AS
(
SELECT A.Z_PLAN_ID_TYPE Z_PLAN_ID_TYPE_CD,A.BUSINESS_UNIT,A.PROJECT_ID,A.Z_PROJECT_DRIVER Z_PROJ_DRVR_CD,
X.XLATLONGNAME Z_PROJ_DRVR_LONG_NM,CURRENT_TIMESTAMP() DTTM_STAMP 
FROM {{ source('BRONZE_PS', 'PS_Z_PRJ_DRIVER') }} A 
LEFT JOIN {{ ref('XLATTABLE') }} X --CRPDB01.EPMADM.XLATTABLE
ON X.FIELDNAME='Z_PROJECT_DRIVER' 
AND X.FIELDVALUE=A.Z_PROJECT_DRIVER   
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    Z_PLAN_ID_TYPE_CD,
    BUSINESS_UNIT,
    PROJECT_ID,
    Z_PROJ_DRVR_CD,
    Z_PROJ_DRVR_LONG_NM,
    DTTM_STAMP
FROM FINAL_SOURCE
