-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_TRANSMISSION_PROJECTS
-- MAPPING           : m_ps_z_ci_td_telecom_dim_ins  (statement 5 of 9)
-- SOURCE FILE       : wkf_LOAD_CI_TRANSMISSION_PROJECTS.sql (lines 60-64)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_TD_TLCMN_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_TD_TELECOM_DIM_INS_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : BUSINESS_UNIT, PROJECT_ID, Z_PLAN_ID_TYPE_CD, Z_TLCMN_CD
-- DEPENDS ON        : d81_xlattable (XLATTABLE lookup)
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['BUSINESS_UNIT', 'PROJECT_ID', 'Z_PLAN_ID_TYPE_CD', 'Z_TLCMN_CD'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_TD_TELECOM_DIM_INS_ASYS')
    ],
    post_hook=[
        log_model_end(this, 'M_PS_Z_CI_TD_TELECOM_DIM_INS_ASYS')
    ]
) }}

WITH FINAL_SOURCE AS
(
SELECT A.BUSINESS_UNIT,A.PROJECT_ID,A.Z_PLAN_ID_TYPE Z_PLAN_ID_TYPE_CD,
A.Z_TELECOM Z_TLCMN_CD,X.XLATLONGNAME Z_TLCMN_LONG_NM,
CURRENT_TIMESTAMP() DTTM_STAMP 
FROM {{ source('BRONZE_PS', 'PS_Z_TELECOM') }} A 
LEFT JOIN {{ ref('XLATTABLE') }} X 
ON X.FIELDNAME='Z_TELECOM' 
AND X.FIELDVALUE=A.Z_TELECOM  --CRPDB01.EPMADM.PS_Z_TELECOM / CRPDB01.EPMADM.XLATTABLE
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    BUSINESS_UNIT,
    PROJECT_ID,
    Z_PLAN_ID_TYPE_CD,
    Z_TLCMN_CD,
    Z_TLCMN_LONG_NM,
    DTTM_STAMP
FROM FINAL_SOURCE
