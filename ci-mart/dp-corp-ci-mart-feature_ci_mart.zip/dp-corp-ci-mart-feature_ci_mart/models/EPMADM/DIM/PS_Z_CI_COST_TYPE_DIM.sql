-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_DIMS
-- MAPPING           : m_ps_z_ci_cost_type_dim_ins_upd   (statement 10 of 20)
-- SOURCE FILE       : wkf_LOAD_CI_DIMS.sql (lines 792-813)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CI_COST_TYPE_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_COST_TYPE_DIM_INS_UPD_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : Z_CI_COST_TYPE
-- PRE_HOOK          : m_ps_z_etl_jobs_upd_parms_dims('CI_COSTTYP')   (statement 3)
-- POST_HOOK         : m_ps_z_ci_cost_type_dim_ins_02                 (statement 11)
--                     m_ps_z_etl_jobs_upd_status_dims('CI_COSTTYP')  (statement 19)
--
-- !! merge_update_columns IS REQUIRED HERE, NOT COSMETIC !!
--    The source MERGE inserts 7 columns but its WHEN MATCHED branch updates only
--    5 - Z_CI_COST_TYPE_ID is deliberately excluded because it is a SURROGATE KEY
--    generated as MAX(existing) + ROW_NUMBER(). DBT's default merge updates every
--    non-key column, which would REASSIGN the surrogate ID of every matched row on
--    every run and break every fact table that references it
--    (PS_Z_CI_EST_FACT.Z_CI_COST_TYPE_ID). merge_update_columns pins the update
--    list to exactly the original five.
--
-- SELF-REFERENCE    : the surrogate-ID expression reads MAX(Z_CI_COST_TYPE_ID)
--                     from the target itself. Expressed as {{ this }} and guarded
--                     with is_incremental() so the first run (table not yet
--                     created) falls back to COALESCE(NULL, 0) = 0, exactly as the
--                     original does against an empty table.
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['Z_CI_COST_TYPE'],
    incremental_strategy='merge',
    merge_update_columns=[
        'EFF_STATUS', 'Z_CI_COST_TYPE_LONG_NM', 'Z_CI_COST_TYPE_SHORT_NM',
        'RESOURCE_TYPE', 'DTTM_STAMP'
    ],
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_COST_TYPE_DIM_INS_UPD_ASYS'),
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }}
SET Z_RUN_PARM1=Z_RUN_PARM2,
    Z_RUN_PARM2=TO_VARCHAR(CURRENT_TIMESTAMP(),'YYYY-MM-DD-HH24.MI.SS'),
    STATUS='R'
WHERE JOB_ID='CI_COSTTYP'
  AND STATUS='C'"
    ],
    post_hook=[
        "INSERT INTO {{ this }}(Z_CI_COST_TYPE_ID,Z_CI_COST_TYPE,EFF_STATUS,Z_CI_COST_TYPE_LONG_NM,Z_CI_COST_TYPE_SHORT_NM,RESOURCE_TYPE,DTTM_STAMP)
WITH B AS
(
    SELECT DISTINCT IFF(LENGTH(TRIM(F.Z_CI_COST_TYPE))=0,' ',RTRIM(F.Z_CI_COST_TYPE)) Z_CI_COST_TYPE
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_EST_F00') }} F
    JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} J ON J.JOB_ID='CI_COSTTYP'
    WHERE F.LAST_UPDT_TS>=TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1) AND F.LAST_UPDT_TS<TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
), N AS
(
    SELECT B.Z_CI_COST_TYPE,COALESCE(C.NEWVALUE,' ') RESOURCE_TYPE,ROW_NUMBER() OVER(ORDER BY B.Z_CI_COST_TYPE) RN
    FROM B LEFT JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_EPM_CONV_TBL') }} C ON C.OLDVALUE=B.Z_CI_COST_TYPE AND C.CHARTFIELD='RESOURCE_TYPE' AND C.SYSTEM_SOURCE='CI'
    WHERE NOT EXISTS(SELECT 1 FROM {{ this }} T WHERE T.Z_CI_COST_TYPE=B.Z_CI_COST_TYPE)
)
SELECT COALESCE((SELECT MAX(Z_CI_COST_TYPE_ID) FROM {{ this }}),0)+RN,Z_CI_COST_TYPE,' ',' ',' ',RESOURCE_TYPE,CURRENT_TIMESTAMP() FROM N",
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} SET STATUS='C' WHERE JOB_ID='CI_COSTTYP' AND STATUS='R'",
        log_model_end(this, 'M_PS_Z_CI_COST_TYPE_DIM_INS_UPD_ASYS')
    ]
) }}

WITH B AS
(
    SELECT IFF(LENGTH(TRIM(X.FIELDVALUE))=0,' ',RTRIM(X.FIELDVALUE)) Z_CI_COST_TYPE,
           IFF(LENGTH(TRIM(X.EFF_STATUS))=0,' ',RTRIM(X.EFF_STATUS)) EFF_STATUS,
           IFF(LENGTH(TRIM(X.XLATLONGNAME))=0,' ',RTRIM(X.XLATLONGNAME)) Z_CI_COST_TYPE_LONG_NM,
           IFF(LENGTH(TRIM(X.XLATSHORTNAME))=0,' ',RTRIM(X.XLATSHORTNAME)) Z_CI_COST_TYPE_SHORT_NM,
           COALESCE(C.NEWVALUE,' ') RESOURCE_TYPE,
           CURRENT_TIMESTAMP() DTTM_STAMP
    FROM {{ ref('XLATTABLE') }} X  --CRPDB01.EPMADM.XLATTABLE
    JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} J ON J.JOB_ID='CI_COSTTYP'  --CRPDB01.EPMADM.PS_Z_ETL_JOBS
    LEFT JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_EPM_CONV_TBL') }} C ON C.OLDVALUE=X.FIELDVALUE AND C.CHARTFIELD='RESOURCE_TYPE' AND C.SYSTEM_SOURCE='CI'  --CRPDB01.EPMADM.PS_Z_EPM_CONV_TBL
    WHERE X.FIELDNAME='Z_CI_COST_TYPE' AND X.LASTUPDDTTM>=TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1) AND X.LASTUPDDTTM<TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    COALESCE(
        {% if is_incremental() %}(SELECT MAX(Z_CI_COST_TYPE_ID) FROM {{ this }}){% else %}NULL{% endif %}
    , 0) + ROW_NUMBER() OVER(ORDER BY Z_CI_COST_TYPE) AS Z_CI_COST_TYPE_ID,  --CRPDB01.EPMADM.PS_Z_CI_COST_TYPE_DIM
    Z_CI_COST_TYPE,
    EFF_STATUS,
    Z_CI_COST_TYPE_LONG_NM,
    Z_CI_COST_TYPE_SHORT_NM,
    RESOURCE_TYPE,
    DTTM_STAMP
FROM B
