-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_SEC_CI_PROJ
-- MAPPING           : m_ps_z_sec_ci_proj_ins       (statement 2 of 2)
-- SOURCE FILE       : wkf_LOAD_SEC_CI_PROJ.sql (lines 20-78)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_SEC_CI_PROJ
-- AUTOSYS_JOB_NAME  : M_PS_Z_SEC_CI_PROJ_INS_ASYS
-- MATERIALIZATION   : incremental (truncate + insert = full replace)
-- PRE_HOOK          : TRUNCATE  <- cmd_truncate_PS_Z_SEC_CI_PROJ (statement 1 of 2)
--
-- The original workflow truncates the target then inserts, so this is a full
-- replace. Kept as `incremental` + `full_refresh=false` with the TRUNCATE in
-- pre_hook rather than `table`, so the existing PeopleSoft table DDL and grants
-- survive every run (CREATE OR REPLACE would drop them).
--
-- NOT CONVERTED     : cmd_remove_load_file - an OS-level file cleanup command
--                     task with no SQL equivalent. Handle in Autosys.
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_SEC_CI_PROJ_INS_ASYS'),
        "TRUNCATE TABLE IF EXISTS {{this}}"
    ],
    post_hook=[
        log_model_end(this, 'M_PS_Z_SEC_CI_PROJ_INS_ASYS')
    ]
) }}

WITH SQ_PS_PROJECT_D00 AS
(
    SELECT DISTINCT
        SEC.USER_OPRID AS USER_OPRID,
        PRJ.PROJECT_ID AS PROJECT_ID
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_SEC_SUMMARY') }} AS SEC  --CRPDB01.EPMADM.PS_Z_SEC_SUMMARY
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }} AS PCBU  --CRPDB01.EPMADM.PS_PROJECT_D00
        ON SEC.Z_START_VALUE = PCBU.PROJECT_ID
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }} AS PRJ  --CRPDB01.EPMADM.PS_PROJECT_D00
        ON PRJ.BUSINESS_UNIT = PCBU.BUSINESS_UNIT
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }} AS CI  --CRPDB01.EPMADM.PS_PROJECT_D00
        ON PRJ.PROJECT_USER1 = CI.PROJECT_ID
    WHERE SEC.Z_SEC_TYPE = 'PERFMON'
      AND SEC.DIMENSION_ID = 'PROJ'
      AND CI.PROJECT_USER5 = 'CI'

    UNION

    SELECT DISTINCT
        SEC.USER_OPRID AS USER_OPRID,
        PRJ.PROJECT_ID AS PROJECT_ID
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_SEC_SUMMARY') }} AS SEC  --CRPDB01.EPMADM.PS_Z_SEC_SUMMARY
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }} AS PCBU  --CRPDB01.EPMADM.PS_PROJECT_D00
        ON SEC.Z_START_VALUE = PCBU.PROJECT_ID
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }} AS PRJ  --CRPDB01.EPMADM.PS_PROJECT_D00
        ON PRJ.BUSINESS_UNIT = PCBU.BUSINESS_UNIT
    WHERE SEC.Z_SEC_TYPE = 'PERFMON'
      AND SEC.DIMENSION_ID = 'PROJ'
      AND PRJ.PROJECT_USER5 = 'IR'
      AND EXISTS
      (
          SELECT 1
          FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_D00') }} AS CI  --CRPDB01.EPMADM.PS_Z_CI_D00
          WHERE CI.PROJECT_ID = PRJ.PROJECT_ID
      )
),
EXP_DATAQUALITYSTANDARDS1 AS
(
    SELECT
        IFF(LENGTH(LTRIM(RTRIM(USER_OPRID))) = 0, ' ', RTRIM(USER_OPRID)) AS OUT_USER_OPRID,
        IFF(LENGTH(LTRIM(RTRIM(PROJECT_ID))) = 0, ' ', RTRIM(PROJECT_ID)) AS OUT_PROJECT_ID
    FROM SQ_PS_PROJECT_D00
),
EXPTRANS AS
(
    SELECT
        OUT_USER_OPRID AS USER_OPRID,
        OUT_PROJECT_ID AS PROJECT_ID
    FROM EXP_DATAQUALITYSTANDARDS1
)

-- Projects exactly the INSERT column list, in order.
SELECT
    USER_OPRID,
    PROJECT_ID
FROM EXPTRANS
