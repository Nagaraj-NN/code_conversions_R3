-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_BUDGETS
-- MAPPING           : m_ps_z_ci_balances_bud_ins_upd   (statement 5 of 8)
-- SOURCE FILE       : wkf_LOAD_CI_BUDGETS.sql (lines 192-410)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CI_BALANCES
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_BALANCES_BUD_INS_UPD_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : BUSINESS_UNIT_GL, BUSINESS_UNIT, DEPTID, PROJECT_ID,
--                     Z_WORK_ORDER, ACCOUNT, RESOURCE_TYPE, Z_BENEFIT_LOC,
--                     FISCAL_YEAR, ACCOUNTING_PERIOD
-- DEPENDS ON        : m_ps_z_ci_bud_delta_ins (PS_Z_CI_BAL_BUD_DELTA)
-- POST_HOOK         : m_ps_z_ci_proj_dim_rec_ins_flag_upd_ci_bal_bud (statement 6)
--
-- Loads the FORECAST / CONTROL side of PS_Z_CI_BALANCES (EPMADM copy). The
-- ACTUALS side of the BOEPMMRT copy is loaded by m_ps_z_ci_balances_act_ins_upd.
--
-- !! Z_ACT_USD AND Z_REV_USD ARE DELIBERATELY NOT PROJECTED !!
--    The source EXP_TRIMFIELDS CTE computes 17 columns, but the MERGE INSERT list
--    names only 15 - Z_ACT_USD and Z_REV_USD (both hard-zero in this workflow) are
--    excluded on purpose, because the ACTUALS workflow owns them. If they were
--    projected here, DBT would insert AND update them, zeroing out actual dollars
--    on every budget run. The final SELECT below therefore stops at 15 columns.
--    With that projection, keys (10) + non-key (5) = 15, so DBT's default
--    "update all non-key columns" reproduces the original WHEN MATCHED list
--    exactly and merge_update_columns is not needed.
--
-- SNOWFLAKE VARS    : $$START_YEAR / $$END_YEAR -> var('bud_start_year') /
--                     var('bud_end_year'), defaults 2026 / 2036 matching both the
--                     source literals and the workflow header.
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=[
        'BUSINESS_UNIT_GL', 'BUSINESS_UNIT', 'DEPTID', 'PROJECT_ID', 'Z_WORK_ORDER',
        'ACCOUNT', 'RESOURCE_TYPE', 'Z_BENEFIT_LOC', 'FISCAL_YEAR', 'ACCOUNTING_PERIOD'
    ],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_BALANCES_BUD_INS_UPD_ASYS')
    ],
    post_hook=[
        "MERGE INTO {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }} AS TGT
USING
(
    WITH SQ_PS_Z_CI_PROJ_DIM AS
    (
        SELECT PROJECT_ID, REC_INS_FL
        FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }}
        WHERE REC_INS_FL = 'Y'
    ),
    EXP_DATAQUALITYSTANDARDS1 AS
    (
        SELECT IFF(LENGTH(TRIM(PROJECT_ID)) = 0, ' ', RTRIM(PROJECT_ID)) AS PROJECT_ID
        FROM SQ_PS_Z_CI_PROJ_DIM
    ),
    EXP_REC_INS_FLAG AS
    (
        SELECT PROJECT_ID, 'N' AS REC_INS_FL, CURRENT_TIMESTAMP() AS DTTM_STAMP
        FROM EXP_DATAQUALITYSTANDARDS1
    )
    SELECT *
    FROM EXP_REC_INS_FLAG
) AS SRC
ON TGT.PROJECT_ID = SRC.PROJECT_ID
WHEN MATCHED THEN UPDATE SET
    TGT.REC_INS_FL = SRC.REC_INS_FL,
    TGT.DTTM_STAMP = SRC.DTTM_STAMP",
        log_model_end(this, 'M_PS_Z_CI_BALANCES_BUD_INS_UPD_ASYS')
    ]
) }}

WITH SQ_ODS_UI_EPM_BUDGET AS
(
    SELECT
        B.DEPT_ID,
        B.GLBU_ID,
        B.PROJCT_ID,
        B.BENLOC_ID,
        B.COST_COMPONENT,
        B.ACCOUNT,
        SUM(IFF(B.MEASURE = 'FORECAST', B.AMOUNT, 0)) AS Z_FORE_USD,
        SUM(IFF(B.MEASURE = 'CONTROL', B.AMOUNT, 0)) AS Z_CTRL_USD,
        B.FISCAL_YEAR,
        B.ACCOUNTING_PERIOD
    FROM {{ source('CRPDB01_EPMADM', 'ODS_UI_EPM_BUDGET') }} AS B  --CRPDB01.EPMADM.ODS_UI_EPM_BUDGET
    INNER JOIN {{ ref('PS_Z_CI_BAL_BUD_DELTA') }} AS D  --CRPDB01.EPMADM.PS_Z_CI_BAL_BUD_DELTA
        ON B.DEPT_ID = D.DEPTID
       AND B.PROJCT_ID = D.PROJECT_ID
       AND B.ACCOUNTING_PERIOD = D.ACCOUNTING_PERIOD
       AND B.FISCAL_YEAR = D.FISCAL_YEAR
    WHERE B.MEASURE IN ('FORECAST', 'CONTROL')
      AND B.STATISTICCODE = 'USD'
      AND B.FISCAL_YEAR >= 2011
      AND B.ACCOUNTING_PERIOD BETWEEN 1 AND 12
      AND B.ACCOUNT IN ('1070000','1070001','1080005','1070910','1070920','1070005','1240025','1210003')
      AND D.FISCAL_YEAR BETWEEN 2026 AND 2036
      AND B.FISCAL_YEAR BETWEEN 2026 AND 2036
    GROUP BY
        B.DEPT_ID,
        B.GLBU_ID,
        B.PROJCT_ID,
        B.BENLOC_ID,
        B.COST_COMPONENT,
        B.ACCOUNT,
        B.FISCAL_YEAR,
        B.ACCOUNTING_PERIOD
),
EXP_DATAQUALITYSTANDARDS1 AS
(
    SELECT
        IFF(LENGTH(TRIM(DEPT_ID)) = 0, ' ', RTRIM(DEPT_ID)) AS DEPTID,
        IFF(LENGTH(TRIM(GLBU_ID)) = 0, ' ', RTRIM(GLBU_ID)) AS BUSINESS_UNIT_GL,
        IFF(LENGTH(TRIM(PROJCT_ID)) = 0, ' ', RTRIM(PROJCT_ID)) AS PROJECT_ID,
        IFF(LENGTH(TRIM(BENLOC_ID)) = 0, ' ', RTRIM(BENLOC_ID)) AS RES_USER,
        IFF(LENGTH(TRIM(COST_COMPONENT)) = 0, ' ', RTRIM(COST_COMPONENT)) AS RESOURCE_TYPE,
        IFF(LENGTH(TRIM(ACCOUNT)) = 0, ' ', RTRIM(ACCOUNT)) AS ACCOUNT,
        Z_FORE_USD,
        Z_CTRL_USD,
        FISCAL_YEAR,
        ACCOUNTING_PERIOD
    FROM SQ_ODS_UI_EPM_BUDGET
),
LKP_PS_PROJECT_D00 AS
(
    SELECT
        PROJECT_ID,
        BUSINESS_UNIT
    FROM {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }}  --CRPDB01.EPMADM.PS_PROJECT_D00
    QUALIFY ROW_NUMBER() OVER (PARTITION BY PROJECT_ID ORDER BY BUSINESS_UNIT) = 1
),
LKP_PS_Z_JTP_RELATE_CI AS
(
    SELECT
        R.Z_LEAD_PROJECT,
        R.Z_RELATED_PROJECT
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_JTP_RELATE_CI') }} AS R  --CRPDB01.EPMADM.PS_Z_JTP_RELATE_CI
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }} AS P  --CRPDB01.EPMADM.PS_Z_CI_PROJ_DIM
        ON R.Z_RELATED_PROJECT = P.PROJECT_ID
    WHERE R.Z_PLANT_ID = 'CARDINAL'
      AND R.Z_RELATED_BUGL = '34'
    QUALIFY ROW_NUMBER() OVER (PARTITION BY R.Z_LEAD_PROJECT ORDER BY R.EFFDT DESC) = 1
),
EXP_CALC_MONTH AS
(
    SELECT
        IFF(D.BUSINESS_UNIT_GL = '104' AND D.DEPTID = '11617' AND D.ACCOUNT IN ('1070000','1070001','1080005'), '34', D.BUSINESS_UNIT_GL) AS BUSINESS_UNIT_GL,
        COALESCE(PD.BUSINESS_UNIT, ' ') AS BUSINESS_UNIT,
        D.DEPTID,
        IFF(D.BUSINESS_UNIT_GL = '104' AND D.DEPTID = '11617' AND D.ACCOUNT IN ('1070000','1070001','1080005'), R.Z_RELATED_PROJECT, D.PROJECT_ID) AS PROJECT_ID,
        ' ' AS ACTIVITY_ID,
        D.ACCOUNT,
        D.RESOURCE_TYPE,
        D.RES_USER,
        D.FISCAL_YEAR,
        D.ACCOUNTING_PERIOD,
        (D.FISCAL_YEAR * 100) + D.ACCOUNTING_PERIOD AS YEAR_MONTH,
        'EPM' AS SYSTEM_SOURCE,
        0::NUMBER(26,3) AS Z_ACT_USD,
        D.Z_FORE_USD,
        D.Z_CTRL_USD,
        0::NUMBER(26,3) AS Z_XFER_USD,
        CURRENT_TIMESTAMP() AS DTTM_STAMP
    FROM EXP_DATAQUALITYSTANDARDS1 AS D
    LEFT JOIN LKP_PS_Z_JTP_RELATE_CI AS R
        ON D.PROJECT_ID = R.Z_LEAD_PROJECT
    LEFT JOIN LKP_PS_PROJECT_D00 AS PD
        ON IFF(D.BUSINESS_UNIT_GL = '104' AND D.DEPTID = '11617' AND D.ACCOUNT IN ('1070000','1070001','1080005'), R.Z_RELATED_PROJECT, D.PROJECT_ID) = PD.PROJECT_ID
),
FLTR_BLOCK_CC_738_AND_NON_CI_BUCKEYE AS
(
    SELECT *
    FROM EXP_CALC_MONTH
    WHERE NOT (RTRIM(RESOURCE_TYPE) = '738' AND FISCAL_YEAR IN (2002, 2003))
      AND PROJECT_ID IS NOT NULL
),
AGGTRANS AS
(
    SELECT
        BUSINESS_UNIT_GL,
        BUSINESS_UNIT,
        DEPTID,
        PROJECT_ID,
        ACTIVITY_ID,
        ACCOUNT,
        RESOURCE_TYPE,
        RES_USER,
        FISCAL_YEAR,
        ACCOUNTING_PERIOD,
        YEAR_MONTH,
        SYSTEM_SOURCE,
        SUM(Z_ACT_USD) AS Z_ACT_USD,
        SUM(Z_FORE_USD) AS Z_FORE_USD,
        SUM(Z_CTRL_USD) AS Z_CTRL_USD,
        SUM(Z_XFER_USD) AS Z_XFER_USD,
        MAX(DTTM_STAMP) AS DTTM_STAMP
    FROM FLTR_BLOCK_CC_738_AND_NON_CI_BUCKEYE
    GROUP BY
        BUSINESS_UNIT_GL,
        BUSINESS_UNIT,
        DEPTID,
        PROJECT_ID,
        ACTIVITY_ID,
        ACCOUNT,
        RESOURCE_TYPE,
        RES_USER,
        FISCAL_YEAR,
        ACCOUNTING_PERIOD,
        YEAR_MONTH,
        SYSTEM_SOURCE
),
EXP_TRIMFIELDS AS
(
    SELECT
        RTRIM(BUSINESS_UNIT_GL) AS BUSINESS_UNIT_GL,
        RTRIM(BUSINESS_UNIT) AS BUSINESS_UNIT,
        RTRIM(DEPTID) AS DEPTID,
        RTRIM(PROJECT_ID) AS PROJECT_ID,
        RTRIM(ACTIVITY_ID) AS Z_WORK_ORDER,
        RTRIM(ACCOUNT) AS ACCOUNT,
        RTRIM(RESOURCE_TYPE) AS RESOURCE_TYPE,
        RTRIM(RES_USER) AS Z_BENEFIT_LOC,
        FISCAL_YEAR,
        ACCOUNTING_PERIOD,
        YEAR_MONTH AS Z_YEAR_MONTH,
        SYSTEM_SOURCE,
        Z_ACT_USD,
        Z_FORE_USD,
        Z_CTRL_USD,
        Z_XFER_USD AS Z_REV_USD,
        DTTM_STAMP
    FROM AGGTRANS
)

-- Projects exactly the MERGE INSERT column list, in order.
-- Z_ACT_USD and Z_REV_USD are intentionally omitted - see the header note.
SELECT
    BUSINESS_UNIT_GL,
    DEPTID,
    PROJECT_ID,
    Z_WORK_ORDER,
    ACCOUNT,
    RESOURCE_TYPE,
    Z_BENEFIT_LOC,
    FISCAL_YEAR,
    BUSINESS_UNIT,
    ACCOUNTING_PERIOD,
    Z_YEAR_MONTH,
    SYSTEM_SOURCE,
    Z_ACT_USD,
    Z_FORE_USD,
    Z_CTRL_USD,
    Z_REV_USD,
    DTTM_STAMP
FROM EXP_TRIMFIELDS
