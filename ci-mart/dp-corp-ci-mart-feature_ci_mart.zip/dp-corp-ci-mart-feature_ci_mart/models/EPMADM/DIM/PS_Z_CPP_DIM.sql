-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_DIMS
-- MAPPING           : m_ps_z_cpp_dim_ins_upd       (statement 9 of 20)
-- SOURCE FILE       : wkf_LOAD_CI_DIMS.sql (lines 577-790)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CPP_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CPP_DIM_INS_UPD_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : Z_CPP_ID, REVISION_NUMBER
-- PRE_HOOK          : m_ps_z_etl_jobs_upd_parms_dims('CPP_DIM')   (statement 2)
--                     m_ps_z_cpp_dim_del                          (statement 7)
--                     TRUNCATE                                    (statement 8)
-- POST_HOOK         : m_ps_z_etl_jobs_upd_status_dims('CPP_DIM')  (statement 18)
--
-- !! PRESERVED REDUNDANCY: statement 7 DELETEs from this table on the CPP_DIM
--    delete-log window, then statement 8 TRUNCATEs the whole table one line later.
--    The DELETE therefore has no observable effect, and because the table is empty
--    when the MERGE runs, the MERGE is effectively insert-only. All three are kept
--    in source order. See README_CONVERSION.md OPEN ITEM 3.
--
-- Unlike every other statement in this workflow, this MERGE's USING clause has NO
-- join to PS_Z_ETL_JOBS - it reads all of PS_Z_CPP_D00 unfiltered. The CPP_DIM run
-- window is only consumed by the statement-7 DELETE. Preserved as-is.
--
-- INSERT cols (49) = keys (2) + UPDATE SET cols (47), so DBT's default
-- "update all non-key columns" reproduces the original WHEN MATCHED list exactly
-- and merge_update_columns is not needed.
--
-- !! BUG FIXED - THE SOURCE MERGE COULD NOT HAVE COMPILED !!
--    The USING clause aliased two different columns to the same name:
--        line 593:  S.Z_APPROVAL_DT AS Z_APPROVAL_DT
--        line 621:  S.APPROVAL_DT   AS z_APPROVAL_DT
--    Snowflake resolves unquoted identifiers case-insensitively, so the subquery
--    exposed TWO columns named Z_APPROVAL_DT and NO column named APPROVAL_DT.
--    That makes SRC.Z_APPROVAL_DT ambiguous and SRC.APPROVAL_DT - referenced in
--    both the UPDATE SET and the VALUES list - an invalid identifier.
--    FIX: the second alias is corrected to APPROVAL_DT, which is plainly the
--    intent (target columns Z_APPROVAL_DT and APPROVAL_DT are both populated,
--    from source columns of the same names). No values change.
--    See README_CONVERSION.md OPEN ITEM 5.
--
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['Z_CPP_ID', 'REVISION_NUMBER'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CPP_DIM_INS_UPD_ASYS'),
         "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }}
SET Z_RUN_PARM1=Z_RUN_PARM2,
    Z_RUN_PARM2=TO_VARCHAR(CURRENT_TIMESTAMP(),'YYYY-MM-DD-HH24.MI.SS'),
    STATUS='R'
WHERE JOB_ID='CPP_DIM'
  AND STATUS='C'",
  
        "DELETE FROM {{ this }} T
USING {{ source('CRPDB01_EPMADM', 'PS_Z_CPP_DELETE_LOG') }} D, {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} J
WHERE J.JOB_ID='CPP_DIM'
  AND D.LAST_UPDT_TS>=TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1)
  AND D.LAST_UPDT_TS<TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
  AND T.Z_CPP_ID=IFF(LENGTH(TRIM(D.Z_CPP_ID))=0,' ',RTRIM(D.Z_CPP_ID))
  AND T.REVISION_NUMBER=D.REVISION_NUMBER",
  
        "TRUNCATE TABLE IF EXISTS {{this}}"
    ],
    post_hook=[
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} SET STATUS='C' WHERE JOB_ID='CPP_DIM' AND STATUS='R'",
        log_model_end(this, 'M_PS_Z_CPP_DIM_INS_UPD_ASYS')
    ]
) }}

WITH FINAL_SOURCE AS
(
    SELECT
            IFF(LENGTH(TRIM(S.Z_CPP_ID)) = 0, ' ', RTRIM(S.Z_CPP_ID)) AS Z_CPP_ID,
            S.REVISION_NUMBER AS REVISION_NUMBER,
            IFF(LENGTH(TRIM(S.BUSINESS_UNIT)) = 0, ' ', RTRIM(S.BUSINESS_UNIT)) AS BUSINESS_UNIT,
            IFF(LENGTH(TRIM(S.PROJECT_ID)) = 0, ' ', RTRIM(S.PROJECT_ID)) AS PROJECT_ID,
            S.Z_CI_REVISION AS Z_CI_REVISION,
            IFF(LENGTH(TRIM(S.BUSINESS_UNIT_GL)) = 0, ' ', RTRIM(S.BUSINESS_UNIT_GL)) AS BUSINESS_UNIT_GL,
            IFF(LENGTH(TRIM(S.DESCR)) = 0, ' ', RTRIM(S.DESCR)) AS DESCR,
            IFF(LENGTH(TRIM(S.Z_CPP_TYPE)) = 0, ' ', RTRIM(S.Z_CPP_TYPE)) AS Z_CPP_TYPE,
            IFF(LENGTH(TRIM(S.DESCR254)) = 0, ' ', RTRIM(S.DESCR254)) AS DESCR254,
            IFF(LENGTH(TRIM(S.Z_CPP_STATUS)) = 0, ' ', RTRIM(S.Z_CPP_STATUS)) AS Z_CPP_STATUS,
            IFF(LENGTH(TRIM(S.Z_APPROVER)) = 0, ' ', RTRIM(S.Z_APPROVER)) AS Z_APPROVER,
            IFF(LENGTH(TRIM(S.Z_APPROVED_BY)) = 0, ' ', RTRIM(S.Z_APPROVED_BY)) AS Z_BU_APPROVER_NM,
            S.Z_APPROVAL_DT AS Z_APPROVAL_DT,
            IFF(LENGTH(TRIM(S.IN_SERVICE_DT)) = 0, ' ', RTRIM(S.IN_SERVICE_DT)) AS IN_SERVICE_DT,
            IFF(LENGTH(TRIM(S.Z_CREATED_BY)) = 0, ' ', RTRIM(S.Z_CREATED_BY)) AS Z_CREATED_BY,
            IFF(LENGTH(TRIM(S.Z_CREATED_BY_DTTM)) = 0, ' ', RTRIM(S.Z_CREATED_BY_DTTM)) AS Z_CREATED_BY_DTTM,
            IFF(LENGTH(TRIM(S.Z_APPROVED_BY)) = 0, ' ', RTRIM(S.Z_APPROVED_BY)) AS Z_APPROVED_BY,
            IFF(LENGTH(TRIM(S.Z_APPROVED_BY_DTTM)) = 0, ' ', RTRIM(S.Z_APPROVED_BY_DTTM)) AS Z_APPROVED_BY_DTTM,
            IFF(LENGTH(TRIM(S.Z_REJECTED_BY)) = 0, ' ', RTRIM(S.Z_REJECTED_BY)) AS Z_REJECTED_BY,
            IFF(LENGTH(TRIM(S.Z_REJECTED_BY_DTTM)) = 0, ' ', RTRIM(S.Z_REJECTED_BY_DTTM)) AS Z_REJECTED_BY_DTTM,
            IFF(LENGTH(TRIM(S.HDR_LAST_MAINT_OPRID)) = 0, ' ', RTRIM(S.HDR_LAST_MAINT_OPRID)) AS HDR_LAST_MAINT_OPRID,
            IFF(LENGTH(TRIM(S.HDR_LAST_MAINT_DTTM)) = 0, ' ', RTRIM(S.HDR_LAST_MAINT_DTTM)) AS HDR_LAST_MAINT_DTTM,
            IFF(LENGTH(TRIM(S.REV_LAST_MAINT_OPRID)) = 0, ' ', RTRIM(S.REV_LAST_MAINT_OPRID)) AS REV_LAST_MAINT_OPRID,
            IFF(LENGTH(TRIM(S.REV_LAST_MAINT_DTTM)) = 0, ' ', RTRIM(S.REV_LAST_MAINT_DTTM)) AS REV_LAST_MAINT_DTTM,
            IFF(LENGTH(TRIM(S.CLOSE_STATUS)) = 0, ' ', RTRIM(S.CLOSE_STATUS)) AS CLOSE_STATUS,
            IFF(LENGTH(TRIM(S.Z_COMP_INTENT_TYPE)) = 0, ' ', RTRIM(S.Z_COMP_INTENT_TYPE)) AS Z_COMP_INTENT_TYPE,
            IFF(LENGTH(TRIM(S.Z_LOB)) = 0, ' ', RTRIM(S.Z_LOB)) AS Z_LOB,
            IFF(LENGTH(TRIM(S.COMPLETION_DATE)) = 0, ' ', RTRIM(S.COMPLETION_DATE)) AS COMPLETION_DATE,
            S.IN_SERVICE_DT_TO AS IN_SERVICE_DT_TO,
            IFF(LENGTH(TRIM(S.START_DATE)) = 0, ' ', RTRIM(S.START_DATE)) AS START_DATE,
            IFF(LENGTH(TRIM(S.Z_LEAD_ORG)) = 0, ' ', RTRIM(S.Z_LEAD_ORG)) AS Z_LEAD_ORG,
            IFF(LENGTH(TRIM(S.Z_OUTAGE)) = 0, ' ', RTRIM(S.Z_OUTAGE)) AS Z_OUTAGE,
            IFF(LENGTH(TRIM(S.Z_OUTAGE_INCREASE)) = 0, ' ', RTRIM(S.Z_OUTAGE_INCREASE)) AS Z_OUTAGE_INCREASE,
            S.Z_OUTAGE_DAYS AS Z_OUTAGE_DAYS,
            IFF(LENGTH(TRIM(S.Z_APPY_PROB_CALC)) = 0, ' ', RTRIM(S.Z_APPY_PROB_CALC)) AS Z_APPY_PROB_CALC,
            IFF(LENGTH(TRIM(S.Z_DESIGN_LIFE)) = 0, ' ', RTRIM(S.Z_DESIGN_LIFE)) AS Z_DESIGN_LIFE,
            IFF(LENGTH(TRIM(S.OPRID_ENTERED_BY)) = 0, ' ', RTRIM(S.OPRID_ENTERED_BY)) AS OPRID_ENTERED_BY,
            IFF(LENGTH(TRIM(S.OPRID_OWNER)) = 0, ' ', RTRIM(S.OPRID_OWNER)) AS OPRID_OWNER,
            S.YEAROFDATE AS YEAROFDATE,
            S.APPROVAL_DATE AS APPROVAL_DATE,
            -- FIX: source aliased this as `z_APPROVAL_DT` (see header note)
            S.APPROVAL_DT AS APPROVAL_DT,
            IFF(LENGTH(TRIM(S.DESCR254_MIXED)) = 0, ' ', RTRIM(S.DESCR254_MIXED)) AS DESCR254_MIXED,
            IFF(LENGTH(TRIM(S.DESCR50_MIXED)) = 0, ' ', RTRIM(S.DESCR50_MIXED)) AS DESCR50_MIXED,
            S.PRIORITY AS PRIORITY,
            IFF(LENGTH(TRIM(S.EMPLID2)) = 0, ' ', RTRIM(S.EMPLID2)) AS EMPLID2,
            IFF(LENGTH(TRIM(S.Z_CI_MNDTRY_RSN)) = 0, ' ', RTRIM(S.Z_CI_MNDTRY_RSN)) AS Z_CI_MNDTRY_RSN,
            IFF(LENGTH(TRIM(S.CSTDN_MGR_EMPLID)) = 0, ' ', RTRIM(S.CSTDN_MGR_EMPLID)) AS CSTDN_MGR_EMPLID,
            CURRENT_TIMESTAMP() AS DTTM_STAMP,
            S.Z_PHASE_IR_AMT AS Z_PHASE_IR_AMT,
            S.PL_COL_NB AS PL_COL_NB
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CPP_D00') }} S  --CRPDB01.EPMADM.PS_Z_CPP_D00

)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    Z_CPP_ID,
    REVISION_NUMBER,
    BUSINESS_UNIT,
    PROJECT_ID,
    Z_CI_REVISION,
    BUSINESS_UNIT_GL,
    DESCR,
    Z_CPP_TYPE,
    DESCR254,
    Z_CPP_STATUS,
    Z_APPROVER,
    Z_BU_APPROVER_NM,
    Z_APPROVAL_DT,
    IN_SERVICE_DT,
    Z_CREATED_BY,
    Z_CREATED_BY_DTTM,
    Z_APPROVED_BY,
    Z_APPROVED_BY_DTTM,
    Z_REJECTED_BY,
    Z_REJECTED_BY_DTTM,
    HDR_LAST_MAINT_OPRID,
    HDR_LAST_MAINT_DTTM,
    REV_LAST_MAINT_OPRID,
    REV_LAST_MAINT_DTTM,
    CLOSE_STATUS,
    Z_COMP_INTENT_TYPE,
    Z_LOB,
    COMPLETION_DATE,
    IN_SERVICE_DT_TO,
    START_DATE,
    Z_LEAD_ORG,
    Z_OUTAGE,
    Z_OUTAGE_INCREASE,
    Z_OUTAGE_DAYS,
    Z_APPY_PROB_CALC,
    Z_DESIGN_LIFE,
    OPRID_ENTERED_BY,
    OPRID_OWNER,
    YEAROFDATE,
    APPROVAL_DATE,
    APPROVAL_DT,
    DESCR254_MIXED,
    DESCR50_MIXED,
    PRIORITY,
    EMPLID2,
    Z_CI_MNDTRY_RSN,
    CSTDN_MGR_EMPLID,
    DTTM_STAMP,
    Z_PHASE_IR_AMT,
    PL_COL_NB
FROM FINAL_SOURCE
