-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_BUDGETS
-- MAPPING           : m_ps_z_ci_bud_delta_ins       (statement 3 of 8)
-- SOURCE FILE       : wkf_LOAD_CI_BUDGETS.sql (lines 81-146)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CI_BAL_BUD_DELTA
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_BUD_DELTA_INS_ASYS
-- MATERIALIZATION   : incremental (truncate + insert = full replace per run)
-- PRE_HOOK          : TRUNCATE  <- cmd_truncate_ps_z_ci_bal_delta   (statement 1)
--                     m_ps_z_etl_jobs_upd_parms_ci_bal_bud          (statement 2)
-- POST_HOOK         : m_ps_z_ci_bud_delta_ins_shadow_projects       (statement 4)
--
-- This model owns PS_Z_CI_BAL_BUD_DELTA. Statement 4 is a second INSERT into the
-- same table and runs as a post_hook, so both delta inserts complete before the
-- downstream CI_BALANCES and buckeye models read it.
--
-- Unlike wkf_LOAD_CI_ACTUALS, this workflow's TRUNCATE targets exactly this
-- model's table, so it is expressed as {{ this }} rather than a literal FQN.
-- (The workflow's PRE SQL header comment writes it as
--  "CRPDB01.PS_Z_CI_BAL_BUD_DELTA", omitting the schema, but the
--  actual statement on line 26 is correctly qualified as EPMADM.)
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_BUD_DELTA_INS_ASYS'),
        "TRUNCATE TABLE IF EXISTS {{this}}",
        "MERGE INTO {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} AS TGT
USING
(
    WITH SQ_PS_Z_ETL_JOBS AS
    (
        SELECT
            JOB_ID,
            Z_RUN_PARM1,
            Z_RUN_PARM2,
            Z_RUN_PARM3,
            Z_RUN_PARM4,
            Z_RUN_PARM5,
            STATUS
        FROM {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }}
        WHERE JOB_ID = 'CI_BAL_BUD'
    ),
    EXP_DATAQUALITYSTANDARDS1 AS
    (
        SELECT
            IFF(LENGTH(TRIM(JOB_ID)) = 0, ' ', RTRIM(JOB_ID)) AS JOB_ID,
            IFF(LENGTH(TRIM(Z_RUN_PARM2)) = 0, ' ', RTRIM(Z_RUN_PARM2)) AS Z_RUN_PARM2,
            IFF(LENGTH(TRIM(Z_RUN_PARM3)) = 0, ' ', RTRIM(Z_RUN_PARM3)) AS Z_RUN_PARM3,
            IFF(LENGTH(TRIM(Z_RUN_PARM4)) = 0, ' ', RTRIM(Z_RUN_PARM4)) AS Z_RUN_PARM4,
            IFF(LENGTH(TRIM(Z_RUN_PARM5)) = 0, ' ', RTRIM(Z_RUN_PARM5)) AS Z_RUN_PARM5,
            IFF(LENGTH(TRIM(STATUS)) = 0, ' ', RTRIM(STATUS)) AS STATUS
        FROM SQ_PS_Z_ETL_JOBS
    ),
    EXP_TIMESTAMP AS
    (
        SELECT
            JOB_ID,
            Z_RUN_PARM2 AS OUT_Z_RUN_PARM1,
            TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYY-MM-DD-HH24.MI.SS') AS OUT_Z_RUN_PARM2,
            Z_RUN_PARM3,
            Z_RUN_PARM4,
            Z_RUN_PARM5,
            STATUS,
            'R' AS OUT_STATUS
        FROM EXP_DATAQUALITYSTANDARDS1
    )
    SELECT *
    FROM EXP_TIMESTAMP
    WHERE STATUS = 'C'
) AS SRC
ON TGT.JOB_ID = SRC.JOB_ID
WHEN MATCHED THEN UPDATE SET
    TGT.Z_RUN_PARM1 = SRC.OUT_Z_RUN_PARM1,
    TGT.Z_RUN_PARM2 = SRC.OUT_Z_RUN_PARM2,
    TGT.Z_RUN_PARM3 = SRC.Z_RUN_PARM3,
    TGT.Z_RUN_PARM4 = SRC.Z_RUN_PARM4,
    TGT.Z_RUN_PARM5 = SRC.Z_RUN_PARM5,
    TGT.STATUS = SRC.OUT_STATUS"
    ],
    post_hook=[
        "INSERT INTO {{ this }}
(
    DEPTID,
    PROJECT_ID,
    ACCOUNTING_PERIOD,
    FISCAL_YEAR
)
WITH SQ_ODS_UI_EPM_BUDGET AS
(
    SELECT DISTINCT
        B.DEPT_ID,
        R.Z_RELATED_PROJECT AS PROJECT_ID,
        B.FISCAL_YEAR,
        B.ACCOUNTING_PERIOD
    FROM {{ source('CRPDB01_EPMADM', 'ODS_UI_EPM_BUDGET') }} AS B
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_JTP_RELATE_CI') }} AS R
        ON B.PROJCT_ID = R.Z_LEAD_PROJECT
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }} AS P
        ON R.Z_RELATED_PROJECT = P.PROJECT_ID
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} AS J
        ON J.JOB_ID = 'CI_BAL_BUD'
    WHERE B.MEASURE IN ('FORECAST', 'CONTROL')
      AND B.FISCAL_YEAR >= 2011
      AND B.ACCOUNTING_PERIOD BETWEEN 1 AND 12
      AND B.GLBU_ID = '104'
      AND B.DEPT_ID = '11617'
      AND B.ACCOUNT IN ('1070000','1070001','1080005','1070910','1070920','1070005','1240025','1210003')
      AND B.LAST_UPDT_TS >= TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1)
      AND B.LAST_UPDT_TS < TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
      AND R.Z_PLANT_ID = 'CARDINAL'
      AND R.Z_RELATED_BUGL = '34'
),
EXP_DATAQUALITYSTANDARDS1 AS
(
    SELECT
        IFF(LENGTH(TRIM(DEPT_ID)) = 0, ' ', RTRIM(DEPT_ID)) AS DEPTID,
        IFF(LENGTH(TRIM(PROJECT_ID)) = 0, ' ', RTRIM(PROJECT_ID)) AS PROJECT_ID,
        ACCOUNTING_PERIOD,
        FISCAL_YEAR
    FROM SQ_ODS_UI_EPM_BUDGET
)
SELECT DEPTID, PROJECT_ID, ACCOUNTING_PERIOD, FISCAL_YEAR
FROM EXP_DATAQUALITYSTANDARDS1",
        log_model_end(this, 'M_PS_Z_CI_BUD_DELTA_INS_ASYS')
    ]
) }}

WITH SQ_ODS_UI_EPM_BUDGET AS
(
    SELECT DISTINCT
        B.DEPT_ID,
        B.PROJCT_ID,
        B.FISCAL_YEAR,
        B.ACCOUNTING_PERIOD
    FROM {{ source('CRPDB01_EPMADM', 'ODS_UI_EPM_BUDGET') }} AS B  --CRPDB01.EPMADM.ODS_UI_EPM_BUDGET
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }} AS P  --CRPDB01.EPMADM.PS_Z_CI_PROJ_DIM
        ON B.PROJCT_ID = P.PROJECT_ID
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} AS J  --CRPDB01.EPMADM.PS_Z_ETL_JOBS
        ON J.JOB_ID = 'CI_BAL_BUD'
    WHERE B.MEASURE IN ('FORECAST', 'CONTROL')
      AND B.FISCAL_YEAR >= 2011
      AND B.ACCOUNTING_PERIOD BETWEEN 1 AND 12
      AND B.ACCOUNT IN ('1070000','1070001','1080005','1070910','1070920','1070005','1240025','1210003')
      AND
      (
          (B.LAST_UPDT_TS >= TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1) AND B.LAST_UPDT_TS < TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2))
          OR
          (P.DTTM_STAMP >= TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1) AND P.DTTM_STAMP < TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2) AND P.REC_INS_FL = 'Y')
      )

    UNION

    SELECT DISTINCT
        B.DEPT_ID,
        B.PROJCT_ID,
        B.FISCAL_YEAR,
        B.ACCOUNTING_PERIOD
    FROM {{ source('CRPDB01_EPMADM', 'ODS_UI_EPM_BUDGET') }} AS B  --CRPDB01.EPMADM.ODS_UI_EPM_BUDGET
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_JTP_RELATE_CI') }} AS R  --CRPDB01.EPMADM.PS_Z_JTP_RELATE_CI
        ON B.PROJCT_ID = R.Z_LEAD_PROJECT
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_CI_PROJ_DIM') }} AS P  --CRPDB01.EPMADM.PS_Z_CI_PROJ_DIM
        ON R.Z_RELATED_PROJECT = P.PROJECT_ID
    INNER JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} AS J  --CRPDB01.EPMADM.PS_Z_ETL_JOBS
        ON J.JOB_ID = 'CI_BAL_BUD'
    WHERE B.MEASURE IN ('FORECAST', 'CONTROL')
      AND B.FISCAL_YEAR >= 2006
      AND B.ACCOUNTING_PERIOD BETWEEN 1 AND 12
      AND B.GLBU_ID = '104'
      AND B.DEPT_ID = '11617'
      AND B.ACCOUNT IN ('1070000','1070001','1080005','1070910','1070920','1070005','1240025','1210003')
      AND B.LAST_UPDT_TS >= TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1)
      AND B.LAST_UPDT_TS < TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
      AND R.Z_PLANT_ID = 'CARDINAL'
      AND R.Z_RELATED_BUGL = '34'
),
EXP_DATAQUALITYSTANDARDS1 AS
(
    SELECT
        IFF(LENGTH(TRIM(DEPT_ID)) = 0, ' ', RTRIM(DEPT_ID)) AS DEPTID,
        IFF(LENGTH(TRIM(PROJCT_ID)) = 0, ' ', RTRIM(PROJCT_ID)) AS PROJECT_ID,
        ACCOUNTING_PERIOD,
        FISCAL_YEAR
    FROM SQ_ODS_UI_EPM_BUDGET
)

-- Projects exactly the INSERT column list, in order.
SELECT DEPTID, PROJECT_ID, ACCOUNTING_PERIOD, FISCAL_YEAR
FROM EXP_DATAQUALITYSTANDARDS1
