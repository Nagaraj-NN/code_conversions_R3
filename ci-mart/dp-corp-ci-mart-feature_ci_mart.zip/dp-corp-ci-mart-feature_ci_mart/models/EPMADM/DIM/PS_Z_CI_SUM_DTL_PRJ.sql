-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_DIMS
-- MAPPING           : m_load_ci_summary_detail_xref   (statement 15 of 20)
-- SOURCE FILE       : wkf_LOAD_CI_DIMS.sql (lines 870-872)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CI_SUM_DTL_PRJ
-- AUTOSYS_JOB_NAME  : M_LOAD_CI_SUMMARY_DETAIL_XREF_ASYS
-- MATERIALIZATION   : incremental (truncate + insert = full replace per run)
-- PRE_HOOK          : TRUNCATE   (statement 14)
-- POST_HOOK         : m_load_ci_summary_detail_xref_standalone_projects (statement 16)
--
-- This model owns PS_Z_CI_SUM_DTL_PRJ. Statement 16 is a second write to the same
-- table (the standalone / master projects) and runs as a post_hook.
--
-- This workflow uses no JOB_ID run window for this table, so there is no
-- PS_Z_ETL_JOBS parms/status pair attached.
--
-- NOTE: reads PS_Z_SUM_DTL_PRJ, which the workflow's own Issues header flags as
--       "does not exist or not authorized".
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_LOAD_CI_SUMMARY_DETAIL_XREF_ASYS'),
        "TRUNCATE TABLE IF EXISTS {{this}}"
    ],
    post_hook=[
        "MERGE INTO {{ this }} T
USING
(
    SELECT IFF(LENGTH(TRIM(P.BUSINESS_UNIT))=0,' ',RTRIM(P.BUSINESS_UNIT)) BUSINESS_UNIT,IFF(LENGTH(TRIM(P.PROJECT_ID))=0,' ',RTRIM(P.PROJECT_ID)) PROJECT_ID,R.REVISION_NUMBER,IFF(LENGTH(TRIM(P.PROJECT_ID))=0,' ',RTRIM(P.PROJECT_ID)) PROJECT_USER4,R.REVISION_NUMBER Z_DTL_REV_NUM,IFF(LENGTH(TRIM(P.BUSINESS_UNIT))=0,' ',RTRIM(P.BUSINESS_UNIT)) BUSINESS_UNIT2,IFF(LENGTH(TRIM(R.Z_CI_STATUS))=0,' ',RTRIM(R.Z_CI_STATUS)) Z_CI_STATUS,CURRENT_TIMESTAMP() LAST_UPDT_TS
    FROM {{ source('BRONZE_PS', 'PS_PROJECT') }} P 
    JOIN {{ source('BRONZE_PS', 'PS_Z_CI_REVISION') }} R 
    ON P.BUSINESS_UNIT=R.BUSINESS_UNIT 
    AND P.PROJECT_ID=R.PROJECT_ID 
    JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_PROJECT') }} Z 
    ON P.BUSINESS_UNIT=Z.BUSINESS_UNIT AND P.PROJECT_ID=Z.PROJECT_ID
    WHERE P.SUMMARY_PRJ='N' AND Z.Z_ENTITY_TYPE IN('S','M')
) S
ON T.BUSINESS_UNIT=S.BUSINESS_UNIT AND T.PROJECT_ID=S.PROJECT_ID AND T.REVISION_NUMBER=S.REVISION_NUMBER AND T.PROJECT_USER4=S.PROJECT_USER4 AND T.Z_DTL_REV_NUM=S.Z_DTL_REV_NUM AND T.BUSINESS_UNIT2=S.BUSINESS_UNIT2
WHEN MATCHED THEN UPDATE SET T.Z_CI_STATUS=S.Z_CI_STATUS,T.LAST_UPDT_TS=S.LAST_UPDT_TS
WHEN NOT MATCHED THEN INSERT(BUSINESS_UNIT,PROJECT_ID,REVISION_NUMBER,PROJECT_USER4,Z_DTL_REV_NUM,BUSINESS_UNIT2,Z_CI_STATUS,LAST_UPDT_TS) VALUES(S.BUSINESS_UNIT,S.PROJECT_ID,S.REVISION_NUMBER,S.PROJECT_USER4,S.Z_DTL_REV_NUM,S.BUSINESS_UNIT2,S.Z_CI_STATUS,S.LAST_UPDT_TS)",
        log_model_end(this, 'M_LOAD_CI_SUMMARY_DETAIL_XREF_ASYS')
    ]
) }}

-- Projects exactly the INSERT column list, in order.
SELECT
    IFF(LENGTH(TRIM(BUSINESS_UNIT))=0,' ',RTRIM(BUSINESS_UNIT))   AS BUSINESS_UNIT,
    IFF(LENGTH(TRIM(PROJECT_ID))=0,' ',RTRIM(PROJECT_ID))         AS PROJECT_ID,
    REVISION_NUMBER                                               AS REVISION_NUMBER,
    IFF(LENGTH(TRIM(PROJECT_USER4))=0,' ',RTRIM(PROJECT_USER4))   AS PROJECT_USER4,
    Z_DTL_REV_NUM                                                 AS Z_DTL_REV_NUM,
    IFF(LENGTH(TRIM(BUSINESS_UNIT2))=0,' ',RTRIM(BUSINESS_UNIT2)) AS BUSINESS_UNIT2,
    IFF(LENGTH(TRIM(Z_CI_STATUS))=0,' ',RTRIM(Z_CI_STATUS))       AS Z_CI_STATUS,
    CURRENT_TIMESTAMP()                                           AS LAST_UPDT_TS
FROM {{ source('BRONZE_PS', 'PS_Z_SUM_DTL_PRJ') }}  --CRPDB01.EPMADM.PS_Z_SUM_DTL_PRJ
