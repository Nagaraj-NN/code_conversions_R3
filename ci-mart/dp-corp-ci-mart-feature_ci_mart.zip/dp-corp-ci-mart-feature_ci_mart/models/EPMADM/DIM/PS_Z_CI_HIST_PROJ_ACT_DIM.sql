-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_BUDGETS
-- MAPPING           : m_add_buckeye_workorders     (statement 7 of 8)
-- SOURCE FILE       : wkf_LOAD_CI_BUDGETS.sql (lines 439-533)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CI_HIST_PROJ_ACT_DIM
-- AUTOSYS_JOB_NAME  : M_ADD_BUCKEYE_WORKORDERS_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : PROJECT_ID, ACTIVITY_ID, BUSINESS_UNIT
-- DEPENDS ON        : m_ps_z_ci_bud_delta_ins (PS_Z_CI_BAL_BUD_DELTA)
-- POST_HOOK         : m_ps_z_etl_jobs_upd_status_ci_bal_bud   (statement 8)
--
-- This is the final load of the workflow, so it closes the CI_BAL_BUD window.
-- Note this targets the EPMADM copy of PS_Z_CI_HIST_PROJ_ACT_DIM; the BOEPMMRT
-- copy is loaded by m_ps_z_ci_hist_proj_act_dim_ins_upd_ci_bal in wkf_LOAD_CI_ACTUALS.
--
-- SNOWFLAKE VARS    : Buckeye $$START_YEAR / $$END_YEAR ->
--                     var('buckeye_start_year') / var('buckeye_end_year'),
--                     defaults 2004 / 2020 matching the source literals.
--
-- PRESERVED ODDITY  : the inner filter carries BOTH
--                       FISCAL_YEAR BETWEEN 2004 AND 2020   (buckeye window)
--                       AND B.FISCAL_YEAR > 2010
--                     so the effective range is 2011..2020. Kept verbatim.
--
-- PRESERVED ODDITY  : ACTIVITY_ID is hard-set to ' ' in SQ_PS_PROJ_RES_ACT_VW,
--                     then EXP_DTTM_STAMP_SEC computes
--                       SUBSTR(ACTIVITY_ID, 1, LENGTH(ACTIVITY_ID) - 2) || 'CDB'
--                     LENGTH(' ') = 1, so the SUBSTR length argument is -1 and the
--                     result is just 'CDB' for every row. Kept verbatim - see
--                     README_CONVERSION.md OPEN ITEM 4.
--
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['PROJECT_ID', 'ACTIVITY_ID', 'BUSINESS_UNIT'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_ADD_BUCKEYE_WORKORDERS_ASYS')
    ],
    post_hook=[
        "MERGE INTO {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} AS TGT
USING
(
    WITH SQ_PS_Z_ETL_JOBS AS
    (
        SELECT JOB_ID, STATUS
        FROM {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }}
        WHERE JOB_ID = 'CI_BAL_BUD'
    ),
    EXP_DATAQUALITYSTANDARDS1 AS
    (
        SELECT
            IFF(LENGTH(TRIM(JOB_ID)) = 0, ' ', RTRIM(JOB_ID)) AS JOB_ID,
            IFF(LENGTH(TRIM(STATUS)) = 0, ' ', RTRIM(STATUS)) AS STATUS
        FROM SQ_PS_Z_ETL_JOBS
    ),
    EXP_STATUS AS
    (
        SELECT JOB_ID, STATUS, 'C' AS OUT_STATUS
        FROM EXP_DATAQUALITYSTANDARDS1
    )
    SELECT *
    FROM EXP_STATUS
    WHERE STATUS = 'R'
) AS SRC
ON TGT.JOB_ID = SRC.JOB_ID
WHEN MATCHED THEN UPDATE SET
    TGT.STATUS = SRC.OUT_STATUS;",
        log_model_end(this, 'M_ADD_BUCKEYE_WORKORDERS_ASYS')
    ]
) }}

WITH SQ_PS_PROJ_RES_ACT_VW AS
(
    SELECT
        COALESCE(P.BUSINESS_UNIT, ' ') AS BUSINESS_UNIT,
        B.PROJECT_ID,
        ' ' AS ACTIVITY_ID
    FROM
    (
        SELECT DISTINCT B.PROJCT_ID AS PROJECT_ID
        FROM {{ source('CRPDB01_EPMADM', 'ODS_UI_EPM_BUDGET') }} AS B  --CRPDB01.EPMADM.ODS_UI_EPM_BUDGET
        INNER JOIN {{ ref('PS_Z_CI_BAL_BUD_DELTA') }} AS D  --CRPDB01.EPMADM.PS_Z_CI_BAL_BUD_DELTA
            ON B.DEPT_ID = D.DEPTID
           AND B.PROJCT_ID = D.PROJECT_ID
           AND B.ACCOUNTING_PERIOD = D.ACCOUNTING_PERIOD
           AND B.FISCAL_YEAR = D.FISCAL_YEAR
        WHERE B.MEASURE IN ('FORECAST', 'CONTROL')
          AND B.STATISTICCODE = 'USD'
          AND B.GLBU_ID = '104'
          AND B.DEPT_ID = '11617'
          AND B.ACCOUNT IN ('1070000','1070001','1080005')
          {# AND D.FISCAL_YEAR BETWEEN --{{ var('buckeye_start_year') }} AND {{ var('buckeye_end_year') }} #}
          AND D.FISCAL_YEAR BETWEEN '2004' and '2020'
          AND B.FISCAL_YEAR BETWEEN '2004' and '2020'
          {# {{ var('buckeye_start_year') }} AND {{ var('buckeye_end_year') }} #}
          AND B.FISCAL_YEAR > 2010
    ) AS B
    LEFT JOIN {{ source('CRPDB01_EPMADM', 'PS_PROJECT_D00') }} AS P  --CRPDB01.EPMADM.PS_PROJECT_D00
        ON P.PROJECT_ID = B.PROJECT_ID
),
EXP_DATAQUALITYSTANDARDS1 AS
(
    SELECT
        IFF(LENGTH(TRIM(BUSINESS_UNIT)) = 0, ' ', RTRIM(BUSINESS_UNIT)) AS BUSINESS_UNIT,
        IFF(LENGTH(TRIM(PROJECT_ID)) = 0, ' ', RTRIM(PROJECT_ID)) AS PROJECT_ID,
        IFF(LENGTH(TRIM(ACTIVITY_ID)) = 0, ' ', RTRIM(ACTIVITY_ID)) AS ACTIVITY_ID
    FROM SQ_PS_PROJ_RES_ACT_VW
),
LKP_PS_Z_JTP_RELATE_CI AS
(
    SELECT Z_LEAD_PROJECT, Z_RELATED_PROJECT
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_JTP_RELATE_CI') }}  --CRPDB01.EPMADM.PS_Z_JTP_RELATE_CI
    WHERE Z_PLANT_ID = 'CARDINAL'
      AND Z_RELATED_BUGL = '34'
    QUALIFY ROW_NUMBER() OVER (PARTITION BY Z_LEAD_PROJECT ORDER BY EFFDT DESC) = 1
),
EXP_DTTM_STAMP_SEC AS
(
    SELECT
        R.Z_RELATED_PROJECT AS PROJECT_ID,
        SUBSTR(D.ACTIVITY_ID, 1, LENGTH(D.ACTIVITY_ID) - 2) || 'CDB' AS ACTIVITY_ID,
        D.BUSINESS_UNIT,
        CURRENT_TIMESTAMP() AS DTTM_STAMP_SEC
    FROM EXP_DATAQUALITYSTANDARDS1 AS D
    LEFT JOIN LKP_PS_Z_JTP_RELATE_CI AS R
        ON D.PROJECT_ID = R.Z_LEAD_PROJECT
),
FIL_VALID_PROJECT AS
(
    SELECT *
    FROM EXP_DTTM_STAMP_SEC
    WHERE PROJECT_ID IS NOT NULL
),
AGG_REMOVE_DUPS AS
(
    SELECT
        PROJECT_ID,
        ACTIVITY_ID,
        BUSINESS_UNIT,
        MAX(DTTM_STAMP_SEC) AS DTTM_STAMP_SEC
    FROM FIL_VALID_PROJECT
    GROUP BY PROJECT_ID, ACTIVITY_ID, BUSINESS_UNIT
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    PROJECT_ID,
    ACTIVITY_ID,
    BUSINESS_UNIT,
    DTTM_STAMP_SEC
FROM AGG_REMOVE_DUPS
