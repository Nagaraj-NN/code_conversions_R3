-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_DIMS
-- MAPPING           : m_ps_z_ci_cost_catg_dim_ins_upd   (statement 12 of 20)
-- SOURCE FILE       : wkf_LOAD_CI_DIMS.sql (lines 830-851)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_CI_COST_CATG_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_COST_CATG_DIM_INS_UPD_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : Z_CI_COST_CATG
-- PRE_HOOK          : m_ps_z_etl_jobs_upd_parms_dims('CI_COSTCAT')   (statement 4)
-- POST_HOOK         : m_ps_z_ci_cost_catg_dim_ins_02                 (statement 13)
--                     m_ps_z_etl_jobs_upd_status_dims('CI_COSTCAT')  (statement 20)
--
-- !! merge_update_columns IS REQUIRED HERE, NOT COSMETIC !!
--    Same surrogate-key hazard as [m_ps_z_ci_cost_type_dim_ins_upd]: the source
--    inserts 7 columns but updates only 5, excluding the generated
--    Z_CI_COST_CATG_ID. Letting DBT update it would reassign surrogate IDs on
--    every run and break PS_Z_CI_EST_FACT.Z_CI_COST_CATG_ID.
--
-- SELF-REFERENCE    : MAX(Z_CI_COST_CATG_ID) reads the target itself; expressed as
--                     {{ this }} guarded by is_incremental().
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['Z_CI_COST_CATG'],
    incremental_strategy='merge',
    merge_update_columns=[
        'EFF_STATUS', 'Z_CI_COST_CATG_LONG_NM', 'Z_CI_COST_CATG_SHORT_NM',
        'ACCOUNT', 'DTTM_STAMP'
    ],
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_COST_CATG_DIM_INS_UPD_ASYS'),
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }}
SET Z_RUN_PARM1=Z_RUN_PARM2,
    Z_RUN_PARM2=TO_VARCHAR(CURRENT_TIMESTAMP(),'YYYY-MM-DD-HH24.MI.SS'),
    STATUS='R'
WHERE JOB_ID='CI_COSTCAT'
  AND STATUS='C'"
    ],
    post_hook=[
        "INSERT INTO {{ this }}(Z_CI_COST_CATG_ID,Z_CI_COST_CATG,EFF_STATUS,Z_CI_COST_CATG_LONG_NM,Z_CI_COST_CATG_SHORT_NM,ACCOUNT,DTTM_STAMP)
WITH B AS
(
    SELECT DISTINCT IFF(LENGTH(TRIM(F.Z_CI_COST_CATG))=0,' ',RTRIM(F.Z_CI_COST_CATG)) Z_CI_COST_CATG
    FROM {{ source('CRPDB01_EPMADM', 'PS_Z_CI_EST_F00') }} F
    JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} J 
    ON J.JOB_ID='CI_COSTCAT'
    WHERE F.LAST_UPDT_TS>=TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1) 
    AND F.LAST_UPDT_TS<TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
), N AS
(
    SELECT B.Z_CI_COST_CATG,COALESCE(C.NEWVALUE,' ') ACCOUNT,ROW_NUMBER() OVER(ORDER BY B.Z_CI_COST_CATG) RN
    FROM B LEFT JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_EPM_CONV_TBL') }} C 
    ON C.OLDVALUE=B.Z_CI_COST_CATG 
    AND C.CHARTFIELD='ACCOUNT' 
    AND C.SYSTEM_SOURCE='CI'
    WHERE NOT EXISTS(SELECT 1 FROM {{ this }} T WHERE T.Z_CI_COST_CATG=B.Z_CI_COST_CATG)
)
SELECT COALESCE((SELECT MAX(Z_CI_COST_CATG_ID) FROM {{ this }}),0)+RN,Z_CI_COST_CATG,' ',' ',' ',ACCOUNT,CURRENT_TIMESTAMP() FROM N",
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} SET STATUS='C' WHERE JOB_ID='CI_COSTCAT' AND STATUS='R'",
        log_model_end(this, 'M_PS_Z_CI_COST_CATG_DIM_INS_UPD_ASYS')
    ]
) }}

WITH B AS
(
    SELECT IFF(LENGTH(TRIM(X.FIELDVALUE))=0,' ',RTRIM(X.FIELDVALUE)) Z_CI_COST_CATG,
           IFF(LENGTH(TRIM(X.EFF_STATUS))=0,' ',RTRIM(X.EFF_STATUS)) EFF_STATUS,
           IFF(LENGTH(TRIM(X.XLATLONGNAME))=0,' ',RTRIM(X.XLATLONGNAME)) Z_CI_COST_CATG_LONG_NM,
           IFF(LENGTH(TRIM(X.XLATSHORTNAME))=0,' ',RTRIM(X.XLATSHORTNAME)) Z_CI_COST_CATG_SHORT_NM,
           COALESCE(C.NEWVALUE,' ') ACCOUNT,
           CURRENT_TIMESTAMP() DTTM_STAMP
    FROM {{ ref('XLATTABLE') }} X  --CRPDB01.EPMADM.XLATTABLE
    JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} J --CRPDB01.EPMADM.PS_Z_ETL_JOBS
    ON J.JOB_ID='CI_COSTCAT'  
    LEFT JOIN {{ source('CRPDB01_EPMADM', 'PS_Z_EPM_CONV_TBL') }} C --CRPDB01.EPMADM.PS_Z_EPM_CONV_TBL
    ON C.OLDVALUE=X.FIELDVALUE 
    AND C.CHARTFIELD='ACCOUNT' 
    AND C.SYSTEM_SOURCE='CI'  
    WHERE X.FIELDNAME='Z_CI_COST_CATG' 
    AND X.LASTUPDDTTM>=TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM1) 
    AND X.LASTUPDDTTM<TRY_TO_TIMESTAMP_NTZ(J.Z_RUN_PARM2)
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    COALESCE(
        {% if is_incremental() %}(SELECT MAX(Z_CI_COST_CATG_ID) FROM {{ this }}){% else %}NULL{% endif %}
    , 0) + ROW_NUMBER() OVER(ORDER BY Z_CI_COST_CATG) AS Z_CI_COST_CATG_ID,
    Z_CI_COST_CATG,
    EFF_STATUS,
    Z_CI_COST_CATG_LONG_NM,
    Z_CI_COST_CATG_SHORT_NM,
    ACCOUNT,
    DTTM_STAMP
FROM B
