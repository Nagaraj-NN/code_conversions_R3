-- ============================================================
-- CONVERSION SUMMARY
-- ============================================================
-- WORKFLOW          : wkf_LOAD_CI_TRANSMISSION_PROJECTS
-- MAPPING           : m_ps_z_ci_td_oec_project_dim_ins  (statement 4 of 9)
-- SOURCE FILE       : wkf_LOAD_CI_TRANSMISSION_PROJECTS.sql (lines 54-58)
-- TARGET TABLE      : CRPDB01.EPMADM.PS_Z_TD_OEC_PRJ_DIM
-- AUTOSYS_JOB_NAME  : M_PS_Z_CI_TD_OEC_PROJECT_DIM_INS_ASYS
-- MATERIALIZATION   : incremental + merge
-- MATCH KEYS        : OEC_ID, ACCESS_GRP_NM, PROJECT_ID
-- NOTE              : CAST + DECODE change-detect layer PENDING target DDL
-- ============================================================

{{ config(
    database='CRPDB01',
    schema='EPMADM',
    materialized='incremental',
    unique_key=['OEC_ID', 'ACCESS_GRP_NM', 'PROJECT_ID'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'M_PS_Z_CI_TD_OEC_PROJECT_DIM_INS_ASYS')
    ],
    post_hook=[
        log_model_end(this, 'M_PS_Z_CI_TD_OEC_PROJECT_DIM_INS_ASYS')
    ]
) }}

WITH FINAL_SOURCE AS
(
SELECT Z_OEC_ID OEC_ID,
ACCESS_GROUP ACCESS_GRP_NM,
PROJECT_ID,
CURRENT_TIMESTAMP() LAST_UPDT_TS 
FROM {{ source('BRONZE_PS', 'PS_Z_OEC_PRJ') }}  --CRPDB01.EPMADM.PS_Z_OEC_PRJ
)

-- Projects exactly the MERGE INSERT column list, in order.
SELECT
    OEC_ID,
    ACCESS_GRP_NM,
    PROJECT_ID,
    LAST_UPDT_TS
FROM FINAL_SOURCE
