{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_VW_CALLS_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0002C_VW_CALLS_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0002C_VW_CALLS_STG')
    ]
) }}

WITH sq_vw_calls AS
(
    SELECT
        call_id,
        company_id,
        voice_platform_session_id,
        voice_platform_full_call_id,
        start_site_id,
        start_site_name,
        call_start_time,
        call_start_date,
        call_start_hour,
        call_end_time,
        call_end_date,
        call_end_hour,
        call_end_site_id,
        call_end_site_name,
        call_end_block_type,
        call_end_block_name,
        call_end_result,
        has_recent_failure,
        is_test_call,
        call_duration,
        cli,
        dnis,
        cluster_id,
        cluster_name,
        cti_fields,
        last_menu_block_type,
        last_menu_block_name,
        cli_type,
        server_id,
        start_channel,
        start_channel_category
    FROM {{ source('BRONZE_CALL_CENTER','VW_CALLS') }} 
)
,
exp_Audit AS
(
    SELECT

        call_id,
        company_id,
        voice_platform_session_id,
        voice_platform_full_call_id,
        start_site_id,
        start_site_name,
        call_start_time,
        call_start_date,
        call_start_hour,
        call_end_time,
        call_end_date,
        call_end_hour,
        call_end_site_id,
        call_end_site_name,
        call_end_block_type,
        call_end_block_name,
        call_end_result,
        has_recent_failure,
        is_test_call,
        call_duration,
        cli,
        dnis,
        cluster_id,
        cluster_name,
        cti_fields,
        last_menu_block_type,
        last_menu_block_name,
        cli_type,
        server_id,
        start_channel,
        start_channel_category,
        's_m_VW_CALLS_STG' AS out_edw_crte_nm,
        CURRENT_TIMESTAMP()  AS out_edw_crte_ts,
        's_m_VW_CALLS_STG' AS out_edw_last_updt_nm,
        CURRENT_TIMESTAMP()  AS out_edw_last_updt_ts,

        MD5(
              COALESCE(TO_VARCHAR(voice_platform_session_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(voice_platform_full_call_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_site_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_site_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_start_time),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_start_date),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_start_hour),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_time),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_date),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_hour),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_site_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_site_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_block_type),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_block_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_end_result),'')
           || '~' ||
              COALESCE(TO_VARCHAR(has_recent_failure),'')
           || '~' ||
              COALESCE(TO_VARCHAR(is_test_call),'')
           || '~' ||
              COALESCE(TO_VARCHAR(call_duration),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cli),'')
           || '~' ||
              COALESCE(TO_VARCHAR(dnis),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cluster_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cluster_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cti_fields),'')
           || '~' ||
              COALESCE(TO_VARCHAR(last_menu_block_type),'')
           || '~' ||
              COALESCE(TO_VARCHAR(last_menu_block_name),'')
           || '~' ||
              COALESCE(TO_VARCHAR(cli_type),'')
           || '~' ||
              COALESCE(TO_VARCHAR(server_id),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_channel),'')
           || '~' ||
              COALESCE(TO_VARCHAR(start_channel_category),'')
        ) AS out_md5_checksum_val

    FROM sq_vw_calls
),

final_cte AS (
SELECT
    out_edw_crte_ts,
    out_edw_crte_nm,
    out_edw_last_updt_ts,
    out_edw_last_updt_nm,
    call_id,
    company_id,
    voice_platform_session_id,
    voice_platform_full_call_id,
    start_site_id,
    start_site_name,
    call_start_time,
    call_start_date,
    call_start_hour,
    call_end_time,
    call_end_date,
    call_end_hour,
    call_end_site_id,
    call_end_site_name,
    call_end_block_type,
    call_end_block_name,
    call_end_result,
    has_recent_failure,
    is_test_call,
    call_duration,
    cli,
    dnis,
    cluster_id,
    cluster_name,
    cti_fields,
    last_menu_block_type,
    last_menu_block_name,
    cli_type,
    server_id,
    start_channel,
    start_channel_category,
    out_md5_checksum_val
FROM exp_Audit
)

SELECT
    SRC.out_edw_crte_ts AS EDW_CRTE_TS,
    SRC.out_edw_crte_nm AS EDW_CRTE_NM,
    SRC.out_edw_last_updt_ts AS EDW_LAST_UPDT_TS,
    SRC.out_edw_last_updt_nm AS EDW_LAST_UPDT_NM,
    SRC.CALL_ID,
    SRC.COMPANY_ID,
    SRC.VOICE_PLATFORM_SESSION_ID,
    SRC.VOICE_PLATFORM_FULL_CALL_ID,
    SRC.START_SITE_ID,
    SRC.START_SITE_NAME,
    TRY_TO_TIMESTAMP_NTZ(TO_VARCHAR(SRC.CALL_START_TIME)) AS CALL_START_TIME,
    TRY_TO_TIMESTAMP_NTZ(TO_VARCHAR(SRC.CALL_START_DATE)) AS CALL_START_DATE,
    SRC.CALL_START_HOUR,
    TRY_TO_TIMESTAMP_NTZ(TO_VARCHAR(SRC.CALL_END_TIME)) AS CALL_END_TIME,
    TRY_TO_TIMESTAMP_NTZ(TO_VARCHAR(SRC.CALL_END_DATE)) AS CALL_END_DATE,
    SRC.CALL_END_HOUR,
    SRC.CALL_END_SITE_ID,
    SRC.CALL_END_SITE_NAME,
    SRC.CALL_END_BLOCK_TYPE,
    SRC.CALL_END_BLOCK_NAME,
    SRC.CALL_END_RESULT,
    SRC.HAS_RECENT_FAILURE,
    SRC.IS_TEST_CALL,
    SRC.CALL_DURATION,
    SRC.CLI,
    SRC.DNIS,
    SRC.CLUSTER_ID,
    SRC.CLUSTER_NAME,
    SRC.CTI_FIELDS,
    SRC.LAST_MENU_BLOCK_TYPE,
    SRC.LAST_MENU_BLOCK_NAME,
    SRC.CLI_TYPE,
    SRC.SERVER_ID,
    SRC.START_CHANNEL,
    SRC.START_CHANNEL_CATEGORY,
    SRC.out_md5_checksum_val AS MD5_CHECKSUM_VAL

FROM
    final_cte SRC