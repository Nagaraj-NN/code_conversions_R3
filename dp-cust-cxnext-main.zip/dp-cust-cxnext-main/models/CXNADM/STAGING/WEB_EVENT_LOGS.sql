{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_WEB_EVENT_LOGS"
    },
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1010C_WEB_EVENT_LOGS')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1010C_WEB_EVENT_LOGS')
    ]
) }}

WITH TARGET_MAX_KEY AS
(
    {% if is_incremental() %}

    SELECT
        COALESCE(MAX(WEB_EVENT_LOGS_ID), 0)::NUMBER(38,0)
            AS MAX_WEB_EVENT_LOGS_ID
    FROM {{ this }}

    {% else %}

    SELECT
        0::NUMBER(38,0) AS MAX_WEB_EVENT_LOGS_ID

    {% endif %}
),

RES1 AS
(
    SELECT
        LES.EVNT_ID AS WEB_EVENT_ID,
        LES.EVNT_TM AS WEB_EVENT_TS,
        LES.EVNT_CD AS WEB_EVENT_CD,
        LES.SVR_NM AS SERVER_NM,
        LES.ENVRMT_NM AS ENVIRONMENT_NM,
        LES.RMT_IP_TX AS WEB_USER_REMOTE_IP,
        LES.PROC_NM AS WEB_EVENT_PROCESS_CD,
        LES.SUB_PROC_NM AS WEB_EVENT_SUBPROCESS_CD,
        LES.URL_TX AS URL_TXT,
        LES.URL_REFERRER_TX AS URL_REFERRER_TXT,
        LES.EVNT_MSG_TX AS EVNT_MSG_TX_TXT,
        SUBSTR(
            LTRIM(
                REGEXP_SUBSTR(
                    LES.EVNT_MSG_TX,
                    'AccountNumber\\=[^|]+'
                ),
                'AccountNumber='
            ),
            1,
            10
        ) AS WEB_USER_BILL_ACCOUNT_NB,
        LTRIM(
            REGEXP_SUBSTR(
                LES.EVNT_MSG_TX,
                'email\\=[^|]+'
            ),
            'email='
        ) AS WEB_USER_EMAIL,
        LTRIM(
            REGEXP_SUBSTR(
                LES.EVNT_MSG_TX,
                'userID\\=[^|]+'
            ),
            'userID='
        ) AS WEB_ID,
        CASE
            WHEN LTRIM(
                REGEXP_SUBSTR(
                    LES.EVNT_MSG_TX,
                    'IsMobileUser\\=[^|]+'
                ),
                'IsMobileUser='
            ) = 'True'
                THEN 'M'
            WHEN LTRIM(
                REGEXP_SUBSTR(
                    LES.EVNT_MSG_TX,
                    'IsMobileUser\\=[^|]+'
                ),
                'IsMobileUser='
            ) = 'False'
                THEN 'D'
        END AS WEB_ACCESS_TYPE_CD,
        LTRIM(
            REGEXP_SUBSTR(
                LES.EVNT_MSG_TX,
                'UserAgent\\=[^|]+'
            ),
            'UserAgent='
        ) AS WEB_USER_AGENT_TXT,
        REPLACE(
            REGEXP_SUBSTR(
                LES.EVNT_MSG_TX,
                'SessionID\\=[^|]+'
            ),
            'SessionID=',
            ''
        ) AS WEB_SESSION_ID,
        LTRIM(
            REGEXP_SUBSTR(
                LES.EVNT_MSG_TX,
                'RequestID\\=[^|]+'
            ),
            'RequestID='
        ) AS WEB_REQUEST_ID
    FROM {{ source('UTLDB01_UTLUSER', 'LOG_EVNTS_STG') }} LES
),

SQ_ODS_CUST_LOG_EVENTS AS
(
    SELECT
        RES1.WEB_EVENT_ID AS EVENT_ID,
        RES1.WEB_EVENT_TS AS EVENT_TIME,
        RES1.WEB_EVENT_CD AS EVENT_CODE,
        RES1.SERVER_NM AS SERVER,
        RES1.ENVIRONMENT_NM AS ENVIRONMENT,
        RES1.WEB_USER_REMOTE_IP AS REMOTE_IP,
        RES1.WEB_EVENT_PROCESS_CD AS PROCESS,
        RES1.WEB_EVENT_SUBPROCESS_CD AS SUBPROCESS,
        RES1.URL_TXT AS URL,
        RES1.URL_REFERRER_TXT AS URL_REFERRER,
        RES1.EVNT_MSG_TX_TXT AS EVENT_MESSAGE,
        RES1.WEB_USER_BILL_ACCOUNT_NB,
        RES1.WEB_USER_EMAIL,
        RES1.WEB_ID,
        RES1.WEB_ACCESS_TYPE_CD AS WEB_ACCESS_TYPE_CODE,
        RES1.WEB_USER_AGENT_TXT,
        RES1.WEB_SESSION_ID,
        RES1.WEB_REQUEST_ID,
        AD.ACCOUNT_D_ID
    FROM RES1
    LEFT JOIN {{ source('UTLDB01_CDWADM', 'ACCOUNT_D') }} AD
        ON RES1.WEB_USER_BILL_ACCOUNT_NB = AD.BILL_ACCOUNT_NB
       AND AD.ACTIVE_FLAG = 'Y'
),

EXP_AUDIT AS
(
    SELECT
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,
        's_m_WEB_EVENT_LOGS'::VARCHAR(50)
            AS EDW_CRTE_NM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,
        's_m_WEB_EVENT_LOGS'::VARCHAR(50)
            AS EDW_LAST_UPDT_NM,
        SQ.WEB_USER_EMAIL,
        SQ.WEB_ID,
        SQ.REMOTE_IP AS WEB_USER_REMOTE_IP,
        CAST(NULL AS VARCHAR(50)) AS WEB_USER_PHONE_NB,
        SQ.ACCOUNT_D_ID,
        SQ.WEB_USER_BILL_ACCOUNT_NB,
        SQ.WEB_ACCESS_TYPE_CODE AS WEB_ACCESS_TYPE_CD,
        SQ.WEB_USER_AGENT_TXT,
        SQ.WEB_SESSION_ID,
        SQ.WEB_REQUEST_ID,
        SQ.EVENT_ID AS WEB_EVENT_ID,
        TO_TIMESTAMP_NTZ(TO_DATE(SQ.EVENT_TIME))
            AS WEB_EVENT_DT,
        SQ.EVENT_TIME AS WEB_EVENT_TS,
        SQ.EVENT_CODE AS WEB_EVENT_CD,
        SQ.PROCESS AS WEB_EVENT_PROCESS_CD,
        SQ.SUBPROCESS AS WEB_EVENT_SUBPROCESS_CD,
        SQ.URL AS URL_TXT,
        SQ.URL_REFERRER AS URL_REFERRER_TXT,
        SQ.EVENT_MESSAGE AS EVENT_MESSAGE_TXT,
        SQ.ENVIRONMENT AS ENVIRONMENT_NM,
        SQ.SERVER AS SERVER_NM,
        'Y' AS ACTIVE_FLAG
    FROM SQ_ODS_CUST_LOG_EVENTS SQ
),

NUMBERED_SOURCE_ROWS AS
(
    SELECT
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM,
        WEB_USER_EMAIL,
        WEB_ID,
        WEB_USER_REMOTE_IP,
        WEB_USER_PHONE_NB,
        ACCOUNT_D_ID,
        WEB_USER_BILL_ACCOUNT_NB,
        WEB_ACCESS_TYPE_CD,
        WEB_USER_AGENT_TXT,
        WEB_SESSION_ID,
        WEB_REQUEST_ID,
        WEB_EVENT_ID,
        WEB_EVENT_DT,
        WEB_EVENT_TS,
        WEB_EVENT_CD,
        WEB_EVENT_PROCESS_CD,
        WEB_EVENT_SUBPROCESS_CD,
        URL_TXT,
        URL_REFERRER_TXT,
        EVENT_MESSAGE_TXT,
        ENVIRONMENT_NM,
        SERVER_NM,
        ACTIVE_FLAG,
        ROW_NUMBER() OVER
        (
            ORDER BY
                WEB_EVENT_ID,
                WEB_EVENT_TS,
                WEB_REQUEST_ID,
                WEB_SESSION_ID
        ) AS INSERT_ROW_NUMBER
    FROM EXP_AUDIT EA

    {% if is_incremental() %}

    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM {{ this }} WEL
        WHERE WEL.WEB_EVENT_ID = EA.WEB_EVENT_ID
    )

    {% endif %}
),

SOURCE_ROWS AS
(
    SELECT
        (
            TMK.MAX_WEB_EVENT_LOGS_ID
            + NSR.INSERT_ROW_NUMBER
        )::NUMBER(38,0) AS WEB_EVENT_LOGS_ID,

        NSR.EDW_CRTE_TS
            AS EDW_CRTE_TS,

        NSR.EDW_CRTE_NM::VARCHAR(50)
            AS EDW_CRTE_NM,

        NSR.EDW_LAST_UPDT_TS
            AS EDW_LAST_UPDT_TS,

        NSR.EDW_LAST_UPDT_NM::VARCHAR(50)
            AS EDW_LAST_UPDT_NM,

        NSR.WEB_USER_EMAIL::VARCHAR(4000)
            AS WEB_USER_EMAIL,

        NSR.WEB_ID::VARCHAR(4000)
            AS WEB_ID,

        NSR.WEB_USER_REMOTE_IP::VARCHAR(45)
            AS WEB_USER_REMOTE_IP,

        NSR.WEB_USER_PHONE_NB::VARCHAR(50)
            AS WEB_USER_PHONE_NB,

        NSR.ACCOUNT_D_ID::NUMBER(38,0)
            AS ACCOUNT_D_ID,

        NSR.WEB_USER_BILL_ACCOUNT_NB::VARCHAR(4000)
            AS WEB_USER_BILL_ACCOUNT_NB,

        NSR.WEB_ACCESS_TYPE_CD
            AS WEB_ACCESS_TYPE_CD,

        NSR.WEB_USER_AGENT_TXT::VARCHAR(4000)
            AS WEB_USER_AGENT_TXT,

        NSR.WEB_SESSION_ID
            AS WEB_SESSION_ID,

        NSR.WEB_REQUEST_ID::VARCHAR(4000)
            AS WEB_REQUEST_ID,

        NSR.WEB_EVENT_ID::NUMBER(38,0)
            AS WEB_EVENT_ID,

        NSR.WEB_EVENT_DT::TIMESTAMP_NTZ(9)
            AS WEB_EVENT_DT,

        NSR.WEB_EVENT_TS::TIMESTAMP_NTZ(9)
            AS WEB_EVENT_TS,

        NSR.WEB_EVENT_CD::NUMBER(38,0)
            AS WEB_EVENT_CD,

        NSR.WEB_EVENT_PROCESS_CD::VARCHAR(256)
            AS WEB_EVENT_PROCESS_CD,

        NSR.WEB_EVENT_SUBPROCESS_CD::VARCHAR(256)
            AS WEB_EVENT_SUBPROCESS_CD,

        NSR.URL_TXT::VARCHAR(2048)
            AS URL_TXT,

        NSR.URL_REFERRER_TXT::VARCHAR(2048)
            AS URL_REFERRER_TXT,

        NSR.EVENT_MESSAGE_TXT::VARCHAR(4000)
            AS EVENT_MESSAGE_TXT,

        NSR.ENVIRONMENT_NM::VARCHAR(20)
            AS ENVIRONMENT_NM,

        NSR.SERVER_NM::VARCHAR(63)
            AS SERVER_NM,

        NSR.ACTIVE_FLAG::VARCHAR(1)
            AS ACTIVE_FLAG

    FROM NUMBERED_SOURCE_ROWS NSR
    CROSS JOIN TARGET_MAX_KEY TMK
)

SELECT
    WEB_EVENT_LOGS_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    WEB_USER_EMAIL,
    WEB_ID,
    WEB_USER_REMOTE_IP,
    WEB_USER_PHONE_NB,
    ACCOUNT_D_ID,
    WEB_USER_BILL_ACCOUNT_NB,
    WEB_ACCESS_TYPE_CD,
    WEB_USER_AGENT_TXT,
    WEB_SESSION_ID,
    WEB_REQUEST_ID,
    WEB_EVENT_ID,
    WEB_EVENT_DT,
    WEB_EVENT_TS,
    WEB_EVENT_CD,
    WEB_EVENT_PROCESS_CD,
    WEB_EVENT_SUBPROCESS_CD,
    URL_TXT,
    URL_REFERRER_TXT,
    EVENT_MESSAGE_TXT,
    ENVIRONMENT_NM,
    SERVER_NM,
    ACTIVE_FLAG
FROM SOURCE_ROWS