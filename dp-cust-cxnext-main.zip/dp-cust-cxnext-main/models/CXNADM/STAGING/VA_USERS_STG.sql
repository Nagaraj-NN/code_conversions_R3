{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_VA_USERS_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1004C_VA_USERS_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1004C_VA_USERS_STG')
    ]
) }}

WITH sq_va_users AS
(
    SELECT
        VA_USERS.USERID,
        VA_USERS.CC_ID,
        VA_USERS.FIRSTNAME,
        VA_USERS.LASTNAME,
        VA_USERS.MI,
        VA_USERS.SUPERVISOR_ID,
        VA_USERS.IS_ACTIVE,
        VA_USERS.PHONE,
        VA_USERS.POSITION_ID,
        VA_USERS.GROUPID,
        VA_USERS.MB_ID,
        VA_USERS.CONTRACTOR_AGENCY_ID,
        CAST(NULL AS VARCHAR(8))    AS CREATEDBY,
        CAST(NULL AS TIMESTAMP_NTZ) AS CREATEDATE,
        CAST(NULL AS VARCHAR(8))    AS LASTUPDATEBY,
        CAST(NULL AS TIMESTAMP_NTZ) AS LASTUPDATE,
        CAST(NULL AS VARCHAR(3))    AS ROUTING_PROVIDER,
        CAST(NULL AS NUMBER(1,0))   AS IS_MB_ACTIVE
    FROM {{ source('BRONZE_CALL_CENTER','VA_USERS') }} VA_USERS
),

exp_Audit AS
(
    SELECT sq_va_users.*,
        CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
        's_m_VA_USERS_STG'  AS out_EDW_CRTE_NM,
        CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
        's_m_VA_USERS_STG'  AS out_EDW_LAST_UPDT_NM,

        MD5(
              COALESCE(TO_VARCHAR(FIRSTNAME), '')
           || '~'
           || COALESCE(TO_VARCHAR(LASTNAME), '')
           || '~'
           || COALESCE(TO_VARCHAR(MI), '')
           || '~'
           || COALESCE(TO_VARCHAR(SUPERVISOR_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(IS_ACTIVE), '')
           || '~'
           || COALESCE(TO_VARCHAR(PHONE), '')
           || '~'
           || COALESCE(TO_VARCHAR(POSITION_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(GROUPID), '')
           || '~'
           || COALESCE(TO_VARCHAR(MB_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(CONTRACTOR_AGENCY_ID), '')
           || '~'
           || COALESCE(TO_VARCHAR(ROUTING_PROVIDER), '')
           || '~'
           || COALESCE(TO_VARCHAR(IS_MB_ACTIVE), '')
        ) AS out_MD5_CHECKSUM_VAL
    FROM sq_va_users
)
,

final_cte AS (
SELECT
    USERID,
    CC_ID,
    out_EDW_CRTE_TS,
    out_EDW_CRTE_NM,
    out_EDW_LAST_UPDT_TS,
    out_EDW_LAST_UPDT_NM,
    FIRSTNAME,
    LASTNAME,
    MI,
    SUPERVISOR_ID,
    IS_ACTIVE,
    PHONE,
    POSITION_ID,
    GROUPID,
    MB_ID,
    CONTRACTOR_AGENCY_ID,
    CREATEDBY,
    CREATEDATE,
    LASTUPDATEBY,
    LASTUPDATE,
    ROUTING_PROVIDER,
    IS_MB_ACTIVE,
    out_MD5_CHECKSUM_VAL
FROM exp_Audit
)

SELECT
    SRC.USERID,
    SRC.CC_ID,
    SRC.out_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.out_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.out_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.out_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM,
    SRC.FIRSTNAME,
    SRC.LASTNAME,
    SRC.MI,
    SRC.SUPERVISOR_ID,
    SRC.IS_ACTIVE,
    SRC.PHONE,
    SRC.POSITION_ID,
    SRC.GROUPID,
    SRC.MB_ID,
    SRC.CONTRACTOR_AGENCY_ID,
    SRC.CREATEDBY,
    SRC.CREATEDATE,
    SRC.LASTUPDATEBY,
    SRC.LASTUPDATE,
    SRC.ROUTING_PROVIDER,
    SRC.IS_MB_ACTIVE,
    SRC.out_MD5_CHECKSUM_VAL AS MD5_CHECKSUM_VAL

FROM
    final_cte SRC