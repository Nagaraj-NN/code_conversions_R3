{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_CALL_INTENTS"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1010C_CALL_INTENTS'),
        log_model_start(this, 'DP_CXN1010C_CALL_INTENTS')
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1010C_CALL_INTENTS'),
        log_model_end(this, 'DP_CXN1010C_CALL_INTENTS')
    ]
) }}
WITH 
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME= 'CALL_INTENTS' AND AUTOSYS_JOB_NAME = 'DP_CXN1010C_CALL_INTENTS')

, TARGET_MAX_KEY AS
(
    {% if is_incremental() %}

    SELECT
        COALESCE(MAX(CALL_INTENTS_ID), 0)::NUMBER(38,0)
            AS MAX_CALL_INTENTS_ID
    FROM {{ this }}

    {% else %}

    SELECT
        0::NUMBER(38,0) AS MAX_CALL_INTENTS_ID

    {% endif %}
),

TEMP AS
(
    SELECT
        CALLS_ID,
        CTI_FIELDS,
        CASE
            WHEN LTRIM(
                REGEXP_SUBSTR(
                    CTI_FIELDS,
                    'intent_list:[^|]+'
                ),
                'intent_list:'
            ) IS NULL
                THEN 'Unidentified'
            ELSE LTRIM(
                REGEXP_SUBSTR(
                    CTI_FIELDS,
                    'intent_list:[^|]+'
                ),
                'intent_list:'
            )
        END AS CTI_FIELD_TEXT
    FROM {{ source('UTLDB01_CXNADM', 'CALLS') }}
    WHERE EDW_LAST_UPDT_TS >= (SELECT START_DATE FROM JOB_CONTROL)
),

TEMP1 AS
(
    SELECT
        T.CALLS_ID,
        T.CTI_FIELDS,
        TRIM(F.VALUE::STRING) AS CTI_FIELD_TEXT,
        F.INDEX + 1 AS ROW_NUM
    FROM TEMP T,
    LATERAL FLATTEN(
        INPUT => SPLIT(T.CTI_FIELD_TEXT, ',')
    ) F
),

TEMP2 AS
(
    SELECT
        CALLS_ID,
        CTI_FIELD_TEXT AS CALL_INTENTS,
        CTI_FIELDS,
        ROW_NUM
    FROM TEMP1
),

TEMP3 AS
(
    SELECT
        CALLS_ID,
        CALL_INTENTS,
        LAG(
            CALLS_ID,
            1,
            0
        ) OVER
        (
            ORDER BY
                CALLS_ID,
                ROW_NUM
        ) AS PREV_CALLS_ID,
        CTI_FIELDS,
        ROW_NUM
    FROM TEMP2
),

TEMP4 AS
(
    SELECT
        CALLS_ID,
        CALL_INTENTS AS CALL_INTENT,
        PREV_CALLS_ID,
        CASE
            WHEN CALL_INTENTS = 'PaymentAssistance'
             AND CALLS_ID <> PREV_CALLS_ID
             AND
             (
                    CTI_FIELDS LIKE '%432071%'
                 OR CTI_FIELDS LIKE '%442071%'
                 OR CTI_FIELDS LIKE '%452071%'
             )
                THEN 'Payment Arrangement'
            WHEN CALL_INTENTS = 'PaymentAssistance'
             AND CALLS_ID <> PREV_CALLS_ID
             AND
             (
                    CTI_FIELDS LIKE '%432070%'
                 OR CTI_FIELDS LIKE '%442070%'
                 OR CTI_FIELDS LIKE '%452070%'
             )
                THEN 'Payment Extension'
            ELSE CALL_INTENTS
        END AS CALL_INTENT_GROUP,
        CTI_FIELDS,
        ROW_NUM
    FROM TEMP3
),

SQ_CALLS AS
(
    SELECT
        T.CALLS_ID,
        T.CALL_INTENT,
        T.PREV_CALLS_ID,
        T.CALL_INTENT_GROUP,
        T.CTI_FIELDS,
        T.ROW_NUM
    FROM TEMP4 T

    {% if is_incremental() %}

    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM {{ this }} CI
        WHERE T.CALLS_ID = CI.CALLS_ID
    )

    {% endif %}
),

EXP_AUDIT_COLUMNS AS
(
    SELECT
        SQ.CALLS_ID,
        SQ.CALL_INTENT,
        SQ.PREV_CALLS_ID,
        SQ.CALL_INTENT_GROUP,
        SQ.CTI_FIELDS,
        SQ.ROW_NUM,
        ROW_NUMBER() OVER
        (
            PARTITION BY SQ.CALLS_ID
            ORDER BY SQ.ROW_NUM
        ) AS SEQ_NUM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,
        's_m_CALL_INTENTS'::VARCHAR(50)
            AS EDW_CRTE_NM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,
        's_m_CALL_INTENTS'::VARCHAR(50)
            AS EDW_LAST_UPDT_NM
    FROM SQ_CALLS SQ
),

NUMBERED_SOURCE_ROWS AS
(
    SELECT
        CALL_INTENT,
        CALL_INTENT_GROUP,
        SEQ_NUM,
        CALLS_ID,
        ROW_NUM,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM,
        ROW_NUMBER() OVER
        (
            ORDER BY
                CALLS_ID,
                ROW_NUM,
                CALL_INTENT
        ) AS INSERT_ROW_NUMBER
    FROM EXP_AUDIT_COLUMNS
),

SOURCE_ROWS AS
(
    SELECT
        (
            TMK.MAX_CALL_INTENTS_ID
            + NSR.INSERT_ROW_NUMBER
        )::NUMBER(38,0) AS CALL_INTENTS_ID,

        NSR.CALL_INTENT
            AS CALL_INTENT,

        NSR.CALL_INTENT_GROUP
            AS CALL_INTENT_GROUP,

        NSR.SEQ_NUM::NUMBER(3,0)
            AS SEQ_NUM,

        NSR.CALLS_ID::NUMBER(38,0)
            AS CALLS_ID,

        NSR.EDW_CRTE_TS
            AS EDW_CRTE_TS,

        NSR.EDW_CRTE_NM
            AS EDW_CRTE_NM,

        NSR.EDW_LAST_UPDT_TS
            AS EDW_LAST_UPDT_TS,

        NSR.EDW_LAST_UPDT_NM
            AS EDW_LAST_UPDT_NM

    FROM NUMBERED_SOURCE_ROWS NSR
    CROSS JOIN TARGET_MAX_KEY TMK
)

SELECT
    CALL_INTENTS_ID,
    CALL_INTENT,
    CALL_INTENT_GROUP,
    SEQ_NUM,
    CALLS_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM
FROM SOURCE_ROWS