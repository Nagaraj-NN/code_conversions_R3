
{{ config(
    materialized='table',
    meta={"mapping_name": "m_KPI_METRIC_F_STG_INS_DA_V2D"},
    pre_hook=[
        open_control_window(this, 'DP_CXN1016C_KPI_METRIC_F_DA_V2D_STG'),
        log_model_start(this, 'DP_CXN1016C_KPI_METRIC_F_DA_V2D_STG'),
        "TRUNCATE TABLE IF EXISTS {{ source('UTLDB01_CXNADM','KPI_METRIC_F_STG') }}"
    ],
    post_hook=[
        "INSERT INTO {{ source('UTLDB01_CXNADM','KPI_METRIC_F_STG') }}
     (
         REPORT_DT,
         COMPANY_ID,
         KPI_METRIC_CD,
         KPI_METRIC_VAL,
         CALL_INTENT_GROUP,
         EDW_CRTE_TS,
         EDW_CRTE_NM,
         EDW_LAST_UPDT_TS,
         EDW_LAST_UPDT_NM
     )
     SELECT
         REPORT_DT,
         COMPANY_ID,
         KPI_METRIC_CD,
         KPI_METRIC_VAL,
         CALL_INTENT_GROUP,
         EDW_CRTE_TS,
         EDW_CRTE_NM,
         EDW_LAST_UPDT_TS,
         EDW_LAST_UPDT_NM
     FROM {{ this }}",
        update_control_table(this, 'DP_CXN1016C_KPI_METRIC_F_DA_V2D_STG'),
        log_model_end(this, 'DP_CXN1016C_KPI_METRIC_F_DA_V2D_STG')
    ]
) }}

WITH
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME = 'KPI_METRIC_F_STG_INS_DA_V2D' AND AUTOSYS_JOB_NAME = 'DP_CXN1016C_KPI_METRIC_F_DA_V2D_STG'
),
SESSION_01_DA_V2D_CS_RPT_AST AS
(
    WITH V2D_C_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%432070%' AND CTI_FIELDS NOT LIKE '%432071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
            CASE WHEN CTI_FIELDS LIKE '%442153%' THEN 1 ELSE 0 END AS V2D_AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))   --$REPORT_DATE
		AND (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)   --$REPORT_DATE
          AND START_SITE_NAME = 'da_main'
          AND CTI_FIELDS LIKE '%442000%'
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_C AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, MIN(CALL_START_TIME) AS MIN_C_CALL_START_TIME
        FROM V2D_C_BASE
        WHERE V2D_AGENT_TRANSFER = 1
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), AGENT_TRANSFER_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%432070%' AND CTI_FIELDS NOT LIKE '%432071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
            CASE
                WHEN CTI_FIELDS LIKE '%442153%' THEN 1
                WHEN CTI_FIELDS LIKE '%432153%' THEN 1
                WHEN CTI_FIELDS LIKE '%452056%' THEN 1
                ELSE 0
            END AS AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_CS AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, CALL_START_TIME
        FROM AGENT_TRANSFER_BASE
        WHERE AGENT_TRANSFER = 1
    ), CS_C_M AS
    (
        SELECT
            ONLY_C.ACCOUNT_NUMBER,
            LPAD(ONLY_C.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            ONLY_C.INTENT,
            ONLY_C.MIN_C_CALL_START_TIME,
            ONLY_CS.CALL_START_TIME AS CS_CALL_START_TIME,
            DATEDIFF(SECOND,
                TO_TIMESTAMP_NTZ(SUBSTR(ONLY_C.MIN_C_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'),
                TO_TIMESTAMP_NTZ(SUBSTR(ONLY_CS.CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')) / 3600.0 AS DIFF
        FROM ONLY_C
        LEFT JOIN ONLY_CS
          ON ONLY_C.ACCOUNT_NUMBER = ONLY_CS.ACCOUNT_NUMBER
         AND ONLY_C.INTENT = ONLY_CS.INTENT
        WHERE ONLY_CS.CALL_START_TIME IS NOT NULL
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'DA-V2D-CS-RPT-AST' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM CS_C_M
        WHERE DIFF BETWEEN 0.001 AND 72
        GROUP BY OPERATING_COMPANY, INTENT
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_RPT_AST' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_RPT_AST' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_02_DA_V2D_CPB AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,   --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-CPB' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 1 ELSE 0 END) AS "Account_Number",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:LiveAgent%' THEN 1 ELSE 0 END) AS "LiveAgent",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:AMP_Budget%' THEN 1 ELSE 0 END) AS "AMP_Budget",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Choice%' THEN 1 ELSE 0 END) AS "Choice",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Commercial%' THEN 1 ELSE 0 END) AS "Commercial",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Hazard%' THEN 1 ELSE 0 END) AS "Hazard",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Orders%' THEN 1 ELSE 0 END) AS "Orders",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Outage%' THEN 1 ELSE 0 END) AS "Outage",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:StartStopService%' THEN 1 ELSE 0 END) AS "StartStopService",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Trees%' THEN 1 ELSE 0 END) AS "Trees",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:SomethingElse%' THEN 1 ELSE 0 END) AS "SomethingElse",
            SUM(CASE WHEN LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') IS NULL THEN 1 ELSE 0 END) AS "Unidentified"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442091%'
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account_Number",
                "LiveAgent",
                "AMP_Budget",
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance",
                "Choice",
                "Commercial",
                "Hazard",
                "Orders",
                "Outage",
                "StartStopService",
                "Trees",
                "SomethingElse",
                "Unidentified"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CPB' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CPB' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_03_DA_V2D_ABND_MAINENTRY AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-ABND_MAINENTRY' AS KPI_METRIC_CD,
            'Any' AS CALL_INTENT_GROUP,
            SUM(
                CASE
                    WHEN CTI_FIELDS LIKE '%442000%'
                     AND CTI_FIELDS NOT LIKE '%442001%'
                     AND CTI_FIELDS NOT LIKE '%442002%'
                     AND CTI_FIELDS NOT LIKE '%442183%'
                     AND CTI_FIELDS NOT LIKE '%442091%'
                     AND CTI_FIELDS NOT LIKE '%442123%'
                    THEN 1 ELSE 0
                END
            ) AS KPI_METRIC_VAL
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL) --$REPORT_DATE
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_ABND_MAINENTRY' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_ABND_MAINENTRY' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_04_DA_V2D_RU_P AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT, --$REPORT_DATE
            LPAD(
                LTRIM(
                    REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'),
                    'var_AccountNumber:'
                ),
                2
            ) AS COMPANY_ID,
            'DA-V2D-RU_P' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL)   --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442036%'
        GROUP BY
            LPAD(
                LTRIM(
                    REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'),
                    'var_AccountNumber:'
                ),
                2
            )
    ),
    SQ_KPI_METRIC_F_CUSTOM_STG_SRC_UNPIVOT AS
    (
        SELECT
            REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            CALL_INTENT_GROUP,
            KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ),
    EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RU_P' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RU_P' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_UNPIVOT
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_05_DA_V2D_CLK_THR AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-CLK-THR' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442000%'
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CLK_THR' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CLK_THR' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_06_DA_V2D_RU_N AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,   --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-RU_N' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL)  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442099%'
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            CALL_INTENT_GROUP,
            KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    )
    , EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RU_N' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RU_N' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_07_DA_V2D_CNTD AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,   --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-CNTD' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442159' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%442127%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442159' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442014%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442123%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442091%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442160' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%442127%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442160' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442014%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442123%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442091%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%442127%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442014%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442123%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442091%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%442127%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442014%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442123%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442091%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%442127%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442014%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442123%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('442127' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) NOT LIKE '%442091%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CNTD' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CNTD' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_08_DA_V2D_CB_SUCCESS AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,   --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-CB-SUCCESS' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 1 ELSE 0 END) AS "Account_Number",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:LiveAgent%' THEN 1 ELSE 0 END) AS "LiveAgent",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:AMP_Budget%' THEN 1 ELSE 0 END) AS "AMP_Budget",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Choice%' THEN 1 ELSE 0 END) AS "Choice",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Commercial%' THEN 1 ELSE 0 END) AS "Commercial",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Hazard%' THEN 1 ELSE 0 END) AS "Hazard",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Orders%' THEN 1 ELSE 0 END) AS "Orders",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Outage%' THEN 1 ELSE 0 END) AS "Outage",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Paperless_Autopay%' THEN 1 ELSE 0 END) AS "Paperless_AutoPay",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:StartStopService%' THEN 1 ELSE 0 END) AS "StartStopService",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Trees%' THEN 1 ELSE 0 END) AS "Trees",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:SomethingElse%' THEN 1 ELSE 0 END) AS "SomethingElse",
            SUM(CASE WHEN LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') IS NULL THEN 1 ELSE 0 END) AS "Unidentified"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442119%'
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account_Number",
                "LiveAgent",
                "AMP_Budget",
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance",
                "Choice",
                "Commercial",
                "Hazard",
                "Orders",
                "Outage",
                "Paperless_AutoPay",
                "StartStopService",
                "Trees",
                "SomethingElse",
                "Unidentified"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CB_SUCCESS' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CB_SUCCESS' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_09_DA_V2D_CS_ALL AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-CS-ALL' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND (CTI_FIELDS LIKE '%442123%' OR CTI_FIELDS LIKE '%442091%')
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_ALL' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_ALL' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_10_DA_V2D_RPT_SS AS
(
    WITH V2D_C_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                    WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                    WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                    ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
                END AS INTENT,
            CASE
                WHEN CTI_FIELDS LIKE '%442159%' THEN 1
                WHEN CTI_FIELDS LIKE '%442160%' THEN 1
                WHEN CTI_FIELDS LIKE '%442161%' THEN 1
                ELSE 0
            END AS V2D_CONTAINMENT
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
		AND (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND START_SITE_NAME = 'da_main'
          AND CTI_FIELDS LIKE '%442000%'
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_C AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            MIN(CALL_START_TIME) AS MIN_C_CALL_START_TIME
        FROM V2D_C_BASE
        WHERE V2D_CONTAINMENT = 1
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), MATCH_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                    WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                    WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                    ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
                END AS INTENT,
            CASE
                    WHEN CTI_FIELDS LIKE '%432127%' AND CTI_FIELDS LIKE '%432014%' THEN 1
                    WHEN CTI_FIELDS LIKE '%432159%' THEN 1
                    WHEN CTI_FIELDS LIKE '%432160%' THEN 1
                    WHEN CTI_FIELDS LIKE '%432161%' THEN 1
                    WHEN CTI_FIELDS LIKE '%442159%' THEN 1
                    WHEN CTI_FIELDS LIKE '%442160%' THEN 1
                    WHEN CTI_FIELDS LIKE '%442161%' THEN 1
                    WHEN CTI_FIELDS LIKE '%452127%' AND CTI_FIELDS LIKE '%452014%' THEN 1
                    WHEN CTI_FIELDS LIKE '%452159%' THEN 1
                    WHEN CTI_FIELDS LIKE '%452160%' THEN 1
                    WHEN CTI_FIELDS LIKE '%452161%' THEN 1
                    WHEN CTI_FIELDS LIKE '%452166%' THEN 1
                    ELSE 0
                END AS MATCH_FLAG
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_CS AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            CALL_START_TIME
        FROM MATCH_BASE
        WHERE MATCH_FLAG = 1
    ), CS_C_M AS
    (
        SELECT
            ONLY_C.ACCOUNT_NUMBER,
            LPAD(ONLY_C.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            ONLY_C.INTENT,
            ONLY_C.MIN_C_CALL_START_TIME,
            ONLY_CS.CALL_START_TIME AS CS_CALL_START_TIME,
            DATEDIFF(SECOND, TO_TIMESTAMP_NTZ(SUBSTR(ONLY_C.MIN_C_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP_NTZ(SUBSTR(ONLY_CS.CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')) / 3600.0 AS DIFF
        FROM ONLY_C
        LEFT JOIN ONLY_CS
          ON ONLY_C.ACCOUNT_NUMBER = ONLY_CS.ACCOUNT_NUMBER
         AND ONLY_C.INTENT = ONLY_CS.INTENT
        WHERE ONLY_CS.CALL_START_TIME IS NOT NULL
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'DA-V2D-RPT-SS' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM CS_C_M
        WHERE DIFF BETWEEN 0.001 AND 72
        GROUP BY OPERATING_COMPANY, INTENT
    )
    , EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RPT_SS' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RPT_SS' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_11_DA_V2D_ABND_INT AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-ABND_INT' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%442001%' AND CTI_FIELDS NOT LIKE '%442127%' AND CTI_FIELDS NOT LIKE '%442067%' AND CTI_FIELDS NOT LIKE '%442091%' AND CTI_FIELDS NOT LIKE '%442123%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%442002%' AND CTI_FIELDS NOT LIKE '%442127%' AND CTI_FIELDS NOT LIKE '%442067%' AND CTI_FIELDS NOT LIKE '%442091%' AND CTI_FIELDS NOT LIKE '%442123%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442127%' AND CTI_FIELDS NOT LIKE '%442067%' AND CTI_FIELDS NOT LIKE '%442091%' AND CTI_FIELDS NOT LIKE '%442123%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%442071%' AND CTI_FIELDS NOT LIKE '%442127%' AND CTI_FIELDS NOT LIKE '%442067%' AND CTI_FIELDS NOT LIKE '%442091%' AND CTI_FIELDS NOT LIKE '%442123%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%442183%' AND CTI_FIELDS NOT LIKE '%442127%' AND CTI_FIELDS NOT LIKE '%442067%' AND CTI_FIELDS NOT LIKE '%442091%' AND CTI_FIELDS NOT LIKE '%442123%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_ABND_INT' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_ABND_INT' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_12_DA_V2D_CS_RPT_SS AS
(
    WITH V2D_C_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%432070%' AND CTI_FIELDS NOT LIKE '%432071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
            CASE WHEN CTI_FIELDS LIKE '%442153%' THEN 1 ELSE 0 END AS V2D_AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
		AND (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND START_SITE_NAME = 'da_main'
          AND CTI_FIELDS LIKE '%442000%'
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_C AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, MIN(CALL_START_TIME) AS MIN_C_CALL_START_TIME
        FROM V2D_C_BASE
        WHERE V2D_AGENT_TRANSFER = 1
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), ALL_CONTAINMENT_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%432070%' AND CTI_FIELDS NOT LIKE '%432071%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
            CASE
                WHEN CTI_FIELDS LIKE '%432127%' AND CTI_FIELDS LIKE '%432014%' THEN 1
                WHEN CTI_FIELDS LIKE '%432159%' THEN 1
                WHEN CTI_FIELDS LIKE '%432160%' THEN 1
                WHEN CTI_FIELDS LIKE '%432161%' THEN 1
                WHEN CTI_FIELDS LIKE '%442159%' THEN 1
                WHEN CTI_FIELDS LIKE '%442160%' THEN 1
                WHEN CTI_FIELDS LIKE '%442161%' THEN 1
                WHEN CTI_FIELDS LIKE '%452127%' AND CTI_FIELDS LIKE '%452014%' THEN 1
                WHEN CTI_FIELDS LIKE '%452159%' THEN 1
                WHEN CTI_FIELDS LIKE '%452160%' THEN 1
                WHEN CTI_FIELDS LIKE '%452161%' THEN 1
                WHEN CTI_FIELDS LIKE '%452166%' THEN 1
                ELSE 0
            END AS ALL_CONTAINMENT
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_CS AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, CALL_START_TIME
        FROM ALL_CONTAINMENT_BASE
        WHERE ALL_CONTAINMENT = 1
    ), CS_C_M AS
    (
        SELECT
            ONLY_C.ACCOUNT_NUMBER,
            LPAD(ONLY_C.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            ONLY_C.INTENT,
            ONLY_C.MIN_C_CALL_START_TIME,
            ONLY_CS.CALL_START_TIME AS CS_CALL_START_TIME,
            DATEDIFF(SECOND,
                TO_TIMESTAMP_NTZ(SUBSTR(ONLY_C.MIN_C_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'),
                TO_TIMESTAMP_NTZ(SUBSTR(ONLY_CS.CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')) / 3600.0 AS DIFF
        FROM ONLY_C
        LEFT JOIN ONLY_CS
          ON ONLY_C.ACCOUNT_NUMBER = ONLY_CS.ACCOUNT_NUMBER
         AND ONLY_C.INTENT = ONLY_CS.INTENT
        WHERE ONLY_CS.CALL_START_TIME IS NOT NULL
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'DA-V2D-CS-RPT-SS' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM CS_C_M
        WHERE DIFF BETWEEN 0.001 AND 72
        GROUP BY OPERATING_COMPANY, INTENT
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_RPT_SS' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_RPT_SS' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_13_DA_V2D_CS_SUCCESS AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  ----$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-CS-SUCCESS' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442153%'
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_SUCCESS' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_CS_SUCCESS' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_14_DA_V2D_RPT_AST AS
(
    WITH V2D_C_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                    WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                    WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                    ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
                END AS INTENT,
            CASE
                WHEN CTI_FIELDS LIKE '%442159%' THEN 1
                WHEN CTI_FIELDS LIKE '%442160%' THEN 1
                WHEN CTI_FIELDS LIKE '%442161%' THEN 1
                ELSE 0
            END AS V2D_CONTAINMENT
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
		AND (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND START_SITE_NAME = 'da_main'
          AND CTI_FIELDS LIKE '%442000%'
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_C AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            MIN(CALL_START_TIME) AS MIN_C_CALL_START_TIME
        FROM V2D_C_BASE
        WHERE V2D_CONTAINMENT = 1
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), MATCH_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                    WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                    WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 'Payment Extension'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 'Payment Arrangement'
                    WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 'Payment Assistance'
                    ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
                END AS INTENT,
            CASE
                    WHEN CTI_FIELDS LIKE '%442153%' THEN 1
                    WHEN CTI_FIELDS LIKE '%432153%' THEN 1
                    WHEN CTI_FIELDS LIKE '%452056%' THEN 1
                    ELSE 0
                END AS MATCH_FLAG
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_CS AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            CALL_START_TIME
        FROM MATCH_BASE
        WHERE MATCH_FLAG = 1
    ), CS_C_M AS
    (
        SELECT
            ONLY_C.ACCOUNT_NUMBER,
            LPAD(ONLY_C.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            ONLY_C.INTENT,
            ONLY_C.MIN_C_CALL_START_TIME,
            ONLY_CS.CALL_START_TIME AS CS_CALL_START_TIME,
            DATEDIFF(SECOND, TO_TIMESTAMP_NTZ(SUBSTR(ONLY_C.MIN_C_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP_NTZ(SUBSTR(ONLY_CS.CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')) / 3600.0 AS DIFF
        FROM ONLY_C
        LEFT JOIN ONLY_CS
          ON ONLY_C.ACCOUNT_NUMBER = ONLY_CS.ACCOUNT_NUMBER
         AND ONLY_C.INTENT = ONLY_CS.INTENT
        WHERE ONLY_CS.CALL_START_TIME IS NOT NULL
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'DA-V2D-RPT-AST' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM CS_C_M
        WHERE DIFF BETWEEN 0.001 AND 72
        GROUP BY OPERATING_COMPANY, INTENT
    )
    , EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RPT_AST' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_RPT_AST' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_15_DA_V2D_NCS AS
(
    WITH SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            'DA-V2D-NCS' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%442071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'da_main'
          AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%442091%'
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_NCS' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_DA_V2D_NCS' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

final_cte AS (
SELECT * FROM SESSION_01_DA_V2D_CS_RPT_AST
UNION ALL
SELECT * FROM SESSION_02_DA_V2D_CPB
UNION ALL
SELECT * FROM SESSION_03_DA_V2D_ABND_MAINENTRY
UNION ALL
SELECT * FROM SESSION_04_DA_V2D_RU_P
UNION ALL
SELECT * FROM SESSION_05_DA_V2D_CLK_THR
UNION ALL
SELECT * FROM SESSION_06_DA_V2D_RU_N
UNION ALL
SELECT * FROM SESSION_07_DA_V2D_CNTD
UNION ALL
SELECT * FROM SESSION_08_DA_V2D_CB_SUCCESS
UNION ALL
SELECT * FROM SESSION_09_DA_V2D_CS_ALL
UNION ALL
SELECT * FROM SESSION_10_DA_V2D_RPT_SS
UNION ALL
SELECT * FROM SESSION_11_DA_V2D_ABND_INT
UNION ALL
SELECT * FROM SESSION_12_DA_V2D_CS_RPT_SS
UNION ALL
SELECT * FROM SESSION_13_DA_V2D_CS_SUCCESS
UNION ALL
SELECT * FROM SESSION_14_DA_V2D_RPT_AST
UNION ALL
SELECT * FROM SESSION_15_DA_V2D_NCS
)

SELECT
    SRC.REPORT_DT,
    SRC.COMPANY_ID,
    SRC.KPI_METRIC_CD,
    SRC.KPI_METRIC_VAL,
    SRC.CALL_INTENT_GROUP,
    SRC.EDW_CRTE_TS,
    SRC.EDW_CRTE_NM,
    SRC.EDW_LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_NM

FROM
    final_cte SRC