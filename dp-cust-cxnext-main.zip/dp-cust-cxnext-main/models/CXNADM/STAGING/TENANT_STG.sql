-- ===========================================================================
-- Model      : TENANT_STG
-- Mapping    : m_TENANT_STG
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.TENANT_STG
-- Load type  : incremental / append (truncate + reload)
-- ---------------------------------------------------------------------------
-- Stages the Genesys TENANT configuration (key, name, cfg dbid,
-- validity timestamps, audit keys) and builds the MD5 checksum used by
-- ODS_TENANT to detect changed rows.
-- Truncate-and-reload staging table.
-- ===========================================================================

{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_TENANT_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_TENANT_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_TENANT_STG')
    ]
) }}

WITH
SQ_TENANT_ AS (
  SELECT
    TENANT_KEY,
    TENANT_NAME,
    TENANT_CFG_DBID,
    START_TS,
    END_TS,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY
  FROM {{ source('BRONZE_CALL_CENTER','TENANT') }}
  -- REJECT: CXNADM.TENANT_STG.TENANT_KEY is NOT NULL. Informatica wrote a
  -- NULL-key row to the bad file and let the session continue; Snowflake
  -- aborts the whole INSERT instead ("NULL result in a non-nullable
  -- column"), so the reject is applied here in the SELECT.
  WHERE TENANT_KEY IS NOT NULL
),

exp_AUDIT_TENANT_STG_step1 AS (
  SELECT
    SQ_TENANT_.*,
    MD5(COALESCE(CAST(IFF((TENANT_KEY IS NULL) = TRUE, -1, TENANT_KEY) AS VARCHAR), '') || COALESCE(CAST(IFF((TENANT_NAME IS NULL) = TRUE, '@#$', TENANT_NAME) AS VARCHAR), '') || COALESCE(CAST(IFF((TENANT_CFG_DBID IS NULL) = TRUE, -1, TENANT_CFG_DBID) AS VARCHAR), '') || COALESCE(CAST(IFF((START_TS IS NULL) = TRUE, -1, START_TS) AS VARCHAR), '') || COALESCE(CAST(IFF((END_TS IS NULL) = TRUE, -1, END_TS) AS VARCHAR), '') || COALESCE(CAST(IFF((CREATE_AUDIT_KEY IS NULL) = TRUE, -1, CREATE_AUDIT_KEY) AS VARCHAR), '') || COALESCE(CAST(IFF((UPDATE_AUDIT_KEY IS NULL) = TRUE, -1, UPDATE_AUDIT_KEY) AS VARCHAR), '')) AS v_MD5_CHECKSUM_VALUE,
    CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
    's_m_TENANT_STG' AS out_EDW_CRTE_NM,
    CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
    's_m_TENANT_STG' AS out_EDW_LAST_UPDT_NM
  FROM SQ_TENANT_
),

exp_AUDIT_TENANT_STG AS (
  SELECT
    exp_AUDIT_TENANT_STG_step1.*,
    v_MD5_CHECKSUM_VALUE AS out_MD5_CHECKSUM_VALUE
  FROM exp_AUDIT_TENANT_STG_step1
)
,

final_cte AS (
SELECT
  TENANT_KEY, TENANT_NAME, TENANT_CFG_DBID, START_TS, END_TS, CREATE_AUDIT_KEY, UPDATE_AUDIT_KEY, out_MD5_CHECKSUM_VALUE, out_EDW_CRTE_TS, out_EDW_CRTE_NM, out_EDW_LAST_UPDT_TS, out_EDW_LAST_UPDT_NM
FROM exp_AUDIT_TENANT_STG
)

SELECT
    SRC.TENANT_KEY,
    SRC.TENANT_NAME,
    SRC.TENANT_CFG_DBID,
    SRC.START_TS,
    SRC.END_TS,
    SRC.CREATE_AUDIT_KEY,
    SRC.UPDATE_AUDIT_KEY,
    SRC.OUT_MD5_CHECKSUM_VALUE AS MD5_CHECKSUM_VAL,
    SRC.OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC