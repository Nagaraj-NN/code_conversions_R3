{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_ACCOUNT_TENURE_D"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1010C_ACCOUNT_TENURE_D'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1010C_ACCOUNT_TENURE_D')
    ]
) }}

WITH LOAD_CONTEXT AS
(
    SELECT
        CURRENT_DATE() AS LOAD_DATE,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9) AS SESSION_START_TS
),

SQ_ACCOUNT_TENURE_D AS
(
    SELECT
        AD.ACCOUNT_D_ID,
        DATEDIFF(
            DAY,
            CAST(AD.CONTRACT_START_DT AS DATE),
            LC.LOAD_DATE
        ) AS TENURE_DAYS_CNT,
        FLOOR(
            MONTHS_BETWEEN(
                LC.LOAD_DATE,
                AD.CONTRACT_START_DT
            ) / 12
        ) AS TENURE_YEARS_CNT
    FROM {{ source('UTLDB01_CDWADM', 'ACCOUNT_D') }} AD
    CROSS JOIN LOAD_CONTEXT LC
    WHERE AD.ACTIVE_FLAG = 'Y'
),

EXP_AUDIT AS
(
    SELECT
        ROW_NUMBER() OVER (
            ORDER BY SQ.ACCOUNT_D_ID
        )::NUMBER(38,0) AS ACCOUNT_TENURE_D_ID,
        SQ.ACCOUNT_D_ID::NUMBER(38,0) AS ACCOUNT_D_ID,
        LC.SESSION_START_TS AS EDW_CRTE_TS,
        's_m_ACCOUNT_TENURE_D'::VARCHAR(50) AS EDW_CRTE_NM,
        LC.SESSION_START_TS AS EDW_LAST_UPDT_TS,
        's_m_ACCOUNT_TENURE_D'::VARCHAR(50) AS EDW_LAST_UPDT_NM,
        SQ.TENURE_DAYS_CNT::NUMBER(5,0) AS TENURE_DAYS_CNT,
        SQ.TENURE_YEARS_CNT::NUMBER(3,0) AS TENURE_YEARS_CNT
    FROM SQ_ACCOUNT_TENURE_D SQ
    CROSS JOIN LOAD_CONTEXT LC
)

SELECT
    ACCOUNT_TENURE_D_ID,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    TENURE_DAYS_CNT,
    TENURE_YEARS_CNT
FROM EXP_AUDIT