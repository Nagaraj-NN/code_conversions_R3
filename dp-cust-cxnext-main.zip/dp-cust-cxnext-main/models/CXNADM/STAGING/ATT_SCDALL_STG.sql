-- ===========================================================================
-- Model      : ATT_SCDALL_STG
-- Mapping    : m_ATT_SCDALL_STG
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.ATT_SCDALL_STG
-- Load type  : incremental / append (truncate + reload)
-- ---------------------------------------------------------------------------
-- Stages the AT&T daily call report feed: report date (cast from the
-- flat-file string with TRY_TO_DATE) and the total call count, plus
-- the EDW audit columns. Truncate-and-reload staging table.
-- NOTE: the Informatica source is the Attdailycallreport*.csv flat file;
-- NOTE: in Snowflake it is read from COMMON.ATTDAILYCALLREPORT_TEMP.
-- ===========================================================================

{{ config(
    materialized='incremental',
    enabled=false,
    incremental_strategy='append',
    meta={"mapping_name": "m_ATT_SCDALL_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1002C_ATT_SCDALL_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1002C_ATT_SCDALL_STG')
    ]
) }}

WITH
SQ_Attdailycallreport1 AS (
  SELECT
    REPORT_DT,
    TOTAL_CALL_COUNT
  FROM {{ source('BRONZE_CALL_CENTER','ATTDAILYCALLREPORT') }}
),

exp_AUDIT_COLS AS (
  SELECT
    SQ_Attdailycallreport1.*,
    's_m_ATT_SCDALL_STG' AS EDW_CRTE_NM,
    CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
    's_m_ATT_SCDALL_STG' AS EDW_LAST_UPDT_NM,
    CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
    TRY_TO_DATE(REPORT_DT) AS out_REPORT_DT --if REPORT_DT is VARCHAR
    -- TO_DATE(REPORT_DT) AS out_REPORT_DT  --if REPORT_DT is TIMESTAMP_NTZ
    -- REPORT_DT AS out_REPORT_DT  --if REPORT_DT is DATE(Used for Testing by cretaing the temp table on my own)
  FROM SQ_Attdailycallreport1
)
,

final_cte AS (
SELECT
  EDW_CRTE_NM, EDW_CRTE_TS, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM, TOTAL_CALL_COUNT, out_REPORT_DT
FROM exp_AUDIT_COLS
)

SELECT
    SRC.EDW_CRTE_NM,
    SRC.EDW_CRTE_TS,
    SRC.EDW_LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_NM,
    SRC.TOTAL_CALL_COUNT,
    SRC.OUT_REPORT_DT AS REPORT_DT

FROM
    final_cte SRC
