{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_CALL_EVENTS"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1010C_CALL_EVENTS'),
        log_model_start(this, 'DP_CXN1010C_CALL_EVENTS')
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1010C_CALL_EVENTS'),
        log_model_end(this, 'DP_CXN1010C_CALL_EVENTS')
    ]
) }}

WITH 
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME= 'CALL_EVENTS' AND AUTOSYS_JOB_NAME = 'DP_CXN1010C_CALL_EVENTS')

, TARGET_MAX_KEY AS
(
    {% if is_incremental() %}

    SELECT
        COALESCE(MAX(CALL_EVENTS_ID), 0)::NUMBER(38,0)
            AS MAX_CALL_EVENTS_ID
    FROM {{ this }}

    {% else %}

    SELECT
        0::NUMBER(38,0) AS MAX_CALL_EVENTS_ID

    {% endif %}
),

EVNT_CD AS
(
    SELECT
        CALLS_ID,
        CALL_ID,
        COMPANY_ID,
        LTRIM(
            REGEXP_SUBSTR(
                CTI_FIELDS,
                'eventCD:[^|]+'
            ),
            'eventCD:'
        ) AS EVENT_CD
    FROM {{ source('UTLDB01_CXNADM', 'CALLS') }}
    WHERE EDW_LAST_UPDT_TS >=(SELECT START_DATE FROM JOB_CONTROL)
),

TEMP1 AS
(
    SELECT
        CALLS_ID,
        REGEXP_REPLACE(
            EVENT_CD,
            '[a-z]',
            ''
        ) AS EVENT_CD
    FROM EVNT_CD
),

TEMP2 AS
(
    SELECT
        T1.CALLS_ID,
        TRIM(F.VALUE::STRING) AS EVENT_CD,
        F.INDEX + 1 AS ROW_NUM
    FROM TEMP1 T1,
    LATERAL FLATTEN(
        INPUT => SPLIT(T1.EVENT_CD, ',')
    ) F
    -- SPLIT on a trailing comma, or on an eventCD that was all lowercase and
    -- so erased by the REGEXP_REPLACE above, yields an empty token. That token
    -- is not an event code: it reaches a NUMBER(38,0) column both at the join
    -- below and at the final cast, and Snowflake raises 100038 on it. Dropping
    -- it here matches the session rejecting the row and carrying on.
    WHERE TRY_TO_NUMBER(TRIM(F.VALUE::STRING)) IS NOT NULL
),

TEMP3 AS
(
    SELECT
        CED.CALL_EVENT_D_ID,
        TMP.EVENT_CD,
        TMP.CALLS_ID,
        TMP.ROW_NUM
    FROM TEMP2 TMP
    LEFT JOIN {{ source('UTLDB01_CDWADM', 'CALL_EVENT_D') }} CED
        ON CED.CALL_EVENT_CD = TMP.EVENT_CD
),

SQ_CALL_EVENTS AS
(
    SELECT
        T3.CALLS_ID,
        T3.CALL_EVENT_D_ID AS CALL_EVENT_ID,
        T3.EVENT_CD AS CALL_EVENT_CD,
        T3.ROW_NUM
    FROM TEMP3 T3

    {% if is_incremental() %}

    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM {{ this }} CE
        WHERE T3.CALLS_ID = CE.CALLS_ID
    )

    {% endif %}
),

EXP_AUDIT AS
(
    SELECT
        SQ.CALLS_ID,
        SQ.CALL_EVENT_ID,
        SQ.CALL_EVENT_CD,
        SQ.ROW_NUM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,
        's_m_CALL_EVENTS'::VARCHAR(50)
            AS EDW_CRTE_NM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,
        's_m_CALL_EVENTS'::VARCHAR(50)
            AS EDW_LAST_UPDT_NM
    FROM SQ_CALL_EVENTS SQ
),

NUMBERED_SOURCE_ROWS AS
(
    SELECT
        CALLS_ID,
        CALL_EVENT_ID,
        CALL_EVENT_CD,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM,
        ROW_NUMBER() OVER
        (
            ORDER BY
                CALLS_ID,
                ROW_NUM,
                CALL_EVENT_CD
        ) AS INSERT_ROW_NUMBER
    FROM EXP_AUDIT
),

SOURCE_ROWS AS
(
    SELECT
        (
            TMK.MAX_CALL_EVENTS_ID
            + NSR.INSERT_ROW_NUMBER
        )::NUMBER(38,0) AS CALL_EVENTS_ID,

        NSR.CALLS_ID::NUMBER(38,0)
            AS CALLS_ID,

        NSR.CALL_EVENT_ID::NUMBER(38,0)
            AS CALL_EVENT_ID,

        NSR.CALL_EVENT_CD::NUMBER(38,0)
            AS CALL_EVENT_CD,

        NSR.EDW_CRTE_TS
            AS EDW_CRTE_TS,

        NSR.EDW_CRTE_NM
            AS EDW_CRTE_NM,

        NSR.EDW_LAST_UPDT_TS
            AS EDW_LAST_UPDT_TS,

        NSR.EDW_LAST_UPDT_NM
            AS EDW_LAST_UPDT_NM

    FROM NUMBERED_SOURCE_ROWS NSR
    CROSS JOIN TARGET_MAX_KEY TMK
)

SELECT
    CALL_EVENTS_ID,
    CALLS_ID,
    CALL_EVENT_ID,
    CALL_EVENT_CD,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM
FROM SOURCE_ROWS