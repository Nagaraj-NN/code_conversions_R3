-- ===========================================================================
-- Model      : GROUP_STG
-- Mapping    : m_GROUP_STG
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.GROUP_STG
-- Load type  : incremental / append (truncate + reload)
-- ---------------------------------------------------------------------------
-- Stages the Genesys GROUP_ configuration table (group / tenant keys,
-- name, type, cfg dbid and validity timestamps) and builds the MD5
-- checksum over every business column for downstream change capture.
-- Truncate-and-reload staging table.
-- ===========================================================================

{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_GROUP_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_GROUP_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_GROUP_STG')
    ]
) }}

WITH
SQ_GROUP_ AS (
  SELECT
    GROUP_KEY,
    TENANT_KEY,
    GROUP_NAME,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY,
    GROUP_TYPE,
    GROUP_TYPE_CODE,
    GROUP_CFG_DBID,
    GROUP_CFG_TYPE_ID,
    START_TS,
    END_TS
  -- FROM GROUP_   -- Genesys SQL Server source, not reachable from Snowflake
  FROM {{ source('BRONZE_CALL_CENTER','GROUP_') }} --USED FOR TESTING
  -- REJECT: CXNADM.GROUP_STG.GROUP_KEY is NOT NULL. Informatica wrote a
  -- NULL-key row to the bad file and let the session continue; Snowflake
  -- aborts the whole INSERT instead ("NULL result in a non-nullable
  -- column"), so the reject is applied here in the SELECT.
  WHERE GROUP_KEY IS NOT NULL
),

exp_AUDIT_GROUP_STG_step1 AS (
  SELECT
    SQ_GROUP_.*,
    MD5(COALESCE(CAST(IFF((GROUP_KEY IS NULL), '@#$', TO_VARCHAR(GROUP_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((TENANT_KEY IS NULL), '@#$', TO_VARCHAR(TENANT_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((GROUP_NAME IS NULL), '@#$', TO_VARCHAR(GROUP_NAME)) AS VARCHAR), '') || COALESCE(CAST(IFF((CREATE_AUDIT_KEY IS NULL), '@#$', TO_VARCHAR(CREATE_AUDIT_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((UPDATE_AUDIT_KEY IS NULL), '@#$', TO_VARCHAR(UPDATE_AUDIT_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((GROUP_TYPE IS NULL), '@#$', TO_VARCHAR(GROUP_TYPE)) AS VARCHAR), '') || COALESCE(CAST(IFF((GROUP_TYPE_CODE IS NULL), '@#$', TO_VARCHAR(GROUP_TYPE_CODE)) AS VARCHAR), '') || COALESCE(CAST(IFF((GROUP_CFG_DBID IS NULL), '@#$', TO_VARCHAR(GROUP_CFG_DBID)) AS VARCHAR), '') || COALESCE(CAST(IFF((GROUP_CFG_TYPE_ID IS NULL), '@#$', TO_VARCHAR(GROUP_CFG_TYPE_ID)) AS VARCHAR), '') || COALESCE(CAST(IFF((START_TS IS NULL), '@#$', TO_VARCHAR(START_TS)) AS VARCHAR), '') || COALESCE(CAST(IFF((END_TS IS NULL), '@#$', TO_VARCHAR(END_TS)) AS VARCHAR), '')) AS v_MD5_CHECKSUM_VALUE,
    CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
    's_m_GROUP_STG' AS out_EDW_CRTE_NM,
    CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
    's_m_GROUP_STG' AS out_EDW_LAST_UPDT_NM
  FROM SQ_GROUP_
),

exp_AUDIT_GROUP_STG AS (
  SELECT
    exp_AUDIT_GROUP_STG_step1.*,
    v_MD5_CHECKSUM_VALUE AS out_MD5_CHECKSUM_VALUE
  FROM exp_AUDIT_GROUP_STG_step1
)
,

final_cte AS (
SELECT
  GROUP_KEY, TENANT_KEY, GROUP_NAME, CREATE_AUDIT_KEY, UPDATE_AUDIT_KEY, GROUP_TYPE, GROUP_TYPE_CODE, GROUP_CFG_DBID, GROUP_CFG_TYPE_ID, START_TS, END_TS, out_MD5_CHECKSUM_VALUE, out_EDW_CRTE_TS, out_EDW_CRTE_NM, out_EDW_LAST_UPDT_TS, out_EDW_LAST_UPDT_NM
FROM exp_AUDIT_GROUP_STG
)

SELECT
    SRC.GROUP_KEY,
    SRC.TENANT_KEY,
    SRC.GROUP_NAME,
    SRC.CREATE_AUDIT_KEY,
    SRC.UPDATE_AUDIT_KEY,
    SRC.GROUP_TYPE,
    SRC.GROUP_TYPE_CODE,
    SRC.GROUP_CFG_DBID,
    SRC.GROUP_CFG_TYPE_ID,
    SRC.START_TS,
    SRC.END_TS,
    SRC.OUT_MD5_CHECKSUM_VALUE AS MD5_CHECKSUM_VAL,
    SRC.OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC