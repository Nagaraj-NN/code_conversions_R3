-- ===========================================================================
-- Model      : CALLCENTER_STG
-- Mapping    : m_CALLCENTER_STG
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.CALLCENTER_STG
-- Load type  : incremental / append (truncate + reload)
-- ---------------------------------------------------------------------------
-- Stages the Genesys call-center configuration list (id + name) and
-- computes MD5(CALLCENTERNAME) as the change-detection checksum used
-- downstream by ODS_CALLCENTER and CALLCTR_AGENCY_D.
-- Truncate-and-reload staging table.
-- ===========================================================================

{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_CALLCENTER_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1004C_CALLCENTER_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1004C_CALLCENTER_STG')
    ]
) }}

WITH SQ_CALLCENTER AS
(
    SELECT
        CALLCENTERID,
        CALLCENTERNAME
    FROM {{ source('BRONZE_CALL_CENTER','CALLCENTER') }}
),

EXP_AUDIT AS
(
    SELECT
        CALLCENTERID,
        CALLCENTERNAME,
        CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
        's_m_CALLCENTER_STG' AS EDW_CRTE_NM,
       CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
        's_m_CALLCENTER_STG' AS EDW_LAST_UPDT_NM,
        MD5(CALLCENTERNAME) AS MD5_CHECKSUM_VAL
    FROM SQ_CALLCENTER
)
,

final_cte AS (
SELECT
    CALLCENTERID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    CALLCENTERNAME,
    MD5_CHECKSUM_VAL
FROM EXP_AUDIT
)

SELECT
    SRC.CALLCENTERID,
    SRC.EDW_CRTE_TS,
    SRC.EDW_CRTE_NM,
    SRC.EDW_LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_NM,
    SRC.CALLCENTERNAME,
    SRC.MD5_CHECKSUM_VAL

FROM
    final_cte SRC
