-- ===========================================================================
-- Model      : MEDIA_TYPE_STG
-- Mapping    : m_MEDIA_TYPE_STG
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.MEDIA_TYPE_STG
-- Load type  : incremental / append (truncate + reload)
-- ---------------------------------------------------------------------------
-- Stages the Genesys media type configuration. Rows are picked up when
-- either their create or their update audit key was written inside the
-- run window (UNION of the two joins to the audit log), then stamped
-- with the EDW audit columns. Truncate-and-reload staging table.
-- NOTE: ${START_TIME}/${END_TIME} resolved from METADATA.CXNADM_JOB_CONTROL;
-- NOTE: SQL Server CONVERT(DATETIME, ...) replaced by the control dates.
-- ===========================================================================

{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_MEDIA_TYPE_STG"},
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN0001C_MEDIA_TYPE_STG'),
        log_model_start(this, 'DP_CXN0001C_MEDIA_TYPE_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN0001C_MEDIA_TYPE_STG'),
        log_model_end(this, 'DP_CXN0001C_MEDIA_TYPE_STG')
    ]
) }}

WITH
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE
    FROM {{ source('UTLDB01_METADATA','CXNADM_JOB_CONTROL') }}
    WHERE JOB_NAME = 'MEDIA_TYPE_STG' AND AUTOSYS_JOB_NAME = 'DP_CXN0001C_MEDIA_TYPE_STG'
),
 SQ_MEDIA_TYPE AS (
  WITH RES1 AS (
    select
      MT."media_type_key"   AS MEDIA_TYPE_KEY,
      MT."media_name"       AS MEDIA_NAME,
      MT."media_name_code"  AS MEDIA_NAME_CODE,
      MT."is_online"        AS IS_ONLINE,
      MT."create_audit_key" AS CREATE_AUDIT_KEY,
      MT."update_audit_key" AS UPDATE_AUDIT_KEY,
      AL.AUDIT_KEY          AS AUDIT_KEY,
      AL.CREATED            AS CREATED
    from
      {{ source('BRONZE_CALL_CENTER','MEDIA_TYPE') }} MT
      -- UTLDB01_DEV_SANDBOX.COMMON.MEDIA_TYPE_TEST MT
      inner join {{ source('BRONZE_CALL_CENTER','CTL_AUDIT_LOG') }} AL on MT."create_audit_key" = AL.AUDIT_KEY
      -- inner join UTLDB01_DEV_SANDBOX.COMMON.CTL_AUDIT_LOG AL on MT.CREATE_AUDIT_KEY = AL.AUDIT_KEY
    UNION
    Select
      MT."media_type_key"   AS MEDIA_TYPE_KEY,
      MT."media_name"       AS MEDIA_NAME,
      MT."media_name_code"  AS MEDIA_NAME_CODE,
      MT."is_online"        AS IS_ONLINE,
      MT."create_audit_key" AS CREATE_AUDIT_KEY,
      MT."update_audit_key" AS UPDATE_AUDIT_KEY,
      AL.AUDIT_KEY          AS AUDIT_KEY,
      AL.CREATED            AS CREATED
    from
      {{ source('BRONZE_CALL_CENTER','MEDIA_TYPE') }} MT
      inner join {{ source('BRONZE_CALL_CENTER','CTL_AUDIT_LOG') }} AL on MT."update_audit_key" = AL.AUDIT_KEY
  )
  SELECT
    MEDIA_TYPE_KEY,
    MEDIA_NAME,
    MEDIA_NAME_CODE,
    IS_ONLINE,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY
  from
    RES1
  where
    CREATED > (SELECT START_DATE FROM JOB_CONTROL)
    AND CREATED <= (SELECT END_DATE FROM JOB_CONTROL)
),

exp_AUDIT_MEDIA_TYPE_STG AS (
  SELECT
    SQ_MEDIA_TYPE.*,
    CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
    's_m_MEDIA_TYPE_STG' AS out_EDW_CRTE_NM,
    CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
    's_m_MEDIA_TYPE_STG' AS out_EDW_LAST_UPDT_NM
  FROM SQ_MEDIA_TYPE
)
,

final_cte AS (
SELECT
  MEDIA_TYPE_KEY, MEDIA_NAME, MEDIA_NAME_CODE, IS_ONLINE, CREATE_AUDIT_KEY, UPDATE_AUDIT_KEY, out_EDW_CRTE_TS, out_EDW_CRTE_NM, out_EDW_LAST_UPDT_TS, out_EDW_LAST_UPDT_NM
FROM exp_AUDIT_MEDIA_TYPE_STG
)

SELECT
    SRC.MEDIA_TYPE_KEY,
    SRC.MEDIA_NAME,
    SRC.MEDIA_NAME_CODE,
    SRC.IS_ONLINE,
    SRC.CREATE_AUDIT_KEY,
    SRC.UPDATE_AUDIT_KEY,
    SRC.OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC