-- =========================================================================
-- Model      : RESOURCE_GROUP_COMBINATION_STG
-- Mapping    : m_RESOURCE_GROUP_COMBINATION_STG
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.RESOURCE_GROUP_COMBINATION_STG
-- Load type  : incremental / append (truncate + reload)
-- -------------------------------------------------------------------------
-- Stages the resource/group combination reference data and computes the
-- MD5 checksum over the five business columns that the downstream ODS
-- merge compares against. Truncate-and-reload staging table.
-- =========================================================================

{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_RESOURCE_GROUP_COMBINATION_STG"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_RESOURCE_GROUP_COMBINATION_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_RESOURCE_GROUP_COMBINATION_STG')
    ]
) }}

WITH
SQ_RESOURCE_GROUP_COMBINATION_ AS (
  SELECT
    GROUP_COMBINATION_KEY,
    GROUP_KEY,
    TENANT_KEY,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY
  FROM {{ source('BRONZE_CALL_CENTER','RESOURCE_GROUP_COMBINATION') }}
  -- FROM UTLDB01_DEV_SANDBOX.COMMON.RESOURCE_GROUP_COMBINATION_TEST
  -- REJECT: CXNADM.RESOURCE_GROUP_COMBINATION_STG.GROUP_COMBINATION_KEY is
  -- NOT NULL. Informatica wrote a NULL-key row to the bad file and let the
  -- session continue; Snowflake aborts the whole INSERT instead ("NULL
  -- result in a non-nullable column"), so the reject is applied here.
  WHERE GROUP_COMBINATION_KEY IS NOT NULL
),

exp_AUDIT_RESOURCE_GROUP_COMBINATION_STG_step1 AS (
  SELECT
    SQ_RESOURCE_GROUP_COMBINATION_.*,
    MD5(COALESCE(CAST(IFF((GROUP_COMBINATION_KEY IS NULL), '@#$', TO_VARCHAR(GROUP_COMBINATION_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((GROUP_KEY IS NULL), '@#$', TO_VARCHAR(GROUP_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((TENANT_KEY IS NULL), '@#$', TO_VARCHAR(TENANT_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((CREATE_AUDIT_KEY IS NULL), '@#$', TO_VARCHAR(CREATE_AUDIT_KEY)) AS VARCHAR), '') || COALESCE(CAST(IFF((UPDATE_AUDIT_KEY IS NULL), '@#$', TO_VARCHAR(UPDATE_AUDIT_KEY)) AS VARCHAR), '')) AS V_MD5_CHECKSUM_VALUE,
    CURRENT_TIMESTAMP() AS OUT_EDW_CRTE_TS,
    's_m_RESOURCE_GROUP_COMBINATION_STG' AS OUT_EDW_CRTE_NM,
    CURRENT_TIMESTAMP() AS OUT_EDW_LAST_UPDT_TS,
    's_m_RESOURCE_GROUP_COMBINATION_STG' AS OUT_EDW_LAST_UPDT_NM
  FROM SQ_RESOURCE_GROUP_COMBINATION_
),

exp_AUDIT_RESOURCE_GROUP_COMBINATION_STG AS (
  SELECT
    exp_AUDIT_RESOURCE_GROUP_COMBINATION_STG_step1.*,
    V_MD5_CHECKSUM_VALUE AS OUT_MD5_CHECKSUM_VALUE
  FROM exp_AUDIT_RESOURCE_GROUP_COMBINATION_STG_step1
),

final_cte AS (
SELECT
  GROUP_COMBINATION_KEY, GROUP_KEY, TENANT_KEY, CREATE_AUDIT_KEY, UPDATE_AUDIT_KEY, OUT_MD5_CHECKSUM_VALUE, OUT_EDW_CRTE_TS, OUT_EDW_CRTE_NM, OUT_EDW_LAST_UPDT_TS, OUT_EDW_LAST_UPDT_NM
FROM exp_AUDIT_RESOURCE_GROUP_COMBINATION_STG
)

SELECT
    SRC.GROUP_COMBINATION_KEY,
    SRC.GROUP_KEY,
    SRC.TENANT_KEY,
    SRC.CREATE_AUDIT_KEY,
    SRC.UPDATE_AUDIT_KEY,
    SRC.OUT_MD5_CHECKSUM_VALUE AS MD5_CHECKSUM_VAL,
    SRC.OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC