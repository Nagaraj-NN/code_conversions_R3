{{ config(
    materialized='incremental',
    incremental_strategy='append',
    full_refresh=false,
    meta={"mapping_name": "m_KPI_METRIC_F_STG_INS_AGT"},
    pre_hook=[
        open_control_window(this, 'DP_CXN1016C_KPI_METRIC_F_AGT_STG'),
        log_model_start(this, 'DP_CXN1016C_KPI_METRIC_F_AGT_STG'),
        "TRUNCATE TABLE IF EXISTS {{ this }}"
    ],
    post_hook=[
         update_control_table(this, 'DP_CXN1016C_KPI_METRIC_F_AGT_STG'),
        log_model_end(this, 'DP_CXN1016C_KPI_METRIC_F_AGT_STG')
    ]
) }}

WITH
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME = 'KPI_METRIC_F_STG' AND AUTOSYS_JOB_NAME = 'DP_CXN1016C_KPI_METRIC_F_AGT_STG'
),
SESSION_01_AGT_IN_OFF AS
(
    WITH AGT_IN_OFF AS
    (
        SELECT (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
               LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
               'AGT-IN-OFF' AS KPI_METRIC_CD,
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Account_Number",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:LiveAgent%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "LiveAgent",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:AMP_Budget%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "AMP_Budget",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('452159' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%452056%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('452160' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%452056%' THEN 1 ELSE 0 END) AS "Make a Payment",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('452161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%452056%' THEN 1 ELSE 0 END) AS "Payment Extension",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('452161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%452056%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' AND COALESCE(SUBSTR(CTI_FIELDS, 1, NULLIF(POSITION('452161' IN CTI_FIELDS), 0) - 1), CTI_FIELDS) LIKE '%452056%' THEN 1 ELSE 0 END) AS "Payment Assistance",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Choice%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Choice",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Commercial%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Commercial",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Hazard%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Hazard",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Orders%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Orders",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Outage%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Outage",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Paperless_Autopay%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Paperless_AutoPay",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:StartStopService%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "StartStopService",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:StartService%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "StartService",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:StopService%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "StopService",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:TransferService%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "TransferService",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Trees%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Trees",
            SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:SomethingElse%' AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "SomethingElse",
            SUM(CASE WHEN LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') IS NULL AND CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END) AS "Unidentified"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE START_SITE_NAME = 'ivr_main' AND IS_TEST_CALL = 0
          AND CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM AGT_IN_OFF
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account_Number",
                "LiveAgent",
                "AMP_Budget",
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance",
                "Choice",
                "Commercial",
                "Hazard",
                "Orders",
                "Outage",
                "Paperless_AutoPay",
                "StartStopService",
                "StartService",
                "StopService",
                "TransferService",
                "Trees",
                "SomethingElse",
                "Unidentified"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_AGT_IN_OFF' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_AGT_IN_OFF' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_02_AGT_RPT_AST_DIF AS
(
    WITH IVR_C_BASE AS
    (
        SELECT LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
               CALL_START_TIME, CASE
                WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 'Account_Number'
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
               CASE WHEN CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END AS IVR_AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))   --$REPORT_DATE
		AND (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND START_SITE_NAME = 'ivr_main' AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_C AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, MIN(CALL_START_TIME) AS MIN_C_CALL_START_TIME
        FROM IVR_C_BASE WHERE IVR_AGENT_TRANSFER = 1 GROUP BY ACCOUNT_NUMBER, INTENT
    ), AGENT_TRANSFER_BASE AS
    (
        SELECT LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
               CALL_START_TIME, CASE
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070,%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071,%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070,%' AND CTI_FIELDS NOT LIKE '%442071,%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432070,%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432071,%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%432070,%' AND CTI_FIELDS NOT LIKE '%432071,%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' AND CTI_FIELDS LIKE '%452197,%' THEN 'Account_Number'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070,%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071,%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070,%' AND CTI_FIELDS NOT LIKE '%452071,%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
               CASE WHEN CTI_FIELDS LIKE '%442153%' THEN 1 WHEN CTI_FIELDS LIKE '%432153%' THEN 1 WHEN CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END AS AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL) AND IS_TEST_CALL = 0  --$REPORT_DATE
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_CS AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, CALL_START_TIME FROM AGENT_TRANSFER_BASE WHERE AGENT_TRANSFER = 1
    ), CS_C_M AS
    (
        SELECT ONLY_C.ACCOUNT_NUMBER, LPAD(ONLY_C.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY, ONLY_C.INTENT,
               ONLY_C.MIN_C_CALL_START_TIME, ONLY_CS.CALL_START_TIME AS CS_CALL_START_TIME,
               DATEDIFF(SECOND, TO_TIMESTAMP_NTZ(SUBSTR(ONLY_C.MIN_C_CALL_START_TIME,1,19),'YYYY-MM-DD HH24:MI:SS'),
                       TO_TIMESTAMP_NTZ(SUBSTR(ONLY_CS.CALL_START_TIME,1,19),'YYYY-MM-DD HH24:MI:SS')) / 3600.0 AS DIFF
        FROM ONLY_C LEFT JOIN ONLY_CS ON ONLY_C.ACCOUNT_NUMBER = ONLY_CS.ACCOUNT_NUMBER
        WHERE ONLY_CS.CALL_START_TIME IS NOT NULL AND ONLY_C.INTENT <> ONLY_CS.INTENT
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT, OPERATING_COMPANY AS COMPANY_ID, 'AGT-RPT-AST-DIF' AS KPI_METRIC_CD,  --$REPORT_DATE
               INTENT AS CALL_INTENT_GROUP, COUNT(*) AS KPI_METRIC_VAL
        FROM CS_C_M WHERE DIFF BETWEEN 0.001 AND 72 GROUP BY OPERATING_COMPANY, INTENT
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_AGT_RPT_AST_DIF' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_AGT_RPT_AST_DIF' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_03_AGT_RPT_AST_SAME AS
(
    WITH IVR_C_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 'Account_Number'
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
            CASE WHEN CTI_FIELDS LIKE '%452056%' THEN 1 ELSE 0 END AS IVR_AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)) AND   --$REPORT_DATE
		(SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND START_SITE_NAME = 'ivr_main'
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_C AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            MIN(CALL_START_TIME) AS MIN_C_CALL_START_TIME
        FROM IVR_C_BASE
        WHERE IVR_AGENT_TRANSFER = 1
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), AGENT_TRANSFER_BASE AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442070,%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%442071,%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%442070,%' AND CTI_FIELDS NOT LIKE '%442071,%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432070,%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%432071,%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%432070,%' AND CTI_FIELDS NOT LIKE '%432071,%' THEN 'Payment Assistance'
                WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' AND CTI_FIELDS LIKE '%452197,%' THEN 'Account_Number'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070,%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071,%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070,%' AND CTI_FIELDS NOT LIKE '%452071,%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT,
            CASE
                WHEN CTI_FIELDS LIKE '%442153%' THEN 1
                WHEN CTI_FIELDS LIKE '%432153%' THEN 1
                WHEN CTI_FIELDS LIKE '%452056%' THEN 1
                ELSE 0
            END AS AGENT_TRANSFER
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE CALL_START_DATE = (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND IS_TEST_CALL = 0
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), ONLY_CS AS
    (
        SELECT ACCOUNT_NUMBER, INTENT, CALL_START_TIME
        FROM AGENT_TRANSFER_BASE
        WHERE AGENT_TRANSFER = 1
    ), CS_C_M AS
    (
        SELECT
            ONLY_C.ACCOUNT_NUMBER,
            LPAD(ONLY_C.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            ONLY_C.INTENT,
            ONLY_C.MIN_C_CALL_START_TIME,
            ONLY_CS.CALL_START_TIME AS CS_CALL_START_TIME,
            DATEDIFF(
                SECOND,
                TO_TIMESTAMP_NTZ(SUBSTR(ONLY_C.MIN_C_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'),
                TO_TIMESTAMP_NTZ(SUBSTR(ONLY_CS.CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')
            ) / 3600.0 AS DIFF
        FROM ONLY_C
        LEFT JOIN ONLY_CS
          ON ONLY_C.ACCOUNT_NUMBER = ONLY_CS.ACCOUNT_NUMBER
        WHERE ONLY_CS.CALL_START_TIME IS NOT NULL
          AND ONLY_C.INTENT = ONLY_CS.INTENT
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'AGT-RPT-AST-SAME' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM CS_C_M
        WHERE DIFF BETWEEN 0.001 AND 72
        GROUP BY OPERATING_COMPANY, INTENT
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_AGT_RPT_AST_SAME' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_AGT_RPT_AST_SAME' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_04_AGT_FCOR AS
(
    WITH BASE_CALLS AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_DATE,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 'Account_Number'
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND (CTI_FIELDS LIKE '%452070%' OR CTI_FIELDS LIKE '%442070%' OR CTI_FIELDS LIKE '%432070%') THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND (CTI_FIELDS LIKE '%452071%' OR CTI_FIELDS LIKE '%442071%' OR CTI_FIELDS LIKE '%432071%') THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND (CTI_FIELDS NOT LIKE '%452070%' OR CTI_FIELDS NOT LIKE '%442070%' OR CTI_FIELDS NOT LIKE '%432070%' OR CTI_FIELDS NOT LIKE '%452071%' OR CTI_FIELDS NOT LIKE '%442071%' OR CTI_FIELDS NOT LIKE '%432071%') THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE IS_TEST_CALL = 0
          AND (CTI_FIELDS LIKE '%452056%' OR CTI_FIELDS LIKE '%432153%' OR CTI_FIELDS LIKE '%442153%')
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), TEMP1 AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            COUNT(*) AS REPEAT_CNT,
            MIN(CALL_START_TIME) AS F_CALL_START_TIME
        FROM BASE_CALLS
        WHERE CALL_START_DATE = DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
        GROUP BY ACCOUNT_NUMBER, INTENT
        HAVING COUNT(*) = 1
    ), TEMP2 AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            MAX(CALL_START_TIME) AS S_CALL_START_TIME
        FROM BASE_CALLS
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -6, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))   --$REPORT_DATE
		AND (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CALL_START_DATE <> DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), TEMP3 AS
    (
        SELECT
            TEMP1.ACCOUNT_NUMBER,
            LPAD(TEMP1.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            TEMP1.INTENT,
            TEMP1.F_CALL_START_TIME,
            TEMP2.S_CALL_START_TIME,
            ABS(
                DATEDIFF(
                    SECOND,
                    TO_TIMESTAMP_NTZ(SUBSTR(TEMP2.S_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'),
                    TO_TIMESTAMP_NTZ(SUBSTR(TEMP1.F_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')
                ) / 3600.0
            ) AS DIFF
        FROM TEMP1
        LEFT JOIN TEMP2
          ON TEMP1.ACCOUNT_NUMBER = TEMP2.ACCOUNT_NUMBER
         AND TEMP1.INTENT = TEMP2.INTENT
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'AGT-FCOR' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM TEMP3
        WHERE S_CALL_START_TIME IS NULL OR DIFF > 72
        GROUP BY OPERATING_COMPANY, INTENT
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_AGT_FCOR' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_AGT_FCOR' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_05_AGT_IN_FCR AS
(
    WITH SOURCE_AGG AS
    (
        SELECT (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
               LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
               'AGT-IN-FCR' AS KPI_METRIC_CD,
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 1 ELSE 0 END) AS "Account_Number",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 1 ELSE 0 END) AS "Payment Extension",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 1 ELSE 0 END) AS "Payment Arrangement",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE IS_TEST_CALL = 0
          AND CALL_START_DATE = DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
          AND CTI_FIELDS LIKE '%452056%'
          AND START_SITE_NAME = 'ivr_main'
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SOURCE_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account_Number",
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT, COMPANY_ID, KPI_METRIC_CD,
               KPI_METRIC_VAL, CALL_INTENT_GROUP, CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
               's_m_KPI_METRIC_F_STG_AGT_IN_FCR' AS EDW_CRTE_NM, CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
               's_m_KPI_METRIC_F_STG_AGT_IN_FCR' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_06_AGT_FCR AS
(
    WITH BASE_CALLS AS
    (
        SELECT
            LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') AS ACCOUNT_NUMBER,
            CALL_START_DATE,
            CALL_START_TIME,
            CASE
                WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 'Account_Number'
                WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS INTENT
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE IS_TEST_CALL = 0
          AND START_SITE_NAME = 'ivr_main'
          AND CTI_FIELDS LIKE '%452056%'
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
    ), TEMP1 AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            COUNT(*) AS REPEAT_CNT,
            MIN(CALL_START_TIME) AS F_CALL_START_TIME
        FROM BASE_CALLS
        WHERE CALL_START_DATE = DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
        GROUP BY ACCOUNT_NUMBER, INTENT
        HAVING COUNT(*) = 1
    ), TEMP2 AS
    (
        SELECT
            ACCOUNT_NUMBER,
            INTENT,
            MAX(CALL_START_TIME) AS S_CALL_START_TIME
        FROM BASE_CALLS
        WHERE CALL_START_DATE BETWEEN DATEADD(DAY, -6, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)) AND   --$REPORT_DATE
		(SELECT TO_DATE(END_DATE) FROM JOB_CONTROL)  --$REPORT_DATE
          AND CALL_START_DATE <> DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
        GROUP BY ACCOUNT_NUMBER, INTENT
    ), TEMP3 AS
    (
        SELECT
            TEMP1.ACCOUNT_NUMBER,
            LPAD(TEMP1.ACCOUNT_NUMBER, 2) AS OPERATING_COMPANY,
            TEMP1.INTENT,
            TEMP1.F_CALL_START_TIME,
            TEMP2.S_CALL_START_TIME,
            ABS(
                DATEDIFF(
                    SECOND,
                    TO_TIMESTAMP_NTZ(SUBSTR(TEMP2.S_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS'),
                    TO_TIMESTAMP_NTZ(SUBSTR(TEMP1.F_CALL_START_TIME, 1, 19), 'YYYY-MM-DD HH24:MI:SS')
                ) / 3600.0
            ) AS DIFF
        FROM TEMP1
        LEFT JOIN TEMP2
          ON TEMP1.ACCOUNT_NUMBER = TEMP2.ACCOUNT_NUMBER
         AND TEMP1.INTENT = TEMP2.INTENT
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT
            (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
            OPERATING_COMPANY AS COMPANY_ID,
            'AGT-FCR' AS KPI_METRIC_CD,
            INTENT AS CALL_INTENT_GROUP,
            COUNT(*) AS KPI_METRIC_VAL
        FROM TEMP3
        WHERE S_CALL_START_TIME IS NULL OR DIFF > 72
        GROUP BY OPERATING_COMPANY, INTENT
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_AGT_FCR' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_AGT_FCR' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT
        REPORT_DT,
        COMPANY_ID,
        KPI_METRIC_CD,
        KPI_METRIC_VAL,
        CALL_INTENT_GROUP,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS,
        EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_07_AGT_HD_IN AS
(
    WITH TEMP1 AS
    (
        SELECT I.MEDIA_SERVER_IXN_GUID, C.VOICE_PLATFORM_FULL_CALL_ID,
               LPAD(LTRIM(REGEXP_SUBSTR(C.CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
               CASE
                   WHEN C.CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 'Account_Number'
                   WHEN C.CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                   WHEN C.CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                   WHEN C.CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND C.CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                   WHEN C.CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND C.CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                   WHEN C.CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND C.CTI_FIELDS NOT LIKE '%452070%' AND C.CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                   WHEN REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(C.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1) IS NULL THEN 'Unidentified'
                   ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(C.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
               END AS CALL_INTENT_GROUP,
               IR.CUSTOMER_TALK_DURATION + IR.CUSTOMER_HOLD_DURATION + IR.CUSTOMER_ACW_DURATION AS HD
        FROM {{ source('UTLDB01_CUSADM','INTERACTION_FACT') }} I
        INNER JOIN {{ source('UTLDB01_CUSADM','INTERACTION_RESOURCE_FACT') }} IR
          ON I.INTERACTION_ID = IR.INTERACTION_ID AND I.START_DATE_TIME_KEY = IR.INTERACTION_SDT_KEY
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_GSYS_DATE_TIME') }} D ON IR.START_DATE_TIME_KEY = D.DATE_TIME_KEY
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_MEDIA_TYPE') }} M ON IR.MEDIA_TYPE_KEY = M.MEDIA_TYPE_KEY
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_INTERACTION_TYPE') }} T ON IR.INTERACTION_TYPE_KEY = T.INTERACTION_TYPE_KEY
        INNER JOIN {{ source('UTLDB01_CUSADM','RESOURCE_') }} R ON R.RESOURCE_KEY = IR.RESOURCE_KEY
        LEFT JOIN {{ source('UTLDB01_CUSADM','IRF_USER_DATA_CUST_1') }} U ON U.INTERACTION_RESOURCE_ID = IR.INTERACTION_RESOURCE_ID
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }} C ON I.MEDIA_SERVER_IXN_GUID = C.VOICE_PLATFORM_FULL_CALL_ID
        WHERE D.LABEL_YYYY_MM_DD = (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL)  --$REPORT_DATE
          AND R.RESOURCE_TYPE_CODE = 'AGENT'
          AND R.RESOURCE_SUBTYPE = 'Agent'
          AND M.MEDIA_NAME = 'Voice'
          AND T.INTERACTION_TYPE = 'Inbound'
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT, COMPANY_ID, 'AGT-HD-IN' AS KPI_METRIC_CD,  --$REPORT_DATE
               CALL_INTENT_GROUP, SUM(HD) AS KPI_METRIC_VAL
        FROM TEMP1
        GROUP BY COMPANY_ID, CALL_INTENT_GROUP
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT, COMPANY_ID, KPI_METRIC_CD,
               KPI_METRIC_VAL, CALL_INTENT_GROUP, CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
               's_m_KPI_METRIC_F_STG_AGT_HD_IN' AS EDW_CRTE_NM, CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
               's_m_KPI_METRIC_F_STG_AGT_HD_IN' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_08_AGT_IN AS
(
    WITH TEMP1 AS
    (
        SELECT
            I.MEDIA_SERVER_IXN_GUID,
            C.VOICE_PLATFORM_FULL_CALL_ID,
            LPAD(LTRIM(REGEXP_SUBSTR(C.CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
            CASE
                WHEN C.CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 'Account_Number'
                WHEN C.CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 'Make a Payment'
                WHEN C.CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 'Account Balance & Details'
                WHEN C.CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND C.CTI_FIELDS LIKE '%452070%' THEN 'Payment Extension'
                WHEN C.CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND C.CTI_FIELDS LIKE '%452071%' THEN 'Payment Arrangement'
                WHEN C.CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND C.CTI_FIELDS NOT LIKE '%452070%' AND C.CTI_FIELDS NOT LIKE '%452071%' THEN 'Payment Assistance'
                WHEN REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(C.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1) IS NULL THEN 'Unidentified'
                ELSE REGEXP_SUBSTR(LTRIM(REGEXP_SUBSTR(C.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:'), '[^,]+[^,]', 1, 1)
            END AS CALL_INTENT_GROUP,
            IR.CUSTOMER_TALK_DURATION + IR.CUSTOMER_HOLD_DURATION + IR.CUSTOMER_ACW_DURATION AS HD
        FROM {{ source('UTLDB01_CUSADM','INTERACTION_FACT') }} I
        INNER JOIN {{ source('UTLDB01_CUSADM','INTERACTION_RESOURCE_FACT') }} IR
          ON I.INTERACTION_ID = IR.INTERACTION_ID
         AND I.START_DATE_TIME_KEY = IR.INTERACTION_SDT_KEY
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_GSYS_DATE_TIME') }} D
          ON IR.START_DATE_TIME_KEY = D.DATE_TIME_KEY
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_MEDIA_TYPE') }} M
          ON IR.MEDIA_TYPE_KEY = M.MEDIA_TYPE_KEY
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_INTERACTION_TYPE') }} T
          ON IR.INTERACTION_TYPE_KEY = T.INTERACTION_TYPE_KEY
        INNER JOIN {{ source('UTLDB01_CUSADM','RESOURCE_') }} R
          ON R.RESOURCE_KEY = IR.RESOURCE_KEY
        LEFT JOIN {{ source('UTLDB01_CUSADM','IRF_USER_DATA_CUST_1') }} U
          ON U.INTERACTION_RESOURCE_ID = IR.INTERACTION_RESOURCE_ID
        INNER JOIN {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }} C
          ON I.MEDIA_SERVER_IXN_GUID = C.VOICE_PLATFORM_FULL_CALL_ID
        WHERE D.LABEL_YYYY_MM_DD = (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL)  --$REPORT_DATE
          AND R.RESOURCE_TYPE_CODE = 'AGENT'
          AND R.RESOURCE_SUBTYPE = 'Agent'
          AND M.MEDIA_NAME = 'Voice'
          AND T.INTERACTION_TYPE = 'Inbound'
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT, COMPANY_ID, 'AGT-IN' AS KPI_METRIC_CD,  --$REPORT_DATE
               CALL_INTENT_GROUP, COUNT(*) AS KPI_METRIC_VAL
        FROM TEMP1
        GROUP BY COMPANY_ID, CALL_INTENT_GROUP
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT
            TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT,
            COMPANY_ID,
            KPI_METRIC_CD,
            KPI_METRIC_VAL,
            CALL_INTENT_GROUP,
            CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
            's_m_KPI_METRIC_F_STG_AGT_IN' AS EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
            's_m_KPI_METRIC_F_STG_AGT_IN' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

SESSION_09_AGT_IN_FCOR AS
(
    WITH SOURCE_AGG AS
    (
        SELECT (SELECT TO_CHAR(END_DATE, 'YYYY-MM-DD') FROM JOB_CONTROL) AS REPORT_DT,  --$REPORT_DATE
               LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2) AS COMPANY_ID,
               'AGT-IN-FCOR' AS KPI_METRIC_CD,
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:Account_Number%' THEN 1 ELSE 0 END) AS "Account_Number",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:CheckAccountBalanceDueDate%' THEN 1 ELSE 0 END) AS "Account Balance & Details",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:MakeAPayment%' THEN 1 ELSE 0 END) AS "Make a Payment",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND (CTI_FIELDS LIKE '%452070%' OR CTI_FIELDS LIKE '%442070%' OR CTI_FIELDS LIKE '%432070%') THEN 1 ELSE 0 END) AS "Payment Extension",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND (CTI_FIELDS LIKE '%452071%' OR CTI_FIELDS LIKE '%442071%' OR CTI_FIELDS LIKE '%432071%') THEN 1 ELSE 0 END) AS "Payment Arrangement",
               SUM(CASE WHEN CTI_FIELDS LIKE '%intent_list:PaymentAssistance%' AND CTI_FIELDS NOT LIKE '%452070%' AND CTI_FIELDS NOT LIKE '%442070%' AND CTI_FIELDS NOT LIKE '%432070%' AND CTI_FIELDS NOT LIKE '%452071%' AND CTI_FIELDS NOT LIKE '%442071%' AND CTI_FIELDS NOT LIKE '%432071%' THEN 1 ELSE 0 END) AS "Payment Assistance"
        FROM {{ source('UTLDB01_CXNADM','ODS_VW_CALLS') }}
        WHERE IS_TEST_CALL = 0
          AND CALL_START_DATE = DATEADD(DAY, -3, (SELECT TO_DATE(END_DATE) FROM JOB_CONTROL))  --$REPORT_DATE
          AND (CTI_FIELDS LIKE '%452056%' OR CTI_FIELDS LIKE '%432153%' OR CTI_FIELDS LIKE '%442153%')
          AND LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:') IS NOT NULL
        GROUP BY LPAD(LTRIM(REGEXP_SUBSTR(CTI_FIELDS, 'var_AccountNumber:[^|]+'), 'var_AccountNumber:'), 2)
    ), SQ_KPI_METRIC_F_CUSTOM_STG_SRC AS
    (
        SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, CALL_INTENT_GROUP, KPI_METRIC_VAL
        FROM SOURCE_AGG
        UNPIVOT
        (
            KPI_METRIC_VAL FOR CALL_INTENT_GROUP IN
            (
                "Account_Number",
                "Account Balance & Details",
                "Make a Payment",
                "Payment Extension",
                "Payment Arrangement",
                "Payment Assistance"
            )
        )
    ), EXP_AUDIT_KPI_METRIC_F_STG AS
    (
        SELECT TO_DATE(REPORT_DT, 'YYYY-MM-DD') AS REPORT_DT, COMPANY_ID, KPI_METRIC_CD,
               KPI_METRIC_VAL, CALL_INTENT_GROUP, CURRENT_TIMESTAMP() AS EDW_CRTE_TS,
               's_m_KPI_METRIC_F_STG_AGT_IN_FCOR' AS EDW_CRTE_NM, CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,
               's_m_KPI_METRIC_F_STG_AGT_IN_FCOR' AS EDW_LAST_UPDT_NM
        FROM SQ_KPI_METRIC_F_CUSTOM_STG_SRC
    )
    SELECT REPORT_DT, COMPANY_ID, KPI_METRIC_CD, KPI_METRIC_VAL, CALL_INTENT_GROUP,
           EDW_CRTE_TS, EDW_CRTE_NM, EDW_LAST_UPDT_TS, EDW_LAST_UPDT_NM
    FROM EXP_AUDIT_KPI_METRIC_F_STG
),

final_cte AS (
SELECT * FROM SESSION_01_AGT_IN_OFF
UNION ALL
SELECT * FROM SESSION_02_AGT_RPT_AST_DIF
UNION ALL
SELECT * FROM SESSION_03_AGT_RPT_AST_SAME
UNION ALL
SELECT * FROM SESSION_04_AGT_FCOR
UNION ALL
SELECT * FROM SESSION_05_AGT_IN_FCR
UNION ALL
SELECT * FROM SESSION_06_AGT_FCR
UNION ALL
SELECT * FROM SESSION_07_AGT_HD_IN
UNION ALL
SELECT * FROM SESSION_08_AGT_IN
UNION ALL
SELECT * FROM SESSION_09_AGT_IN_FCOR
)

SELECT
    SRC.REPORT_DT,
    SRC.COMPANY_ID,
    SRC.KPI_METRIC_CD,
    SRC.KPI_METRIC_VAL,
    SRC.CALL_INTENT_GROUP,
    SRC.EDW_CRTE_TS,
    SRC.EDW_CRTE_NM,
    SRC.EDW_LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_NM

FROM
    final_cte SRC