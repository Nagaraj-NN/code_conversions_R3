{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key=['DATE_TIME_KEY', 'GROUP_COMBINATION_KEY', 'RESOURCE_KEY', 'TENANT_KEY', 'MEDIA_TYPE_KEY'],
    merge_update_columns=[
        'ACTIVE_TIME',
        'READY_TIME',
        'NOT_READY_TIME',
        'BUSY_TIME',
        'WRAP_TIME',
        'ISREADY',
        'READY',
        'ISNOT_READY',
        'NOT_READY',
        'ISBUSY',
        'BUSY',
        'ISWRAP',
        'WRAP',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM'
    ],
    meta={"mapping_name": "m_ODS_AG2_I_SESS_STATE_DAY"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_ODS_AG2_I_SESS_STATE_DAY')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_ODS_AG2_I_SESS_STATE_DAY')
    ]
) }}

WITH SQ_AG2_I_SESS_STATE_DAY_STG AS
(
    SELECT
        SRC.DATE_TIME_KEY,
        SRC.GROUP_COMBINATION_KEY,
        SRC.RESOURCE_KEY,
        SRC.TENANT_KEY,
        SRC.MEDIA_TYPE_KEY,
        SRC.ACTIVE_TIME,
        SRC.READY_TIME,
        SRC.NOT_READY_TIME,
        SRC.BUSY_TIME,
        SRC.WRAP_TIME,
        SRC.ISREADY,
        SRC.READY,
        SRC.ISNOT_READY,
        SRC.NOT_READY,
        SRC.ISBUSY,
        SRC.BUSY,
        SRC.ISWRAP,
        SRC.WRAP,

        TGT.DATE_TIME_KEY         AS TGT_DATE_TIME_KEY,
        TGT.GROUP_COMBINATION_KEY AS TGT_GROUP_COMBINATION_KEY,
        TGT.RESOURCE_KEY          AS TGT_RESOURCE_KEY,
        TGT.TENANT_KEY            AS TGT_TENANT_KEY,
        TGT.MEDIA_TYPE_KEY        AS TGT_MEDIA_TYPE_KEY

    FROM {{ source('UTLDB01_CXNADM','AG2_I_SESS_STATE_DAY_STG') }} SRC

    LEFT OUTER JOIN
    {% if is_incremental() %}
    {{ this }} TGT
    {% else %}
    -- First run: the target table does not exist yet. Stand in a zero-row
    -- relation of the same shape so every SRC row sees TGT.* as NULL and is
    -- routed to the insert branch, which is what a first load must do.
    (
            SELECT
                NULL::NUMBER(10,0) AS DATE_TIME_KEY,
                NULL::NUMBER(10,0) AS GROUP_COMBINATION_KEY,
                NULL::NUMBER(10,0) AS MEDIA_TYPE_KEY,
                NULL::NUMBER(10,0) AS RESOURCE_KEY,
                NULL::NUMBER(10,0) AS TENANT_KEY
            FROM (SELECT 1 AS DUMMY) DUMMY_ROW
            WHERE 1 = 0
    ) TGT
    {% endif %}
    
        ON SRC.DATE_TIME_KEY = TGT.DATE_TIME_KEY
       AND SRC.GROUP_COMBINATION_KEY = TGT.GROUP_COMBINATION_KEY
       AND SRC.RESOURCE_KEY = TGT.RESOURCE_KEY
       AND SRC.TENANT_KEY = TGT.TENANT_KEY
       AND SRC.MEDIA_TYPE_KEY = TGT.MEDIA_TYPE_KEY
),

exp_AUDIT_ODS_AG2_I_SESS_STATE_DAY AS
(
    SELECT

        DATE_TIME_KEY,
        GROUP_COMBINATION_KEY,
        RESOURCE_KEY,
        TENANT_KEY,
        MEDIA_TYPE_KEY,

        ACTIVE_TIME,
        READY_TIME,
        NOT_READY_TIME,
        BUSY_TIME,
        WRAP_TIME,

        ISREADY,
        READY,
        ISNOT_READY,
        NOT_READY,
        ISBUSY,
        BUSY,
        ISWRAP,
        WRAP,

        TGT_DATE_TIME_KEY,
        TGT_GROUP_COMBINATION_KEY,
        TGT_RESOURCE_KEY,
        TGT_TENANT_KEY,
        TGT_MEDIA_TYPE_KEY,

        CURRENT_TIMESTAMP()             AS OUT_EDW_CRTE_TS,
        's_m_ODS_AG2_I_SESS_STATE_DAY'          AS OUT_EDW_CRTE_NM,

        CURRENT_TIMESTAMP()            AS OUT_EDW_LAST_UPDT_TS,
        's_m_ODS_AG2_I_SESS_STATE_DAY'          AS OUT_EDW_LAST_UPDT_NM,

        CASE
           WHEN DATE_TIME_KEY IS NOT NULL
            AND TGT_DATE_TIME_KEY IS NULL
           THEN 'I'

           WHEN DATE_TIME_KEY IS NOT NULL
            AND TGT_DATE_TIME_KEY IS NOT NULL
           THEN 'U'

           ELSE 'R'
        END AS OUT_RECORD_FLAG

    FROM SQ_AG2_I_SESS_STATE_DAY_STG
),

rtr_INS_UPD_INSERT AS
(
    SELECT *
    FROM exp_AUDIT_ODS_AG2_I_SESS_STATE_DAY
    WHERE OUT_RECORD_FLAG IN ('I', 'U')
),

rtr_INS_UPD_DEFAULT1 AS
(
    SELECT *
    FROM exp_AUDIT_ODS_AG2_I_SESS_STATE_DAY
    WHERE OUT_RECORD_FLAG = 'R'
),

upd_INSERT AS
(
    SELECT *
    FROM rtr_INS_UPD_INSERT
),

final_cte AS (
SELECT
    DATE_TIME_KEY,
    GROUP_COMBINATION_KEY,
    RESOURCE_KEY,
    TENANT_KEY,
    MEDIA_TYPE_KEY,
    ACTIVE_TIME,
    READY_TIME,
    NOT_READY_TIME,
    BUSY_TIME,
    WRAP_TIME,
    ISREADY,
    READY,
    ISNOT_READY,
    NOT_READY,
    ISBUSY,
    BUSY,
    ISWRAP,
    WRAP,
    OUT_EDW_CRTE_TS,
    OUT_EDW_CRTE_NM,
    OUT_EDW_LAST_UPDT_TS,
    OUT_EDW_LAST_UPDT_NM
FROM upd_INSERT
)

SELECT
    SRC.DATE_TIME_KEY,
    SRC.GROUP_COMBINATION_KEY,
    SRC.RESOURCE_KEY,
    SRC.TENANT_KEY,
    SRC.MEDIA_TYPE_KEY,
    SRC.ACTIVE_TIME,
    SRC.READY_TIME,
    SRC.NOT_READY_TIME,
    SRC.BUSY_TIME,
    SRC.WRAP_TIME,
    SRC.ISREADY,
    SRC.READY,
    SRC.ISNOT_READY,
    SRC.NOT_READY,
    SRC.ISBUSY,
    SRC.BUSY,
    SRC.ISWRAP,
    SRC.WRAP,
    SRC.OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY SRC.DATE_TIME_KEY, SRC.GROUP_COMBINATION_KEY, SRC.RESOURCE_KEY, SRC.TENANT_KEY, SRC.MEDIA_TYPE_KEY
    ORDER BY SRC.DATE_TIME_KEY, SRC.GROUP_COMBINATION_KEY, SRC.RESOURCE_KEY, SRC.TENANT_KEY, SRC.MEDIA_TYPE_KEY
) = 1