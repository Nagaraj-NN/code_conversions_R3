{{ config(
    materialized='view',
    alias='ODS_CALLCENTER_VW',
    meta={"mapping_name": "m_ODS_CALLCENTER"},
    pre_hook=[
        log_model_start(this, 'DP_CXN1004C_ODS_CALLCENTER')
    ],
    post_hook=[
        "MERGE INTO {{ source('UTLDB01_CXNADM','ODS_CALLCENTER') }} AS ODS_CALLCENTER
     USING {{ this }} AS SOURCE_ROWS
     ON ODS_CALLCENTER.ODS_CALLCENTER_ID = SOURCE_ROWS.ODS_CALLCENTER_ID
     WHEN MATCHED AND SOURCE_ROWS.TARGET_OPERATION = 'DD_UPDATE' THEN
         UPDATE SET
             ODS_CALLCENTER.EDW_LAST_UPDT_TS = SOURCE_ROWS.EDW_LAST_UPDT_TS,
             ODS_CALLCENTER.EDW_LAST_UPDT_NM = SOURCE_ROWS.EDW_LAST_UPDT_NM,
             ODS_CALLCENTER.CALLCENTERNAME = SOURCE_ROWS.CALLCENTERNAME,
             ODS_CALLCENTER.MD5_CHECKSUM_VAL = SOURCE_ROWS.MD5_CHECKSUM_VAL
     WHEN MATCHED AND SOURCE_ROWS.TARGET_OPERATION = 'DD_DELETE' THEN
         UPDATE SET
             ODS_CALLCENTER.EDW_LAST_UPDT_TS = SOURCE_ROWS.EDW_LAST_UPDT_TS,
             ODS_CALLCENTER.EDW_LAST_UPDT_NM = SOURCE_ROWS.EDW_LAST_UPDT_NM,
             ODS_CALLCENTER.ACTIVE_FLAG = SOURCE_ROWS.ACTIVE_FLAG
     WHEN NOT MATCHED AND SOURCE_ROWS.TARGET_OPERATION = 'DD_INSERT' THEN
         INSERT
         (
             ODS_CALLCENTER_ID,
             CALLCENTERID,
             EDW_CRTE_TS,
             EDW_CRTE_NM,
             EDW_LAST_UPDT_TS,
             EDW_LAST_UPDT_NM,
             CALLCENTERNAME,
             MD5_CHECKSUM_VAL,
             ACTIVE_FLAG
         )
         VALUES
         (
             SOURCE_ROWS.ODS_CALLCENTER_ID,
             SOURCE_ROWS.CALLCENTERID,
             SOURCE_ROWS.EDW_CRTE_TS,
             SOURCE_ROWS.EDW_CRTE_NM,
             SOURCE_ROWS.EDW_LAST_UPDT_TS,
             SOURCE_ROWS.EDW_LAST_UPDT_NM,
             SOURCE_ROWS.CALLCENTERNAME,
             SOURCE_ROWS.MD5_CHECKSUM_VAL,
             SOURCE_ROWS.ACTIVE_FLAG
         )",
        log_model_end(this, 'DP_CXN1004C_ODS_CALLCENTER')
    ]
) }}

WITH max_key AS
    (
        SELECT COALESCE(MAX(ODS_CALLCENTER_ID),0) AS MAX_ID
        FROM {{ source('UTLDB01_CXNADM','ODS_CALLCENTER') }}
    ),
    sq_callcenter_stg AS
    (
        SELECT
            TGT.MD5_CHECKSUM_VAL AS TGT_MD5_CHECKSUM_VAL,
            TGT.ODS_CALLCENTER_ID AS TGT_ODS_CALLCENTER_ID,
            SRC.CALLCENTERID AS SRC_CALLCENTERID,
            SRC.CALLCENTERNAME AS SRC_CALLCENTERNAME,
            SRC.MD5_CHECKSUM_VAL AS SRC_MD5_CHECKSUM_VAL
        FROM {{ source('UTLDB01_CXNADM','CALLCENTER_STG') }} SRC
        FULL OUTER JOIN
        (
            SELECT
                ODS_CALLCENTER_ID,
                CALLCENTERID,
                MD5_CHECKSUM_VAL
            FROM {{ source('UTLDB01_CXNADM','ODS_CALLCENTER') }}
            WHERE ACTIVE_FLAG = 'Y'
        ) TGT
            ON SRC.CALLCENTERID = TGT.CALLCENTERID
    ),
    exp_Audit_fields AS
    (
        SELECT
            sq_callcenter_stg.SRC_CALLCENTERID AS SRC_CALLCENTERID,
            sq_callcenter_stg.SRC_CALLCENTERNAME AS SRC_CALLCENTERNAME,
            sq_callcenter_stg.SRC_MD5_CHECKSUM_VAL AS SRC_MD5_CHECKSUM_VAL,
            sq_callcenter_stg.TGT_ODS_CALLCENTER_ID AS TGT_ODS_CALLCENTER_ID,
            sq_callcenter_stg.TGT_MD5_CHECKSUM_VAL AS TGT_MD5_CHECKSUM_VAL,
            CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
            's_m_ODS_CALLCENTER' AS out_EDW_CRTE_NM,
            CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
            's_m_ODS_CALLCENTER' AS out_EDW_LAST_UPDT_NM,
            'Y' AS out_ACTIVE_FLAG_Y,
            'N' AS out_ACTIVE_FLAG_N
        FROM sq_callcenter_stg
    ),
    rtr_flag_record AS
    (
        SELECT
            exp_Audit_fields.SRC_CALLCENTERID AS SRC_CALLCENTERID,
            exp_Audit_fields.SRC_CALLCENTERNAME AS SRC_CALLCENTERNAME,
            exp_Audit_fields.SRC_MD5_CHECKSUM_VAL AS SRC_MD5_CHECKSUM_VAL,
            exp_Audit_fields.TGT_ODS_CALLCENTER_ID AS TGT_ODS_CALLCENTER_ID,
            exp_Audit_fields.TGT_MD5_CHECKSUM_VAL AS TGT_MD5_CHECKSUM_VAL,
            exp_Audit_fields.out_EDW_CRTE_TS AS out_EDW_CRTE_TS,
            exp_Audit_fields.out_EDW_CRTE_NM AS out_EDW_CRTE_NM,
            exp_Audit_fields.out_EDW_LAST_UPDT_TS AS out_EDW_LAST_UPDT_TS,
            exp_Audit_fields.out_EDW_LAST_UPDT_NM AS out_EDW_LAST_UPDT_NM,
            exp_Audit_fields.out_ACTIVE_FLAG_Y AS out_ACTIVE_FLAG_Y,
            exp_Audit_fields.out_ACTIVE_FLAG_N AS out_ACTIVE_FLAG_N,
            CASE
                WHEN exp_Audit_fields.TGT_ODS_CALLCENTER_ID IS NULL
                 AND exp_Audit_fields.SRC_CALLCENTERID IS NOT NULL THEN 'INSERT'
                WHEN exp_Audit_fields.TGT_ODS_CALLCENTER_ID IS NOT NULL
                 AND exp_Audit_fields.SRC_CALLCENTERID IS NOT NULL
                 AND exp_Audit_fields.SRC_MD5_CHECKSUM_VAL <> exp_Audit_fields.TGT_MD5_CHECKSUM_VAL THEN 'UPDATE'
                WHEN exp_Audit_fields.SRC_CALLCENTERID IS NULL
                 AND exp_Audit_fields.TGT_ODS_CALLCENTER_ID IS NOT NULL THEN 'DELETE'
                ELSE 'DEFAULT1'
            END AS ROUTER_GROUP
        FROM exp_Audit_fields
    ),
    tgt_insert AS
    (
        SELECT
            rtr_flag_record.SRC_CALLCENTERID AS SRC_CALLCENTERID,
            rtr_flag_record.SRC_CALLCENTERNAME AS SRC_CALLCENTERNAME,
            rtr_flag_record.SRC_MD5_CHECKSUM_VAL AS SRC_MD5_CHECKSUM_VAL,
            rtr_flag_record.out_EDW_CRTE_TS AS out_EDW_CRTE_TS,
            rtr_flag_record.out_EDW_CRTE_NM AS out_EDW_CRTE_NM,
            rtr_flag_record.out_EDW_LAST_UPDT_TS AS out_EDW_LAST_UPDT_TS,
            rtr_flag_record.out_EDW_LAST_UPDT_NM AS out_EDW_LAST_UPDT_NM,
            rtr_flag_record.out_ACTIVE_FLAG_Y AS out_ACTIVE_FLAG_Y,
            'DD_INSERT' AS TARGET_OPERATION
        FROM rtr_flag_record
        WHERE rtr_flag_record.ROUTER_GROUP = 'INSERT'
    ),
    ods_callcenter_insert AS
    (
        SELECT
            (
                max_key.MAX_ID
                + ROW_NUMBER() OVER (ORDER BY tgt_insert.SRC_CALLCENTERID)
            )::NUMBER(38,0) AS ODS_CALLCENTER_ID,
            tgt_insert.SRC_CALLCENTERID AS CALLCENTERID,
            tgt_insert.out_EDW_CRTE_TS AS EDW_CRTE_TS,
            tgt_insert.out_EDW_CRTE_NM AS EDW_CRTE_NM,
            tgt_insert.out_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
            tgt_insert.out_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM,
            tgt_insert.SRC_CALLCENTERNAME AS CALLCENTERNAME,
            tgt_insert.SRC_MD5_CHECKSUM_VAL AS MD5_CHECKSUM_VAL,
            tgt_insert.out_ACTIVE_FLAG_Y AS ACTIVE_FLAG,
            tgt_insert.TARGET_OPERATION AS TARGET_OPERATION
        FROM tgt_insert
        CROSS JOIN max_key
    ),
    tgt_update AS
    (
        SELECT
            rtr_flag_record.TGT_ODS_CALLCENTER_ID AS TGT_ODS_CALLCENTER_ID3,
            rtr_flag_record.SRC_CALLCENTERNAME AS SRC_CALLCENTERNAME3,
            rtr_flag_record.SRC_MD5_CHECKSUM_VAL AS SRC_MD5_CHECKSUM_VAL,
            rtr_flag_record.out_EDW_LAST_UPDT_TS AS out_EDW_LAST_UPDT_TS,
            rtr_flag_record.out_EDW_LAST_UPDT_NM AS out_EDW_LAST_UPDT_NM,
            'DD_UPDATE' AS TARGET_OPERATION
        FROM rtr_flag_record
        WHERE rtr_flag_record.ROUTER_GROUP = 'UPDATE'
    ),
    ods_callcenter_update AS
    (
        SELECT
            tgt_update.TGT_ODS_CALLCENTER_ID3 AS ODS_CALLCENTER_ID,
            NULL::VARCHAR AS CALLCENTERID,
            NULL::TIMESTAMP_NTZ AS EDW_CRTE_TS,
            NULL::VARCHAR AS EDW_CRTE_NM,
            tgt_update.out_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
            tgt_update.out_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM,
            tgt_update.SRC_CALLCENTERNAME3 AS CALLCENTERNAME,
            tgt_update.SRC_MD5_CHECKSUM_VAL AS MD5_CHECKSUM_VAL,
            NULL::VARCHAR AS ACTIVE_FLAG,
            tgt_update.TARGET_OPERATION AS TARGET_OPERATION
        FROM tgt_update
    ),
    tgt_delete AS
    (
        SELECT
            rtr_flag_record.TGT_ODS_CALLCENTER_ID AS TGT_ODS_CALLCENTER_ID4,
            rtr_flag_record.out_ACTIVE_FLAG_N AS out_ACTIVE_FLAG_N4,
            rtr_flag_record.out_EDW_LAST_UPDT_TS AS out_EDW_LAST_UPDT_TS4,
            rtr_flag_record.out_EDW_LAST_UPDT_NM AS out_EDW_LAST_UPDT_NM4,
            'DD_DELETE' AS TARGET_OPERATION
        FROM rtr_flag_record
        WHERE rtr_flag_record.ROUTER_GROUP = 'DELETE'
    ),
    ods_callcenter_delete AS
    (
        SELECT
            tgt_delete.TGT_ODS_CALLCENTER_ID4 AS ODS_CALLCENTER_ID,
            NULL::VARCHAR AS CALLCENTERID,
            NULL::TIMESTAMP_NTZ AS EDW_CRTE_TS,
            NULL::VARCHAR AS EDW_CRTE_NM,
            tgt_delete.out_EDW_LAST_UPDT_TS4 AS EDW_LAST_UPDT_TS,
            tgt_delete.out_EDW_LAST_UPDT_NM4 AS EDW_LAST_UPDT_NM,
            NULL::VARCHAR AS CALLCENTERNAME,
            NULL::VARCHAR AS MD5_CHECKSUM_VAL,
            tgt_delete.out_ACTIVE_FLAG_N4 AS ACTIVE_FLAG,
            tgt_delete.TARGET_OPERATION AS TARGET_OPERATION
        FROM tgt_delete
    ),

    source_rows_all AS
    (
    SELECT
        ods_callcenter_insert.ODS_CALLCENTER_ID,
        ods_callcenter_insert.CALLCENTERID,
        ods_callcenter_insert.EDW_CRTE_TS,
        ods_callcenter_insert.EDW_CRTE_NM,
        ods_callcenter_insert.EDW_LAST_UPDT_TS,
        ods_callcenter_insert.EDW_LAST_UPDT_NM,
        ods_callcenter_insert.CALLCENTERNAME,
        ods_callcenter_insert.MD5_CHECKSUM_VAL,
        ods_callcenter_insert.ACTIVE_FLAG,
        ods_callcenter_insert.TARGET_OPERATION
    FROM ods_callcenter_insert
    UNION ALL
    SELECT
        ods_callcenter_update.ODS_CALLCENTER_ID,
        ods_callcenter_update.CALLCENTERID,
        ods_callcenter_update.EDW_CRTE_TS,
        ods_callcenter_update.EDW_CRTE_NM,
        ods_callcenter_update.EDW_LAST_UPDT_TS,
        ods_callcenter_update.EDW_LAST_UPDT_NM,
        ods_callcenter_update.CALLCENTERNAME,
        ods_callcenter_update.MD5_CHECKSUM_VAL,
        ods_callcenter_update.ACTIVE_FLAG,
        ods_callcenter_update.TARGET_OPERATION
    FROM ods_callcenter_update
    UNION ALL
    SELECT
        ods_callcenter_delete.ODS_CALLCENTER_ID,
        ods_callcenter_delete.CALLCENTERID,
        ods_callcenter_delete.EDW_CRTE_TS,
        ods_callcenter_delete.EDW_CRTE_NM,
        ods_callcenter_delete.EDW_LAST_UPDT_TS,
        ods_callcenter_delete.EDW_LAST_UPDT_NM,
        ods_callcenter_delete.CALLCENTERNAME,
        ods_callcenter_delete.MD5_CHECKSUM_VAL,
        ods_callcenter_delete.ACTIVE_FLAG,
        ods_callcenter_delete.TARGET_OPERATION
    FROM ods_callcenter_delete
    )

SELECT *
FROM source_rows_all

/* one row per merge key: the post-hook MERGE matches on ODS_CALLCENTER_ID and
   aborts with 100090 if two source rows carry the same id. The insert branch is
   safe on its own (MAX_ID + ROW_NUMBER gives distinct ids), but the update and
   delete branches both take TGT_ODS_CALLCENTER_ID from the target lookup, so two
   CALLCENTER_STG rows sharing a CALLCENTERID land on one id. CALLCENTER_STG has
   no dedupe of its own, so nothing upstream prevents that.
   A real update is preferred over a soft delete when both reach the same id. */
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY ODS_CALLCENTER_ID
    ORDER BY CASE TARGET_OPERATION
                 WHEN 'DD_UPDATE' THEN 1
                 WHEN 'DD_INSERT' THEN 2
                 ELSE 3
             END,
             MD5_CHECKSUM_VAL
) = 1