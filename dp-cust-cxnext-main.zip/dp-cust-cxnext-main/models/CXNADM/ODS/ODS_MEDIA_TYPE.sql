{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='MEDIA_TYPE_KEY',
    merge_update_columns=[
        'MEDIA_NAME',
        'MEDIA_NAME_CODE',
        'IS_ONLINE',
        'CREATE_AUDIT_KEY',
        'UPDATE_AUDIT_KEY',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM'
    ],
    meta={"mapping_name": "m_ODS_MEDIA_TYPE"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_ODS_MEDIA_TYPE')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_ODS_MEDIA_TYPE')
    ]
) }}

WITH
SQ_MEDIA_TYPE_STG AS
(
    SELECT
          TGT.MEDIA_TYPE_KEY AS TGT_MEDIA_TYPE_KEY
        , SRC.MEDIA_TYPE_KEY AS SRC_MEDIA_TYPE_KEY
        , SRC.MEDIA_NAME
        , SRC.MEDIA_NAME_CODE
        , SRC.IS_ONLINE
        , SRC.CREATE_AUDIT_KEY
        , SRC.UPDATE_AUDIT_KEY

    FROM {{ source('UTLDB01_CXNADM','MEDIA_TYPE_STG') }} SRC

    LEFT OUTER JOIN
    (
        SELECT MEDIA_TYPE_KEY
        FROM {% if is_incremental() %}{{ this }}{% else %}(SELECT NULL::NUMBER(10,0) AS MEDIA_TYPE_KEY FROM (SELECT 1 AS DUMMY) DUMMY_ROW WHERE 1 = 0){% endif %} FIRST_RUN_SAFE 
    ) TGT
      ON SRC.MEDIA_TYPE_KEY = TGT.MEDIA_TYPE_KEY
),

EXP_AUDIT_ODS_MEDIA_TYPE AS
(
    SELECT
          SRC_MEDIA_TYPE_KEY
        , MEDIA_NAME
        , MEDIA_NAME_CODE
        , IS_ONLINE
        , CREATE_AUDIT_KEY
        , UPDATE_AUDIT_KEY
        , TGT_MEDIA_TYPE_KEY

        , CURRENT_TIMESTAMP() AS OUT_EDW_CRTE_TS
        , 's_m_ODS_MEDIA_TYPE'    AS OUT_EDW_CRTE_NM

        , CURRENT_TIMESTAMP() AS OUT_EDW_LAST_UPDT_TS
        , 's_m_ODS_MEDIA_TYPE'    AS OUT_EDW_LAST_UPDT_NM

    FROM SQ_MEDIA_TYPE_STG
)

SELECT
    SRC_MEDIA_TYPE_KEY AS MEDIA_TYPE_KEY,
    MEDIA_NAME,
    MEDIA_NAME_CODE,
    IS_ONLINE,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY,
    OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM
FROM EXP_AUDIT_ODS_MEDIA_TYPE

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY SRC_MEDIA_TYPE_KEY
    ORDER BY UPDATE_AUDIT_KEY DESC
) = 1