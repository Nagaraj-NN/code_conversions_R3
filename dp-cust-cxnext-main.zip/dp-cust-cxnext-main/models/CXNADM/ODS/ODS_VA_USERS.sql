{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='ODS_VA_USERS_ID',
    merge_update_columns=[
        'FIRSTNAME',
        'LASTNAME',
        'MI',
        'SUPERVISOR_ID',
        'IS_ACTIVE',
        'PHONE',
        'POSITION_ID',
        'GROUPID',
        'MB_ID',
        'CONTRACTOR_AGENCY_ID',
        'CREATEDBY',
        'CREATEDATE',
        'LASTUPDATEBY',
        'LASTUPDATE',
        'ROUTING_PROVIDER',
        'IS_MB_ACTIVE',
        'MD5_CHECKSUM_VAL',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM'
    ],
    meta={"mapping_name": "m_ODS_VA_USERS"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1004C_ODS_VA_USERS')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1004C_ODS_VA_USERS')
    ]
) }}

WITH SRC_DATA AS
    (
        SELECT
            ODS.ODS_VA_USERS_ID      AS TGT_ODS_VA_USERS_ID,
            ODS.MD5_CHECKSUM_VAL     AS TGT_MD5_CHECKSUM_VAL,
            SRC.USERID,
            SRC.CC_ID,
            SRC.FIRSTNAME,
            SRC.LASTNAME,
            SRC.MI,
            SRC.SUPERVISOR_ID,
            SRC.IS_ACTIVE,
            SRC.PHONE,
            SRC.POSITION_ID,
            SRC.GROUPID,
            SRC.MB_ID,
            SRC.CONTRACTOR_AGENCY_ID,
            SRC.CREATEDBY,
            SRC.CREATEDATE,
            SRC.LASTUPDATEBY,
            SRC.LASTUPDATE,
            SRC.ROUTING_PROVIDER,
            SRC.IS_MB_ACTIVE,
            SRC.MD5_CHECKSUM_VAL
        FROM {{ source('UTLDB01_CXNADM','VA_USERS_STG') }} SRC
        LEFT JOIN
        {% if is_incremental() %}
        {{ this }} ODS
        {% else %}
        -- First run: the target table does not exist yet. Stand in a zero-row
        -- relation of the same shape so every SRC row sees ODS.* as NULL and is
        -- routed to the insert branch, which is what a first load must do.
        (
                SELECT
                    NULL::VARCHAR(10) AS CC_ID,
                    NULL::VARCHAR(32) AS MD5_CHECKSUM_VAL,
                    NULL::NUMBER(38,0) AS ODS_VA_USERS_ID,
                    NULL::VARCHAR(10) AS USERID
                FROM (SELECT 1 AS DUMMY) DUMMY_ROW
                WHERE 1 = 0
        ) ODS
        {% endif %}
        
          ON SRC.USERID = ODS.USERID
         AND SRC.CC_ID  = ODS.CC_ID

        /* one row per natural key BEFORE a surrogate id is handed out: the
           id generator below gives every row a distinct value, so a duplicate
           caught after it would already look unique */
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY SRC.USERID, SRC.CC_ID
            ORDER BY SRC.LASTUPDATE DESC NULLS LAST
        ) = 1
    ),
    MAX_KEY AS
    (
        {% if is_incremental() %}

        SELECT COALESCE(MAX(ODS_VA_USERS_ID),0) AS MAX_ID
        FROM {{ this }}

        {% else %}

        -- First run: the target table does not exist yet, so the key sequence
        -- starts from zero.
        SELECT 0::NUMBER(38,0) AS MAX_ID

        {% endif %}
    ),

final_cte AS (
SELECT
        S.*,

        CASE
            WHEN S.TGT_ODS_VA_USERS_ID IS NULL
            THEN M.MAX_ID
                 + ROW_NUMBER() OVER
                   (
                       PARTITION BY
                           CASE
                               WHEN S.TGT_ODS_VA_USERS_ID IS NULL THEN 1
                               ELSE 0
                           END
                       ORDER BY S.USERID, S.CC_ID
                   )
        END AS NEW_ODS_VA_USERS_ID,
        CURRENT_TIMESTAMP() AS EDW_TS,
        's_m_ODS_VA_USERS' AS EDW_USER
    FROM SRC_DATA S
    CROSS JOIN MAX_KEY M
WHERE (TGT_ODS_VA_USERS_ID IS NOT NULL
        AND NVL(TGT_MD5_CHECKSUM_VAL,'~') <> NVL(MD5_CHECKSUM_VAL,'~'))
   OR (TGT_ODS_VA_USERS_ID IS NULL
        AND USERID IS NOT NULL AND CC_ID IS NOT NULL)
)

SELECT
    COALESCE(TGT_ODS_VA_USERS_ID, NEW_ODS_VA_USERS_ID) AS ODS_VA_USERS_ID,
    USERID,
    CC_ID,
    FIRSTNAME,
    LASTNAME,
    MI,
    SUPERVISOR_ID,
    IS_ACTIVE,
    PHONE,
    POSITION_ID,
    GROUPID,
    MB_ID,
    CONTRACTOR_AGENCY_ID,
    CREATEDBY,
    CREATEDATE,
    LASTUPDATEBY,
    LASTUPDATE,
    ROUTING_PROVIDER,
    IS_MB_ACTIVE,
    MD5_CHECKSUM_VAL,
    EDW_TS AS EDW_CRTE_TS,
    EDW_USER AS EDW_CRTE_NM,
    EDW_TS AS EDW_LAST_UPDT_TS,
    EDW_USER AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY COALESCE(TGT_ODS_VA_USERS_ID, NEW_ODS_VA_USERS_ID)
    ORDER BY MD5_CHECKSUM_VAL
) = 1