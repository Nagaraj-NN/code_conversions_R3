
{{ config(
    materialized='incremental',
    incremental_strategy='append',
    alias='ODS_CUST_LOG_EVENTS',
    meta={"mapping_name": "m_ODS_CUST_LOG_EVENTS_INS"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1006C_ODS_CUST_LOG_EVENTS_INS')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1006C_ODS_CUST_LOG_EVENTS_INS')
    ]
) }}

WITH sq_stg_log_events AS
(
    SELECT
        SRC.EVNT_ID           AS EVENT_ID,
        SRC.EVNT_TM           AS EVENT_TIME,
        SRC.EVNT_CD           AS EVENT_CODE,
        SRC.SVR_NM            AS SERVER,
        SRC.ENVRMT_NM         AS ENVIRONMENT,
        SRC.RMT_IP_TX         AS REMOTE_IP,
        SRC.PROC_NM           AS PROCESS,
        SRC.SUB_PROC_NM       AS SUBPROCESS,
        SRC.URL_TX            AS URL,
        SRC.URL_REFERRER_TX   AS URL_REFERRER,
        SRC.EVNT_MSG_TX       AS EVENT_MESSAGE
    FROM {{ source('UTLDB01_UTLUSER','LOG_EVNTS_STG') }} SRC
),
exp_Audit AS
(
    SELECT
        EVENT_ID,
        EVENT_TIME,
        EVENT_CODE,
        SERVER,
        ENVIRONMENT,
        REMOTE_IP,
        PROCESS,
        SUBPROCESS,
        URL,
        URL_REFERRER,
        EVENT_MESSAGE,
        CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
        's_m_ODS_CUST_LOG_EVENTS_INS' AS out_EDW_CRTE_NM,
        CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
        's_m_ODS_CUST_LOG_EVENTS_INS' AS out_EDW_LAST_UPDT_NM,
        'Y' AS out_ACTIVE_FLAG_Y
    FROM sq_stg_log_events
),
MAX_ID AS
(
{% if is_incremental() %}

SELECT COALESCE(MAX(ODS_CUST_LOG_EVENTS_ID),0) AS MAX_ID
FROM {{ this }}

{% else %}

-- First run: the target table does not exist yet, so the key sequence
-- starts from zero.
SELECT 0::NUMBER(38,0) AS MAX_ID

{% endif %}
),

final_cte AS (
SELECT
    M.MAX_ID + ROW_NUMBER() OVER (ORDER BY EVENT_ID)
AS ODS_CUST_LOG_EVENTS_ID,
    EVENT_ID,
    out_EDW_CRTE_NM,
    out_EDW_CRTE_TS,
    out_EDW_LAST_UPDT_NM,
    out_EDW_LAST_UPDT_TS,
    EVENT_TIME,
    EVENT_CODE,
    SERVER,
    ENVIRONMENT,
    REMOTE_IP,
    PROCESS,
    SUBPROCESS,
    URL,
    URL_REFERRER,
    EVENT_MESSAGE,
    out_ACTIVE_FLAG_Y
FROM exp_Audit EA
CROSS JOIN MAX_ID M

{% if is_incremental() %}

WHERE NOT EXISTS
(
    SELECT
        1
    FROM {{ this }} OCL
    WHERE OCL.EVENT_ID = EA.EVENT_ID
)

{% endif %}

/* NOT EXISTS stops a re-insert across runs; this stops two rows for the same
   EVENT_ID inside one batch. It leaves gaps in the id sequence, which is
   harmless - the ids stay unique. */
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY EA.EVENT_ID
    ORDER BY EA.EVENT_ID
) = 1
)

SELECT
    SRC.ODS_CUST_LOG_EVENTS_ID,
    SRC.EVENT_ID,
    SRC.out_EDW_CRTE_NM AS EDW_CRTE_NM,
    SRC.out_EDW_CRTE_TS AS EDW_CRTE_TS,
    SRC.out_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM,
    SRC.out_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    SRC.EVENT_TIME,
    SRC.EVENT_CODE,
    SRC.SERVER,
    SRC.ENVIRONMENT,
    SRC.REMOTE_IP,
    SRC.PROCESS,
    SRC.SUBPROCESS,
    SRC.URL,
    SRC.URL_REFERRER,
    SRC.EVENT_MESSAGE,
    SRC.out_ACTIVE_FLAG_Y AS ACTIVE_FLAG

FROM
    final_cte SRC