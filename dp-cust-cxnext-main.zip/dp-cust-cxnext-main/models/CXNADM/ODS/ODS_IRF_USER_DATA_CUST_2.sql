{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key=['INTERACTION_RESOURCE_ID', 'START_DATE_TIME_KEY'],
    merge_update_columns=[
        'TENANT_KEY',
        'CREATE_AUDIT_KEY',
        'UPDATE_AUDIT_KEY',
        'CUSTOM_DATA_1',
        'CUSTOM_DATA_2',
        'CUSTOM_DATA_3',
        'CUSTOM_DATA_4',
        'CUSTOM_DATA_5',
        'CUSTOM_DATA_6',
        'CUSTOM_DATA_7',
        'CUSTOM_DATA_8',
        'CUSTOM_DATA_9',
        'CUSTOM_DATA_10',
        'CUSTOM_DATA_11',
        'CUSTOM_DATA_12',
        'CUSTOM_DATA_13',
        'CUSTOM_DATA_14',
        'CUSTOM_DATA_15',
        'CUSTOM_DATA_16',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM'
    ],
    meta={"mapping_name": "m_ODS_IRF_USER_DATA_CUST_2"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_ODS_IRF_USER_DATA_CUST_2')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_ODS_IRF_USER_DATA_CUST_2')
    ]
) }}

WITH
SQ_IRF_USER_DATA_CUST_2_STG AS
(
    SELECT
          SRC.INTERACTION_RESOURCE_ID
        , SRC.START_DATE_TIME_KEY
        , SRC.TENANT_KEY
        , SRC.CREATE_AUDIT_KEY
        , SRC.UPDATE_AUDIT_KEY
        , SRC.CUSTOM_DATA_1
        , SRC.CUSTOM_DATA_2
        , SRC.CUSTOM_DATA_3
        , SRC.CUSTOM_DATA_4
        , SRC.CUSTOM_DATA_5
        , SRC.CUSTOM_DATA_6
        , SRC.CUSTOM_DATA_7
        , SRC.CUSTOM_DATA_8
        , SRC.CUSTOM_DATA_9
        , SRC.CUSTOM_DATA_10
        , SRC.CUSTOM_DATA_11
        , SRC.CUSTOM_DATA_12
        , SRC.CUSTOM_DATA_13
        , SRC.CUSTOM_DATA_14
        , SRC.CUSTOM_DATA_15
        , SRC.CUSTOM_DATA_16
        , TGT.INTERACTION_RESOURCE_ID AS TGT_INTERACTION_RESOURCE_ID
        , TGT.START_DATE_TIME_KEY     AS TGT_START_DATE_TIME_KEY
    FROM {{ source('UTLDB01_CXNADM','IRF_USER_DATA_CUST_2_STG') }} SRC
    LEFT JOIN
    {% if is_incremental() %}
    {{ this }} TGT
    {% else %}
    -- First run: the target table does not exist yet. Stand in a zero-row
    -- relation of the same shape so every SRC row sees TGT.* as NULL and is
    -- routed to the insert branch, which is what a first load must do.
    (
            SELECT
                NULL::NUMBER(19,0) AS INTERACTION_RESOURCE_ID,
                NULL::NUMBER(10,0) AS START_DATE_TIME_KEY
            FROM (SELECT 1 AS DUMMY) DUMMY_ROW
            WHERE 1 = 0
    ) TGT
    {% endif %}
    --UTLDB01_DEV_SANDBOX.CXNADM.ODS_IRF_USER_DATA_CUST_2
      ON SRC.INTERACTION_RESOURCE_ID = TGT.INTERACTION_RESOURCE_ID
     AND SRC.START_DATE_TIME_KEY     = TGT.START_DATE_TIME_KEY
),

EXP_AUDIT_ODS_IRF_USER_DATA_CUST_2 AS
(
    SELECT
          SQ_IRF_USER_DATA_CUST_2_STG.*

        , CURRENT_TIMESTAMP() AS OUT_EDW_CRTE_TS
        , 's_m_ODS_IRF_USER_DATA_CUST_2' AS OUT_EDW_CRTE_NM

        , CURRENT_TIMESTAMP() AS OUT_EDW_LAST_UPDT_TS
        , 's_m_ODS_IRF_USER_DATA_CUST_2' AS OUT_EDW_LAST_UPDT_NM

        , CASE
            WHEN INTERACTION_RESOURCE_ID IS NOT NULL
             AND TGT_INTERACTION_RESOURCE_ID IS NULL
                THEN 'I'

            WHEN INTERACTION_RESOURCE_ID IS NOT NULL
             AND TGT_INTERACTION_RESOURCE_ID IS NOT NULL
                THEN 'U'

            ELSE 'R'
          END AS OUT_RECORD_FLAG

    FROM SQ_IRF_USER_DATA_CUST_2_STG
)

SELECT
    INTERACTION_RESOURCE_ID,
    START_DATE_TIME_KEY,
    TENANT_KEY,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY,
    CUSTOM_DATA_1,
    CUSTOM_DATA_2,
    CUSTOM_DATA_3,
    CUSTOM_DATA_4,
    CUSTOM_DATA_5,
    CUSTOM_DATA_6,
    CUSTOM_DATA_7,
    CUSTOM_DATA_8,
    CUSTOM_DATA_9,
    CUSTOM_DATA_10,
    CUSTOM_DATA_11,
    CUSTOM_DATA_12,
    CUSTOM_DATA_13,
    CUSTOM_DATA_14,
    CUSTOM_DATA_15,
    CUSTOM_DATA_16,
    OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM
FROM EXP_AUDIT_ODS_IRF_USER_DATA_CUST_2
WHERE OUT_RECORD_FLAG IN ('I', 'U')

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY INTERACTION_RESOURCE_ID, START_DATE_TIME_KEY
    ORDER BY UPDATE_AUDIT_KEY DESC
) = 1