
{{ config(
    materialized='incremental',
    incremental_strategy='append',
    alias='AGENT_CHAT_SPECIALIST_JAR_F',
    meta={
        "mapping_name": "m_AGENT_CHAT_SPECIALIST_JAR_F_INCR"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1014C_AGENT_CHAT_SPECIALIST_JAR_F_INCR'),
        log_model_start(
            this,
            'DP_CXN1014C_AGENT_CHAT_SPECIALIST_JAR_F_INCR'
        )
    ],
    post_hook=[
         update_control_table(this, 'DP_CXN1014C_AGENT_CHAT_SPECIALIST_JAR_F_INCR'),
        log_model_end(
            this,
            'DP_CXN1014C_AGENT_CHAT_SPECIALIST_JAR_F_INCR'
        )
    ]
) }}

WITH JOB_CONTROL AS
(
    SELECT
        JOB_ID,
        START_DATE::TIMESTAMP_NTZ(9) AS START_DATE,
        END_DATE::TIMESTAMP_NTZ(9) AS END_DATE
    FROM {{ source(
        'UTLDB01_METADATA',
        'CXNADM_JOB_CONTROL'
    ) }}
    WHERE JOB_NAME = 'AGENT_CHAT_SPECIALIST_JAR_F_INCR'
      AND AUTOSYS_JOB_NAME =
          'DP_CXN1014C_AGENT_CHAT_SPECIALIST_JAR_F_INCR'
),

VOICE_AGENT_SOURCE AS
(
    SELECT DISTINCT
        IFCT.INTERACTION_ID,
        IRF.INTERACTION_SDT_KEY AS TIME_IN_UNIX,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.START_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS INTERACTION_STEP_START_TIME,

        TO_VARCHAR(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IFCT.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            ),
            'YYYY-MM-DD'
        ) AS CALL_START_DATE,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.END_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS INTERACTION_CALL_END_TIME,

        TO_VARCHAR(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IFCT.END_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            ),
            'YYYY-MM-DD'
        ) AS CALL_END_DATE,

        IFCT.MEDIA_SERVER_IXN_GUID
            AS VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,

        R.AGENT_NAME,
        R.AGENT_FIRST_NAME,
        R.AGENT_LAST_NAME,
        IRF.CUSTOMER_TALK_DURATION,
        IRF.CUSTOMER_HOLD_DURATION,
        IRF.CUSTOMER_ACW_DURATION,
        IRF.INTERACTION_RESOURCE_ID,
        UD.CUSTOM_DATA_1 AS BILL_ACCOUNT_NUMBER,
        IRF.EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS_N

    FROM {{ source('UTLDB01_CUSADM', 'RESOURCE_') }} R

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_RESOURCE_FACT'
    ) }} IRF
        ON IRF.RESOURCE_KEY = R.RESOURCE_KEY

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_FACT'
    ) }} IFCT
        ON IRF.INTERACTION_ID = IFCT.INTERACTION_ID
       AND IRF.INTERACTION_SDT_KEY = IFCT.START_DATE_TIME_KEY

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'IRF_USER_DATA_CUST_1'
    ) }} UD
        ON IRF.INTERACTION_RESOURCE_ID = UD.INTERACTION_RESOURCE_ID

    WHERE R.RESOURCE_TYPE_CODE = 'AGENT'
      AND R.RESOURCE_SUBTYPE = 'Agent'

      AND TO_DATE(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IRF.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            )
          ) >= TO_DATE(
            (
                SELECT START_DATE
                FROM JOB_CONTROL
            )
          )

      AND TO_DATE(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IRF.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            )
          ) <= TO_DATE(
            (
                SELECT END_DATE
                FROM JOB_CONTROL
            )
          )

      -- Original hard-coded mapping window:
      -- START DATE >= 2026-08-02
      -- END DATE   <= 2026-08-03

      AND IRF.MEDIA_TYPE_KEY = 1
      AND IRF.CUSTOMER_TALK_DURATION <> 0
      AND UD.CUSTOM_DATA_1 IS NOT NULL
),

CHAT_SPECIALIST_SOURCE AS
(
    SELECT DISTINCT
        IFCT.INTERACTION_ID,
        IRF.INTERACTION_SDT_KEY AS TIME_IN_UNIX,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.START_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS INTERACTION_STEP_START_TIME,

        TO_VARCHAR(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IFCT.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            ),
            'YYYY-MM-DD'
        ) AS CALL_START_DATE,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.END_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS INTERACTION_CALL_END_TIME,

        TO_VARCHAR(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IFCT.END_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            ),
            'YYYY-MM-DD'
        ) AS CALL_END_DATE,

        IFCT.MEDIA_SERVER_IXN_GUID
            AS VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,

        R.AGENT_NAME,
        R.AGENT_FIRST_NAME,
        R.AGENT_LAST_NAME,
        IRF.CUSTOMER_TALK_DURATION,
        IRF.CUSTOMER_HOLD_DURATION,
        IRF.CUSTOMER_ACW_DURATION,
        IRF.INTERACTION_RESOURCE_ID,
        UD.CUSTOM_DATA_1 AS BILL_ACCOUNT_NUMBER,
        IRF.EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS_N

    FROM {{ source('UTLDB01_CUSADM', 'RESOURCE_') }} R

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_RESOURCE_FACT'
    ) }} IRF
        ON IRF.RESOURCE_KEY = R.RESOURCE_KEY

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_FACT'
    ) }} IFCT
        ON IRF.INTERACTION_ID = IFCT.INTERACTION_ID
       AND IRF.INTERACTION_SDT_KEY = IFCT.START_DATE_TIME_KEY

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'IRF_USER_DATA_CUST_1'
    ) }} UD
        ON IRF.INTERACTION_RESOURCE_ID = UD.INTERACTION_RESOURCE_ID

    WHERE R.RESOURCE_TYPE_CODE = 'AGENT'
      AND R.RESOURCE_SUBTYPE = 'Agent'

      AND TO_DATE(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IRF.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            )
          ) >= TO_DATE(
            (
                SELECT START_DATE
                FROM JOB_CONTROL
            )
          )

      AND TO_DATE(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IRF.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            )
          ) <= TO_DATE(
            (
                SELECT END_DATE
                FROM JOB_CONTROL
            )
          )

      -- Original hard-coded mapping window:
      -- START DATE >= 2026-08-02
      -- END DATE   <= 2026-08-03

      AND IRF.MEDIA_TYPE_KEY = 3
      AND IRF.INTERACTION_TYPE_KEY = 8
      AND IRF.CUSTOMER_TALK_DURATION <> 0
      AND UD.CUSTOM_DATA_1 IS NOT NULL
),

EMAIL_SOURCE AS
(
    SELECT DISTINCT
        IFCT.INTERACTION_ID,
        IRF.INTERACTION_SDT_KEY AS TIME_IN_UNIX,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.START_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS INTERACTION_STEP_START_TIME,

        TO_VARCHAR(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IFCT.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            ),
            'YYYY-MM-DD'
        ) AS CALL_START_DATE,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.END_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS INTERACTION_CALL_END_TIME,

        TO_VARCHAR(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IFCT.END_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            ),
            'YYYY-MM-DD'
        ) AS CALL_END_DATE,

        IFCT.MEDIA_SERVER_IXN_GUID
            AS VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,

        R.AGENT_NAME,
        R.AGENT_FIRST_NAME,
        R.AGENT_LAST_NAME,
        IRF.CUSTOMER_TALK_DURATION,
        IRF.CUSTOMER_HOLD_DURATION,
        IRF.CUSTOMER_ACW_DURATION,
        IRF.INTERACTION_RESOURCE_ID,
        UD.CUSTOM_DATA_1 AS BILL_ACCOUNT_NUMBER,
        IRF.EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS_N

    FROM {{ source('UTLDB01_CUSADM', 'RESOURCE_') }} R

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_RESOURCE_FACT'
    ) }} IRF
        ON IRF.RESOURCE_KEY = R.RESOURCE_KEY

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_FACT'
    ) }} IFCT
        ON IRF.INTERACTION_ID = IFCT.INTERACTION_ID
       AND IRF.INTERACTION_SDT_KEY = IFCT.START_DATE_TIME_KEY

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'IRF_USER_DATA_CUST_1'
    ) }} UD
        ON IRF.INTERACTION_RESOURCE_ID = UD.INTERACTION_RESOURCE_ID

    WHERE R.RESOURCE_TYPE_CODE = 'AGENT'
      AND R.RESOURCE_SUBTYPE = 'Agent'

      AND TO_DATE(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IRF.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            )
          ) >= TO_DATE(
            (
                SELECT START_DATE
                FROM JOB_CONTROL
            )
          )

      AND TO_DATE(
            CONVERT_TIMEZONE(
                'UTC',
                'America/New_York',
                DATEADD(
                    SECOND,
                    IRF.START_TS,
                    TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
                )
            )
          ) <= TO_DATE(
            (
                SELECT END_DATE
                FROM JOB_CONTROL
            )
          )

      -- Original hard-coded mapping window:
      -- START DATE >= 2026-08-02
      -- END DATE   <= 2026-08-03

      AND IRF.MEDIA_TYPE_KEY = 2
      AND IRF.INTERACTION_TYPE_KEY = 13
      AND IRF.CUSTOMER_TALK_DURATION <> 0
      AND UD.CUSTOM_DATA_1 IS NOT NULL
),

INFOMART_ALL AS
(
    SELECT
        INTERACTION_ID,
        TIME_IN_UNIX,
        INTERACTION_STEP_START_TIME AS CALL_START_TIME_N,
        CALL_START_DATE,
        INTERACTION_CALL_END_TIME AS CALL_END_TIME_N,
        CALL_END_DATE,
        EDW_LAST_UPDT_TS_N,
        VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,
        BILL_ACCOUNT_NUMBER,
        'Voice_Agent' AS INTERACTION_CHANNEL_NAME,
        '452056' AS EVENT_CODE
    FROM VOICE_AGENT_SOURCE

    UNION

    SELECT
        INTERACTION_ID,
        TIME_IN_UNIX,
        INTERACTION_STEP_START_TIME AS CALL_START_TIME_N,
        CALL_START_DATE,
        INTERACTION_CALL_END_TIME AS CALL_END_TIME_N,
        CALL_END_DATE,
        EDW_LAST_UPDT_TS_N,
        VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,
        BILL_ACCOUNT_NUMBER,
        'Chat Specialist' AS INTERACTION_CHANNEL_NAME,
        '432153' AS EVENT_CODE
    FROM CHAT_SPECIALIST_SOURCE

    UNION

    SELECT
        INTERACTION_ID,
        TIME_IN_UNIX,
        INTERACTION_STEP_START_TIME AS CALL_START_TIME_N,
        CALL_START_DATE,
        INTERACTION_CALL_END_TIME AS CALL_END_TIME_N,
        CALL_END_DATE,
        EDW_LAST_UPDT_TS_N,
        VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,
        BILL_ACCOUNT_NUMBER,
        'Email' AS INTERACTION_CHANNEL_NAME,
        '12345' AS EVENT_CODE
    FROM EMAIL_SOURCE
),

CTE2 AS
(
    SELECT
        INFO.INTERACTION_ID,
        INFO.TIME_IN_UNIX,
        INFO.CALL_START_TIME_N AS CALL_START_TIME,
        INFO.CALL_START_DATE,
        INFO.CALL_END_TIME_N AS CALL_END_TIME,
        INFO.CALL_END_DATE,
        INFO.EDW_LAST_UPDT_TS_N AS EDW_LAST_UPDT_TS,
        INFO.VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,
        INFO.BILL_ACCOUNT_NUMBER,
        INFO.INTERACTION_CHANNEL_NAME,
        INFO.EVENT_CODE AS EVENT_CODES,
        BF.ACCOUNT_D_ID
    FROM INFOMART_ALL INFO

    LEFT JOIN {{ source(
        'UTLDB01_CXNADM',
        'BILLING_F'
    ) }} BF
        ON INFO.BILL_ACCOUNT_NUMBER = BF.BILL_ACCOUNT_NB
       AND INFO.CALL_START_DATE =
           TO_CHAR(BF.REPORT_DT, 'YYYY-MM-DD')
),

CALLS_SOURCE AS
(
    SELECT
        C.BILL_ACCOUNT_NB,
        C.CALL_START_TIME,
        C.CALL_START_DATE,
        C.CALL_END_TIME,
        C.CALL_END_DATE,
        C.EDW_LAST_UPDT_TS,
        C.VOICE_PLATFORM_FULL_CALL_ID
            AS VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,

        LTRIM(
            REGEXP_SUBSTR(
                C.CTI_FIELDS,
                'eventCD\\:[^|]+'
            ),
            'eventCD:'
        ) AS EVENT_CODES,

        C.ACCOUNT_D_ID

    FROM {{ source('UTLDB01_CXNADM', 'CALLS') }} C

    WHERE TO_DATE(C.CALL_START_DATE) >=
          TO_DATE(
              (
                  SELECT START_DATE
                  FROM JOB_CONTROL
              )
          )

      AND TO_DATE(C.CALL_START_DATE) <=
          TO_DATE(
              (
                  SELECT END_DATE
                  FROM JOB_CONTROL
              )
          )

      -- Original hard-coded mapping predicates:
      -- CALL_START_DATE >= SUBSTR('2026-08-02 08:57:37', 1, 10)
      -- CALL_START_DATE <= SUBSTR('2026-08-03 08:47:13', 1, 10)

      AND C.IS_TEST_CALL = 0
),

UNION_CTE AS
(
    SELECT
        CTE2.BILL_ACCOUNT_NUMBER AS BILL_ACCOUNT_NB,
        CTE2.CALL_START_TIME,
        CTE2.CALL_START_DATE,
        CTE2.CALL_END_TIME,
        CTE2.CALL_END_DATE,
        CTE2.EDW_LAST_UPDT_TS,
        CTE2.VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,
        CTE2.EVENT_CODES,
        CTE2.ACCOUNT_D_ID
    FROM CTE2

    UNION

    SELECT
        CS.BILL_ACCOUNT_NB,
        CS.CALL_START_TIME::TIMESTAMP_NTZ
            AS CALL_START_TIME,
        TO_CHAR(
            CS.CALL_START_DATE,
            'YYYY-MM-DD'
        ) AS CALL_START_DATE,
        CS.CALL_END_TIME::TIMESTAMP_NTZ
            AS CALL_END_TIME,
        TO_CHAR(
            CS.CALL_END_DATE,
            'YYYY-MM-DD'
        ) AS CALL_END_DATE,
        CS.EDW_LAST_UPDT_TS,
        CS.VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID,
        CS.EVENT_CODES,
        CS.ACCOUNT_D_ID
    FROM CALLS_SOURCE CS
),

TEMP1_SOURCE AS
(
    SELECT
        C.BILL_ACCOUNT_NB AS ACS_BILL_ACC_NB,
        C.ACCOUNT_D_ID,
        C.EVENT_CODES,
        C.CALL_START_TIME AS ACS_START_TIME,
        C.VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID
    FROM UNION_CTE C
    WHERE C.BILL_ACCOUNT_NB IS NOT NULL
      AND C.ACCOUNT_D_ID IS NOT NULL

      AND DATE_TRUNC(
            'DAY',
            C.EDW_LAST_UPDT_TS
          ) BETWEEN
          DATE_TRUNC(
              'DAY',
              (
                  SELECT START_DATE
                  FROM JOB_CONTROL
              )
          )
          AND DATE_TRUNC(
              'DAY',
              (
                  SELECT END_DATE
                  FROM JOB_CONTROL
              )
          )

      -- Original hard-coded mapping window:
      -- DATE_TRUNC('DAY', C.EDW_LAST_UPDT_TS)
      -- BETWEEN TO_TIMESTAMP_NTZ(
      --     '2026-08-02 08:57:37',
      --     'YYYY-MM-DD HH24:MI:SS'
      -- )
      -- AND TO_TIMESTAMP_NTZ(
      --     '2026-08-03 08:47:13',
      --     'YYYY-MM-DD HH24:MI:SS'
      -- )

      AND C.CALL_START_TIME BETWEEN
          DATEADD(
              MONTH,
              -13,
              DATE_TRUNC(
                  'DAY',
                  CURRENT_TIMESTAMP()
              )
          )
          AND DATE_TRUNC(
              'DAY',
              CURRENT_TIMESTAMP()
          )
),

ACTIVE_ACCOUNTS AS
(
    SELECT
        BILL_ACCOUNT_NB,
        ACCOUNT_D_ID
    FROM {{ source('UTLDB01_CDWADM', 'ACCOUNT_D') }}
    WHERE CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
      AND ACTIVE_FLAG = 'Y'
),

TEMP1 AS
(
    SELECT
        C.ACS_BILL_ACC_NB,
        A.ACCOUNT_D_ID,
        C.EVENT_CODES,
        C.ACS_START_TIME,
        C.VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID
    FROM TEMP1_SOURCE C
    INNER JOIN ACTIVE_ACCOUNTS A
        ON C.ACS_BILL_ACC_NB = A.BILL_ACCOUNT_NB
),

TEMP2 AS
(
    SELECT
        ACS_BILL_ACC_NB,
        ACCOUNT_D_ID,
        ACS_START_TIME,
        VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID
    FROM TEMP1
    WHERE EVENT_CODES LIKE '%452056%'
       OR EVENT_CODES LIKE '%432153%'
       OR EVENT_CODES LIKE '%442153%'
       OR EVENT_CODES = '12345'
       OR EVENT_CODES = '452056'
       OR EVENT_CODES = '432153'
),

IRF_RANKED AS
(
    SELECT
        IRF.INTERACTION_RESOURCE_ID,
        IRF.INTERACTION_ID,
        IRF.PLACE_KEY,
        IRF.PREV_IRF_ID,
        IRF.CUSTOMER_TALK_DURATION,
        IRF.CUSTOMER_TALK_COUNT,
        IRF.POST_CONS_XFER_TALK_COUNT,
        IRF.CONF_INIT_TALK_COUNT,
        IRF.CONS_INIT_TALK_COUNT,
        IRF.CONS_RCV_TALK_COUNT,
        IRF.TECHNICAL_DESCRIPTOR_KEY,
        IRF.MEDIA_TYPE_KEY,
        IRF.END_TS,
        IRF.ROUTING_POINT_DURATION,
        IRF.INTERACTION_RESOURCE_ORDINAL,
        IRF.RESOURCE_KEY,
        IRF.CONS_RCV_ACW_DURATION,
        IRF.CUSTOMER_ACW_DURATION,
        IRF.CONS_RCV_HOLD_DURATION,
        IRF.CONF_INIT_HOLD_DURATION,
        IRF.CUSTOMER_HOLD_DURATION,
        IRF.CONS_RCV_TALK_DURATION,
        IRF.CONF_INIT_TALK_DURATION,
        IRF.POST_CONS_XFER_TALK_DURATION,
        IRF.INTERACTION_TYPE_KEY,
        IRF.POST_CONS_XFER_HOLD_DURATION,

        ROW_NUMBER() OVER
        (
            PARTITION BY IRF.INTERACTION_ID
            ORDER BY IRF.START_TS
        ) AS RNK

    FROM {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_RESOURCE_FACT'
    ) }} IRF
),

RES AS
(
    SELECT
        T.ACS_BILL_ACC_NB,
        T.ACCOUNT_D_ID,
        IFCT.INTERACTION_ID AS ACS_INTERACTION_ID,
        IFCT.MEDIA_SERVER_IXN_GUID,
        IRF.INTERACTION_RESOURCE_ID,

        CASE
            WHEN IRF.MEDIA_TYPE_KEY = 1
                THEN 'Voice Agent'
            WHEN IRF.MEDIA_TYPE_KEY = 3
                THEN 'Chat Specialist'
            WHEN IRF.MEDIA_TYPE_KEY = 2
             AND IRF.INTERACTION_TYPE_KEY = 13
                THEN 'Email'
        END AS ACS_CHANNEL_NAME,

        CASE
            WHEN IRF.MEDIA_TYPE_KEY = 3
                THEN IRF.RNK
            ELSE IRF.INTERACTION_RESOURCE_ORDINAL
        END AS ACS_CHANNEL_STEP,

        T.ACS_START_TIME,

        CONVERT_TIMEZONE(
            'UTC',
            'America/New_York',
            DATEADD(
                SECOND,
                IRF.END_TS,
                TO_TIMESTAMP_NTZ('1970-01-01 00:00:00')
            )
        ) AS ACS_END_TIME,

        NULL AS ACS_EVENT_CD,
        NULL AS ACS_INTENT_NAME,
        IRF.MEDIA_TYPE_KEY,
        IRF.PLACE_KEY,

        CASE
            WHEN R.RESOURCE_KEY IS NULL
                THEN '()'
            ELSE
                R.AGENT_FIRST_NAME
                || ' '
                || R.AGENT_LAST_NAME
                || ' ('
                || R.EMPLOYEE_ID
                || ')'
        END AS AGENT_ID,

        IRF.PREV_IRF_ID,
        IRF.CUSTOMER_TALK_COUNT,
        IRF.POST_CONS_XFER_TALK_COUNT,
        IRF.CONF_INIT_TALK_COUNT,
        IRF.CONS_INIT_TALK_COUNT,
        IRF.CONS_RCV_TALK_COUNT,
        IRF.TECHNICAL_DESCRIPTOR_KEY,
        IRF.ROUTING_POINT_DURATION AS QUEUE_TIME,

        CASE
            WHEN IRF.CUSTOMER_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID IS NULL
                THEN IRF.CUSTOMER_TALK_DURATION

            WHEN IRF.POST_CONS_XFER_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.POST_CONS_XFER_TALK_DURATION

            WHEN IRF.CONF_INIT_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.CONF_INIT_TALK_DURATION

            WHEN IRF.CONS_RCV_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.CONS_RCV_TALK_DURATION
        END AS TALK_TIME,

        CASE
            WHEN IRF.CUSTOMER_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID IS NULL
                THEN IRF.CUSTOMER_HOLD_DURATION

            WHEN IRF.POST_CONS_XFER_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.POST_CONS_XFER_HOLD_DURATION

            WHEN IRF.CONF_INIT_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.CONF_INIT_HOLD_DURATION

            WHEN IRF.CONS_RCV_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.CONS_RCV_HOLD_DURATION
        END AS HOLD_TIME,

        CASE
            WHEN IRF.CUSTOMER_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID IS NULL
                THEN IRF.CUSTOMER_ACW_DURATION

            WHEN IRF.CONS_RCV_TALK_COUNT = 1
             AND IRF.PLACE_KEY > 0
             AND IRF.PREV_IRF_ID > 0
                THEN IRF.CONS_RCV_ACW_DURATION
        END AS ACW_TIME

    FROM TEMP2 T

    INNER JOIN {{ source(
        'UTLDB01_CUSADM',
        'INTERACTION_FACT'
    ) }} IFCT
        ON IFCT.MEDIA_SERVER_IXN_GUID =
           T.VOICE_PLATFORM_FULL_CALL_ID_MEDIA_SERVER_IXN_GUID

    INNER JOIN IRF_RANKED IRF
        ON IRF.INTERACTION_ID = IFCT.INTERACTION_ID

    LEFT JOIN {{ source(
        'UTLDB01_CUSADM',
        'RESOURCE_'
    ) }} R
        ON IRF.RESOURCE_KEY = R.RESOURCE_KEY
),

RES_1 AS
(
    SELECT DISTINCT
        RES.*,

        CASE
            WHEN PLACE_KEY > 0
             AND PREV_IRF_ID IS NULL
             AND CUSTOMER_TALK_COUNT = 1
                THEN
                    'First Agent Handled by '
                    || AGENT_ID
                    || ' With QT of '
                    || QUEUE_TIME
                    || ' secs and Handle Time of '
                    || (TALK_TIME + HOLD_TIME + ACW_TIME)
                    || ' secs'

            WHEN PLACE_KEY > 0
             AND PREV_IRF_ID > 0
             AND POST_CONS_XFER_TALK_COUNT = 1
                THEN
                    'Internal Transferred to '
                    || AGENT_ID
                    || ' With QT of '
                    || QUEUE_TIME
                    || ' secs and Handle Time of '
                    || (TALK_TIME + HOLD_TIME + ACW_TIME)
                    || ' secs'

            WHEN PLACE_KEY > 0
             AND PREV_IRF_ID > 0
             AND CONS_INIT_TALK_COUNT = 1
                THEN
                    'Consultation Initiated by '
                    || AGENT_ID

            WHEN PLACE_KEY > 0
             AND PREV_IRF_ID > 0
             AND CONS_RCV_TALK_COUNT = 1
                THEN
                    'Consulted with '
                    || AGENT_ID
                    || ' With QT of '
                    || QUEUE_TIME
                    || ' secs and Handle Time of '
                    || (TALK_TIME + HOLD_TIME + ACW_TIME)
                    || ' secs'

            WHEN PLACE_KEY > 0
             AND PREV_IRF_ID > 0
             AND CONF_INIT_TALK_COUNT = 1
                THEN
                    'Internal Conferenced with '
                    || AGENT_ID
                    || ' With QT of '
                    || QUEUE_TIME
                    || ' secs and Handle Time of '
                    || (TALK_TIME + HOLD_TIME + ACW_TIME)
                    || ' secs'

            WHEN TECHNICAL_DESCRIPTOR_KEY IN
            (
                1, 6, 11, 16, 21, 26, 30, 33, 55, 56, 61, 82,
                119, 118, 127, 123, 122, 121, 120, 207, 202,
                208, 209
            )
                THEN 'ABANDONED'

            WHEN TECHNICAL_DESCRIPTOR_KEY IN
            (
                38, 39, 36, 37, 42, 43, 40, 41, 46, 47, 44,
                45, 59, 58, 57, 63, 62, 84, 83, 129, 128,
                131, 133, 132, 134, 201, 220, 221, 222, 223,
                224, 244
            )
                THEN 'CUSTOMER ABANDONED'

            ELSE NULL
        END AS ACS_EVENT_DESC

    FROM RES
),

SQ_CALLS_INTERACTION1 AS
(
    SELECT
        RES_1.*
    FROM RES_1

    {% if is_incremental() %}

    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM {{ this }} ACS
        WHERE RES_1.ACS_BILL_ACC_NB = ACS.ACS_BILL_ACCT_NB
          AND RES_1.ACS_INTERACTION_ID = ACS.ACS_INTERACTION_ID
          AND RES_1.ACS_CHANNEL_STEP = ACS.ACS_CHANNEL_STEP
          AND RES_1.ACCOUNT_D_ID = ACS.ACCOUNT_D_ID
          AND RES_1.ACS_START_TIME = ACS.ACS_START_TIME
    )

    {% endif %}
),

EXP_AUDIT_COLS1 AS
(
    SELECT
        ACS_BILL_ACC_NB AS ACS_BILL_ACCT_NB,
        ACCOUNT_D_ID,
        ACS_INTERACTION_ID,
        MEDIA_SERVER_IXN_GUID,
        INTERACTION_RESOURCE_ID,
        ACS_CHANNEL_NAME,
        ACS_CHANNEL_STEP,
        ACS_START_TIME,
        ACS_END_TIME,
        ACS_EVENT_CD,
        ACS_INTENT_NAME,
        MEDIA_TYPE_KEY,
        PLACE_KEY,
        AGENT_ID,
        PREV_IRF_ID,
        CUSTOMER_TALK_COUNT,
        POST_CONS_XFER_TALK_COUNT,
        CONF_INIT_TALK_COUNT,
        CONS_INIT_TALK_COUNT,
        CONS_RCV_TALK_COUNT,
        TECHNICAL_DESCRIPTOR_KEY AS TECHNICAL_DESCRIPTOR,
        QUEUE_TIME,
        TALK_TIME,
        HOLD_TIME,
        ACW_TIME,
        ACS_EVENT_DESC,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,

        's_m_AGENT_CHAT_SPECIALIST_JAR_F_INCR'::VARCHAR(50)
            AS EDW_CRTE_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        's_m_AGENT_CHAT_SPECIALIST_JAR_F_INCR'::VARCHAR(50)
            AS EDW_LAST_UPDT_NM

    FROM SQ_CALLS_INTERACTION1
),

AGG_REMOVE_DUPLICATES AS
(
    SELECT
        EDW_LAST_UPDT_NM,
        MEDIA_SERVER_IXN_GUID,
        INTERACTION_RESOURCE_ID,
        MEDIA_TYPE_KEY,
        PLACE_KEY,
        ACS_START_TIME,
        ACS_END_TIME,
        AGENT_ID,
        ACS_EVENT_CD,
        CONS_RCV_TALK_COUNT,
        TALK_TIME,
        HOLD_TIME,
        ACW_TIME,
        POST_CONS_XFER_TALK_COUNT,
        CONF_INIT_TALK_COUNT,
        TECHNICAL_DESCRIPTOR,
        QUEUE_TIME,
        CUSTOMER_TALK_COUNT,
        PREV_IRF_ID,
        CONS_INIT_TALK_COUNT,
        ACS_INTENT_NAME,
        ACS_CHANNEL_NAME,
        ACS_EVENT_DESC,
        ACS_BILL_ACCT_NB,
        ACS_INTERACTION_ID,
        ACS_CHANNEL_STEP,
        ACCOUNT_D_ID,
        EDW_CRTE_TS,
        EDW_CRTE_NM,
        EDW_LAST_UPDT_TS

    FROM EXP_AUDIT_COLS1

    QUALIFY ROW_NUMBER() OVER
    (
        PARTITION BY
            ACS_INTERACTION_ID,
            MEDIA_SERVER_IXN_GUID,
            INTERACTION_RESOURCE_ID,
            PLACE_KEY,
            TECHNICAL_DESCRIPTOR,
            QUEUE_TIME,
            TALK_TIME
        ORDER BY
            ACS_INTERACTION_ID,
            MEDIA_SERVER_IXN_GUID,
            INTERACTION_RESOURCE_ID,
            PLACE_KEY,
            TECHNICAL_DESCRIPTOR,
            QUEUE_TIME,
            TALK_TIME
    ) = 1
)

SELECT
    EDW_LAST_UPDT_NM,
    MEDIA_SERVER_IXN_GUID,
    INTERACTION_RESOURCE_ID,
    MEDIA_TYPE_KEY,
    PLACE_KEY,
    ACS_START_TIME,
    ACS_END_TIME,
    AGENT_ID,
    ACS_EVENT_CD,
    CONS_RCV_TALK_COUNT,
    TALK_TIME,
    HOLD_TIME,
    ACW_TIME,
    POST_CONS_XFER_TALK_COUNT,
    CONF_INIT_TALK_COUNT,
    TECHNICAL_DESCRIPTOR,
    QUEUE_TIME,
    CUSTOMER_TALK_COUNT,
    PREV_IRF_ID,
    CONS_INIT_TALK_COUNT,
    ACS_INTENT_NAME,
    ACS_CHANNEL_NAME,
    ACS_EVENT_DESC,
    ACS_BILL_ACCT_NB,
    ACS_INTERACTION_ID,
    ACS_CHANNEL_STEP,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS
FROM AGG_REMOVE_DUPLICATES