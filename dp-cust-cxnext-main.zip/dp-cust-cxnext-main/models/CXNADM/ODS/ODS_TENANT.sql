{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='TENANT_KEY',
    merge_update_columns=[
        'TENANT_NAME',
        'TENANT_CFG_DBID',
        'START_TS',
        'END_TS',
        'CREATE_AUDIT_KEY',
        'UPDATE_AUDIT_KEY',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM'
    ],
    meta={"mapping_name": "m_ODS_TENANT"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN0001C_ODS_TENANT')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN0001C_ODS_TENANT')
    ]
) }}

WITH
SQ_TENANT_STG AS
(
    SELECT
          SRC.TENANT_KEY
        , SRC.TENANT_NAME
        , SRC.TENANT_CFG_DBID
        , SRC.START_TS
        , SRC.END_TS
        , SRC.CREATE_AUDIT_KEY
        , SRC.UPDATE_AUDIT_KEY
        , SRC.MD5_CHECKSUM_VAL

        , TGT.TENANT_KEY              AS TGT_TENANT_KEY
        , TGT.TENANT_NAME             AS TGT_TENANT_NAME
        , TGT.TENANT_CFG_DBID         AS TGT_TENANT_CFG_DBID
        , TGT.START_TS                AS TGT_START_TS
        , TGT.END_TS                  AS TGT_END_TS
        , TGT.CREATE_AUDIT_KEY        AS TGT_CREATE_AUDIT_KEY
        , TGT.UPDATE_AUDIT_KEY        AS TGT_UPDATE_AUDIT_KEY

    FROM {{ source('UTLDB01_CXNADM','TENANT_STG') }} SRC
         LEFT OUTER JOIN
         {% if is_incremental() %}
         {{ this }} TGT
         {% else %}
         -- First run: the target table does not exist yet. Stand in a zero-row
         -- relation of the same shape so every SRC row sees TGT.* as NULL and is
         -- routed to the insert branch, which is what a first load must do.
         (
                 SELECT
                     NULL::NUMBER(19,0) AS CREATE_AUDIT_KEY,
                     NULL::NUMBER(10,0) AS END_TS,
                     NULL::NUMBER(10,0) AS START_TS,
                     NULL::NUMBER(10,0) AS TENANT_CFG_DBID,
                     NULL::NUMBER(10,0) AS TENANT_KEY,
                     NULL::VARCHAR(16777216) AS TENANT_NAME,
                     NULL::NUMBER(19,0) AS UPDATE_AUDIT_KEY
                 FROM (SELECT 1 AS DUMMY) DUMMY_ROW
                 WHERE 1 = 0
         ) TGT
         {% endif %}
         
           ON SRC.TENANT_KEY = TGT.TENANT_KEY
),

exp_AUDIT_ODS_TENANT AS
(
    SELECT
          *

        , MD5(
              COALESCE(TO_VARCHAR(TGT_TENANT_KEY),'-1')
            || COALESCE(TGT_TENANT_NAME,'@#$')
            || COALESCE(TO_VARCHAR(TGT_TENANT_CFG_DBID),'-1')
            || COALESCE(TO_VARCHAR(TGT_START_TS),'-1')
            || COALESCE(TO_VARCHAR(TGT_END_TS),'-1')
            || COALESCE(TO_VARCHAR(TGT_CREATE_AUDIT_KEY),'-1')
            || COALESCE(TO_VARCHAR(TGT_UPDATE_AUDIT_KEY),'-1')
          ) AS OUT_TGT_MD5_CHECKSUM_VAL

        , CURRENT_TIMESTAMP() AS OUT_EDW_CRTE_TS
        , 's_m_ODS_TENANT'    AS OUT_EDW_CRTE_NM

        , CURRENT_TIMESTAMP() AS OUT_EDW_LAST_UPDT_TS
        , 's_m_ODS_TENANT'    AS OUT_EDW_LAST_UPDT_NM

        , CASE
             WHEN TENANT_KEY IS NOT NULL
              AND TGT_TENANT_KEY IS NULL
                  THEN 'I'

             WHEN TENANT_KEY IS NOT NULL
              AND TGT_TENANT_KEY IS NOT NULL
              AND MD5_CHECKSUM_VAL <>
                    MD5(
                        COALESCE(TO_VARCHAR(TGT_TENANT_KEY),'-1')
                      || COALESCE(TGT_TENANT_NAME,'@#$')
                      || COALESCE(TO_VARCHAR(TGT_TENANT_CFG_DBID),'-1')
                      || COALESCE(TO_VARCHAR(TGT_START_TS),'-1')
                      || COALESCE(TO_VARCHAR(TGT_END_TS),'-1')
                      || COALESCE(TO_VARCHAR(TGT_CREATE_AUDIT_KEY),'-1')
                      || COALESCE(TO_VARCHAR(TGT_UPDATE_AUDIT_KEY),'-1')
                    )
                  THEN 'U'

             ELSE 'R'
          END AS OUT_RECORD_FLAG

    FROM SQ_TENANT_STG
)

SELECT
    TENANT_KEY,
    TENANT_NAME,
    TENANT_CFG_DBID,
    START_TS,
    END_TS,
    CREATE_AUDIT_KEY,
    UPDATE_AUDIT_KEY,
    OUT_EDW_CRTE_TS AS EDW_CRTE_TS,
    OUT_EDW_CRTE_NM AS EDW_CRTE_NM,
    OUT_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    OUT_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM
FROM exp_AUDIT_ODS_TENANT
WHERE OUT_RECORD_FLAG IN ('I', 'U')

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY TENANT_KEY
    ORDER BY UPDATE_AUDIT_KEY DESC
) = 1