{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_BILLING_F"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1012C_BILLING_F'),
        log_model_start(
            this,
            'DP_CXN1012C_BILLING_F'
        )
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1012C_BILLING_F'),
        log_model_end(
            this,
            'DP_CXN1012C_BILLING_F'
        )
    ]
) }}

WITH JOB_CONTROL AS
(
    SELECT
        JOB_ID,
        START_DATE::TIMESTAMP_NTZ(9) AS START_DATE,
        END_DATE::TIMESTAMP_NTZ(9) AS END_DATE,
        TO_DATE(END_DATE) AS REPORT_DATE
    FROM {{ source(
        'UTLDB01_METADATA',
        'CXNADM_JOB_CONTROL'
    ) }}
    WHERE JOB_NAME = 'BILLING_F'
      AND AUTOSYS_JOB_NAME = 'DP_CXN1012C_BILLING_F'
),

ACCT AS
(
    SELECT
        AD.ACCOUNT_D_ID,
        AD.BILL_ACCOUNT_NB
    FROM {{ source(
        'UTLDB01_CDWADM',
        'ACCOUNT_D'
    ) }} AD
    WHERE AD.CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
      AND AD.ACTIVE_FLAG = 'Y'
      AND AD.BILL_ACCOUNT_NB
          BETWEEN '0100000000' AND '0699999999'
),

ACCT_BILL_HDR AS
(
    SELECT
        BH.BILL_ACCT_NB,
        BH.BILL_HEAD_NB,
        BH.BILL_DT,
        BH.BILL_AT,
        BH.ACCT_BAL_AT
    FROM {{ source(
        'UTLDB01_UTLUSER',
        'ODS_MCS_BILL_HEADER'
    ) }} BH
    WHERE BH.BILL_HEAD_STAT_CD = 'C'
      AND BH.BILL_ACCT_NB
          BETWEEN '0100000000' AND '0699999999'
      AND BH.BILL_DT BETWEEN
          DATEADD(
              MONTH,
              -12,
              (
                  SELECT REPORT_DATE
                  FROM JOB_CONTROL
              )
          )
          AND
          (
              SELECT REPORT_DATE
              FROM JOB_CONTROL
          )

    -- Original frozen mapping window:
    -- BH.BILL_DT BETWEEN
    --     DATEADD(MONTH, -12, TO_DATE('2026-06-30'))
    --     AND TO_DATE('2026-06-30')
),

SRC_1 AS
(
    SELECT
        JC.REPORT_DATE AS REPORT_DT,
        AD.ACCOUNT_D_ID,
        AD.BILL_ACCOUNT_NB,

        COUNT(
            DISTINCT CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -30, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_HEAD_NB
            END
        ) AS LAST30DAYS_BILL_CNT,

        COUNT(
            DISTINCT CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -60, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_HEAD_NB
            END
        ) AS LAST60DAYS_BILL_CNT,

        COUNT(
            DISTINCT CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -90, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_HEAD_NB
            END
        ) AS LAST90DAYS_BILL_CNT,

        COUNT(
            DISTINCT CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_HEAD_NB
            END
        ) AS LAST1YEAR_BILL_CNT,

        DATEDIFF(
            DAY,
            MAX(TO_DATE(BH.BILL_DT)),
            JC.REPORT_DATE
        ) AS DAYS_SINCE_LAST_BILL_CNT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -30, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST30DAYS_AVG_BILL_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -60, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST60DAYS_AVG_BILL_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -90, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST90DAYS_AVG_BILL_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST1YEAR_AVG_BILL_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -30, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST30DAYS_TOTAL_BILL_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -60, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST60DAYS_TOTAL_BILL_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -90, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST90DAYS_TOTAL_BILL_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.BILL_AT
            END
        ) AS LAST1YEAR_TOTAL_BILL_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -30, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST30DAYS_CURRENT_ACCOUNT_BALANCE_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -60, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST60DAYS_CURRENT_ACCOUNT_BALANCE_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -90, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST90DAYS_CURRENT_ACCOUNT_BALANCE_AMT,

        AVG(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST1YEAR_CURRENT_ACCOUNT_BALANCE_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -30, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST30DAYS_TOTAL_ACCOUNT_BALANCE_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -60, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST60DAYS_TOTAL_ACCOUNT_BALANCE_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(DAY, -90, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST90DAYS_TOTAL_ACCOUNT_BALANCE_AMT,

        SUM(
            CASE
                WHEN BH.BILL_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BH.ACCT_BAL_AT
            END
        ) AS LAST1YEAR_TOTAL_ACCOUNT_BALANCE_AMT

    FROM ACCT AD
    CROSS JOIN JOB_CONTROL JC

    LEFT JOIN ACCT_BILL_HDR BH
        ON AD.BILL_ACCOUNT_NB = BH.BILL_ACCT_NB

    GROUP BY
        JC.REPORT_DATE,
        AD.ACCOUNT_D_ID,
        AD.BILL_ACCOUNT_NB
),

BILLABLE_USAGE_SOURCE AS
(
    SELECT
        BU.BILL_ACCT_NB,
        BU.BILL_HEAD_NB,
        BU.BILL_KWH_QY,
        BU.USAG_NBR_DAYS_QY,
        BU.BILL_COMP_NB
    FROM {{ source(
        'UTLDB01_UTLUSER',
        'ODS_MCS_BILLABLE_USAGE'
    ) }} BU
    WHERE TRIM(BU.READ_CD) IS NOT NULL
      AND BU.TIME_OF_DAY_CD = 'T'
      AND BU.BILL_ACCT_NB
          BETWEEN '0100000000' AND '0699999999'
),

BILL_COMPONENT_SOURCE AS
(
    SELECT
        BC.BILL_ACCT_NB,
        BC.BILL_HEAD_NB,
        BC.BILL_COMP_NB,
        BC.BILL_PERD_TO_DT
    FROM {{ source(
        'UTLDB01_UTLUSER',
        'ODS_MCS_BILL_COMPONENT'
    ) }} BC
    WHERE BC.BILL_COMP_STAT_CD = 'G'
      AND BC.BILL_ACCT_NB
          BETWEEN '0100000000' AND '0699999999'
      AND BC.BILL_PERD_TO_DT BETWEEN
          DATEADD(
              MONTH,
              -12,
              (
                  SELECT REPORT_DATE
                  FROM JOB_CONTROL
              )
          )
          AND
          (
              SELECT REPORT_DATE
              FROM JOB_CONTROL
          )

    -- Original frozen mapping window:
    -- BC.BILL_PERD_TO_DT BETWEEN
    --     DATEADD(MONTH, -12, TO_DATE('2026-06-30'))
    --     AND TO_DATE('2026-06-30')
),

BU AS
(
    SELECT
        BUS.BILL_ACCT_NB,
        BUS.BILL_HEAD_NB,
        BCS.BILL_PERD_TO_DT,
        SUM(BUS.BILL_KWH_QY) AS BILL_KWH_QY,
        SUM(BUS.USAG_NBR_DAYS_QY) AS USAG_NBR_DAYS_QY
    FROM BILLABLE_USAGE_SOURCE BUS

    INNER JOIN BILL_COMPONENT_SOURCE BCS
        ON BUS.BILL_ACCT_NB = BCS.BILL_ACCT_NB
       AND BUS.BILL_HEAD_NB = BCS.BILL_HEAD_NB
       AND BUS.BILL_COMP_NB = BCS.BILL_COMP_NB

    GROUP BY
        BUS.BILL_ACCT_NB,
        BUS.BILL_HEAD_NB,
        BCS.BILL_PERD_TO_DT
),

-- Original converted SQL also carried a commented-out SRC_2 version that
-- calculated only the one-year usage measures. It remains superseded by the
-- active 30/60/90-day and one-year implementation below.

SRC_2 AS
(
    SELECT
        AD.ACCOUNT_D_ID,
        AD.BILL_ACCOUNT_NB,

        AVG(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(DAY, -30, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS LAST30DAYS_AVG_ELECTRIC_CONSUMPTION_QY,

        AVG(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(DAY, -60, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS LAST60DAYS_AVG_ELECTRIC_CONSUMPTION_QY,

        AVG(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(DAY, -90, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS LAST90DAYS_AVG_ELECTRIC_CONSUMPTION_QY,

        AVG(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS LAST1YEAR_AVG_ELECTRIC_CONSUMPTION_QY,

        AVG(
            CASE
                WHEN MONTH(BU.BILL_PERD_TO_DT) IN (6, 7, 8, 9)
                 AND BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS SUMMER_AVG_ELECTRIC_CONSUMPTION_QY,

        AVG(
            CASE
                WHEN MONTH(BU.BILL_PERD_TO_DT) IN (1, 2, 3, 12)
                 AND BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS WINTER_AVG_ELECTRIC_CONSUMPTION_QY,

        SUM(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.BILL_KWH_QY
            END
        ) AS LAST1YEAR_TOTAL_ELECTRIC_CONSUMPTION_QY,

        AVG(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.USAG_NBR_DAYS_QY
            END
        ) AS AVG_BILLING_DAYS,

        SUM(
            CASE
                WHEN BU.BILL_PERD_TO_DT BETWEEN
                     DATEADD(MONTH, -12, JC.REPORT_DATE)
                     AND JC.REPORT_DATE
                    THEN BU.USAG_NBR_DAYS_QY
            END
        ) AS B_SUM_BILLING_DAYS

    FROM ACCT AD
    CROSS JOIN JOB_CONTROL JC

    INNER JOIN ACCT_BILL_HDR BH
        ON AD.BILL_ACCOUNT_NB = BH.BILL_ACCT_NB

    INNER JOIN BU
        ON BH.BILL_ACCT_NB = BU.BILL_ACCT_NB
       AND BH.BILL_HEAD_NB = BU.BILL_HEAD_NB

    GROUP BY
        AD.ACCOUNT_D_ID,
        AD.BILL_ACCOUNT_NB
),

BILLING_SOURCE AS
(
    SELECT
        S1.REPORT_DT,
        S1.ACCOUNT_D_ID,
        S1.BILL_ACCOUNT_NB,
        S1.LAST30DAYS_BILL_CNT,
        S1.LAST60DAYS_BILL_CNT,
        S1.LAST90DAYS_BILL_CNT,
        S1.LAST1YEAR_BILL_CNT,
        S1.DAYS_SINCE_LAST_BILL_CNT,
        S1.LAST30DAYS_AVG_BILL_AMT,
        S1.LAST60DAYS_AVG_BILL_AMT,
        S1.LAST90DAYS_AVG_BILL_AMT,
        S1.LAST1YEAR_AVG_BILL_AMT,
        S1.LAST30DAYS_TOTAL_BILL_AMT,
        S1.LAST60DAYS_TOTAL_BILL_AMT,
        S1.LAST90DAYS_TOTAL_BILL_AMT,
        S1.LAST1YEAR_TOTAL_BILL_AMT,
        S1.LAST30DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        S1.LAST60DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        S1.LAST90DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        S1.LAST1YEAR_CURRENT_ACCOUNT_BALANCE_AMT,
        S1.LAST30DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        S1.LAST60DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        S1.LAST90DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        S1.LAST1YEAR_TOTAL_ACCOUNT_BALANCE_AMT,
        S2.LAST30DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        S2.LAST60DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        S2.LAST90DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        S2.LAST1YEAR_AVG_ELECTRIC_CONSUMPTION_QY,
        S2.SUMMER_AVG_ELECTRIC_CONSUMPTION_QY,
        S2.WINTER_AVG_ELECTRIC_CONSUMPTION_QY,
        S2.LAST1YEAR_TOTAL_ELECTRIC_CONSUMPTION_QY,
        S2.AVG_BILLING_DAYS,

        S1.LAST1YEAR_TOTAL_BILL_AMT
            / NULLIF(
                S2.B_SUM_BILLING_DAYS,
                0
            ) AS AVG_BILL_AMT_PER_DAY,

        S2.LAST1YEAR_TOTAL_ELECTRIC_CONSUMPTION_QY
            / NULLIF(
                S2.B_SUM_BILLING_DAYS,
                0
            ) AS AVG_QY_PER_DAY

    FROM SRC_1 S1

    LEFT JOIN SRC_2 S2
        ON S1.ACCOUNT_D_ID = S2.ACCOUNT_D_ID
       AND S1.BILL_ACCOUNT_NB = S2.BILL_ACCOUNT_NB
),

SQ_BILLING_F AS
(
    SELECT
        SRC.REPORT_DT,
        SRC.ACCOUNT_D_ID,
        SRC.BILL_ACCOUNT_NB,
        SRC.LAST30DAYS_BILL_CNT,
        SRC.LAST60DAYS_BILL_CNT,
        SRC.LAST90DAYS_BILL_CNT,
        SRC.LAST1YEAR_BILL_CNT,
        SRC.DAYS_SINCE_LAST_BILL_CNT,
        SRC.LAST30DAYS_AVG_BILL_AMT,
        SRC.LAST60DAYS_AVG_BILL_AMT,
        SRC.LAST90DAYS_AVG_BILL_AMT,
        SRC.LAST1YEAR_AVG_BILL_AMT,
        SRC.LAST30DAYS_TOTAL_BILL_AMT,
        SRC.LAST60DAYS_TOTAL_BILL_AMT,
        SRC.LAST90DAYS_TOTAL_BILL_AMT,
        SRC.LAST1YEAR_TOTAL_BILL_AMT,
        SRC.LAST30DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        SRC.LAST60DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        SRC.LAST90DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        SRC.LAST1YEAR_CURRENT_ACCOUNT_BALANCE_AMT,
        SRC.LAST30DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        SRC.LAST60DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        SRC.LAST90DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        SRC.LAST1YEAR_TOTAL_ACCOUNT_BALANCE_AMT,
        SRC.LAST30DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        SRC.LAST60DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        SRC.LAST90DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        SRC.LAST1YEAR_AVG_ELECTRIC_CONSUMPTION_QY,
        SRC.SUMMER_AVG_ELECTRIC_CONSUMPTION_QY,
        SRC.WINTER_AVG_ELECTRIC_CONSUMPTION_QY,
        SRC.LAST1YEAR_TOTAL_ELECTRIC_CONSUMPTION_QY,
        SRC.AVG_BILLING_DAYS,
        SRC.AVG_BILL_AMT_PER_DAY,
        SRC.AVG_QY_PER_DAY
    FROM BILLING_SOURCE SRC

    {% if is_incremental() %}

    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM {{ this }} BF

        -- Physical target:
        -- UTLDB01_DEV_SANDBOX.CXNADM.BILLING_F

        WHERE BF.REPORT_DT = SRC.REPORT_DT
          AND BF.BILL_ACCOUNT_NB = SRC.BILL_ACCOUNT_NB
    )

    {% endif %}
),

EXP_AUDIT_COLS AS
(
    SELECT
        REPORT_DT,
        BILL_ACCOUNT_NB,
        ACCOUNT_D_ID,

        's_m_BILLING_F_01_06'::VARCHAR(50)
            AS EDW_CRTE_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,

        's_m_BILLING_F_01_06'::VARCHAR(50)
            AS EDW_LAST_UPDT_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        LAST30DAYS_BILL_CNT,
        LAST60DAYS_BILL_CNT,
        LAST90DAYS_BILL_CNT,
        LAST1YEAR_BILL_CNT,
        DAYS_SINCE_LAST_BILL_CNT,
        LAST30DAYS_AVG_BILL_AMT,
        LAST60DAYS_AVG_BILL_AMT,
        LAST90DAYS_AVG_BILL_AMT,
        LAST1YEAR_AVG_BILL_AMT,
        LAST30DAYS_TOTAL_BILL_AMT,
        LAST60DAYS_TOTAL_BILL_AMT,
        LAST90DAYS_TOTAL_BILL_AMT,
        LAST1YEAR_TOTAL_BILL_AMT,
        LAST30DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        LAST60DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        LAST90DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
        LAST1YEAR_CURRENT_ACCOUNT_BALANCE_AMT,
        LAST1YEAR_TOTAL_ACCOUNT_BALANCE_AMT,
        LAST90DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        LAST30DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        LAST60DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
        LAST30DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        LAST60DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        LAST90DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
        LAST1YEAR_AVG_ELECTRIC_CONSUMPTION_QY,
        SUMMER_AVG_ELECTRIC_CONSUMPTION_QY,
        WINTER_AVG_ELECTRIC_CONSUMPTION_QY,
        LAST1YEAR_TOTAL_ELECTRIC_CONSUMPTION_QY,
        AVG_BILLING_DAYS,
        AVG_BILL_AMT_PER_DAY,
        AVG_QY_PER_DAY

    FROM SQ_BILLING_F
)

SELECT
    REPORT_DT,
    BILL_ACCOUNT_NB,
    ACCOUNT_D_ID,
    EDW_CRTE_NM,
    EDW_CRTE_TS,
    EDW_LAST_UPDT_NM,
    EDW_LAST_UPDT_TS,
    LAST30DAYS_BILL_CNT,
    LAST60DAYS_BILL_CNT,
    LAST90DAYS_BILL_CNT,
    LAST1YEAR_BILL_CNT AS LAST1YEARDAYS_BILL_CNT,
    DAYS_SINCE_LAST_BILL_CNT,
    LAST30DAYS_AVG_BILL_AMT,
    LAST60DAYS_AVG_BILL_AMT,
    LAST90DAYS_AVG_BILL_AMT,
    LAST1YEAR_AVG_BILL_AMT AS LAST1YEARDAYS_AVG_BILL_AMT,
    LAST30DAYS_TOTAL_BILL_AMT,
    LAST60DAYS_TOTAL_BILL_AMT,
    LAST90DAYS_TOTAL_BILL_AMT,
    LAST1YEAR_TOTAL_BILL_AMT,
    LAST30DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
    LAST60DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
    LAST90DAYS_CURRENT_ACCOUNT_BALANCE_AMT,
    LAST1YEAR_CURRENT_ACCOUNT_BALANCE_AMT,
    LAST1YEAR_TOTAL_ACCOUNT_BALANCE_AMT,
    LAST90DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
    LAST30DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
    LAST60DAYS_TOTAL_ACCOUNT_BALANCE_AMT,
    LAST30DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
    LAST60DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
    LAST90DAYS_AVG_ELECTRIC_CONSUMPTION_QY,
    LAST1YEAR_AVG_ELECTRIC_CONSUMPTION_QY,
    SUMMER_AVG_ELECTRIC_CONSUMPTION_QY,
    WINTER_AVG_ELECTRIC_CONSUMPTION_QY,
    LAST1YEAR_TOTAL_ELECTRIC_CONSUMPTION_QY,
    AVG_BILLING_DAYS,
    AVG_BILL_AMT_PER_DAY,
    AVG_QY_PER_DAY
FROM EXP_AUDIT_COLS