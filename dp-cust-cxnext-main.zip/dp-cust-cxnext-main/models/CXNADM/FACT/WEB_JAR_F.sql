
{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_WEB_JAR_F"},
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1014C_WEB_JAR_F'),
        log_model_start(this, 'DP_CXN1014C_WEB_JAR_F')
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1014C_WEB_JAR_F'),
        log_model_end(this, 'DP_CXN1014C_WEB_JAR_F')
    ]
) }}
WITH 
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME= 'WEB_JAR_F' AND AUTOSYS_JOB_NAME = 'DP_CXN1014C_WEB_JAR_F') ,


sq_SQL_OVERRIDE AS
(
    WITH LD AS
    (
        SELECT
            A.WEB_BILL_ACCT_NB,
            A.WEB_INTERACTION_ID,
            ROW_NUMBER() OVER
            (
                PARTITION BY
                    A.WEB_BILL_ACCT_NB,
                    A.WEB_INTERACTION_ID
                ORDER BY
                    A.WEB_START_TIME,
                    A.WEB_EVENT_ID
            ) AS WEB_CHANNEL_STEP,
            A.ACCOUNT_D_ID,
            A.WEB_CHANNEL_NAME,
            A.WEB_EVENT_ID,
            A.WEB_EVENT_CD,
            A.SERVER_NM,
            A.ENVIRONMENT_NM,
            A.WEB_USER_REMOTE_IP,
            A.WEB_EVENT_PROCESS_CD,
            A.WEB_EVENT_SUBPROCESS_CD,
            A.URL_TXT,
            A.URL_REFERRER_TXT,
            A.WEB_USER_EMAIL,
            A.WEB_USER_PHONE_NB,
            A.WEB_ID,
            A.WEB_ACCESS_TYPE_CD,
            A.WEB_USER_AGENT_TXT,
            A.WEB_REQUEST_ID,
            A.WEB_INTENT_NAME,
            A.WEB_EVENT_DESC,
            A.WEB_START_TIME,
            A.WEB_END_TIME
        FROM
        (
            SELECT
                W.WEB_BILL_ACCT_NB,
                W.WEB_INTERACTION_ID,
                ACT.ACCOUNT_D_ID,
                W.WEB_CHANNEL_NAME,
                W.WEB_EVENT_ID,
                W.WEB_EVENT_CD,
                W.SERVER_NM,
                W.ENVIRONMENT_NM,
                W.WEB_USER_REMOTE_IP,
                W.WEB_EVENT_PROCESS_CD,
                W.WEB_EVENT_SUBPROCESS_CD,
                W.URL_TXT,
                W.URL_REFERRER_TXT,
                W.WEB_USER_EMAIL,
                W.WEB_USER_PHONE_NB,
                W.WEB_ID,
                W.WEB_ACCESS_TYPE_CD,
                W.WEB_USER_AGENT_TXT,
                W.WEB_REQUEST_ID,
                W.WEB_INTENT_NAME,
                W.WEB_EVENT_DESC,
                W.WEB_START_TIME,
                W.WEB_END_TIME

            FROM
            (
                SELECT
                    TRIM(
                        WEB_EVENT_LOGS.WEB_USER_BILL_ACCOUNT_NB
                    ) AS WEB_BILL_ACCT_NB,
                    TRIM(
                        WEB_EVENT_LOGS.WEB_SESSION_ID
                    ) AS WEB_INTERACTION_ID,
                    WEB_EVENT_LOGS.ACCOUNT_D_ID AS ACCOUNT_D_ID,
                    CASE
                        WHEN TRIM(
                            WEB_EVENT_LOGS.WEB_ACCESS_TYPE_CD
                        ) = 'M'
                            THEN 'Web-Mobile'
                        ELSE 'Web-Desktop'
                    END AS WEB_CHANNEL_NAME,
                    WEB_EVENT_LOGS.WEB_EVENT_ID
                        AS WEB_EVENT_ID,
                    WEB_EVENT_LOGS.WEB_EVENT_CD
                        AS WEB_EVENT_CD,
                    WEB_EVENT_LOGS.SERVER_NM
                        AS SERVER_NM,
                    WEB_EVENT_LOGS.ENVIRONMENT_NM
                        AS ENVIRONMENT_NM,
                    WEB_EVENT_LOGS.WEB_USER_REMOTE_IP
                        AS WEB_USER_REMOTE_IP,
                    WEB_EVENT_LOGS.WEB_EVENT_PROCESS_CD
                        AS WEB_EVENT_PROCESS_CD,
                    WEB_EVENT_LOGS.WEB_EVENT_SUBPROCESS_CD
                        AS WEB_EVENT_SUBPROCESS_CD,
                    WEB_EVENT_LOGS.URL_TXT
                        AS URL_TXT,
                    WEB_EVENT_LOGS.URL_REFERRER_TXT
                        AS URL_REFERRER_TXT,
                    WEB_EVENT_LOGS.WEB_USER_EMAIL
                        AS WEB_USER_EMAIL,
                    WEB_EVENT_LOGS.WEB_USER_PHONE_NB
                        AS WEB_USER_PHONE_NB,
                    WEB_EVENT_LOGS.WEB_ID
                        AS WEB_ID,
                    WEB_EVENT_LOGS.WEB_ACCESS_TYPE_CD
                        AS WEB_ACCESS_TYPE_CD,
                    WEB_EVENT_LOGS.WEB_USER_AGENT_TXT
                        AS WEB_USER_AGENT_TXT,
                    WEB_EVENT_LOGS.WEB_REQUEST_ID
                        AS WEB_REQUEST_ID,
                    WEB_EVENT_LOGS.WEB_EVENT_PROCESS_CD
                        AS WEB_INTENT_NAME,
                    WEB_EVENT_LOGS.WEB_EVENT_SUBPROCESS_CD
                        AS WEB_EVENT_DESC,
                    CAST(
                        WEB_EVENT_LOGS.WEB_EVENT_TS
                        AS TIMESTAMP_NTZ(9)
                    ) AS WEB_START_TIME,
                    CAST(NULL AS TIMESTAMP_NTZ(9))
                        AS WEB_END_TIME
                FROM
                    {{ source('UTLDB01_CXNADM','WEB_EVENT_LOGS') }} WEB_EVENT_LOGS
                WHERE
                    WEB_EVENT_LOGS.ACCOUNT_D_ID IS NOT NULL
                    AND WEB_EVENT_LOGS.WEB_EVENT_DT
                        BETWEEN DATEADD
                        (
                            MONTH,
                            -13,
                            DATE_TRUNC(
                                'DAY',
                                CURRENT_TIMESTAMP()
                            )
                        )
                        AND DATE_TRUNC(
                            'DAY',
                            CURRENT_TIMESTAMP()
                        )
                    AND WEB_EVENT_LOGS.EDW_LAST_UPDT_TS
                        -- BETWEEN TO_TIMESTAMP_NTZ
                        -- (
                        --     '${START_TIME}',
                        --     'YYYY-MM-DD HH24:MI:SS'
                        -- )
                        -- AND TO_TIMESTAMP_NTZ
                        -- (
                        --     '${END_TIME}',
                        --     'YYYY-MM-DD HH24:MI:SS'
                        -- )
                        BETWEEN (SELECT START_DATE FROM JOB_CONTROL)
                        AND (SELECT END_DATE FROM JOB_CONTROL)
            ) W
            INNER JOIN
            (
                SELECT
                    BILL_ACCOUNT_NB,
                    ACCOUNT_D_ID
                FROM
                    {{ source('UTLDB01_CDWADM','ACCOUNT_D') }}
                WHERE
                    CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
                    AND ACTIVE_FLAG = 'Y'
            ) ACT
                ON W.WEB_BILL_ACCT_NB = ACT.BILL_ACCOUNT_NB
        ) A
        ORDER BY
        web_bill_acct_nb,
        web_interaction_id,
        web_event_id
    )

    SELECT
        LD.WEB_BILL_ACCT_NB,
        LD.WEB_INTERACTION_ID,
        LD.WEB_CHANNEL_STEP,
        LD.ACCOUNT_D_ID,
        LD.WEB_CHANNEL_NAME,
        LD.WEB_EVENT_ID,
        LD.WEB_EVENT_CD,
        LD.SERVER_NM,
        LD.ENVIRONMENT_NM,
        LD.WEB_USER_REMOTE_IP,
        LD.WEB_EVENT_PROCESS_CD,
        LD.WEB_EVENT_SUBPROCESS_CD,
        LD.URL_TXT,
        LD.URL_REFERRER_TXT,
        LD.WEB_USER_EMAIL,
        LD.WEB_USER_PHONE_NB,
        LD.WEB_ID,
        LD.WEB_ACCESS_TYPE_CD,
        LD.WEB_USER_AGENT_TXT,
        LD.WEB_REQUEST_ID,
        LD.WEB_INTENT_NAME,
        LD.WEB_EVENT_DESC,
        LD.WEB_START_TIME,
        LD.WEB_END_TIME
    FROM LD
    {% if is_incremental() %}

    -- First run: nothing has been loaded yet, so the anti-join has no target to
    -- check against and every row is new.
    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM
            {{ this }} WJF
        WHERE
            LD.WEB_BILL_ACCT_NB =
                WJF.WEB_BILL_ACCT_NB
            AND LD.WEB_INTERACTION_ID =
                WJF.WEB_INTERACTION_ID
            AND LD.WEB_CHANNEL_STEP =
                WJF.WEB_CHANNEL_STEP
            AND LD.ACCOUNT_D_ID =
                WJF.ACCOUNT_D_ID
            AND LD.WEB_START_TIME =
                WJF.WEB_START_TIME
    )

    {% endif %}
),

exp_Audit_Cols AS
(
    SELECT
        sq_SQL_OVERRIDE.WEB_BILL_ACCT_NB,
        sq_SQL_OVERRIDE.WEB_INTERACTION_ID,
        sq_SQL_OVERRIDE.WEB_CHANNEL_STEP,
        sq_SQL_OVERRIDE.ACCOUNT_D_ID,
        CURRENT_TIMESTAMP()
            AS EDW_CRTE_TS,
        's_m_WEB_JAR_F_INCR'
            AS EDW_CRTE_NM,
        CURRENT_TIMESTAMP()
            AS EDW_LAST_UPDT_TS,
        's_m_WEB_JAR_F_INCR'
            AS EDW_LAST_UPDT_NM,
        sq_SQL_OVERRIDE.WEB_CHANNEL_NAME,
        sq_SQL_OVERRIDE.WEB_EVENT_ID,
        sq_SQL_OVERRIDE.WEB_EVENT_CD,
        sq_SQL_OVERRIDE.SERVER_NM,
        sq_SQL_OVERRIDE.ENVIRONMENT_NM,
        sq_SQL_OVERRIDE.WEB_USER_REMOTE_IP,
        sq_SQL_OVERRIDE.WEB_EVENT_PROCESS_CD,
        sq_SQL_OVERRIDE.WEB_EVENT_SUBPROCESS_CD,
        sq_SQL_OVERRIDE.URL_TXT,
        sq_SQL_OVERRIDE.URL_REFERRER_TXT,
        sq_SQL_OVERRIDE.WEB_USER_EMAIL,
        sq_SQL_OVERRIDE.WEB_USER_PHONE_NB,
        sq_SQL_OVERRIDE.WEB_ID,
        sq_SQL_OVERRIDE.WEB_ACCESS_TYPE_CD,
        sq_SQL_OVERRIDE.WEB_USER_AGENT_TXT,
        sq_SQL_OVERRIDE.WEB_REQUEST_ID,
        sq_SQL_OVERRIDE.WEB_INTENT_NAME,
        sq_SQL_OVERRIDE.WEB_EVENT_DESC,
        sq_SQL_OVERRIDE.WEB_START_TIME,
        sq_SQL_OVERRIDE.WEB_END_TIME
    FROM sq_SQL_OVERRIDE
)
,

final_cte AS (
SELECT
    WEB_BILL_ACCT_NB,
    WEB_INTERACTION_ID,
    WEB_CHANNEL_STEP,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    WEB_CHANNEL_NAME,
    WEB_EVENT_ID,
    WEB_EVENT_CD,
    SERVER_NM,
    ENVIRONMENT_NM,
    WEB_USER_REMOTE_IP,
    WEB_EVENT_PROCESS_CD,
    WEB_EVENT_SUBPROCESS_CD,
    URL_TXT,
    URL_REFERRER_TXT,
    WEB_USER_EMAIL,
    WEB_USER_PHONE_NB,
    WEB_ID,
    WEB_ACCESS_TYPE_CD,
    WEB_USER_AGENT_TXT,
    WEB_REQUEST_ID,
    WEB_INTENT_NAME,
    WEB_EVENT_DESC,
    WEB_START_TIME,
    WEB_END_TIME
FROM exp_Audit_Cols
)

SELECT
    SRC.WEB_BILL_ACCT_NB,
    SRC.WEB_INTERACTION_ID,
    SRC.WEB_CHANNEL_STEP,
    SRC.ACCOUNT_D_ID,
    SRC.EDW_CRTE_TS,
    SRC.EDW_CRTE_NM,
    SRC.EDW_LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_NM,
    SRC.WEB_CHANNEL_NAME,
    SRC.WEB_EVENT_ID,
    SRC.WEB_EVENT_CD,
    SRC.SERVER_NM,
    SRC.ENVIRONMENT_NM,
    SRC.WEB_USER_REMOTE_IP,
    SRC.WEB_EVENT_PROCESS_CD,
    SRC.WEB_EVENT_SUBPROCESS_CD,
    SRC.URL_TXT,
    SRC.URL_REFERRER_TXT,
    SRC.WEB_USER_EMAIL,
    SRC.WEB_USER_PHONE_NB,
    SRC.WEB_ID,
    SRC.WEB_ACCESS_TYPE_CD,
    SRC.WEB_USER_AGENT_TXT,
    SRC.WEB_REQUEST_ID,
    SRC.WEB_INTENT_NAME,
    SRC.WEB_EVENT_DESC,
    SRC.WEB_START_TIME,
    SRC.WEB_END_TIME

FROM
    final_cte SRC