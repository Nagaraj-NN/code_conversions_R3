{{ config(
    materialized='incremental',
    incremental_strategy='append',
    full_refresh=false,
    meta={
        "mapping_name": "m_ARRANGEMENTS_EXTENSIONS_F"
    },
    pre_hook=[
        open_control_window(this, 'DP_CXN1012C_ARRANGEMENTS_EXTENSIONS_F'),
        log_model_start(
            this,
            'DP_CXN1012C_ARRANGEMENTS_EXTENSIONS_F'
        )
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1012C_ARRANGEMENTS_EXTENSIONS_F'),
        log_model_end(
            this,
            'DP_CXN1012C_ARRANGEMENTS_EXTENSIONS_F'
        )
    ]
) }}

WITH JOB_CONTROL AS
(
    SELECT
        JOB_ID,
        START_DATE::TIMESTAMP_NTZ(9) AS START_DATE,
        END_DATE::TIMESTAMP_NTZ(9) AS END_DATE,
        TO_DATE(END_DATE) AS REPORT_DATE
    FROM {{ source(
        'UTLDB01_METADATA',
        'CXNADM_JOB_CONTROL'
    ) }}
    WHERE JOB_NAME = 'ARRANGEMENTS_EXTENSIONS_F'
      AND AUTOSYS_JOB_NAME =
          'DP_CXN1012C_ARRANGEMENTS_EXTENSIONS_F'
),

SQ_ARRANGEMENTS_EXTENSIONS_F AS
(
    WITH ACCT1 AS
    (
        SELECT
            JC.REPORT_DATE AS REPORT_DT,
            AD.BILL_ACCOUNT_NB,
            AD.ACCOUNT_D_ID
        FROM {{ source(
            'UTLDB01_CDWADM',
            'ACCOUNT_D'
        ) }} AD
        CROSS JOIN JOB_CONTROL JC

        -- Original frozen expression:
        -- TO_DATE('2026-07-02', 'YYYY-MM-DD') AS REPORT_DT

        WHERE AD.CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
          AND AD.ACTIVE_FLAG = 'Y'
          AND
          (
                 AD.BILL_ACCOUNT_NB
                     BETWEEN '0100000000' AND '0299999999'
              OR AD.BILL_ACCOUNT_NB
                     BETWEEN '0300000000' AND '0499999999'
              OR AD.BILL_ACCOUNT_NB
                     BETWEEN '0600000000' AND '0699999999'
              OR AD.BILL_ACCOUNT_NB
                     BETWEEN '0700000000' AND '0799999999'
              OR AD.BILL_ACCOUNT_NB
                     BETWEEN '1000000000' AND '1099999999'
              OR AD.BILL_ACCOUNT_NB
                     BETWEEN '9400000000' AND '9599999999'
              OR AD.BILL_ACCOUNT_NB
                     BETWEEN '9600000000' AND '9799999999'
          )
    ),

    ACCT_DTL_A AS
    (
        SELECT
            ACCT1.BILL_ACCOUNT_NB,
            ACCT1.ACCOUNT_D_ID,
            OMBPCE1.STAT_LAST_CHNG_DT,
            OMBPCE1.EXTN_TYPE_CD,
            OMBPCE1.PAY_ARRG_STAT_CD,
            OMBPCE1.PROD_ORDR_NB,
            ACCT1.REPORT_DT
        FROM ACCT1

        LEFT JOIN
        (
            SELECT
                STAT_LAST_CHNG_DT,
                BILL_ACCT_NB,
                EXTN_TYPE_CD,
                PAY_ARRG_STAT_CD,
                PROD_ORDR_NB
            FROM {{ source(
                'UTLDB01_UTLUSER',
                'ODS_MCS_BUS_PA_CRDT_EX'
            ) }} OMBPCE1_SRC
            WHERE STAT_LAST_CHNG_DT >= DATE_TRUNC(
                      'DAY',
                      DATEADD(
                          MONTH,
                          -12,
                          (
                              SELECT REPORT_DATE
                              FROM JOB_CONTROL
                          )
                      )
                  )
              AND EXTN_TYPE_CD IN ('PA', 'PH')
              AND
              (
                     OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '0100000000' AND '0299999999'
                  OR OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '0300000000' AND '0499999999'
                  OR OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '0600000000' AND '0699999999'
                  OR OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '0700000000' AND '0799999999'
                  OR OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '1000000000' AND '1099999999'
                  OR OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '9400000000' AND '9599999999'
                  OR OMBPCE1_SRC.BILL_ACCT_NB
                         BETWEEN '9600000000' AND '9799999999'
              )

            -- Original frozen lower bound:
            -- DATEADD(
            --     MONTH,
            --     -12,
            --     TO_DATE('2026-07-02', 'YYYY-MM-DD')
            -- )
        ) OMBPCE1
            ON ACCT1.BILL_ACCOUNT_NB = OMBPCE1.BILL_ACCT_NB
    ),

    CAR_VAR_RES_1_A AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            COUNT(
                CASE
                    WHEN CALL_EVENT_CD = 452176
                     AND DIR_TYPE_CD = '2010'
                     AND BSNS_CD = 'EPA'
                     AND BSNS_SET_UP_DT
                         BETWEEN CALL_START_DATE AND CALL_END_DATE
                        THEN 1
                END
            ) AS LAST1YEAR_IVR_CONTAINED_PAYMENT_ARRANGEMENT_CALL_CNT,

            COUNT(
                CASE
                    WHEN CALL_EVENT_CD = 442176
                     AND DIR_TYPE_CD = '2010'
                     AND BSNS_CD = 'EPA'
                     AND BSNS_SET_UP_DT
                         BETWEEN CALL_START_DATE AND CALL_END_DATE
                        THEN 1
                END
            ) AS LAST1YEAR_V2DDA_INTENT_PAYMENT_ARRANGEMENT_CNT,

            COUNT(
                CASE
                    WHEN CALL_EVENT_CD = 432176
                     AND DIR_TYPE_CD = '2010'
                     AND BSNS_CD = 'EPA'
                     AND BSNS_SET_UP_DT
                         BETWEEN CALL_START_DATE AND CALL_END_DATE
                        THEN 1
                END
            ) AS LAST1YEAR_WEBDA_INTENT_PAYMENT_ARRANGEMENT_CNT

        FROM
        (
            SELECT
                OMBD1.BILL_ACCOUNT_NB,
                CALLS_DTL1.CALL_EVENT_CD,
                DATE_TRUNC(
                    'DAY',
                    CALLS_DTL1.CALL_START_DATE
                ) AS CALL_START_DATE,
                DATE_TRUNC(
                    'DAY',
                    CALLS_DTL1.CALL_END_DATE
                ) AS CALL_END_DATE,
                OMBD1.BSNS_SET_UP_DT,
                OMBD1.DIR_TYPE_CD,
                OMBD1.BSNS_CD,
                OMBD1.REPORT_DT
            FROM
            (
                SELECT
                    ACCT_DTL_A.BILL_ACCOUNT_NB,
                    ACCT_DTL_A.PROD_ORDR_NB,
                    A1.BSNS_SET_UP_DT,
                    A1.DIR_TYPE_CD,
                    A1.BSNS_CD,
                    ACCT_DTL_A.REPORT_DT
                FROM
                (
                    SELECT
                        BILL_ACCT_NB,
                        PROD_ORDR_NB,
                        BSNS_SET_UP_DT,
                        DIR_TYPE_CD,
                        BSNS_CD
                    FROM {{ source(
                        'UTLDB01_UTLUSER',
                        'ODS_MCS_BUS_DIR'
                    ) }} A1_SRC
                    WHERE DIR_TYPE_CD = '2010'
                      AND BSNS_CD = 'EPA'
                      AND BSNS_SET_UP_DT >= DATE_TRUNC(
                              'DAY',
                              DATEADD(
                                  MONTH,
                                  -12,
                                  (
                                      SELECT REPORT_DATE
                                      FROM JOB_CONTROL
                                  )
                              )
                          )
                      AND
                      (
                             A1_SRC.BILL_ACCT_NB
                                 BETWEEN '0100000000' AND '0299999999'
                          OR A1_SRC.BILL_ACCT_NB
                                 BETWEEN '0300000000' AND '0499999999'
                          OR A1_SRC.BILL_ACCT_NB
                                 BETWEEN '0600000000' AND '0699999999'
                          OR A1_SRC.BILL_ACCT_NB
                                 BETWEEN '0700000000' AND '0799999999'
                          OR A1_SRC.BILL_ACCT_NB
                                 BETWEEN '1000000000' AND '1099999999'
                          OR A1_SRC.BILL_ACCT_NB
                                 BETWEEN '9400000000' AND '9599999999'
                          OR A1_SRC.BILL_ACCT_NB
                                 BETWEEN '9600000000' AND '9799999999'
                      )
                ) A1
                INNER JOIN ACCT_DTL_A
                    ON A1.BILL_ACCT_NB =
                       ACCT_DTL_A.BILL_ACCOUNT_NB
                   AND A1.PROD_ORDR_NB =
                       ACCT_DTL_A.PROD_ORDR_NB
            ) OMBD1

            INNER JOIN
            (
                SELECT DISTINCT
                    CE1.CALL_EVENT_CD,
                    C1.CALL_START_DATE,
                    C1.CALL_END_DATE,
                    C1.BILL_ACCOUNT_NB
                FROM
                (
                    SELECT
                        BILL_ACCOUNT_NB,
                        CALLS_ID,
                        CALL_START_DATE,
                        CALL_END_DATE
                    FROM {{ source(
                        'UTLDB01_CXNADM',
                        'CALLS'
                    ) }}
                    WHERE
                    (
                           BILL_ACCOUNT_NB
                               BETWEEN '0100000000' AND '0299999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '0300000000' AND '0499999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '0600000000' AND '0699999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '0700000000' AND '0799999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '1000000000' AND '1099999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '9400000000' AND '9599999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '9600000000' AND '9799999999'
                    )
                      AND DATE_TRUNC(
                              'DAY',
                              CALL_START_DATE
                          ) >= DATE_TRUNC(
                              'DAY',
                              DATEADD(
                                  MONTH,
                                  -12,
                                  (
                                      SELECT REPORT_DATE
                                      FROM JOB_CONTROL
                                  )
                              )
                          )
                      AND IS_TEST_CALL = 0
                ) C1

                INNER JOIN
                (
                    SELECT
                        CALLS_ID,
                        CALL_EVENT_CD
                    FROM {{ source(
                        'UTLDB01_CXNADM',
                        'CALL_EVENTS'
                    ) }}
                    WHERE CALL_EVENT_CD IN
                    (
                        452176,
                        442176,
                        432176,
                        452175,
                        442175,
                        432175
                    )
                ) CE1
                    ON C1.CALLS_ID = CE1.CALLS_ID
            ) CALLS_DTL1
                ON OMBD1.BILL_ACCOUNT_NB =
                   CALLS_DTL1.BILL_ACCOUNT_NB
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_2_A AS
    (
        SELECT
            BILL_ACCOUNT_NB,

            COUNT(
                CASE
                    WHEN DIR_TYPE_CD = '2010'
                     AND BSNS_CD = 'EPA'
                        THEN 1
                END
            ) AS LAST1YEAR_AGENT_HANDLED_PAYMENT_ARRANGEMENT_CALL_CNT,

            REPORT_DT
        FROM
        (
            SELECT
                ACCT_DTL_A.BILL_ACCOUNT_NB,
                ACCT_DTL_A.PROD_ORDR_NB,
                BUS1.DIR_TYPE_CD,
                BUS1.BSNS_CD,
                HIST1.USER_ID,
                ACCT_DTL_A.REPORT_DT
            FROM ACCT_DTL_A

            INNER JOIN
            (
                SELECT
                    BILL_ACCT_NB,
                    PROD_ORDR_NB,
                    DIR_TYPE_CD,
                    BSNS_CD,
                    TOT_INSM_BSNS_AT,
                    BSNS_SET_UP_DT
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_BUS_DIR'
                ) }} BUS1_SRC
                WHERE DIR_TYPE_CD = '2010'
                  AND BSNS_CD = 'EPA'
                  AND BSNS_SET_UP_DT >= DATE_TRUNC(
                          'DAY',
                          DATEADD(
                              MONTH,
                              -12,
                              (
                                  SELECT REPORT_DATE
                                  FROM JOB_CONTROL
                              )
                          )
                      )
                  AND
                  (
                         BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '0100000000' AND '0299999999'
                      OR BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '0300000000' AND '0499999999'
                      OR BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '0600000000' AND '0699999999'
                      OR BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '0700000000' AND '0799999999'
                      OR BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '1000000000' AND '1099999999'
                      OR BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '9400000000' AND '9599999999'
                      OR BUS1_SRC.BILL_ACCT_NB
                             BETWEEN '9600000000' AND '9799999999'
                  )
            ) BUS1
                ON ACCT_DTL_A.BILL_ACCOUNT_NB = BUS1.BILL_ACCT_NB
               AND ACCT_DTL_A.PROD_ORDR_NB = BUS1.PROD_ORDR_NB

            INNER JOIN
            (
                SELECT
                    BILL_ACCT_NB,
                    USER_ID,
                    LAST_UPDT_TS,
                    TRNS_AT
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_TRANS_HIST_HDR'
                ) }} HIST1_SRC
                WHERE
                (
                       HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '0100000000' AND '0299999999'
                    OR HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '0300000000' AND '0499999999'
                    OR HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '0600000000' AND '0699999999'
                    OR HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '0700000000' AND '0799999999'
                    OR HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '1000000000' AND '1099999999'
                    OR HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '9400000000' AND '9599999999'
                    OR HIST1_SRC.BILL_ACCT_NB
                           BETWEEN '9600000000' AND '9799999999'
                )
                  AND USER_ID NOT IN
                      ('ACCTWEB', 'INTERNET', 'CDSBBOTP')
                  AND USER_ID NOT LIKE 'MCS%'
            ) HIST1
                ON ACCT_DTL_A.BILL_ACCOUNT_NB =
                   HIST1.BILL_ACCT_NB
               AND BUS1.TOT_INSM_BSNS_AT = HIST1.TRNS_AT
               AND DATE_TRUNC(
                       'DAY',
                       BUS1.BSNS_SET_UP_DT
                   ) = DATE_TRUNC(
                       'DAY',
                       HIST1.LAST_UPDT_TS
                   )
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_3_A AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            COUNT(
                CASE
                    WHEN EXTN_TYPE_CD IN ('PA', 'PH')
                     AND WEB_EVENT_PROCESS_CD = 'KPI - EPA'
                     AND WEB_EVENT_SUBPROCESS_CD = 'Confirmation'
                     AND WEB_EVENT_CD = 2153
                        THEN 1
                END
            ) AS LAST1YEAR_WEB_INTENT_PAYMENT_ARRANGEMENT_CNT

        FROM
        (
            SELECT DISTINCT
                ACCT_DTL_A.BILL_ACCOUNT_NB,
                ACCT_DTL_A.EXTN_TYPE_CD,
                WEL1.WEB_EVENT_PROCESS_CD,
                WEL1.WEB_EVENT_SUBPROCESS_CD,
                WEL1.WEB_EVENT_CD,
                WEL1.WEB_EVENT_TS,
                WEL1.WEB_EVENT_LOGS_ID,
                ACCT_DTL_A.REPORT_DT
            FROM ACCT_DTL_A

            INNER JOIN
            (
                SELECT
                    WEB_USER_BILL_ACCOUNT_NB,
                    WEB_EVENT_PROCESS_CD,
                    WEB_EVENT_SUBPROCESS_CD,
                    WEB_EVENT_CD,
                    WEB_EVENT_TS,
                    WEB_EVENT_LOGS_ID
                FROM {{ source(
                    'UTLDB01_CXNADM',
                    'WEB_EVENT_LOGS'
                ) }}
                WHERE WEB_EVENT_PROCESS_CD = 'KPI - EPA'
                  AND WEB_EVENT_SUBPROCESS_CD = 'Confirmation'
                  AND WEB_EVENT_CD = 2153
                  AND WEB_EVENT_TS BETWEEN
                      DATE_TRUNC(
                          'DAY',
                          DATEADD(
                              MONTH,
                              -12,
                              (
                                  SELECT REPORT_DATE
                                  FROM JOB_CONTROL
                              )
                          )
                      )
                      AND DATE_TRUNC(
                          'DAY',
                          (
                              SELECT REPORT_DATE
                              FROM JOB_CONTROL
                          )
                      )
                  AND
                  (
                         WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0100000000' AND '0299999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0300000000' AND '0499999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0600000000' AND '0699999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0700000000' AND '0799999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '1000000000' AND '1099999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '9400000000' AND '9599999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '9600000000' AND '9799999999'
                  )

                -- Original frozen mapping date:
                -- TO_DATE('2026-07-02', 'YYYY-MM-DD')
            ) WEL1
                ON ACCT_DTL_A.BILL_ACCOUNT_NB =
                   WEL1.WEB_USER_BILL_ACCOUNT_NB
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_4_A AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            COUNT(
                CASE
                    WHEN NOTE_DESC_TX IS NOT NULL
                        THEN 1
                END
            ) AS LAST1YEAR_2WAY_INTENT_PAYMENT_ARRANGEMENT_CNT

        FROM
        (
            SELECT
                ACCT_DTL_A.BILL_ACCOUNT_NB,
                OMN.NOTE_DESC_TX,
                ACCT_DTL_A.REPORT_DT
            FROM ACCT_DTL_A

            INNER JOIN
            (
                SELECT
                    NOTE_DESC_TX,
                    BILL_ACCT_NB,
                    CRTN_TS
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_NOTES'
                ) }}
                WHERE NOTE_DESC_TX =
                      'CUSTOMER OFFERED EPA VIA TWO WAY TEXT'
            ) OMN
                ON ACCT_DTL_A.BILL_ACCOUNT_NB =
                   OMN.BILL_ACCT_NB

            INNER JOIN {{ source(
                'UTLDB01_UTLUSER',
                'ODS_MCS_BUS_DIR'
            ) }} BD
                ON ACCT_DTL_A.BILL_ACCOUNT_NB =
                   BD.BILL_ACCT_NB

            WHERE BD.BSNS_SET_UP_DT
                  BETWEEN OMN.CRTN_TS
                      AND DATEADD(HOUR, 24, OMN.CRTN_TS)
              AND BD.DIR_TYPE_CD = '2010'
              AND BD.BSNS_CD = 'EPA'
              AND
              (
                     BD.BILL_ACCT_NB
                         BETWEEN '0100000000' AND '0299999999'
                  OR BD.BILL_ACCT_NB
                         BETWEEN '0300000000' AND '0499999999'
                  OR BD.BILL_ACCT_NB
                         BETWEEN '0600000000' AND '0699999999'
                  OR BD.BILL_ACCT_NB
                         BETWEEN '0700000000' AND '0799999999'
                  OR BD.BILL_ACCT_NB
                         BETWEEN '1000000000' AND '1099999999'
                  OR BD.BILL_ACCT_NB
                         BETWEEN '9400000000' AND '9599999999'
                  OR BD.BILL_ACCT_NB
                         BETWEEN '9600000000' AND '9799999999'
              )
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_5_A AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            CASE
                WHEN SUM(
                    CASE
                        WHEN EXTN_TYPE_CD IN ('PA', 'PH')
                         AND PAY_ARRG_STAT_CD = 'A'
                            THEN 1
                    END
                ) > 0
                    THEN 'Y'
                ELSE 'N'
            END AS EXTENDED_PAYMENT_ARRANGEMENT_ACTIVE_FL,

            CASE
                WHEN SUM(
                    CASE
                        WHEN EXTN_TYPE_CD IN ('PA', 'PH')
                            THEN 1
                    END
                ) > 0
                    THEN 'Y'
                ELSE 'N'
            END AS EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_FL,

            COUNT(
                CASE
                    WHEN EXTN_TYPE_CD IN ('PA', 'PH')
                        THEN 1
                END
            ) AS EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_CNT

        FROM
        (
            SELECT
                ACCT_DTL_A.BILL_ACCOUNT_NB,
                ACCT_DTL_A.PROD_ORDR_NB,
                ACCT_DTL_A.REPORT_DT,
                ACCT_DTL_A.PAY_ARRG_STAT_CD,
                ACCT_DTL_A.EXTN_TYPE_CD
            FROM
            (
                SELECT
                    BILL_ACCT_NB,
                    PROD_ORDR_NB,
                    BSNS_SET_UP_DT,
                    DIR_TYPE_CD,
                    BSNS_CD
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_BUS_DIR'
                ) }} A3_SRC
                WHERE DIR_TYPE_CD = '2010'
                  AND BSNS_CD = 'EPA'
                  AND BSNS_SET_UP_DT >= DATE_TRUNC(
                          'DAY',
                          DATEADD(
                              MONTH,
                              -12,
                              (
                                  SELECT REPORT_DATE
                                  FROM JOB_CONTROL
                              )
                          )
                      )
                  AND
                  (
                         A3_SRC.BILL_ACCT_NB
                             BETWEEN '0100000000' AND '0299999999'
                      OR A3_SRC.BILL_ACCT_NB
                             BETWEEN '0300000000' AND '0499999999'
                      OR A3_SRC.BILL_ACCT_NB
                             BETWEEN '0600000000' AND '0699999999'
                      OR A3_SRC.BILL_ACCT_NB
                             BETWEEN '0700000000' AND '0799999999'
                      OR A3_SRC.BILL_ACCT_NB
                             BETWEEN '1000000000' AND '1099999999'
                      OR A3_SRC.BILL_ACCT_NB
                             BETWEEN '9400000000' AND '9599999999'
                      OR A3_SRC.BILL_ACCT_NB
                             BETWEEN '9600000000' AND '9799999999'
                  )
            ) A3

            INNER JOIN ACCT_DTL_A
                ON A3.BILL_ACCT_NB =
                   ACCT_DTL_A.BILL_ACCOUNT_NB
               AND A3.PROD_ORDR_NB =
                   ACCT_DTL_A.PROD_ORDR_NB
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    RES1_BASE AS
    (
        SELECT
            TEMP1.ACCOUNT_D_ID,
            TEMP1.BILL_ACCOUNT_NB,
            TEMP1.REPORT_DT,
            TEMP6.EXTENDED_PAYMENT_ARRANGEMENT_ACTIVE_FL,
            TEMP6.EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_FL,
            TEMP1.EXTENDED_PAYMENT_ARRANGEMENT_DEFAULTED_LAST1YEAR_CNT,
            TEMP6.EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_CNT,
            TEMP2.LAST1YEAR_IVR_CONTAINED_PAYMENT_ARRANGEMENT_CALL_CNT,
            TEMP3.LAST1YEAR_AGENT_HANDLED_PAYMENT_ARRANGEMENT_CALL_CNT,
            TEMP4.LAST1YEAR_WEB_INTENT_PAYMENT_ARRANGEMENT_CNT,
            TEMP2.LAST1YEAR_V2DDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
            TEMP2.LAST1YEAR_WEBDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
            TEMP5.LAST1YEAR_2WAY_INTENT_PAYMENT_ARRANGEMENT_CNT
        FROM
        (
            SELECT
                BILL_ACCOUNT_NB,
                ACCOUNT_D_ID,

                COUNT(
                    CASE
                        WHEN EXTN_TYPE_CD IN ('PA', 'PH')
                         AND PAY_ARRG_STAT_CD IN ('D', 'R', 'S', 'I')
                            THEN 1
                    END
                ) AS EXTENDED_PAYMENT_ARRANGEMENT_DEFAULTED_LAST1YEAR_CNT,

                REPORT_DT
            FROM ACCT_DTL_A
            GROUP BY
                BILL_ACCOUNT_NB,
                ACCOUNT_D_ID,
                REPORT_DT
        ) TEMP1

        LEFT JOIN CAR_VAR_RES_1_A TEMP2
            ON TEMP1.BILL_ACCOUNT_NB = TEMP2.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_2_A TEMP3
            ON TEMP1.BILL_ACCOUNT_NB = TEMP3.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_3_A TEMP4
            ON TEMP1.BILL_ACCOUNT_NB = TEMP4.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_4_A TEMP5
            ON TEMP1.BILL_ACCOUNT_NB = TEMP5.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_5_A TEMP6
            ON TEMP1.BILL_ACCOUNT_NB = TEMP6.BILL_ACCOUNT_NB
    ),

    RES1 AS
    (
        SELECT
            R.*
        FROM RES1_BASE R

        {% if is_incremental() %}

        WHERE NOT EXISTS
        (
            SELECT
                1
            FROM {{ this }} AEF1
            WHERE AEF1.REPORT_DT = R.REPORT_DT
              AND AEF1.BILL_ACCOUNT_NB = R.BILL_ACCOUNT_NB
        )

        {% endif %}
    ),

    ACCT_DTL_E AS
    (
        SELECT
            ACCT1.BILL_ACCOUNT_NB,
            ACCT1.ACCOUNT_D_ID,
            OMBPCE2.STAT_LAST_CHNG_DT,
            OMBPCE2.EXTN_TYPE_CD,
            OMBPCE2.PAY_ARRG_STAT_CD,
            OMBPCE2.PROD_ORDR_NB,
            ACCT1.REPORT_DT
        FROM ACCT1

        LEFT JOIN
        (
            SELECT
                STAT_LAST_CHNG_DT,
                BILL_ACCT_NB,
                EXTN_TYPE_CD,
                PAY_ARRG_STAT_CD,
                PROD_ORDR_NB
            FROM {{ source(
                'UTLDB01_UTLUSER',
                'ODS_MCS_BUS_PA_CRDT_EX'
            ) }} OMBPCE2_SRC
            WHERE STAT_LAST_CHNG_DT >= DATE_TRUNC(
                      'DAY',
                      DATEADD(
                          MONTH,
                          -12,
                          (
                              SELECT REPORT_DATE
                              FROM JOB_CONTROL
                          )
                      )
                  )
              AND
              (
                     OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '0100000000' AND '0299999999'
                  OR OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '0300000000' AND '0499999999'
                  OR OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '0600000000' AND '0699999999'
                  OR OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '0700000000' AND '0799999999'
                  OR OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '1000000000' AND '1099999999'
                  OR OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '9400000000' AND '9599999999'
                  OR OMBPCE2_SRC.BILL_ACCT_NB
                         BETWEEN '9600000000' AND '9799999999'
              )
        ) OMBPCE2
            ON ACCT1.BILL_ACCOUNT_NB = OMBPCE2.BILL_ACCT_NB
    ),

    CAR_VAR_RES_1_E AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            COUNT(
                CASE
                    WHEN CALL_EVENT_CD = 452175
                     AND DIR_TYPE_CD = '2135'
                     AND BSNS_CD = 'EXT'
                     AND BSNS_SET_UP_DT
                         BETWEEN CALL_START_DATE AND CALL_END_DATE
                        THEN 1
                END
            ) AS LAST1YEAR_IVR_CONTAINED_PAYMENT_EXTENSION_CALL_CNT,

            COUNT(
                CASE
                    WHEN CALL_EVENT_CD = 442175
                     AND DIR_TYPE_CD = '2135'
                     AND BSNS_CD = 'EXT'
                     AND BSNS_SET_UP_DT
                         BETWEEN CALL_START_DATE AND CALL_END_DATE
                        THEN 1
                END
            ) AS LAST1YEAR_V2DDA_INTENT_PAYMENT_EXTENSION_CNT,

            COUNT(
                CASE
                    WHEN CALL_EVENT_CD = 432175
                     AND DIR_TYPE_CD = '2135'
                     AND BSNS_CD = 'EXT'
                     AND BSNS_SET_UP_DT
                         BETWEEN CALL_START_DATE AND CALL_END_DATE
                        THEN 1
                END
            ) AS LAST1YEAR_WEBDA_INTENT_PAYMENT_EXTENSION_CNT

        FROM
        (
            SELECT
                OMBD2.BILL_ACCOUNT_NB,
                CALLS_DTL2.CALL_EVENT_CD,
                DATE_TRUNC(
                    'DAY',
                    CALLS_DTL2.CALL_START_DATE
                ) AS CALL_START_DATE,
                DATE_TRUNC(
                    'DAY',
                    CALLS_DTL2.CALL_END_DATE
                ) AS CALL_END_DATE,
                OMBD2.BSNS_SET_UP_DT,
                OMBD2.DIR_TYPE_CD,
                OMBD2.BSNS_CD,
                OMBD2.REPORT_DT
            FROM
            (
                SELECT
                    ACCT_DTL_E.BILL_ACCOUNT_NB,
                    ACCT_DTL_E.PROD_ORDR_NB,
                    A2.BSNS_SET_UP_DT,
                    A2.DIR_TYPE_CD,
                    A2.BSNS_CD,
                    ACCT_DTL_E.REPORT_DT
                FROM
                (
                    SELECT
                        BILL_ACCT_NB,
                        PROD_ORDR_NB,
                        BSNS_SET_UP_DT,
                        DIR_TYPE_CD,
                        BSNS_CD
                    FROM {{ source(
                        'UTLDB01_UTLUSER',
                        'ODS_MCS_BUS_DIR'
                    ) }} A2_SRC
                    WHERE DIR_TYPE_CD = '2135'
                      AND BSNS_CD = 'EXT'
                      AND BSNS_SET_UP_DT >= DATE_TRUNC(
                              'DAY',
                              DATEADD(
                                  MONTH,
                                  -12,
                                  (
                                      SELECT REPORT_DATE
                                      FROM JOB_CONTROL
                                  )
                              )
                          )
                      AND
                      (
                             A2_SRC.BILL_ACCT_NB
                                 BETWEEN '0100000000' AND '0299999999'
                          OR A2_SRC.BILL_ACCT_NB
                                 BETWEEN '0300000000' AND '0499999999'
                          OR A2_SRC.BILL_ACCT_NB
                                 BETWEEN '0600000000' AND '0699999999'
                          OR A2_SRC.BILL_ACCT_NB
                                 BETWEEN '0700000000' AND '0799999999'
                          OR A2_SRC.BILL_ACCT_NB
                                 BETWEEN '1000000000' AND '1099999999'
                          OR A2_SRC.BILL_ACCT_NB
                                 BETWEEN '9400000000' AND '9599999999'
                          OR A2_SRC.BILL_ACCT_NB
                                 BETWEEN '9600000000' AND '9799999999'
                      )
                ) A2

                INNER JOIN ACCT_DTL_E
                    ON A2.BILL_ACCT_NB =
                       ACCT_DTL_E.BILL_ACCOUNT_NB
                   AND A2.PROD_ORDR_NB =
                       ACCT_DTL_E.PROD_ORDR_NB
            ) OMBD2

            INNER JOIN
            (
                SELECT DISTINCT
                    CE2.CALL_EVENT_CD,
                    C2.CALL_START_DATE,
                    C2.CALL_END_DATE,
                    C2.BILL_ACCOUNT_NB
                FROM
                (
                    SELECT
                        BILL_ACCOUNT_NB,
                        CALLS_ID,
                        CALL_START_DATE,
                        CALL_END_DATE
                    FROM {{ source(
                        'UTLDB01_CXNADM',
                        'CALLS'
                    ) }}
                    WHERE
                    (
                           BILL_ACCOUNT_NB
                               BETWEEN '0100000000' AND '0299999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '0300000000' AND '0499999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '0600000000' AND '0699999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '0700000000' AND '0799999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '1000000000' AND '1099999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '9400000000' AND '9599999999'
                        OR BILL_ACCOUNT_NB
                               BETWEEN '9600000000' AND '9799999999'
                    )
                      AND DATE_TRUNC(
                              'DAY',
                              CALL_START_DATE
                          ) >= DATE_TRUNC(
                              'DAY',
                              DATEADD(
                                  MONTH,
                                  -12,
                                  (
                                      SELECT REPORT_DATE
                                      FROM JOB_CONTROL
                                  )
                              )
                          )
                      AND IS_TEST_CALL = 0
                ) C2

                INNER JOIN
                (
                    SELECT
                        CALLS_ID,
                        CALL_EVENT_CD
                    FROM {{ source(
                        'UTLDB01_CXNADM',
                        'CALL_EVENTS'
                    ) }}
                    WHERE CALL_EVENT_CD IN
                    (
                        452176,
                        442176,
                        432176,
                        452175,
                        442175,
                        432175
                    )
                ) CE2
                    ON C2.CALLS_ID = CE2.CALLS_ID
            ) CALLS_DTL2
                ON OMBD2.BILL_ACCOUNT_NB =
                   CALLS_DTL2.BILL_ACCOUNT_NB
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_2_E AS
    (
        SELECT
            BILL_ACCOUNT_NB,

            COUNT(
                CASE
                    WHEN DIR_TYPE_CD = '2135'
                     AND BSNS_CD = 'EXT'
                        THEN 1
                END
            ) AS LAST1YEAR_AGENT_HANDLED_PAYMENT_EXTENSION_CALL_CNT,

            REPORT_DT
        FROM
        (
            SELECT
                ACCT_DTL_E.BILL_ACCOUNT_NB,
                ACCT_DTL_E.PROD_ORDR_NB,
                BUS2.DIR_TYPE_CD,
                BUS2.BSNS_CD,
                HIST2.USER_ID,
                ACCT_DTL_E.REPORT_DT
            FROM ACCT_DTL_E

            INNER JOIN
            (
                SELECT
                    BILL_ACCT_NB,
                    PROD_ORDR_NB,
                    DIR_TYPE_CD,
                    BSNS_CD,
                    TOT_INSM_BSNS_AT,
                    BSNS_SET_UP_DT
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_BUS_DIR'
                ) }} BUS2_SRC
                WHERE DIR_TYPE_CD = '2135'
                  AND BSNS_CD = 'EXT'
                  AND BSNS_SET_UP_DT >= DATE_TRUNC(
                          'DAY',
                          DATEADD(
                              MONTH,
                              -12,
                              (
                                  SELECT REPORT_DATE
                                  FROM JOB_CONTROL
                              )
                          )
                      )
                  AND
                  (
                         BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '0100000000' AND '0299999999'
                      OR BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '0300000000' AND '0499999999'
                      OR BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '0600000000' AND '0699999999'
                      OR BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '0700000000' AND '0799999999'
                      OR BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '1000000000' AND '1099999999'
                      OR BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '9400000000' AND '9599999999'
                      OR BUS2_SRC.BILL_ACCT_NB
                             BETWEEN '9600000000' AND '9799999999'
                  )
            ) BUS2
                ON ACCT_DTL_E.BILL_ACCOUNT_NB = BUS2.BILL_ACCT_NB
               AND ACCT_DTL_E.PROD_ORDR_NB = BUS2.PROD_ORDR_NB

            INNER JOIN
            (
                SELECT
                    BILL_ACCT_NB,
                    USER_ID,
                    LAST_UPDT_TS,
                    TRNS_AT
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_TRANS_HIST_HDR'
                ) }} HIST2_SRC
                WHERE
                (
                       HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '0100000000' AND '0299999999'
                    OR HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '0300000000' AND '0499999999'
                    OR HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '0600000000' AND '0699999999'
                    OR HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '0700000000' AND '0799999999'
                    OR HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '1000000000' AND '1099999999'
                    OR HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '9400000000' AND '9599999999'
                    OR HIST2_SRC.BILL_ACCT_NB
                           BETWEEN '9600000000' AND '9799999999'
                )
                  AND USER_ID NOT IN
                      ('ACCTWEB', 'INTERNET', 'CDSBBOTP')
                  AND USER_ID NOT LIKE 'MCS%'
            ) HIST2
                ON ACCT_DTL_E.BILL_ACCOUNT_NB =
                   HIST2.BILL_ACCT_NB
               AND BUS2.TOT_INSM_BSNS_AT = HIST2.TRNS_AT
               AND DATE_TRUNC(
                       'DAY',
                       BUS2.BSNS_SET_UP_DT
                   ) = DATE_TRUNC(
                       'DAY',
                       HIST2.LAST_UPDT_TS
                   )
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_3_E AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            COUNT(
                CASE
                    WHEN EXTN_TYPE_CD IN ('CR', 'CA')
                     AND WEB_EVENT_PROCESS_CD =
                         'KPI - Payment Extension'
                     AND WEB_EVENT_SUBPROCESS_CD = 'Confirmation'
                     AND WEB_EVENT_CD = 2162
                        THEN 1
                END
            ) AS LAST1YEAR_WEB_INTENT_PAYMENT_EXTENSION_CNT

        FROM
        (
            SELECT DISTINCT
                ACCT_DTL_E.BILL_ACCOUNT_NB,
                ACCT_DTL_E.EXTN_TYPE_CD,
                WEL2.WEB_EVENT_PROCESS_CD,
                WEL2.WEB_EVENT_SUBPROCESS_CD,
                WEL2.WEB_EVENT_CD,
                WEL2.WEB_EVENT_TS,
                WEL2.WEB_EVENT_LOGS_ID,
                ACCT_DTL_E.REPORT_DT
            FROM ACCT_DTL_E

            INNER JOIN
            (
                SELECT
                    WEB_USER_BILL_ACCOUNT_NB,
                    WEB_EVENT_PROCESS_CD,
                    WEB_EVENT_SUBPROCESS_CD,
                    WEB_EVENT_CD,
                    WEB_EVENT_TS,
                    WEB_EVENT_LOGS_ID
                FROM {{ source(
                    'UTLDB01_CXNADM',
                    'WEB_EVENT_LOGS'
                ) }}
                WHERE WEB_EVENT_PROCESS_CD =
                      'KPI - Payment Extension'
                  AND WEB_EVENT_SUBPROCESS_CD = 'Confirmation'
                  AND WEB_EVENT_CD = 2162
                  AND WEB_EVENT_TS BETWEEN
                      DATE_TRUNC(
                          'DAY',
                          DATEADD(
                              MONTH,
                              -12,
                              (
                                  SELECT REPORT_DATE
                                  FROM JOB_CONTROL
                              )
                          )
                      )
                      AND DATE_TRUNC(
                          'DAY',
                          (
                              SELECT REPORT_DATE
                              FROM JOB_CONTROL
                          )
                      )
                  AND
                  (
                         WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0100000000' AND '0299999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0300000000' AND '0499999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0600000000' AND '0699999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '0700000000' AND '0799999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '1000000000' AND '1099999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '9400000000' AND '9599999999'
                      OR WEB_USER_BILL_ACCOUNT_NB
                             BETWEEN '9600000000' AND '9799999999'
                  )

                -- Original frozen mapping date:
                -- TO_DATE('2026-07-02', 'YYYY-MM-DD')
            ) WEL2
                ON ACCT_DTL_E.BILL_ACCOUNT_NB =
                   WEL2.WEB_USER_BILL_ACCOUNT_NB
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    CAR_VAR_RES_4_E AS
    (
        SELECT
            BILL_ACCOUNT_NB,
            REPORT_DT,

            CASE
                WHEN SUM(
                    CASE
                        WHEN EXTN_TYPE_CD IN ('CR', 'CA')
                            THEN 1
                    END
                ) > 0
                    THEN 'Y'
                ELSE 'N'
            END AS PAYMENT_EXTENSION_LAST1YEAR_FL,

            COUNT(
                CASE
                    WHEN EXTN_TYPE_CD IN ('CR', 'CA')
                        THEN 1
                END
            ) AS PAYMENT_EXTENSION_LAST1YEAR_CNT

        FROM
        (
            SELECT
                ACCT_DTL_E.BILL_ACCOUNT_NB,
                ACCT_DTL_E.PROD_ORDR_NB,
                ACCT_DTL_E.REPORT_DT,
                ACCT_DTL_E.PAY_ARRG_STAT_CD,
                ACCT_DTL_E.EXTN_TYPE_CD
            FROM
            (
                SELECT
                    BILL_ACCT_NB,
                    PROD_ORDR_NB,
                    BSNS_SET_UP_DT,
                    DIR_TYPE_CD,
                    BSNS_CD
                FROM {{ source(
                    'UTLDB01_UTLUSER',
                    'ODS_MCS_BUS_DIR'
                ) }} A4_SRC
                WHERE DIR_TYPE_CD = '2135'
                  AND BSNS_CD = 'EXT'
                  AND BSNS_SET_UP_DT >= DATE_TRUNC(
                          'DAY',
                          DATEADD(
                              MONTH,
                              -12,
                              (
                                  SELECT REPORT_DATE
                                  FROM JOB_CONTROL
                              )
                          )
                      )
                  AND
                  (
                         A4_SRC.BILL_ACCT_NB
                             BETWEEN '0100000000' AND '0299999999'
                      OR A4_SRC.BILL_ACCT_NB
                             BETWEEN '0300000000' AND '0499999999'
                      OR A4_SRC.BILL_ACCT_NB
                             BETWEEN '0600000000' AND '0699999999'
                      OR A4_SRC.BILL_ACCT_NB
                             BETWEEN '0700000000' AND '0799999999'
                      OR A4_SRC.BILL_ACCT_NB
                             BETWEEN '1000000000' AND '1099999999'
                      OR A4_SRC.BILL_ACCT_NB
                             BETWEEN '9400000000' AND '9599999999'
                      OR A4_SRC.BILL_ACCT_NB
                             BETWEEN '9600000000' AND '9799999999'
                  )
            ) A4

            INNER JOIN ACCT_DTL_E
                ON A4.BILL_ACCT_NB =
                   ACCT_DTL_E.BILL_ACCOUNT_NB
               AND A4.PROD_ORDR_NB =
                   ACCT_DTL_E.PROD_ORDR_NB
        )
        GROUP BY
            BILL_ACCOUNT_NB,
            REPORT_DT
    ),

    RES2_BASE AS
    (
        SELECT
            TEMP6.ACCOUNT_D_ID,
            TEMP6.BILL_ACCOUNT_NB,
            TEMP6.REPORT_DT,
            TEMP10.PAYMENT_EXTENSION_LAST1YEAR_FL,
            TEMP10.PAYMENT_EXTENSION_LAST1YEAR_CNT,
            TEMP6.PAYMENT_EXTENSION_DEFAULTED_LAST1YEAR_CNT,
            TEMP7.LAST1YEAR_IVR_CONTAINED_PAYMENT_EXTENSION_CALL_CNT,
            TEMP8.LAST1YEAR_AGENT_HANDLED_PAYMENT_EXTENSION_CALL_CNT,
            TEMP9.LAST1YEAR_WEB_INTENT_PAYMENT_EXTENSION_CNT,
            TEMP7.LAST1YEAR_V2DDA_INTENT_PAYMENT_EXTENSION_CNT,
            TEMP7.LAST1YEAR_WEBDA_INTENT_PAYMENT_EXTENSION_CNT
        FROM
        (
            SELECT
                BILL_ACCOUNT_NB,
                ACCOUNT_D_ID,

                COUNT(
                    CASE
                        WHEN EXTN_TYPE_CD IN ('CR', 'CA')
                         AND PAY_ARRG_STAT_CD IN ('D', 'R', 'S', 'I')
                            THEN 1
                    END
                ) AS PAYMENT_EXTENSION_DEFAULTED_LAST1YEAR_CNT,

                REPORT_DT
            FROM ACCT_DTL_E
            GROUP BY
                BILL_ACCOUNT_NB,
                ACCOUNT_D_ID,
                REPORT_DT
        ) TEMP6

        LEFT JOIN CAR_VAR_RES_1_E TEMP7
            ON TEMP6.BILL_ACCOUNT_NB = TEMP7.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_2_E TEMP8
            ON TEMP6.BILL_ACCOUNT_NB = TEMP8.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_3_E TEMP9
            ON TEMP6.BILL_ACCOUNT_NB = TEMP9.BILL_ACCOUNT_NB

        LEFT JOIN CAR_VAR_RES_4_E TEMP10
            ON TEMP6.BILL_ACCOUNT_NB = TEMP10.BILL_ACCOUNT_NB
    ),

    RES2 AS
    (
        SELECT
            R.*
        FROM RES2_BASE R

        {% if is_incremental() %}

        WHERE NOT EXISTS
        (
            SELECT
                1
            FROM {{ this }} AEF2
            WHERE AEF2.REPORT_DT = R.REPORT_DT
              AND AEF2.BILL_ACCOUNT_NB = R.BILL_ACCOUNT_NB
        )

        {% endif %}
    )

    SELECT
        RES1.ACCOUNT_D_ID,
        RES1.BILL_ACCOUNT_NB,
        RES1.REPORT_DT,
        RES1.EXTENDED_PAYMENT_ARRANGEMENT_ACTIVE_FL,
        RES1.EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_FL,
        RES1.EXTENDED_PAYMENT_ARRANGEMENT_DEFAULTED_LAST1YEAR_CNT,
        RES2.PAYMENT_EXTENSION_LAST1YEAR_FL,
        RES1.EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_CNT,
        RES2.PAYMENT_EXTENSION_LAST1YEAR_CNT,
        RES2.PAYMENT_EXTENSION_DEFAULTED_LAST1YEAR_CNT,
        RES1.LAST1YEAR_IVR_CONTAINED_PAYMENT_ARRANGEMENT_CALL_CNT,
        RES1.LAST1YEAR_AGENT_HANDLED_PAYMENT_ARRANGEMENT_CALL_CNT,
        RES1.LAST1YEAR_WEB_INTENT_PAYMENT_ARRANGEMENT_CNT,
        RES1.LAST1YEAR_V2DDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
        RES1.LAST1YEAR_WEBDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
        RES1.LAST1YEAR_2WAY_INTENT_PAYMENT_ARRANGEMENT_CNT,
        RES2.LAST1YEAR_IVR_CONTAINED_PAYMENT_EXTENSION_CALL_CNT,
        RES2.LAST1YEAR_AGENT_HANDLED_PAYMENT_EXTENSION_CALL_CNT,
        RES2.LAST1YEAR_WEB_INTENT_PAYMENT_EXTENSION_CNT,
        RES2.LAST1YEAR_V2DDA_INTENT_PAYMENT_EXTENSION_CNT,
        RES2.LAST1YEAR_WEBDA_INTENT_PAYMENT_EXTENSION_CNT
    FROM RES1
    INNER JOIN RES2
        ON RES1.ACCOUNT_D_ID = RES2.ACCOUNT_D_ID
       AND RES1.BILL_ACCOUNT_NB = RES2.BILL_ACCOUNT_NB
       AND RES1.REPORT_DT = RES2.REPORT_DT
),

EXP_AUDIT AS
(
    SELECT
        SRC.REPORT_DT,
        SRC.BILL_ACCOUNT_NB,
        SRC.ACCOUNT_D_ID,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,

        CASE
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '0299999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_01_02'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0300000000' AND '0499999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_03_049'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0600000000' AND '0699999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_06_069'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0700000000' AND '0799999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_07_079'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '1000000000' AND '1099999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_10_109'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9599999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_94_95'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '9600000000' AND '9799999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_96_97'
        END AS EDW_CRTE_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        CASE
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '0299999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_01_02'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0300000000' AND '0499999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_03_049'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0600000000' AND '0699999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_06_069'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '0700000000' AND '0799999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_07_079'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '1000000000' AND '1099999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_10_109'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9599999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_94_95'
            WHEN SRC.BILL_ACCOUNT_NB
                 BETWEEN '9600000000' AND '9799999999'
                THEN 's_m_ARRANGEMENTS_EXTENSIONS_F_96_97'
        END AS EDW_LAST_UPDT_NM,

        SRC.EXTENDED_PAYMENT_ARRANGEMENT_ACTIVE_FL,
        SRC.EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_FL,
        SRC.EXTENDED_PAYMENT_ARRANGEMENT_DEFAULTED_LAST1YEAR_CNT,
        SRC.PAYMENT_EXTENSION_LAST1YEAR_CNT,
        SRC.PAYMENT_EXTENSION_DEFAULTED_LAST1YEAR_CNT,
        SRC.PAYMENT_EXTENSION_LAST1YEAR_FL,
        SRC.EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_CNT,
        SRC.LAST1YEAR_IVR_CONTAINED_PAYMENT_ARRANGEMENT_CALL_CNT,
        SRC.LAST1YEAR_AGENT_HANDLED_PAYMENT_ARRANGEMENT_CALL_CNT,
        SRC.LAST1YEAR_WEB_INTENT_PAYMENT_ARRANGEMENT_CNT,
        SRC.LAST1YEAR_V2DDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
        SRC.LAST1YEAR_WEBDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
        SRC.LAST1YEAR_2WAY_INTENT_PAYMENT_ARRANGEMENT_CNT,
        SRC.LAST1YEAR_IVR_CONTAINED_PAYMENT_EXTENSION_CALL_CNT,
        SRC.LAST1YEAR_AGENT_HANDLED_PAYMENT_EXTENSION_CALL_CNT,
        SRC.LAST1YEAR_WEB_INTENT_PAYMENT_EXTENSION_CNT,
        SRC.LAST1YEAR_V2DDA_INTENT_PAYMENT_EXTENSION_CNT,
        SRC.LAST1YEAR_WEBDA_INTENT_PAYMENT_EXTENSION_CNT

    FROM SQ_ARRANGEMENTS_EXTENSIONS_F SRC
)

SELECT
    REPORT_DT,
    BILL_ACCOUNT_NB,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    EXTENDED_PAYMENT_ARRANGEMENT_ACTIVE_FL,
    EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_FL,
    EXTENDED_PAYMENT_ARRANGEMENT_DEFAULTED_LAST1YEAR_CNT,
    PAYMENT_EXTENSION_LAST1YEAR_CNT,
    PAYMENT_EXTENSION_DEFAULTED_LAST1YEAR_CNT,
    PAYMENT_EXTENSION_LAST1YEAR_FL,
    EXTENDED_PAYMENT_ARRANGEMENT_LAST1YEAR_CNT,
    LAST1YEAR_IVR_CONTAINED_PAYMENT_ARRANGEMENT_CALL_CNT,
    LAST1YEAR_AGENT_HANDLED_PAYMENT_ARRANGEMENT_CALL_CNT,
    LAST1YEAR_WEB_INTENT_PAYMENT_ARRANGEMENT_CNT,
    LAST1YEAR_V2DDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
    LAST1YEAR_WEBDA_INTENT_PAYMENT_ARRANGEMENT_CNT,
    LAST1YEAR_2WAY_INTENT_PAYMENT_ARRANGEMENT_CNT,
    LAST1YEAR_IVR_CONTAINED_PAYMENT_EXTENSION_CALL_CNT,
    LAST1YEAR_AGENT_HANDLED_PAYMENT_EXTENSION_CALL_CNT,
    LAST1YEAR_WEB_INTENT_PAYMENT_EXTENSION_CNT,
    LAST1YEAR_V2DDA_INTENT_PAYMENT_EXTENSION_CNT,
    LAST1YEAR_WEBDA_INTENT_PAYMENT_EXTENSION_CNT
FROM EXP_AUDIT