{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='PARTY_ACCOUNT_RELATIONSHIP_F_ID',
    merge_update_columns=[
        'ACCOUNT_RELATIONSHIP_START_DT',
        'ACCOUNT_RELATIONSHIP_END_DT',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM'
    ],
    meta={"mapping_name": "m_PARTY_ACCOUNT_RELATIONSHIP_F"},
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1012C_PARTY_ACCOUNT_RELATIONSHIP_F')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1012C_PARTY_ACCOUNT_RELATIONSHIP_F')
    ]
) }}

WITH SQ_PARTY_D AS (
    SELECT
        SRC.PARTY_D_ID,
        SRC.PARTY_ID,
        SRC.PARTY_SOURCE_CD,
        SRC.PARTY_TYPE_CD,
        SRC.TURN_ON_DT,
        SRC.TURN_OFF_DT,
        SRC.CUST_NB_NULL_TURNOFF,
        SRC.TURN_OFF_DT_NULL,
        TGT.PARTY_ACCOUNT_RELATIONSHIP_F_ID,
        TGT.ACCOUNT_RELATIONSHIP_START_DT,
        TGT.ACCOUNT_RELATIONSHIP_END_DT
    FROM
        (
        SELECT
            PD.PARTY_D_ID,
            PD.PARTY_ID,
            PD.PARTY_SOURCE_CD,
            PD.PARTY_TYPE_CD,
            OM.TURN_ON_DT,
            OM.TURN_OFF_DT,
            NTOFF.CUST_NB_NULL_TURNOFF,
            NTOFF.TURN_OFF_DT_NULL
        FROM
            {{ source('UTLDB01_CDWADM','PARTY_D') }} PD
            INNER JOIN (
            select
                CUST_NB as CUST_NB,
                min(TURN_ON_DT) as TURN_ON_DT,
                max(TURN_OFF_DT) as TURN_OFF_DT
            from
                {{ source('UTLDB01_UTLUSER','ODS_MCS_INDICATIV_DATA') }}
            group by
                CUST_NB
            ) OM ON OM.CUST_NB = PD.PARTY_ID
            LEFT JOIN (
            select
                CUST_NB as CUST_NB_NULL_TURNOFF,
                turn_off_dt as TURN_OFF_DT_NULL
            from
                {{ source('UTLDB01_UTLUSER','ODS_MCS_INDICATIV_DATA') }}
            where
                turn_off_dt is null
                and TURN_ON_DT is not null
            GROUP BY
                CUST_NB,
                turn_off_dt
            ) NTOFF ON PD.PARTY_ID = NTOFF.CUST_NB_NULL_TURNOFF
        WHERE
            PD.PARTY_SOURCE_CD = 'M'
            AND OM.TURN_ON_DT is NOT NULL
        ) SRC
        LEFT OUTER JOIN
        {% if is_incremental() %}
        {{ this }} TGT
        {% else %}
        -- First run: the target table does not exist yet. Stand in a zero-row
        -- relation of the same shape so every SRC row sees TGT.* as NULL and is
        -- routed to the insert branch, which is what a first load must do.
        (
                SELECT
                    NULL::TIMESTAMP_NTZ(9) AS ACCOUNT_RELATIONSHIP_END_DT,
                    NULL::TIMESTAMP_NTZ(9) AS ACCOUNT_RELATIONSHIP_START_DT,
                    NULL::NUMBER(38,0) AS PARTY_ACCOUNT_RELATIONSHIP_F_ID,
                    NULL::VARCHAR(20) AS PARTY_ID,
                    NULL::VARCHAR(10) AS PARTY_SOURCE_CD,
                    NULL::VARCHAR(50) AS PARTY_TYPE_CD
                FROM (SELECT 1 AS DUMMY) DUMMY_ROW
                WHERE 1 = 0
        ) TGT
        {% endif %}
        ON SRC.PARTY_ID = TGT.PARTY_ID
        AND SRC.PARTY_SOURCE_CD = TGT.PARTY_SOURCE_CD
        AND SRC.PARTY_TYPE_CD = TGT.PARTY_TYPE_CD
    ),

    exp_PARTY_ACCOUNT_RELATIONSHIP_F AS (
    SELECT
        SQ_PARTY_D.*,
        IFF(NOT ((CUST_NB_NULL_TURNOFF IS NULL)), TURN_OFF_DT_NULL, TURN_OFF_DT) AS OUT_TURN_OFF_DT,
        CURRENT_TIMESTAMP() AS out_EDW_CRTE_TS,
        's_m_PARTY_ACCOUNT_RELATIONSHIP_F' AS out_EDW_CRTE_NM,
        CURRENT_TIMESTAMP() AS out_EDW_LAST_UPDT_TS,
        's_m_PARTY_ACCOUNT_RELATIONSHIP_F' AS out_EDW_LAST_UPDT_NM
    FROM SQ_PARTY_D

    /* one row per natural key BEFORE a surrogate id is handed out */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PARTY_ID, PARTY_SOURCE_CD, PARTY_TYPE_CD
        ORDER BY OUT_TURN_OFF_DT DESC NULLS LAST
    ) = 1
    ),

    MAX_KEY AS
    (
        {% if is_incremental() %}

        SELECT
            COALESCE(MAX(PARTY_ACCOUNT_RELATIONSHIP_F_ID),0) AS MAX_ID
        FROM {{ this }}

        {% else %}

        -- First run: the target table does not exist yet, so the key sequence
        -- starts from zero.
        SELECT 0::NUMBER(38,0) AS MAX_ID

        {% endif %}
    ),

    cte AS
    (
        SELECT
            E.*,

            CASE
                WHEN PARTY_ACCOUNT_RELATIONSHIP_F_ID IS NULL
                THEN
                    M.MAX_ID
                    + ROW_NUMBER() OVER
                    (
                        ORDER BY
                            PARTY_ID,
                            PARTY_SOURCE_CD,
                            PARTY_TYPE_CD
                    )
            END AS NEW_PARTY_ACCOUNT_RELATIONSHIP_F_ID

        FROM exp_PARTY_ACCOUNT_RELATIONSHIP_F E
        CROSS JOIN MAX_KEY M
    ),

final_cte AS (
SELECT *
    FROM cte
)

SELECT
    COALESCE(PARTY_ACCOUNT_RELATIONSHIP_F_ID, NEW_PARTY_ACCOUNT_RELATIONSHIP_F_ID) AS PARTY_ACCOUNT_RELATIONSHIP_F_ID,
    PARTY_D_ID,
    PARTY_ID,
    PARTY_SOURCE_CD,
    PARTY_TYPE_CD,
    TURN_ON_DT AS ACCOUNT_RELATIONSHIP_START_DT,
    OUT_TURN_OFF_DT AS ACCOUNT_RELATIONSHIP_END_DT,
    out_EDW_CRTE_TS AS EDW_CRTE_TS,
    out_EDW_CRTE_NM AS EDW_CRTE_NM,
    out_EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
    out_EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM

FROM
    final_cte SRC

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY COALESCE(PARTY_ACCOUNT_RELATIONSHIP_F_ID, NEW_PARTY_ACCOUNT_RELATIONSHIP_F_ID)
    ORDER BY PARTY_D_ID
) = 1