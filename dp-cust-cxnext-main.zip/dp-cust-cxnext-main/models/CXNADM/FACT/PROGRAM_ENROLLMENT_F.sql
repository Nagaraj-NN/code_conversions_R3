-- =========================================================================
-- Model      : PROGRAM_ENROLLMENT_F
-- Mapping    : m_PROGRAM_ENROLLMENT_F
-- Target     : UTLDB01_DEV_SANDBOX.CXNADM.PROGRAM_ENROLLMENT_F
-- Load type  : incremental / append
-- -------------------------------------------------------------------------
-- Per-account enrolment snapshot for five customer programmes.
-- REPORT_DT is derived from CXNADM_JOB_CONTROL.END_DATE using the original
-- mapping rule: DATEADD(DAY, -365, TO_DATE(END_DATE)).
-- The carried-over double-subtraction defect in the LAST1YEAR predicates
-- has been corrected. Each LAST1YEAR condition now looks back 365 days
-- from the derived REPORT_DT.
-- =========================================================================

{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_PROGRAM_ENROLLMENT_F"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1012C_PROGRAM_ENROLLMENT_F'),
        log_model_start(
            this,
            'DP_CXN1012C_PROGRAM_ENROLLMENT_F'
        )
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1012C_PROGRAM_ENROLLMENT_F'),
        log_model_end(
            this,
            'DP_CXN1012C_PROGRAM_ENROLLMENT_F'
        )
    ]
) }}

WITH JOB_CONTROL AS
(
    SELECT
        JOB_ID,
        START_DATE::TIMESTAMP_NTZ(9) AS START_DATE,
        END_DATE::TIMESTAMP_NTZ(9) AS END_DATE,
        DATEADD(
            DAY,
            -365,
            TO_DATE(END_DATE)
        ) AS REPORT_DATE
    FROM {{ source(
        'UTLDB01_METADATA',
        'CXNADM_JOB_CONTROL'
    ) }}
    WHERE JOB_NAME = 'PROGRAM_ENROLLMENT_F'
      AND AUTOSYS_JOB_NAME =
          'DP_CXN1012C_PROGRAM_ENROLLMENT_F'
),

ACCT AS
(
    SELECT
        JC.REPORT_DATE,
        AD.BILL_ACCOUNT_NB,
        AD.ACCOUNT_D_ID
    FROM {{ source(
        'UTLDB01_CDWADM',
        'ACCOUNT_D'
    ) }} AD
    CROSS JOIN JOB_CONTROL JC
    WHERE AD.CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
      AND AD.ACTIVE_FLAG = 'Y'
      AND
      (
             AD.BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '0199999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '0200000000' AND '0299999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '0300000000' AND '0399999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '0400000000' AND '0499999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '0600000000' AND '0699999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '0700000000' AND '0799999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '1000000000' AND '1099999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9499999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '9500000000' AND '9599999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '9600000000' AND '9699999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '9700000000' AND '9799999999'
      )
),

AEP_ACCOUNTS AS
(
    SELECT
        BILL_ACCT_NB,
        BILL_ACCT_ID
    FROM {{ source(
        'UTLDB01_CSGADM',
        'AEP_ACCOUNT_DIM'
    ) }}
    WHERE
    (
           BILL_ACCT_NB
               BETWEEN '0100000000' AND '0199999999'
        OR BILL_ACCT_NB
               BETWEEN '0200000000' AND '0299999999'
        OR BILL_ACCT_NB
               BETWEEN '0300000000' AND '0399999999'
        OR BILL_ACCT_NB
               BETWEEN '0400000000' AND '0499999999'
        OR BILL_ACCT_NB
               BETWEEN '0600000000' AND '0699999999'
        OR BILL_ACCT_NB
               BETWEEN '0700000000' AND '0799999999'
        OR BILL_ACCT_NB
               BETWEEN '1000000000' AND '1099999999'
        OR BILL_ACCT_NB
               BETWEEN '9400000000' AND '9499999999'
        OR BILL_ACCT_NB
               BETWEEN '9500000000' AND '9599999999'
        OR BILL_ACCT_NB
               BETWEEN '9600000000' AND '9699999999'
        OR BILL_ACCT_NB
               BETWEEN '9700000000' AND '9799999999'
    )
),

PAPERLESS_DETAIL AS
(
    SELECT
        AD.BILL_ACCOUNT_NB,
        AD.ACCOUNT_D_ID,

        CASE
            WHEN PLF.ACT_FL = 'Y'
             AND PD.PGM_ID IN (7, 8, 9, 10)
                THEN 'Y'
            ELSE 'N'
        END AS PAPERLESS_BILLING_ACTIVE_FL,

        CASE
            WHEN PLF.ACT_FL = 'Y'
             AND PD.PGM_ID IN (7, 8, 9, 10)
             AND PLF.OPT_IN_TS >= DATEADD(
                    DAY,
                    -365,
                    AD.REPORT_DATE
                 )
                THEN 'Y'
            ELSE 'N'
        END AS PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,

        CASE
            WHEN PD.PGM_ID IN (7, 8, 9, 10)
                THEN 'Y'
            ELSE 'N'
        END AS PAPERLESS_BILLING_EVER_ENROLLED_FL

    FROM ACCT AD
    LEFT JOIN AEP_ACCOUNTS AAD
        ON AD.BILL_ACCOUNT_NB = AAD.BILL_ACCT_NB
    INNER JOIN {{ source(
        'UTLDB01_CSGADM',
        'AEP_PGM_PL_FACT'
    ) }} PLF
        ON AAD.BILL_ACCT_ID = PLF.BILL_ACCT_ID
    LEFT JOIN {{ source(
        'UTLDB01_CSGADM',
        'AEP_PGM_DIM'
    ) }} PD
        ON PD.PGM_ID = PLF.PGM_ID
),

CAR_VAL_RES_1 AS
(
    SELECT
        BILL_ACCOUNT_NB,

        IFF(
            SUM(
                IFF(
                    PAPERLESS_BILLING_ACTIVE_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_PAPERLESS_BILLING_ACTIVE_FL,

        IFF(
            SUM(
                IFF(
                    PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,

        IFF(
            SUM(
                IFF(
                    PAPERLESS_BILLING_EVER_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_PAPERLESS_BILLING_EVER_ENROLLED_FL

    FROM PAPERLESS_DETAIL
    GROUP BY BILL_ACCOUNT_NB
),

PROGRAM_DETAIL AS
(
    SELECT
        AD.BILL_ACCOUNT_NB,
        AD.ACCOUNT_D_ID,

        CASE
            WHEN PF.ACT_FL = 'Y'
             AND PD.PGM_ID = 5
                THEN 'Y'
            ELSE 'N'
        END AS AMP_PLAN_ACTIVE_FL,

        CASE
            WHEN PF.ACT_FL = 'Y'
             AND PD.PGM_ID = 5
             AND PF.OPT_IN_TS >= DATEADD(
                    DAY,
                    -365,
                    AD.REPORT_DATE
                 )
                THEN 'Y'
            ELSE 'N'
        END AS AMP_PLAN_LAST1YEAR_ENROLLED_FL,

        CASE
            WHEN PD.PGM_ID = 5
                THEN 'Y'
            ELSE 'N'
        END AS AMP_PLAN_EVER_ENROLLED_FL,

        CASE
            WHEN PF.ACT_FL = 'Y'
             AND PD.PGM_ID = 6
                THEN 'Y'
            ELSE 'N'
        END AS BUDGET_BILLING_PLAN_ACTIVE_FL,

        CASE
            WHEN PF.ACT_FL = 'Y'
             AND PD.PGM_ID = 6
             AND PF.OPT_IN_TS >= DATEADD(
                    DAY,
                    -365,
                    AD.REPORT_DATE
                 )
                THEN 'Y'
            ELSE 'N'
        END AS BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,

        CASE
            WHEN PD.PGM_ID = 6
                THEN 'Y'
            ELSE 'N'
        END AS BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,

        CASE
            WHEN PF.ACT_FL = 'Y'
             AND PD.PGM_ID = 3
                THEN 'Y'
            ELSE 'N'
        END AS PREPAY_PLAN_ACTIVE_FL,

        CASE
            WHEN PF.ACT_FL = 'Y'
             AND PD.PGM_ID = 3
             AND PF.OPT_IN_TS >= DATEADD(
                    DAY,
                    -365,
                    AD.REPORT_DATE
                 )
                THEN 'Y'
            ELSE 'N'
        END AS PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,

        CASE
            WHEN PD.PGM_ID = 3
                THEN 'Y'
            ELSE 'N'
        END AS PREPAY_PLAN_EVER_ENROLLED_FL

    FROM ACCT AD
    LEFT JOIN AEP_ACCOUNTS AAD
        ON AD.BILL_ACCOUNT_NB = AAD.BILL_ACCT_NB
    INNER JOIN {{ source(
        'UTLDB01_CSGADM',
        'AEP_PGM_FACT'
    ) }} PF
        ON AAD.BILL_ACCT_ID = PF.BILL_ACCT_ID
    LEFT JOIN {{ source(
        'UTLDB01_CSGADM',
        'AEP_PGM_DIM'
    ) }} PD
        ON PD.PGM_ID = PF.PGM_ID
),

CAR_VAL_RES_2 AS
(
    SELECT
        BILL_ACCOUNT_NB,

        IFF(
            SUM(IFF(AMP_PLAN_ACTIVE_FL = 'Y', 1, 0)) > 0,
            'Y',
            'N'
        ) AS CNT_AMP_PLAN_ACTIVE_FL,

        IFF(
            SUM(
                IFF(
                    AMP_PLAN_LAST1YEAR_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_AMP_PLAN_LAST1YEAR_ENROLLED_FL,

        IFF(
            SUM(IFF(AMP_PLAN_EVER_ENROLLED_FL = 'Y', 1, 0)) > 0,
            'Y',
            'N'
        ) AS CNT_AMP_PLAN_EVER_ENROLLED_FL,

        IFF(
            SUM(
                IFF(
                    BUDGET_BILLING_PLAN_ACTIVE_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_BUDGET_BILLING_PLAN_ACTIVE_FL,

        IFF(
            SUM(
                IFF(
                    BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,

        IFF(
            SUM(
                IFF(
                    BUDGET_BILLING_PLAN_EVER_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,

        IFF(
            SUM(IFF(PREPAY_PLAN_ACTIVE_FL = 'Y', 1, 0)) > 0,
            'Y',
            'N'
        ) AS CNT_PREPAY_PLAN_ACTIVE_FL,

        IFF(
            SUM(
                IFF(
                    PREPAY_PLAN_LAST1YEAR_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,

        IFF(
            SUM(IFF(PREPAY_PLAN_EVER_ENROLLED_FL = 'Y', 1, 0)) > 0,
            'Y',
            'N'
        ) AS CNT_PREPAY_PLAN_EVER_ENROLLED_FL

    FROM PROGRAM_DETAIL
    GROUP BY BILL_ACCOUNT_NB
),

GREEN_POWER_SOURCE AS
(
    SELECT
        BILL_ACCT_NB,
        GP_AGRMT_STAT_CD,
        GP_EFCT_DT
    FROM {{ source(
        'UTLDB01_UTLUSER',
        'ODS_MCS_BA_GREEN_PWR'
    ) }}
    WHERE
    (
           BILL_ACCT_NB
               BETWEEN '0100000000' AND '0199999999'
        OR BILL_ACCT_NB
               BETWEEN '0200000000' AND '0299999999'
        OR BILL_ACCT_NB
               BETWEEN '0300000000' AND '0399999999'
        OR BILL_ACCT_NB
               BETWEEN '0400000000' AND '0499999999'
        OR BILL_ACCT_NB
               BETWEEN '0600000000' AND '0699999999'
        OR BILL_ACCT_NB
               BETWEEN '0700000000' AND '0799999999'
        OR BILL_ACCT_NB
               BETWEEN '1000000000' AND '1099999999'
        OR BILL_ACCT_NB
               BETWEEN '9400000000' AND '9499999999'
        OR BILL_ACCT_NB
               BETWEEN '9500000000' AND '9599999999'
        OR BILL_ACCT_NB
               BETWEEN '9600000000' AND '9699999999'
        OR BILL_ACCT_NB
               BETWEEN '9700000000' AND '9799999999'
    )
),

RENEWABLES_DETAIL AS
(
    SELECT
        AD.BILL_ACCOUNT_NB,
        AD.ACCOUNT_D_ID,

        CASE
            WHEN BGP.GP_AGRMT_STAT_CD = 'A'
                THEN 'Y'
            ELSE 'N'
        END AS RENEWABLES_PLAN_ACTIVE_FL,

        CASE
            WHEN BGP.GP_AGRMT_STAT_CD = 'A'
             AND BGP.GP_EFCT_DT >= DATEADD(
                    DAY,
                    -365,
                    AD.REPORT_DATE
                 )
                THEN 'Y'
            ELSE 'N'
        END AS RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,

        CASE
            WHEN BGP.BILL_ACCT_NB IS NOT NULL
                THEN 'Y'
            ELSE 'N'
        END AS RENEWABLES_PLAN_EVER_ENROLLED_FL

    FROM ACCT AD
    LEFT JOIN GREEN_POWER_SOURCE BGP
        ON AD.BILL_ACCOUNT_NB = BGP.BILL_ACCT_NB
),

CAR_VAL_RES_3 AS
(
    SELECT
        BILL_ACCOUNT_NB,

        IFF(
            SUM(IFF(RENEWABLES_PLAN_ACTIVE_FL = 'Y', 1, 0)) > 0,
            'Y',
            'N'
        ) AS CNT_RENEWABLES_PLAN_ACTIVE_FL,

        IFF(
            SUM(
                IFF(
                    RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,

        IFF(
            SUM(
                IFF(
                    RENEWABLES_PLAN_EVER_ENROLLED_FL = 'Y',
                    1,
                    0
                )
            ) > 0,
            'Y',
            'N'
        ) AS CNT_RENEWABLES_PLAN_EVER_ENROLLED_FL

    FROM RENEWABLES_DETAIL
    GROUP BY BILL_ACCOUNT_NB
),

MAIN AS
(
    SELECT
        ACCT.REPORT_DATE AS REPORT_DT,
        ACCT.BILL_ACCOUNT_NB,
        ACCT.ACCOUNT_D_ID,

        COALESCE(
            R1.CNT_PAPERLESS_BILLING_ACTIVE_FL,
            'N'
        ) AS CNT_PAPERLESS_BILLING_ACTIVE_FL,

        COALESCE(
            R1.CNT_PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,
            'N'
        ) AS CNT_PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,

        COALESCE(
            R1.CNT_PAPERLESS_BILLING_EVER_ENROLLED_FL,
            'N'
        ) AS CNT_PAPERLESS_BILLING_EVER_ENROLLED_FL,

        COALESCE(
            R2.CNT_AMP_PLAN_ACTIVE_FL,
            'N'
        ) AS CNT_AMP_PLAN_ACTIVE_FL,

        COALESCE(
            R2.CNT_AMP_PLAN_LAST1YEAR_ENROLLED_FL,
            'N'
        ) AS CNT_AMP_PLAN_LAST1YEAR_ENROLLED_FL,

        COALESCE(
            R2.CNT_AMP_PLAN_EVER_ENROLLED_FL,
            'N'
        ) AS CNT_AMP_PLAN_EVER_ENROLLED_FL,

        COALESCE(
            R2.CNT_BUDGET_BILLING_PLAN_ACTIVE_FL,
            'N'
        ) AS CNT_BUDGET_BILLING_PLAN_ACTIVE_FL,

        COALESCE(
            R2.CNT_BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,
            'N'
        ) AS CNT_BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,

        COALESCE(
            R2.CNT_BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,
            'N'
        ) AS CNT_BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,

        COALESCE(
            R2.CNT_PREPAY_PLAN_ACTIVE_FL,
            'N'
        ) AS CNT_PREPAY_PLAN_ACTIVE_FL,

        COALESCE(
            R2.CNT_PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,
            'N'
        ) AS CNT_PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,

        COALESCE(
            R2.CNT_PREPAY_PLAN_EVER_ENROLLED_FL,
            'N'
        ) AS CNT_PREPAY_PLAN_EVER_ENROLLED_FL,

        COALESCE(
            R3.CNT_RENEWABLES_PLAN_ACTIVE_FL,
            'N'
        ) AS CNT_RENEWABLES_PLAN_ACTIVE_FL,

        COALESCE(
            R3.CNT_RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,
            'N'
        ) AS CNT_RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,

        COALESCE(
            R3.CNT_RENEWABLES_PLAN_EVER_ENROLLED_FL,
            'N'
        ) AS CNT_RENEWABLES_PLAN_EVER_ENROLLED_FL

    FROM ACCT
    LEFT JOIN CAR_VAL_RES_1 R1
        ON ACCT.BILL_ACCOUNT_NB = R1.BILL_ACCOUNT_NB
    LEFT JOIN CAR_VAL_RES_2 R2
        ON ACCT.BILL_ACCOUNT_NB = R2.BILL_ACCOUNT_NB
    LEFT JOIN CAR_VAL_RES_3 R3
        ON ACCT.BILL_ACCOUNT_NB = R3.BILL_ACCOUNT_NB
),

SQ_PROGRAM_ENROLLMENT_F AS
(
    SELECT
        MAIN.REPORT_DT,
        MAIN.BILL_ACCOUNT_NB,
        MAIN.ACCOUNT_D_ID,
        MAIN.CNT_PAPERLESS_BILLING_ACTIVE_FL,
        MAIN.CNT_PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,
        MAIN.CNT_PAPERLESS_BILLING_EVER_ENROLLED_FL,
        MAIN.CNT_AMP_PLAN_ACTIVE_FL,
        MAIN.CNT_AMP_PLAN_LAST1YEAR_ENROLLED_FL,
        MAIN.CNT_AMP_PLAN_EVER_ENROLLED_FL,
        MAIN.CNT_BUDGET_BILLING_PLAN_ACTIVE_FL,
        MAIN.CNT_BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,
        MAIN.CNT_BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,
        MAIN.CNT_PREPAY_PLAN_ACTIVE_FL,
        MAIN.CNT_PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,
        MAIN.CNT_PREPAY_PLAN_EVER_ENROLLED_FL,
        MAIN.CNT_RENEWABLES_PLAN_ACTIVE_FL,
        MAIN.CNT_RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,
        MAIN.CNT_RENEWABLES_PLAN_EVER_ENROLLED_FL

    FROM MAIN

    {% if is_incremental() %}

    LEFT JOIN
    (
        SELECT
            REPORT_DT,
            BILL_ACCOUNT_NB
        FROM {{ this }}
        WHERE
        (
               BILL_ACCOUNT_NB
                   BETWEEN '0100000000' AND '0199999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '0200000000' AND '0299999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '0300000000' AND '0399999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '0400000000' AND '0499999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '0600000000' AND '0699999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '0700000000' AND '0799999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '1000000000' AND '1099999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '9400000000' AND '9499999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '9500000000' AND '9599999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '9600000000' AND '9699999999'
            OR BILL_ACCOUNT_NB
                   BETWEEN '9700000000' AND '9799999999'
        )
    ) PEF
        ON PEF.REPORT_DT = MAIN.REPORT_DT
       AND PEF.BILL_ACCOUNT_NB = MAIN.BILL_ACCOUNT_NB

    WHERE PEF.BILL_ACCOUNT_NB IS NULL

    {% endif %}
),

EXP_AUDIT_COLS AS
(
    SELECT
        REPORT_DT,
        BILL_ACCOUNT_NB,
        ACCOUNT_D_ID,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,

        's_m_PROGRAM_ENROLLMENT_F'::VARCHAR(50)
            AS EDW_CRTE_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        's_m_PROGRAM_ENROLLMENT_F'::VARCHAR(50)
            AS EDW_LAST_UPDT_NM,

        CNT_PAPERLESS_BILLING_ACTIVE_FL
            AS PAPERLESS_BILLING_ACTIVE_FL,

        CNT_PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL
            AS PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,

        CNT_PAPERLESS_BILLING_EVER_ENROLLED_FL
            AS PAPERLESS_BILLING_EVER_ENROLLED_FL,

        CNT_AMP_PLAN_ACTIVE_FL
            AS AMP_PLAN_ACTIVE_FL,

        CNT_AMP_PLAN_LAST1YEAR_ENROLLED_FL
            AS AMP_PLAN_LAST1YEAR_ENROLLED_FL,

        CNT_AMP_PLAN_EVER_ENROLLED_FL
            AS AMP_PLAN_EVER_ENROLLED_FL,

        CNT_BUDGET_BILLING_PLAN_ACTIVE_FL
            AS BUDGET_BILLING_PLAN_ACTIVE_FL,

        CNT_BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL
            AS BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,

        CNT_BUDGET_BILLING_PLAN_EVER_ENROLLED_FL
            AS BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,

        CNT_PREPAY_PLAN_ACTIVE_FL
            AS PREPAY_PLAN_ACTIVE_FL,

        CNT_PREPAY_PLAN_LAST1YEAR_ENROLLED_FL
            AS PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,

        CNT_PREPAY_PLAN_EVER_ENROLLED_FL
            AS PREPAY_PLAN_EVER_ENROLLED_FL,

        CNT_RENEWABLES_PLAN_ACTIVE_FL
            AS RENEWABLES_PLAN_ACTIVE_FL,

        CNT_RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL
            AS RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,

        CNT_RENEWABLES_PLAN_EVER_ENROLLED_FL
            AS RENEWABLES_PLAN_EVER_ENROLLED_FL

    FROM SQ_PROGRAM_ENROLLMENT_F
)

SELECT
    REPORT_DT,
    BILL_ACCOUNT_NB,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    PAPERLESS_BILLING_ACTIVE_FL,
    PAPERLESS_BILLING_LAST1YEAR_ENROLLED_FL,
    PAPERLESS_BILLING_EVER_ENROLLED_FL,
    AMP_PLAN_ACTIVE_FL,
    AMP_PLAN_LAST1YEAR_ENROLLED_FL,
    AMP_PLAN_EVER_ENROLLED_FL,
    BUDGET_BILLING_PLAN_ACTIVE_FL,
    BUDGET_BILLING_PLAN_LAST1YEAR_ENROLLED_FL,
    BUDGET_BILLING_PLAN_EVER_ENROLLED_FL,
    PREPAY_PLAN_ACTIVE_FL,
    PREPAY_PLAN_LAST1YEAR_ENROLLED_FL,
    PREPAY_PLAN_EVER_ENROLLED_FL,
    RENEWABLES_PLAN_ACTIVE_FL,
    RENEWABLES_PLAN_LAST1YEAR_ENROLLED_FL,
    RENEWABLES_PLAN_EVER_ENROLLED_FL
FROM EXP_AUDIT_COLS