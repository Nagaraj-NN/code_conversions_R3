{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_ARREARS_F"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1012C_ARREARS_F'),
        log_model_start(
            this,
            'DP_CXN1012C_ARREARS_F'
        )
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1012C_ARREARS_F'),
        log_model_end(
            this,
            'DP_CXN1012C_ARREARS_F'
        )
    ]
) }}

WITH JOB_CONTROL AS
(
    SELECT
        JOB_ID,
        START_DATE::TIMESTAMP_NTZ(9) AS START_DATE,
        END_DATE::TIMESTAMP_NTZ(9) AS END_DATE,
        TO_DATE(END_DATE) AS REPORT_DATE
    FROM {{ source(
        'UTLDB01_METADATA',
        'CXNADM_JOB_CONTROL'
    ) }}
    WHERE JOB_NAME = 'ARREARS_F'
      AND AUTOSYS_JOB_NAME = 'DP_CXN1012C_ARREARS_F'
),

ACCT AS
(
    SELECT
        JC.REPORT_DATE AS REPORT_DT,
        AD.BILL_ACCOUNT_NB,
        AD.ACCOUNT_D_ID
    FROM {{ source(
        'UTLDB01_CDWADM',
        'ACCOUNT_D'
    ) }} AD
    CROSS JOIN JOB_CONTROL JC

    -- Original frozen mapping expression:
    -- TO_DATE('2026-08-01', 'YYYY-MM-DD') AS REPORT_DT

    WHERE AD.CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
      AND AD.ACTIVE_FLAG = 'Y'
      AND
      (
             AD.BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '1099999999'
          OR AD.BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9799999999'
      )
),

DEBIT_ACTIVITY AS
(
    SELECT
        DBA.BILL_ACCT_NB,
        DBA.BILL_HEAD_NB,
        DBA.DEBT_AT,
        DBA.REMN_DEBT_AT,
        DBA.DEBT_TS,
        DBA.AGE_OF_DEBIT_CD
    FROM {{ source(
        'UTLDB01_UTLUSER',
        'ODS_MCS_DEBIT_ACTIVITY'
    ) }} DBA
    WHERE DBA.DEBT_TS BETWEEN
          DATE_TRUNC(
              'DAY',
              DATEADD(
                  MONTH,
                  -12,
                  (
                      SELECT REPORT_DATE
                      FROM JOB_CONTROL
                  )
              )
          )
          AND DATE_TRUNC(
              'DAY',
              LAST_DAY(
                  (
                      SELECT REPORT_DATE
                      FROM JOB_CONTROL
                  )
              )
          )
      AND DBA.BILL_HEAD_NB > 0
      AND
      (
             DBA.BILL_ACCT_NB
                 BETWEEN '0100000000' AND '1099999999'
          OR DBA.BILL_ACCT_NB
                 BETWEEN '9400000000' AND '9799999999'
      )

    -- Original frozen mapping window:
    -- DEBT_TS BETWEEN
    --     DATE_TRUNC(
    --         'DAY',
    --         DATEADD(
    --             MONTH,
    --             -12,
    --             TO_DATE('2026-08-01', 'YYYY-MM-DD')
    --         )
    --     )
    --     AND DATE_TRUNC(
    --         'DAY',
    --         LAST_DAY(
    --             TO_DATE('2026-08-01', 'YYYY-MM-DD')
    --         )
    --     )
),

ACCT_DTL AS
(
    SELECT
        ACCT.BILL_ACCOUNT_NB,
        ACCT.ACCOUNT_D_ID,
        ACCT.REPORT_DT,
        DBT_ACT.BILL_HEAD_NB,
        DBT_ACT.DEBT_AT,
        DBT_ACT.REMN_DEBT_AT,
        DBT_ACT.DEBT_TS,
        DBT_ACT.AGE_OF_DEBIT_CD
    FROM ACCT

    LEFT JOIN DEBIT_ACTIVITY DBT_ACT
        ON ACCT.BILL_ACCOUNT_NB = DBT_ACT.BILL_ACCT_NB
),

CAR_VAR_RES AS
(
    SELECT
        BILL_ACCOUNT_NB,
        ACCOUNT_D_ID,
        REPORT_DT,

        SUM(
            CASE
                WHEN AGE_OF_DEBIT_CD = '1'
                    THEN REMN_DEBT_AT
            END
        ) AS CURRENT_1_30DAYS_ARREARS_TOTAL_AMT,

        SUM(
            CASE
                WHEN AGE_OF_DEBIT_CD = '2'
                    THEN REMN_DEBT_AT
            END
        ) AS CURRENT_31_60DAYS_ARREARS_TOTAL_AMT,

        SUM(
            CASE
                WHEN AGE_OF_DEBIT_CD = '3'
                    THEN REMN_DEBT_AT
            END
        ) AS CURRENT_61_90DAYS_ARREARS_TOTAL_AMT,

        SUM(
            CASE
                WHEN AGE_OF_DEBIT_CD = '4'
                    THEN REMN_DEBT_AT
            END
        ) AS CURRENT_90PLUSDAYS_ARREARS_TOTAL_AMT,

        SUM(
            CASE
                WHEN AGE_OF_DEBIT_CD IN ('1', '2', '3', '4')
                    THEN REMN_DEBT_AT
            END
        ) AS CURRENT_ARREARS_TOTAL_AMT,

        COUNT(
            DISTINCT CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '1'
                    THEN BILL_HEAD_NB
            END
        ) AS LAST1YEAR_1_30DAYS_ARREARS_MONTHS_CNT,

        COUNT(
            DISTINCT CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '2'
                    THEN BILL_HEAD_NB
            END
        ) AS LAST1YEAR_31_60DAYS_ARREARS_MONTHS_CNT,

        COUNT(
            DISTINCT CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '3'
                    THEN BILL_HEAD_NB
            END
        ) AS LAST1YEAR_61_90DAYS_ARREARS_MONTHS_CNT,

        COUNT(
            DISTINCT CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '4'
                    THEN BILL_HEAD_NB
            END
        ) AS LAST1YEAR_90PLUSDAYS_ARREARS_MONTHS_CNT,

        AVG(
            CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '1'
                    THEN DEBT_AT
            END
        ) AS LAST1YEAR_1_30DAYS_ARREARS_AVG_AMT,

        AVG(
            CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '2'
                    THEN DEBT_AT
            END
        ) AS LAST1YEAR_31_60DAYS_ARREARS_AVG_AMT,

        AVG(
            CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '3'
                    THEN DEBT_AT
            END
        ) AS LAST1YEAR_61_90DAYS_ARREARS_AVG_AMT,

        AVG(
            CASE
                WHEN REMN_DEBT_AT >= 0
                 AND AGE_OF_DEBIT_CD = '4'
                    THEN DEBT_AT
            END
        ) AS LAST1YEAR_90PLUSDAYS_ARREARS_AVG_AMT,

        TRUNCATE(
            (
                DATEDIFF(
                    DAY,
                    TO_DATE(MAX(DEBT_TS)),
                    TO_DATE(REPORT_DT)
                ) + 1
            ) / 30,
            0
        ) AS MONTHS_SINCE_LAST_ARREAR

    FROM ACCT_DTL

    GROUP BY
        BILL_ACCOUNT_NB,
        ACCOUNT_D_ID,
        REPORT_DT
),

SQ_ARREARS_F AS
(
    SELECT DISTINCT
        MAIN.REPORT_DT,
        MAIN.ACCOUNT_D_ID,
        MAIN.BILL_ACCOUNT_NB,
        MAIN.CURRENT_1_30DAYS_ARREARS_TOTAL_AMT,
        MAIN.CURRENT_31_60DAYS_ARREARS_TOTAL_AMT,
        MAIN.CURRENT_61_90DAYS_ARREARS_TOTAL_AMT,
        MAIN.CURRENT_90PLUSDAYS_ARREARS_TOTAL_AMT,
        MAIN.CURRENT_ARREARS_TOTAL_AMT,
        MAIN.LAST1YEAR_1_30DAYS_ARREARS_MONTHS_CNT,
        MAIN.LAST1YEAR_31_60DAYS_ARREARS_MONTHS_CNT,
        MAIN.LAST1YEAR_61_90DAYS_ARREARS_MONTHS_CNT,
        MAIN.LAST1YEAR_90PLUSDAYS_ARREARS_MONTHS_CNT,
        MAIN.LAST1YEAR_1_30DAYS_ARREARS_AVG_AMT,
        MAIN.LAST1YEAR_31_60DAYS_ARREARS_AVG_AMT,
        MAIN.LAST1YEAR_61_90DAYS_ARREARS_AVG_AMT,
        MAIN.LAST1YEAR_90PLUSDAYS_ARREARS_AVG_AMT,
        MAIN.MONTHS_SINCE_LAST_ARREAR
    FROM CAR_VAR_RES MAIN

    {% if is_incremental() %}

    WHERE NOT EXISTS
    (
        SELECT
            1
        FROM {{ this }} ARR
        WHERE ARR.BILL_ACCOUNT_NB = MAIN.BILL_ACCOUNT_NB
          AND ARR.REPORT_DT = MAIN.REPORT_DT
          AND
          (
                 ARR.BILL_ACCOUNT_NB
                     BETWEEN '0100000000' AND '1099999999'
              OR ARR.BILL_ACCOUNT_NB
                     BETWEEN '9400000000' AND '9799999999'
          )
    )

    {% endif %}
),

EXP_AUDIT AS
(
    SELECT
        SQ.REPORT_DT,
        SQ.BILL_ACCOUNT_NB,
        SQ.ACCOUNT_D_ID,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,

        CASE
            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '0699999999'
                THEN 's_m_ARREARS_F_01_06'

            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '0700000000' AND '1099999999'
                THEN 's_m_ARREARS_F_07_10'

            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9599999999'
                THEN 's_m_ARREARS_F_94_95'

            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '9600000000' AND '9799999999'
                THEN 's_m_ARREARS_F_96_97'
        END::VARCHAR(50) AS EDW_CRTE_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        CASE
            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '0699999999'
                THEN 's_m_ARREARS_F_01_06'

            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '0700000000' AND '1099999999'
                THEN 's_m_ARREARS_F_07_10'

            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9599999999'
                THEN 's_m_ARREARS_F_94_95'

            WHEN SQ.BILL_ACCOUNT_NB
                 BETWEEN '9600000000' AND '9799999999'
                THEN 's_m_ARREARS_F_96_97'
        END::VARCHAR(50) AS EDW_LAST_UPDT_NM,

        SQ.CURRENT_1_30DAYS_ARREARS_TOTAL_AMT,
        SQ.CURRENT_31_60DAYS_ARREARS_TOTAL_AMT,
        SQ.CURRENT_61_90DAYS_ARREARS_TOTAL_AMT,
        SQ.CURRENT_90PLUSDAYS_ARREARS_TOTAL_AMT,
        SQ.CURRENT_ARREARS_TOTAL_AMT,
        SQ.LAST1YEAR_1_30DAYS_ARREARS_MONTHS_CNT,
        SQ.LAST1YEAR_31_60DAYS_ARREARS_MONTHS_CNT,
        SQ.LAST1YEAR_61_90DAYS_ARREARS_MONTHS_CNT,
        SQ.LAST1YEAR_90PLUSDAYS_ARREARS_MONTHS_CNT,
        SQ.LAST1YEAR_1_30DAYS_ARREARS_AVG_AMT,
        SQ.LAST1YEAR_31_60DAYS_ARREARS_AVG_AMT,
        SQ.LAST1YEAR_61_90DAYS_ARREARS_AVG_AMT,
        SQ.LAST1YEAR_90PLUSDAYS_ARREARS_AVG_AMT,
        SQ.MONTHS_SINCE_LAST_ARREAR

    FROM SQ_ARREARS_F SQ
)

SELECT
    REPORT_DT,
    BILL_ACCOUNT_NB,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    CURRENT_1_30DAYS_ARREARS_TOTAL_AMT,
    CURRENT_31_60DAYS_ARREARS_TOTAL_AMT,
    CURRENT_61_90DAYS_ARREARS_TOTAL_AMT,
    CURRENT_90PLUSDAYS_ARREARS_TOTAL_AMT,
    CURRENT_ARREARS_TOTAL_AMT,
    LAST1YEAR_1_30DAYS_ARREARS_MONTHS_CNT,
    LAST1YEAR_31_60DAYS_ARREARS_MONTHS_CNT,
    LAST1YEAR_61_90DAYS_ARREARS_MONTHS_CNT,
    LAST1YEAR_90PLUSDAYS_ARREARS_MONTHS_CNT,
    LAST1YEAR_1_30DAYS_ARREARS_AVG_AMT,
    LAST1YEAR_31_60DAYS_ARREARS_AVG_AMT,
    LAST1YEAR_61_90DAYS_ARREARS_AVG_AMT,
    LAST1YEAR_90PLUSDAYS_ARREARS_AVG_AMT,
    MONTHS_SINCE_LAST_ARREAR
FROM EXP_AUDIT