
{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={"mapping_name": "m_CIVR_V2D_DA_JAR_F"},
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1014C_CIVR_V2D_DA_JAR_F'),
        log_model_start(this, 'DP_CXN1014C_CIVR_V2D_DA_JAR_F')
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1014C_CIVR_V2D_DA_JAR_F'),
        log_model_end(this, 'DP_CXN1014C_CIVR_V2D_DA_JAR_F')
    ]
) }}
WITH 
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME= 'CIVR_V2D_DA_JAR_F' AND AUTOSYS_JOB_NAME = 'DP_CXN1014C_CIVR_V2D_DA_JAR_F'),

 
 ACTIVE_ACCOUNT_D AS
(
    SELECT
        ACCOUNT_D_ID,
        BILL_ACCOUNT_NB
    FROM {{ source('UTLDB01_CDWADM','ACCOUNT_D') }}
    WHERE ACTIVE_FLAG = 'Y'
      AND CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
),
SQ_CALLS_BASE AS
(
    SELECT
        A.BILL_ACCOUNT_NB AS CVD_BILL_ACCT_NB,
        A.VOICE_PLATFORM_FULL_CALL_ID AS CVD_INTERACTION_ID,
        ROW_NUMBER() OVER
        (
            PARTITION BY A.BILL_ACCOUNT_NB, A.VOICE_PLATFORM_FULL_CALL_ID
            ORDER BY B.CALL_EVENTS_ID ASC
        ) AS CVD_CHANNEL_STEP,
        C.ACCOUNT_D_ID,
        A.CALL_START_TIME AS CVD_START_TIME,
        A.CALL_END_TIME AS CVD_END_TIME,
        A.START_SITE_NAME,
        CASE
            WHEN A.CTI_FIELDS LIKE '%452000%' THEN 'CIVR'
            WHEN A.CTI_FIELDS LIKE '%432000%' THEN 'DA'
            WHEN A.CTI_FIELDS LIKE '%442000%' THEN 'V2D'
            WHEN A.CTI_FIELDS LIKE '%432056%' THEN 'DA'
            ELSE 'N/A'
        END AS CVD_CHANNEL_NAME,
        B.CALL_EVENT_CD AS CVD_EVENT_CD,
        D.CALL_EVENT_CD_DESC AS CVD_EVENT_DESC,
        CASE
            WHEN
                LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') = 'PaymentAssistance'
                AND
                (
                    LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') LIKE '%452070%'
                    OR LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') LIKE '%442070%'
                    OR LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') LIKE '%432070%'
                )
                THEN 'PaymentExtension'
            WHEN
                (
                    LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') = 'PaymentAssistance'
                    AND LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') LIKE '%452071%'
                )
                OR LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') LIKE '%442071%'
                OR LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') LIKE '%432071%'
                THEN 'PaymentArrangement'
            WHEN
                LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') = 'PaymentAssistance'
                AND LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') NOT LIKE '%452070%'
                AND LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'eventCD:[^|]+'), 'eventCD:') NOT LIKE '%452071%'
                THEN 'PaymentAssistance'
            WHEN LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') <> 'PaymentAssistance'
                THEN LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:')
            WHEN LTRIM(REGEXP_SUBSTR(A.CTI_FIELDS, 'intent_list:[^|]+'), 'intent_list:') IS NULL
                THEN 'Unidentified'
        END AS CVD_INTENT_NAME
    FROM {{ source('UTLDB01_CXNADM','CALLS') }} A
    INNER JOIN {{ source('UTLDB01_CXNADM','CALL_EVENTS') }} B
      ON A.CALLS_ID = B.CALLS_ID
    INNER JOIN ACTIVE_ACCOUNT_D C
      ON A.BILL_ACCOUNT_NB = C.BILL_ACCOUNT_NB
    LEFT JOIN {{ source('UTLDB01_CDWADM','CALL_EVENT_D') }} D
      ON B.CALL_EVENT_ID = D.CALL_EVENT_D_ID
    WHERE A.BILL_ACCOUNT_NB IS NOT NULL
      AND A.CALL_START_TIME BETWEEN ADD_MONTHS(DATE_TRUNC('DAY', CURRENT_DATE()), -13) AND DATE_TRUNC('DAY', CURRENT_DATE())
      AND A.EDW_LAST_UPDT_TS BETWEEN (SELECT START_DATE FROM JOB_CONTROL) AND (SELECT END_DATE FROM JOB_CONTROL)
),
SQ_CALLS AS
(
    SELECT
        A.CVD_BILL_ACCT_NB,
        A.CVD_INTERACTION_ID,
        A.CVD_CHANNEL_STEP,
        A.ACCOUNT_D_ID,
        A.CVD_START_TIME,
        A.CVD_END_TIME,
        A.START_SITE_NAME,
        A.CVD_CHANNEL_NAME,
        A.CVD_EVENT_CD,
        A.CVD_EVENT_DESC,
        A.CVD_INTENT_NAME
    FROM SQ_CALLS_BASE A
    {% if is_incremental() %}

    -- First run: nothing has been loaded yet, so the anti-join has no target to
    -- check against and every row is new.
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM {{ this }} SS
        WHERE A.CVD_BILL_ACCT_NB = SS.CVD_BILL_ACCT_NB
          AND A.CVD_INTERACTION_ID = SS.CVD_INTERACTION_ID
          AND A.CVD_CHANNEL_STEP = SS.CVD_CHANNEL_STEP
          AND A.ACCOUNT_D_ID = SS.ACCOUNT_D_ID
          AND A.CVD_START_TIME = SS.CVD_START_TIME
    )

    {% endif %}
),
EXP_AUDIT_COLS AS
(
    SELECT
        CVD_BILL_ACCT_NB,
        CVD_INTERACTION_ID,
        CVD_CHANNEL_STEP,
        ACCOUNT_D_ID,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9) AS EDW_CRTE_TS,
        's_m_CIVR_V2D_DA_JAR_F_INCR' AS EDW_CRTE_NM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9) AS EDW_LAST_UPDT_TS,
        's_m_CIVR_V2D_DA_JAR_F_INCR' AS EDW_LAST_UPDT_NM,
        CVD_START_TIME,
        CVD_END_TIME,
        START_SITE_NAME,
        CVD_CHANNEL_NAME,
        CVD_EVENT_CD,
        CVD_EVENT_DESC,
        CVD_INTENT_NAME
    FROM SQ_CALLS
),

final_cte AS (
SELECT
    CVD_BILL_ACCT_NB,
    CVD_INTERACTION_ID,
    CVD_CHANNEL_STEP,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    CVD_START_TIME,
    CVD_END_TIME,
    START_SITE_NAME,
    CVD_CHANNEL_NAME,
    CVD_EVENT_CD,
    CVD_EVENT_DESC,
    CVD_INTENT_NAME
FROM EXP_AUDIT_COLS
)

SELECT
    SRC.CVD_BILL_ACCT_NB,
    SRC.CVD_INTERACTION_ID,
    SRC.CVD_CHANNEL_STEP,
    SRC.ACCOUNT_D_ID,
    SRC.EDW_CRTE_TS,
    SRC.EDW_CRTE_NM,
    SRC.EDW_LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_NM,
    SRC.CVD_START_TIME,
    SRC.CVD_END_TIME,
    SRC.START_SITE_NAME,
    SRC.CVD_CHANNEL_NAME,
    SRC.CVD_EVENT_CD,
    SRC.CVD_EVENT_DESC,
    SRC.CVD_INTENT_NAME

FROM
    final_cte SRC