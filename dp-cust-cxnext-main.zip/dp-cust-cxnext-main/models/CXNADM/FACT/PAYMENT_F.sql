{{ config(
    materialized='incremental',
    incremental_strategy='append',
    meta={
        "mapping_name": "m_PAYMENT_F"
    },
    full_refresh=false,
    pre_hook=[
        open_control_window(this, 'DP_CXN1012C_PAYMENT_F'),
        log_model_start(this, 'DP_CXN1012C_PAYMENT_F')
    ],
    post_hook=[
        update_control_table(this, 'DP_CXN1012C_PAYMENT_F'),
        log_model_end(this, 'DP_CXN1012C_PAYMENT_F')
    ]
) }}

WITH JOB_CONTROL AS
(
    SELECT
        JOB_ID,
        START_DATE,
        END_DATE,
        TO_DATE(END_DATE) AS REPORT_DATE
    FROM {{ source('UTLDB01_METADATA', 'CXNADM_JOB_CONTROL') }}
    WHERE JOB_NAME = 'PAYMENT_F'
      AND AUTOSYS_JOB_NAME = 'DP_CXN1012C_PAYMENT_F'
),

ACCT AS
(
    SELECT
        JC.REPORT_DATE,
        AD.BILL_ACCOUNT_NB,
        AD.ACCOUNT_D_ID
    FROM {{ source('UTLDB01_CDWADM', 'ACCOUNT_D') }} AD
    CROSS JOIN JOB_CONTROL JC
    WHERE AD.CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
      AND AD.ACTIVE_FLAG = 'Y'
      AND
      (
             AD.BILL_ACCOUNT_NB BETWEEN '0100000000' AND '1099999999'
          OR AD.BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9799999999'
      )
),

PMT AS
(
    SELECT
        CS.BILL_ACCT_NB,
        TRIM(CS.PYMN_CSHR_CD) AS PYMN_CSHR_CD,
        TRIM(CS.TRANS_TYPE_CD) AS TRANS_TYPE_CD,
        CS.PYMN_CRDT_DT
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_CREDIT_SOURCE') }} CS
    CROSS JOIN JOB_CONTROL JC
    WHERE TRIM(CS.TRANS_TYPE_CD) = 'PYMN'
      AND CS.PYMN_CRDT_DT BETWEEN
          DATE_TRUNC(
              'DAY',
              DATEADD(MONTH, -12, JC.REPORT_DATE)
          )
          AND DATE_TRUNC(
              'DAY',
              JC.REPORT_DATE
          )
      AND
      (
             CS.BILL_ACCT_NB BETWEEN '0100000000' AND '1099999999'
          OR CS.BILL_ACCT_NB BETWEEN '9400000000' AND '9799999999'
      )
),

CALLS_PMT AS
(
    SELECT
        AD.BILL_ACCOUNT_NB,
        AD.REPORT_DATE,
        CS.TRANS_TYPE_CD,
        CS.PYMN_CSHR_CD,
        CS.PYMN_CRDT_DT,
        CS.CRDT_CRTN_TS,
        TEMP_CLL.CALL_START_TIME,
        TEMP_CLL.CALL_END_TIME,
        TEMP_CLL.VOICE_PLATFORM_FULL_CALL_ID,
        TEMP_CLL.CALL_EVENT_CD,
        CS.PYMN_CRDT_AT
    FROM ACCT AD
    INNER JOIN
    (
        SELECT
            TRIM(CS.TRANS_TYPE_CD) AS TRANS_TYPE_CD,
            TRIM(CS.PYMN_CSHR_CD) AS PYMN_CSHR_CD,
            CS.PYMN_CRDT_DT,
            CS.CRDT_CRTN_TS,
            CS.BILL_ACCT_NB,
            CS.PYMN_CRDT_AT
        FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_CREDIT_SOURCE') }} CS
        CROSS JOIN JOB_CONTROL JC
        WHERE CS.CRDT_CRTN_TS BETWEEN
              DATE_TRUNC(
                  'DAY',
                  DATEADD(MONTH, -12, JC.REPORT_DATE)
              )
              AND DATE_TRUNC(
                  'DAY',
                  JC.REPORT_DATE
              )
          AND
          (
                 CS.BILL_ACCT_NB BETWEEN '0100000000' AND '1099999999'
              OR CS.BILL_ACCT_NB BETWEEN '9400000000' AND '9799999999'
          )
    ) CS
        ON AD.BILL_ACCOUNT_NB = CS.BILL_ACCT_NB
    LEFT JOIN
    (
        SELECT
            CALLS.BILL_ACCOUNT_NB,
            CALLS.CALL_START_TIME,
            CALLS.CALL_END_TIME,
            CALLS.VOICE_PLATFORM_FULL_CALL_ID,
            ECD.CALL_EVENT_CD
        FROM
        (
            SELECT
                C.BILL_ACCOUNT_NB,
                C.CALLS_ID,
                C.CALL_START_TIME,
                C.CALL_END_TIME,
                C.VOICE_PLATFORM_FULL_CALL_ID,
                C.START_SITE_NAME,
                C.IS_TEST_CALL
            FROM {{ source('UTLDB01_CXNADM', 'CALLS') }} C
            CROSS JOIN JOB_CONTROL JC
            WHERE UPPER(C.START_SITE_NAME) = 'DA_MAIN'
              AND C.IS_TEST_CALL = 0
              AND C.CALL_START_TIME BETWEEN
                  DATE_TRUNC(
                      'DAY',
                      DATEADD(MONTH, -12, JC.REPORT_DATE)
                  )
                  AND DATE_TRUNC(
                      'DAY',
                      JC.REPORT_DATE
                  )
              AND
              (
                     C.BILL_ACCOUNT_NB
                         BETWEEN '0100000000' AND '1099999999'
                  OR C.BILL_ACCOUNT_NB
                         BETWEEN '9400000000' AND '9799999999'
              )
        ) CALLS
        INNER JOIN
        (
            SELECT
                CALL_EVENT_CD,
                CALLS_ID
            FROM {{ source('UTLDB01_CXNADM', 'CALL_EVENTS') }}
            WHERE CALL_EVENT_CD IN (442160, 432160)
        ) ECD
            ON CALLS.CALLS_ID = ECD.CALLS_ID
    ) TEMP_CLL
        ON AD.BILL_ACCOUNT_NB = TEMP_CLL.BILL_ACCOUNT_NB
),

CAR_VAL_RES_1 AS
(
    SELECT
        BILL_ACCOUNT_NB,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_CHECKLESS_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_CHECKLESS_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_CHECKLESS_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_CHECKLESS_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_ELECTRONIC_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_ELECTRONIC_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_ELECTRONIC_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_ELECTRONIC_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_WEB_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_WEB_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_WEB_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_WEB_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_MAIL_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_MAIL_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_MAIL_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_MAIL_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_KIOSK_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_KIOSK_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_KIOSK_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_KIOSK_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_PAYSTATION_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_PAYSTATION_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_PAYSTATION_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_PAYSTATION_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST30DAYS_ASSISTANCEAGENCY_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST60DAYS_ASSISTANCEAGENCY_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST90DAYS_ASSISTANCEAGENCY_CNT,

        COUNT(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN 1
            END
        ) AS LAST1YEAR_ASSISTANCEAGENCY_CNT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_CHECKLESS_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_CHECKLESS_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_CHECKLESS_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '999'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_CHECKLESS_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_ELECTRONIC_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_ELECTRONIC_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_ELECTRONIC_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN
                     ('893', '898', '890', '891', '500', '501', '502', '951', '999')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_ELECTRONIC_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_WEB_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_WEB_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_WEB_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('890', '500', '501', '502')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_WEB_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_MAIL_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_MAIL_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_MAIL_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('920', '900', '901')
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_MAIL_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_KIOSK_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_KIOSK_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_KIOSK_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '892'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_KIOSK_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_PAYSTATION_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_PAYSTATION_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_PAYSTATION_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '895'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_PAYSTATION_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST30DAYS_ASSISTANCEAGENCY_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST60DAYS_ASSISTANCEAGENCY_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST90DAYS_ASSISTANCEAGENCY_AMT,

        SUM(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD = '933'
                 AND PYMN_CRDT_DT BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                    THEN PYMN_CRDT_AT
            END
        ) AS LAST1YEAR_ASSISTANCEAGENCY_AMT,

        MIN(
            CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                    THEN DATEDIFF(
                        DAY,
                        TO_DATE(PYMN_CRDT_DT),
                        REPORT_DATE
                    ) + 1
            END
        ) AS DAYS_SINCE_LAST_BILL_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 442160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST30DAYS_V2DDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 442160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST60DAYS_V2DDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 442160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST90DAYS_V2DDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 442160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST1YEAR_V2DDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 432160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST30DAYS_WEBDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 432160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST60DAYS_WEBDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 432160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST90DAYS_WEBDA_CNT,

        COUNT(
            DISTINCT CASE
                WHEN TRANS_TYPE_CD = 'PYMN'
                 AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                 AND CRDT_CRTN_TS BETWEEN
                     DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                     AND DATE_TRUNC('DAY', REPORT_DATE)
                 AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                      AND DATEADD(HOUR, 72, CALL_END_TIME)
                 AND CALL_EVENT_CD = 432160
                    THEN VOICE_PLATFORM_FULL_CALL_ID
            END
        ) AS LAST1YEAR_WEBDA_CNT

    FROM CALLS_PMT
    GROUP BY BILL_ACCOUNT_NB
),

CAR_VAL_RES_2 AS
(
    SELECT
        BILL_ACCOUNT_NB,
        SUM(LAST30DAYS_V2DDA_AMT) AS LAST30DAYS_V2DDA_AMT,
        SUM(LAST60DAYS_V2DDA_AMT) AS LAST60DAYS_V2DDA_AMT,
        SUM(LAST90DAYS_V2DDA_AMT) AS LAST90DAYS_V2DDA_AMT,
        SUM(LAST1YEAR_V2DDA_AMT) AS LAST1YEAR_V2DDA_AMT,
        SUM(LAST30DAYS_WEBDA_AMT) AS LAST30DAYS_WEBDA_AMT,
        SUM(LAST60DAYS_WEBDA_AMT) AS LAST60DAYS_WEBDA_AMT,
        SUM(LAST90DAYS_WEBDA_AMT) AS LAST90DAYS_WEBDA_AMT,
        SUM(LAST1YEAR_WEBDA_AMT) AS LAST1YEAR_WEBDA_AMT
    FROM
    (
        SELECT
            VOICE_PLATFORM_FULL_CALL_ID,
            BILL_ACCOUNT_NB,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 442160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST30DAYS_V2DDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 442160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST60DAYS_V2DDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 442160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST90DAYS_V2DDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 442160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST1YEAR_V2DDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(DAY, -30, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 432160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST30DAYS_WEBDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(DAY, -60, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 432160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST60DAYS_WEBDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(DAY, -90, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 432160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST90DAYS_WEBDA_AMT,

            SUM(
                DISTINCT CASE
                    WHEN TRANS_TYPE_CD = 'PYMN'
                     AND PYMN_CSHR_CD IN ('502', '501', '500', '898', '890', '893')
                     AND CRDT_CRTN_TS BETWEEN
                         DATE_TRUNC('DAY', DATEADD(MONTH, -12, REPORT_DATE))
                         AND DATE_TRUNC('DAY', REPORT_DATE)
                     AND CRDT_CRTN_TS BETWEEN CALL_END_TIME
                                          AND DATEADD(HOUR, 72, CALL_END_TIME)
                     AND CALL_EVENT_CD = 432160
                        THEN PYMN_CRDT_AT
                END
            ) AS LAST1YEAR_WEBDA_AMT

        FROM CALLS_PMT
        WHERE VOICE_PLATFORM_FULL_CALL_ID IS NOT NULL
        GROUP BY
            VOICE_PLATFORM_FULL_CALL_ID,
            BILL_ACCOUNT_NB
    )
    GROUP BY BILL_ACCOUNT_NB
),

TEMP3 AS
(
    SELECT
        BILL_ACCT_NB,
        LISTAGG(PYMN_CSHR_CD, '|')
            WITHIN GROUP (ORDER BY PYMN_CSHR_CD)
            AS UNIQUE_PAYMENT_METHOD_CD
    FROM
    (
        SELECT DISTINCT
            BILL_ACCT_NB,
            PYMN_CSHR_CD
        FROM PMT
    )
    GROUP BY BILL_ACCT_NB
),

TEMP4 AS
(
    SELECT
        BILL_ACCT_NB AS P_BILL,
        PYMN_CSHR_CD AS P_PYMN_CSHR_CD
    FROM
    (
        SELECT
            BILL_ACCT_NB,
            PYMN_CSHR_CD,
            PAY_COUNT,
            ROW_NUMBER() OVER
            (
                PARTITION BY BILL_ACCT_NB
                ORDER BY BILL_ACCT_NB, PAY_COUNT DESC
            ) AS ROW_NUM
        FROM
        (
            SELECT
                BILL_ACCT_NB,
                PYMN_CSHR_CD,
                COUNT(*) AS PAY_COUNT
            FROM PMT
            GROUP BY
                BILL_ACCT_NB,
                PYMN_CSHR_CD
        )
    )
    WHERE ROW_NUM = 1
),

TEMP5 AS
(
    SELECT
        BILL_ACCT_NB AS S_BILL,
        PYMN_CSHR_CD AS S_PYMN_CSHR_CD
    FROM
    (
        SELECT
            BILL_ACCT_NB,
            PYMN_CSHR_CD,
            PAY_COUNT,
            ROW_NUMBER() OVER
            (
                PARTITION BY BILL_ACCT_NB
                ORDER BY BILL_ACCT_NB, PAY_COUNT DESC
            ) AS ROW_NUM
        FROM
        (
            SELECT
                BILL_ACCT_NB,
                PYMN_CSHR_CD,
                COUNT(*) AS PAY_COUNT
            FROM PMT
            GROUP BY
                BILL_ACCT_NB,
                PYMN_CSHR_CD
        )
    )
    WHERE ROW_NUM = 2
),

SQ_PAYMENT_F AS
(
    SELECT
        AD.REPORT_DATE,
        AD.ACCOUNT_D_ID,
        AD.BILL_ACCOUNT_NB,
        TEMP4.P_PYMN_CSHR_CD,
        TEMP5.S_PYMN_CSHR_CD,
        TEMP3.UNIQUE_PAYMENT_METHOD_CD,
        TEMP1.DAYS_SINCE_LAST_BILL_CNT,
        TEMP1.LAST30DAYS_CHECKLESS_CNT,
        TEMP1.LAST60DAYS_CHECKLESS_CNT,
        TEMP1.LAST90DAYS_CHECKLESS_CNT,
        TEMP1.LAST1YEAR_CHECKLESS_CNT,
        TEMP1.LAST30DAYS_ELECTRONIC_CNT,
        TEMP1.LAST60DAYS_ELECTRONIC_CNT,
        TEMP1.LAST90DAYS_ELECTRONIC_CNT,
        TEMP1.LAST1YEAR_ELECTRONIC_CNT,
        TEMP1.LAST30DAYS_WEB_CNT,
        TEMP1.LAST60DAYS_WEB_CNT,
        TEMP1.LAST90DAYS_WEB_CNT,
        TEMP1.LAST1YEAR_WEB_CNT,
        TEMP1.LAST30DAYS_V2DDA_CNT,
        TEMP1.LAST60DAYS_V2DDA_CNT,
        TEMP1.LAST90DAYS_V2DDA_CNT,
        TEMP1.LAST1YEAR_V2DDA_CNT,
        TEMP1.LAST30DAYS_WEBDA_CNT,
        TEMP1.LAST60DAYS_WEBDA_CNT,
        TEMP1.LAST90DAYS_WEBDA_CNT,
        TEMP1.LAST1YEAR_WEBDA_CNT,
        TEMP1.LAST30DAYS_MAIL_CNT,
        TEMP1.LAST60DAYS_MAIL_CNT,
        TEMP1.LAST90DAYS_MAIL_CNT,
        TEMP1.LAST1YEAR_MAIL_CNT,
        TEMP1.LAST30DAYS_KIOSK_CNT,
        TEMP1.LAST60DAYS_KIOSK_CNT,
        TEMP1.LAST90DAYS_KIOSK_CNT,
        TEMP1.LAST1YEAR_KIOSK_CNT,
        TEMP1.LAST30DAYS_PAYSTATION_CNT,
        TEMP1.LAST60DAYS_PAYSTATION_CNT,
        TEMP1.LAST90DAYS_PAYSTATION_CNT,
        TEMP1.LAST1YEAR_PAYSTATION_CNT,
        TEMP1.LAST30DAYS_ASSISTANCEAGENCY_CNT,
        TEMP1.LAST60DAYS_ASSISTANCEAGENCY_CNT,
        TEMP1.LAST90DAYS_ASSISTANCEAGENCY_CNT,
        TEMP1.LAST1YEAR_ASSISTANCEAGENCY_CNT,
        TEMP1.LAST30DAYS_CHECKLESS_AMT,
        TEMP1.LAST60DAYS_CHECKLESS_AMT,
        TEMP1.LAST90DAYS_CHECKLESS_AMT,
        TEMP1.LAST1YEAR_CHECKLESS_AMT,
        TEMP1.LAST30DAYS_ELECTRONIC_AMT,
        TEMP1.LAST60DAYS_ELECTRONIC_AMT,
        TEMP1.LAST90DAYS_ELECTRONIC_AMT,
        TEMP1.LAST1YEAR_ELECTRONIC_AMT,
        TEMP1.LAST30DAYS_WEB_AMT,
        TEMP1.LAST60DAYS_WEB_AMT,
        TEMP1.LAST90DAYS_WEB_AMT,
        TEMP1.LAST1YEAR_WEB_AMT,
        TEMP2.LAST30DAYS_V2DDA_AMT,
        TEMP2.LAST60DAYS_V2DDA_AMT,
        TEMP2.LAST90DAYS_V2DDA_AMT,
        TEMP2.LAST1YEAR_V2DDA_AMT,
        TEMP2.LAST30DAYS_WEBDA_AMT,
        TEMP2.LAST60DAYS_WEBDA_AMT,
        TEMP2.LAST90DAYS_WEBDA_AMT,
        TEMP2.LAST1YEAR_WEBDA_AMT,
        TEMP1.LAST30DAYS_MAIL_AMT,
        TEMP1.LAST60DAYS_MAIL_AMT,
        TEMP1.LAST90DAYS_MAIL_AMT,
        TEMP1.LAST1YEAR_MAIL_AMT,
        TEMP1.LAST30DAYS_KIOSK_AMT,
        TEMP1.LAST60DAYS_KIOSK_AMT,
        TEMP1.LAST90DAYS_KIOSK_AMT,
        TEMP1.LAST1YEAR_KIOSK_AMT,
        TEMP1.LAST30DAYS_PAYSTATION_AMT,
        TEMP1.LAST60DAYS_PAYSTATION_AMT,
        TEMP1.LAST90DAYS_PAYSTATION_AMT,
        TEMP1.LAST1YEAR_PAYSTATION_AMT,
        TEMP1.LAST30DAYS_ASSISTANCEAGENCY_AMT,
        TEMP1.LAST60DAYS_ASSISTANCEAGENCY_AMT,
        TEMP1.LAST90DAYS_ASSISTANCEAGENCY_AMT,
        TEMP1.LAST1YEAR_ASSISTANCEAGENCY_AMT
    FROM ACCT AD
    LEFT JOIN CAR_VAL_RES_1 TEMP1
        ON AD.BILL_ACCOUNT_NB = TEMP1.BILL_ACCOUNT_NB
    LEFT JOIN CAR_VAL_RES_2 TEMP2
        ON AD.BILL_ACCOUNT_NB = TEMP2.BILL_ACCOUNT_NB
    LEFT JOIN TEMP3
        ON AD.BILL_ACCOUNT_NB = TEMP3.BILL_ACCT_NB
    LEFT JOIN TEMP4
        ON AD.BILL_ACCOUNT_NB = TEMP4.P_BILL
    LEFT JOIN TEMP5
        ON AD.BILL_ACCOUNT_NB = TEMP5.S_BILL
    LEFT JOIN
    (
        SELECT
            REPORT_DT,
            BILL_ACCOUNT_NB
        FROM {% if is_incremental() %}{{ this }}{% else %}(SELECT NULL::TIMESTAMP_NTZ(9) AS REPORT_DT, NULL::VARCHAR(50) AS BILL_ACCOUNT_NB FROM (SELECT 1 AS DUMMY) DUMMY_ROW WHERE 1 = 0){% endif %} FIRST_RUN_SAFE
        WHERE
        (
               BILL_ACCOUNT_NB BETWEEN '0100000000' AND '1099999999'
            OR BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9799999999'
        )
    ) PF
        ON PF.REPORT_DT = AD.REPORT_DATE
       AND PF.BILL_ACCOUNT_NB = AD.BILL_ACCOUNT_NB
    WHERE PF.BILL_ACCOUNT_NB IS NULL
),

EXP_AUDIT AS
(
    SELECT
        SQ.REPORT_DATE AS REPORT_DT,
        SQ.BILL_ACCOUNT_NB,
        SQ.ACCOUNT_D_ID,
        CURRENT_TIMESTAMP() AS EDW_CRTE_TS,

        CASE
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '0100000000' AND '0399999999'
                THEN 's_m_PAYMENT_F_01_03'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '0400000000' AND '0699999999'
                THEN 's_m_PAYMENT_F_04_06'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '0700000000' AND '1099999999'
                THEN 's_m_PAYMENT_F_07_10'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9599999999'
                THEN 's_m_PAYMENT_F_94_95'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '9600000000' AND '9799999999'
                THEN 's_m_PAYMENT_F_96_97'
        END AS EDW_CRTE_NM,

        CURRENT_TIMESTAMP() AS EDW_LAST_UPDT_TS,

        CASE
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '0100000000' AND '0399999999'
                THEN 's_m_PAYMENT_F_01_03'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '0400000000' AND '0699999999'
                THEN 's_m_PAYMENT_F_04_06'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '0700000000' AND '1099999999'
                THEN 's_m_PAYMENT_F_07_10'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9599999999'
                THEN 's_m_PAYMENT_F_94_95'
            WHEN SQ.BILL_ACCOUNT_NB BETWEEN '9600000000' AND '9799999999'
                THEN 's_m_PAYMENT_F_96_97'
        END AS EDW_LAST_UPDT_NM,

        SQ.P_PYMN_CSHR_CD AS PRIMARY_PREFERRED_PAYMENT_METHOD_CD,
        SQ.S_PYMN_CSHR_CD AS SECONDARY_PREFERRED_PAYMENT_METHOD_CD,
        SQ.UNIQUE_PAYMENT_METHOD_CD,
        SQ.DAYS_SINCE_LAST_BILL_CNT AS DAYS_SINCE_LAST_PAYMENT,
        SQ.LAST30DAYS_CHECKLESS_CNT,
        SQ.LAST60DAYS_CHECKLESS_CNT,
        SQ.LAST90DAYS_CHECKLESS_CNT,
        SQ.LAST1YEAR_CHECKLESS_CNT,
        SQ.LAST30DAYS_ELECTRONIC_CNT,
        SQ.LAST60DAYS_ELECTRONIC_CNT,
        SQ.LAST90DAYS_ELECTRONIC_CNT,
        SQ.LAST1YEAR_ELECTRONIC_CNT,
        SQ.LAST30DAYS_WEB_CNT,
        SQ.LAST60DAYS_WEB_CNT,
        SQ.LAST90DAYS_WEB_CNT,
        SQ.LAST1YEAR_WEB_CNT,
        SQ.LAST30DAYS_V2DDA_CNT,
        SQ.LAST60DAYS_V2DDA_CNT,
        SQ.LAST90DAYS_V2DDA_CNT,
        SQ.LAST1YEAR_V2DDA_CNT,
        SQ.LAST30DAYS_WEBDA_CNT,
        SQ.LAST60DAYS_WEBDA_CNT,
        SQ.LAST90DAYS_WEBDA_CNT,
        SQ.LAST1YEAR_WEBDA_CNT,
        SQ.LAST30DAYS_MAIL_CNT,
        SQ.LAST60DAYS_MAIL_CNT,
        SQ.LAST90DAYS_MAIL_CNT,
        SQ.LAST1YEAR_MAIL_CNT,
        SQ.LAST30DAYS_KIOSK_CNT,
        SQ.LAST60DAYS_KIOSK_CNT,
        SQ.LAST90DAYS_KIOSK_CNT,
        SQ.LAST1YEAR_KIOSK_CNT,
        SQ.LAST30DAYS_PAYSTATION_CNT,
        SQ.LAST60DAYS_PAYSTATION_CNT,
        SQ.LAST90DAYS_PAYSTATION_CNT,
        SQ.LAST1YEAR_PAYSTATION_CNT,
        SQ.LAST30DAYS_ASSISTANCEAGENCY_CNT,
        SQ.LAST60DAYS_ASSISTANCEAGENCY_CNT,
        SQ.LAST90DAYS_ASSISTANCEAGENCY_CNT,
        SQ.LAST1YEAR_ASSISTANCEAGENCY_CNT,
        SQ.LAST30DAYS_CHECKLESS_AMT,
        SQ.LAST60DAYS_CHECKLESS_AMT,
        SQ.LAST90DAYS_CHECKLESS_AMT,
        SQ.LAST1YEAR_CHECKLESS_AMT,
        SQ.LAST30DAYS_ELECTRONIC_AMT,
        SQ.LAST60DAYS_ELECTRONIC_AMT,
        SQ.LAST90DAYS_ELECTRONIC_AMT,
        SQ.LAST1YEAR_ELECTRONIC_AMT,
        SQ.LAST30DAYS_WEB_AMT,
        SQ.LAST60DAYS_WEB_AMT,
        SQ.LAST90DAYS_WEB_AMT,
        SQ.LAST1YEAR_WEB_AMT,
        SQ.LAST30DAYS_V2DDA_AMT,
        SQ.LAST60DAYS_V2DDA_AMT,
        SQ.LAST90DAYS_V2DDA_AMT,
        SQ.LAST1YEAR_V2DDA_AMT,
        SQ.LAST30DAYS_WEBDA_AMT,
        SQ.LAST60DAYS_WEBDA_AMT,
        SQ.LAST90DAYS_WEBDA_AMT,
        SQ.LAST1YEAR_WEBDA_AMT,
        SQ.LAST30DAYS_MAIL_AMT,
        SQ.LAST60DAYS_MAIL_AMT,
        SQ.LAST90DAYS_MAIL_AMT,
        SQ.LAST1YEAR_MAIL_AMT,
        SQ.LAST30DAYS_KIOSK_AMT,
        SQ.LAST60DAYS_KIOSK_AMT,
        SQ.LAST90DAYS_KIOSK_AMT,
        SQ.LAST1YEAR_KIOSK_AMT,
        SQ.LAST30DAYS_PAYSTATION_AMT,
        SQ.LAST60DAYS_PAYSTATION_AMT,
        SQ.LAST90DAYS_PAYSTATION_AMT,
        SQ.LAST1YEAR_PAYSTATION_AMT,
        SQ.LAST30DAYS_ASSISTANCEAGENCY_AMT,
        SQ.LAST60DAYS_ASSISTANCEAGENCY_AMT,
        SQ.LAST90DAYS_ASSISTANCEAGENCY_AMT,
        SQ.LAST1YEAR_ASSISTANCEAGENCY_AMT
    FROM SQ_PAYMENT_F SQ
)

SELECT
    REPORT_DT,
    BILL_ACCOUNT_NB,
    ACCOUNT_D_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    PRIMARY_PREFERRED_PAYMENT_METHOD_CD,
    SECONDARY_PREFERRED_PAYMENT_METHOD_CD,
    UNIQUE_PAYMENT_METHOD_CD,
    DAYS_SINCE_LAST_PAYMENT,
    LAST30DAYS_CHECKLESS_CNT,
    LAST60DAYS_CHECKLESS_CNT,
    LAST90DAYS_CHECKLESS_CNT,
    LAST1YEAR_CHECKLESS_CNT,
    LAST30DAYS_ELECTRONIC_CNT,
    LAST60DAYS_ELECTRONIC_CNT,
    LAST90DAYS_ELECTRONIC_CNT,
    LAST1YEAR_ELECTRONIC_CNT,
    LAST30DAYS_WEB_CNT,
    LAST60DAYS_WEB_CNT,
    LAST90DAYS_WEB_CNT,
    LAST1YEAR_WEB_CNT,
    LAST30DAYS_V2DDA_CNT,
    LAST60DAYS_V2DDA_CNT,
    LAST90DAYS_V2DDA_CNT,
    LAST1YEAR_V2DDA_CNT,
    LAST30DAYS_WEBDA_CNT,
    LAST60DAYS_WEBDA_CNT,
    LAST90DAYS_WEBDA_CNT,
    LAST1YEAR_WEBDA_CNT,
    LAST30DAYS_MAIL_CNT,
    LAST60DAYS_MAIL_CNT,
    LAST90DAYS_MAIL_CNT,
    LAST1YEAR_MAIL_CNT,
    LAST30DAYS_KIOSK_CNT,
    LAST60DAYS_KIOSK_CNT,
    LAST90DAYS_KIOSK_CNT,
    LAST1YEAR_KIOSK_CNT,
    LAST30DAYS_PAYSTATION_CNT,
    LAST60DAYS_PAYSTATION_CNT,
    LAST90DAYS_PAYSTATION_CNT,
    LAST1YEAR_PAYSTATION_CNT,
    LAST30DAYS_ASSISTANCEAGENCY_CNT,
    LAST60DAYS_ASSISTANCEAGENCY_CNT,
    LAST90DAYS_ASSISTANCEAGENCY_CNT,
    LAST1YEAR_ASSISTANCEAGENCY_CNT,
    LAST30DAYS_CHECKLESS_AMT,
    LAST60DAYS_CHECKLESS_AMT,
    LAST90DAYS_CHECKLESS_AMT,
    LAST1YEAR_CHECKLESS_AMT,
    LAST30DAYS_ELECTRONIC_AMT,
    LAST60DAYS_ELECTRONIC_AMT,
    LAST90DAYS_ELECTRONIC_AMT,
    LAST1YEAR_ELECTRONIC_AMT,
    LAST30DAYS_WEB_AMT,
    LAST60DAYS_WEB_AMT,
    LAST90DAYS_WEB_AMT,
    LAST1YEAR_WEB_AMT,
    LAST30DAYS_V2DDA_AMT,
    LAST60DAYS_V2DDA_AMT,
    LAST90DAYS_V2DDA_AMT,
    LAST1YEAR_V2DDA_AMT,
    LAST30DAYS_WEBDA_AMT,
    LAST60DAYS_WEBDA_AMT,
    LAST90DAYS_WEBDA_AMT,
    LAST1YEAR_WEBDA_AMT,
    LAST30DAYS_MAIL_AMT,
    LAST60DAYS_MAIL_AMT,
    LAST90DAYS_MAIL_AMT,
    LAST1YEAR_MAIL_AMT,
    LAST30DAYS_KIOSK_AMT,
    LAST60DAYS_KIOSK_AMT,
    LAST90DAYS_KIOSK_AMT,
    LAST1YEAR_KIOSK_AMT,
    LAST30DAYS_PAYSTATION_AMT,
    LAST60DAYS_PAYSTATION_AMT,
    LAST90DAYS_PAYSTATION_AMT,
    LAST1YEAR_PAYSTATION_AMT,
    LAST30DAYS_ASSISTANCEAGENCY_AMT,
    LAST60DAYS_ASSISTANCEAGENCY_AMT,
    LAST90DAYS_ASSISTANCEAGENCY_AMT,
    LAST1YEAR_ASSISTANCEAGENCY_AMT
FROM EXP_AUDIT