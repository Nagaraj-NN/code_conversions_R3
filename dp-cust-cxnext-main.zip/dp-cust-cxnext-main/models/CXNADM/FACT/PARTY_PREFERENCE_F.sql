{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='PARTY_PREFERENCE_F_ID',
    merge_update_columns=[
        'MOBILE_ACTIVE_FL',
        'MOBILE_LAST1YEAR_FL',
        'MOBILE_EMAIL_ALERT_ACTIVE_FL',
        'MOBILE_EMAIL_ALERT_LAST1YEAR_FL',
        'MOBILE_SMS_ALERT_ACTIVE_FL',
        'MOBILE_SMS_ALERT_LAST1YEAR_FL',
        'WEB_PROFILE_ACTIVE_FL',
        'WEB_PROFILE_LAST1YEAR_FL',
        'MD5_CHECKSUM_VAL',
        'EDW_LAST_UPDT_NM',
        'EDW_LAST_UPDT_TS'
    ],
    meta={
        "mapping_name": "m_PARTY_PREFERENCE_F"
    },
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1012C_PARTY_PREFERENCE_F')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1012C_PARTY_PREFERENCE_F')
    ]
) }}

WITH TARGET_MAX_KEY AS
(
    {% if is_incremental() %}

    SELECT
        COALESCE(MAX(PARTY_PREFERENCE_F_ID), 0)::NUMBER(38,0)
            AS MAX_PARTY_PREFERENCE_F_ID
    FROM {{ this }}

    {% else %}

    SELECT
        0::NUMBER(38,0) AS MAX_PARTY_PREFERENCE_F_ID

    {% endif %}
),

RES1 AS
(
    SELECT
        BILL_ACCOUNT_NB,
        ACCOUNT_D_ID
    FROM {{ source('UTLDB01_CDWADM', 'ACCOUNT_D') }}
    WHERE CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
      AND ACTIVE_FLAG = 'Y'
      AND
      (
             BILL_ACCOUNT_NB BETWEEN '0100000000' AND '0699999999'
          OR BILL_ACCOUNT_NB BETWEEN '0700000000' AND '1099999999'
          OR BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9599999999'
          OR BILL_ACCOUNT_NB BETWEEN '9600000000' AND '9799999999'
      )
),

RES2 AS
(
    SELECT
        WEB_USER_BILL_ACCOUNT_NB,

        CASE
            WHEN SUM
            (
                CASE
                    WHEN WEB_SESSION_ID IS NOT NULL
                     AND WEB_EVENT_DT BETWEEN DATEADD(
                            DAY,
                            -30,
                            CURRENT_DATE()
                         ) AND CURRENT_DATE()
                     AND WEB_ACCESS_TYPE_CD = 'M'
                        THEN 1
                END
            ) > 0
                THEN 'Y'
            ELSE 'N'
        END AS MOBILE_ACTIVE_FL,

        CASE
            WHEN SUM
            (
                CASE
                    WHEN WEB_SESSION_ID IS NOT NULL
                     AND WEB_EVENT_DT BETWEEN ADD_MONTHS(
                            CURRENT_DATE(),
                            -12
                         ) AND CURRENT_DATE()
                     AND WEB_ACCESS_TYPE_CD = 'M'
                        THEN 1
                END
            ) > 0
                THEN 'Y'
            ELSE 'N'
        END AS MOBILE_LAST1YEAR_FL,

        CASE
            WHEN SUM
            (
                CASE
                    WHEN WEB_SESSION_ID IS NOT NULL
                     AND WEB_EVENT_DT BETWEEN DATEADD(
                            DAY,
                            -30,
                            CURRENT_DATE()
                         ) AND CURRENT_DATE()
                        THEN 1
                END
            ) > 0
                THEN 'Y'
            ELSE 'N'
        END AS WEB_PROFILE_ACTIVE_FL,

        CASE
            WHEN SUM
            (
                CASE
                    WHEN WEB_SESSION_ID IS NOT NULL
                     AND WEB_EVENT_DT BETWEEN ADD_MONTHS(
                            CURRENT_DATE(),
                            -12
                         ) AND CURRENT_DATE()
                        THEN 1
                END
            ) > 0
                THEN 'Y'
            ELSE 'N'
        END AS WEB_PROFILE_LAST1YEAR_FL

    FROM {{ source('UTLDB01_CXNADM', 'WEB_EVENT_LOGS') }}
    WHERE WEB_EVENT_DT >= ADD_MONTHS(CURRENT_DATE(), -12)
      AND WEB_USER_BILL_ACCOUNT_NB IS NOT NULL
      AND
      (
             WEB_USER_BILL_ACCOUNT_NB
                 BETWEEN '0100000000' AND '0699999999'
          OR WEB_USER_BILL_ACCOUNT_NB
                 BETWEEN '0700000000' AND '1099999999'
          OR WEB_USER_BILL_ACCOUNT_NB
                 BETWEEN '9400000000' AND '9599999999'
          OR WEB_USER_BILL_ACCOUNT_NB
                 BETWEEN '9600000000' AND '9799999999'
      )
    GROUP BY
        WEB_USER_BILL_ACCOUNT_NB
),

RES3 AS
(
    SELECT
        BILL_ACCT_NB,

        CASE
            WHEN MA_EB_CURRENT_IND = 1
                THEN 'Y'
            ELSE 'N'
        END AS MOBILE_EMAIL_ALERT_ACTIVE_FL,

        CASE
            WHEN MA_EB_HIST_IND = 1
                THEN 'Y'
            ELSE 'N'
        END AS MOBILE_EMAIL_ALERT_LAST1YEAR_FL,

        CASE
            WHEN MA_PB_CURRENT_IND = 1
                THEN 'Y'
            ELSE 'N'
        END AS MOBILE_SMS_ALERT_ACTIVE_FL,

        CASE
            WHEN MA_PB_HIST_IND = 1
                THEN 'Y'
            ELSE 'N'
        END AS MOBILE_SMS_ALERT_LAST1YEAR_FL

    FROM {{ source('UTLDB01_CSGADM', 'CDAP_CUST_CMPRHNSV') }}
    WHERE
    (
           BILL_ACCT_NB BETWEEN '0100000000' AND '0699999999'
        OR BILL_ACCT_NB BETWEEN '0700000000' AND '1099999999'
        OR BILL_ACCT_NB BETWEEN '9400000000' AND '9599999999'
        OR BILL_ACCT_NB BETWEEN '9600000000' AND '9799999999'
    )
),

SQ_PARTY_PREFERENCE_F AS
(
    SELECT
        RES1.ACCOUNT_D_ID,
        RES2.MOBILE_ACTIVE_FL,
        RES2.MOBILE_LAST1YEAR_FL,
        RES3.MOBILE_EMAIL_ALERT_ACTIVE_FL,
        RES3.MOBILE_EMAIL_ALERT_LAST1YEAR_FL,
        RES3.MOBILE_SMS_ALERT_ACTIVE_FL,
        RES3.MOBILE_SMS_ALERT_LAST1YEAR_FL,
        RES2.WEB_PROFILE_ACTIVE_FL,
        RES2.WEB_PROFILE_LAST1YEAR_FL,

        {% if is_incremental() %}

        TGT.PARTY_PREFERENCE_F_ID
            AS TGT_PARTY_PREFERENCE_F_ID,
        TGT.ACCOUNT_D_ID
            AS TGT_ACCOUNT_D_ID,
        TGT.MD5_CHECKSUM_VAL
            AS TGT_MD5_CHECKSUM_VAL,
        TGT.EDW_CRTE_NM
            AS TGT_EDW_CRTE_NM,
        TGT.EDW_CRTE_TS
            AS TGT_EDW_CRTE_TS

        {% else %}

        NULL::NUMBER(38,0)
            AS TGT_PARTY_PREFERENCE_F_ID,
        NULL::NUMBER(38,0)
            AS TGT_ACCOUNT_D_ID,
        NULL::VARCHAR(32)
            AS TGT_MD5_CHECKSUM_VAL,
        NULL::VARCHAR(50)
            AS TGT_EDW_CRTE_NM,
        NULL::TIMESTAMP_NTZ(9)
            AS TGT_EDW_CRTE_TS

        {% endif %}

    FROM RES1
    LEFT JOIN RES2
        ON RES1.BILL_ACCOUNT_NB
         = RES2.WEB_USER_BILL_ACCOUNT_NB
    LEFT JOIN RES3
        ON RES1.BILL_ACCOUNT_NB
         = RES3.BILL_ACCT_NB

    {% if is_incremental() %}

    LEFT JOIN {{ this }} TGT
        ON TGT.ACCOUNT_D_ID = RES1.ACCOUNT_D_ID

    {% endif %}
),

EXP_AUDIT_FIELDS AS
(
    SELECT
        ACCOUNT_D_ID AS SRC_ACCOUNT_D_ID,
        MOBILE_ACTIVE_FL,
        MOBILE_LAST1YEAR_FL,
        MOBILE_EMAIL_ALERT_ACTIVE_FL,
        MOBILE_EMAIL_ALERT_LAST1YEAR_FL,
        MOBILE_SMS_ALERT_ACTIVE_FL,
        MOBILE_SMS_ALERT_LAST1YEAR_FL,
        WEB_PROFILE_ACTIVE_FL,
        WEB_PROFILE_LAST1YEAR_FL,
        TGT_PARTY_PREFERENCE_F_ID,
        TGT_ACCOUNT_D_ID,
        TGT_MD5_CHECKSUM_VAL,
        TGT_EDW_CRTE_NM,
        TGT_EDW_CRTE_TS,

        MD5
        (
            COALESCE(MOBILE_ACTIVE_FL, '')
            || '~' || COALESCE(MOBILE_LAST1YEAR_FL, '')
            || '~' || COALESCE(MOBILE_EMAIL_ALERT_ACTIVE_FL, '')
            || '~' || COALESCE(MOBILE_EMAIL_ALERT_LAST1YEAR_FL, '')
            || '~' || COALESCE(MOBILE_SMS_ALERT_ACTIVE_FL, '')
            || '~' || COALESCE(MOBILE_SMS_ALERT_LAST1YEAR_FL, '')
            || '~' || COALESCE(WEB_PROFILE_ACTIVE_FL, '')
            || '~' || COALESCE(WEB_PROFILE_LAST1YEAR_FL, '')
        )::VARCHAR(32) AS SRC_MD5_CHECKSUM_VAL,

        's_m_PARTY_PREFERENCE_F'::VARCHAR(50)
            AS SRC_EDW_CRTE_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS SRC_EDW_CRTE_TS,

        's_m_PARTY_PREFERENCE_F'::VARCHAR(50)
            AS SRC_EDW_LAST_UPDT_NM,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS SRC_EDW_LAST_UPDT_TS

    FROM SQ_PARTY_PREFERENCE_F
),

RTR_CHANGED_RECORDS AS
(
    SELECT
        SRC_ACCOUNT_D_ID,
        MOBILE_ACTIVE_FL,
        MOBILE_LAST1YEAR_FL,
        MOBILE_EMAIL_ALERT_ACTIVE_FL,
        MOBILE_EMAIL_ALERT_LAST1YEAR_FL,
        MOBILE_SMS_ALERT_ACTIVE_FL,
        MOBILE_SMS_ALERT_LAST1YEAR_FL,
        WEB_PROFILE_ACTIVE_FL,
        WEB_PROFILE_LAST1YEAR_FL,
        TGT_PARTY_PREFERENCE_F_ID,
        TGT_ACCOUNT_D_ID,
        TGT_MD5_CHECKSUM_VAL,
        TGT_EDW_CRTE_NM,
        TGT_EDW_CRTE_TS,
        SRC_MD5_CHECKSUM_VAL,
        SRC_EDW_CRTE_NM,
        SRC_EDW_CRTE_TS,
        SRC_EDW_LAST_UPDT_NM,
        SRC_EDW_LAST_UPDT_TS,

        CASE
            WHEN TGT_ACCOUNT_D_ID IS NULL
             AND SRC_ACCOUNT_D_ID IS NOT NULL
                THEN 'INSERT'

            WHEN TGT_ACCOUNT_D_ID IS NOT NULL
             AND SRC_MD5_CHECKSUM_VAL <> TGT_MD5_CHECKSUM_VAL
                THEN 'UPDATE'

            ELSE 'NO_CHANGE'
        END AS ROUTER_GROUP

    FROM EXP_AUDIT_FIELDS
),

NUMBERED_CHANGED_RECORDS AS
(
    SELECT
        SRC_ACCOUNT_D_ID,
        MOBILE_ACTIVE_FL,
        MOBILE_LAST1YEAR_FL,
        MOBILE_EMAIL_ALERT_ACTIVE_FL,
        MOBILE_EMAIL_ALERT_LAST1YEAR_FL,
        MOBILE_SMS_ALERT_ACTIVE_FL,
        MOBILE_SMS_ALERT_LAST1YEAR_FL,
        WEB_PROFILE_ACTIVE_FL,
        WEB_PROFILE_LAST1YEAR_FL,
        TGT_PARTY_PREFERENCE_F_ID,
        TGT_EDW_CRTE_NM,
        TGT_EDW_CRTE_TS,
        SRC_MD5_CHECKSUM_VAL,
        SRC_EDW_CRTE_NM,
        SRC_EDW_CRTE_TS,
        SRC_EDW_LAST_UPDT_NM,
        SRC_EDW_LAST_UPDT_TS,
        ROUTER_GROUP,

        CASE
            WHEN ROUTER_GROUP = 'INSERT'
                THEN ROW_NUMBER() OVER
                (
                    PARTITION BY ROUTER_GROUP
                    ORDER BY SRC_ACCOUNT_D_ID
                )
        END AS INSERT_ROW_NUMBER

    FROM RTR_CHANGED_RECORDS
    WHERE ROUTER_GROUP IN ('INSERT', 'UPDATE')
),

SOURCE_ROWS AS
(
    SELECT
        CASE
            WHEN NCR.ROUTER_GROUP = 'INSERT'
                THEN TMK.MAX_PARTY_PREFERENCE_F_ID
                   + NCR.INSERT_ROW_NUMBER
            ELSE NCR.TGT_PARTY_PREFERENCE_F_ID
        END::NUMBER(38,0)
            AS PARTY_PREFERENCE_F_ID,

        CASE
            WHEN NCR.ROUTER_GROUP = 'INSERT'
                THEN NCR.SRC_EDW_CRTE_NM
            ELSE NCR.TGT_EDW_CRTE_NM
        END::VARCHAR(50)
            AS EDW_CRTE_NM,

        CASE
            WHEN NCR.ROUTER_GROUP = 'INSERT'
                THEN NCR.SRC_EDW_CRTE_TS
            ELSE NCR.TGT_EDW_CRTE_TS
        END::TIMESTAMP_NTZ(9)
            AS EDW_CRTE_TS,

        NCR.SRC_EDW_LAST_UPDT_NM::VARCHAR(50)
            AS EDW_LAST_UPDT_NM,

        NCR.SRC_EDW_LAST_UPDT_TS::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        NCR.SRC_ACCOUNT_D_ID::NUMBER(38,0)
            AS ACCOUNT_D_ID,

        NCR.MOBILE_ACTIVE_FL::VARCHAR(1)
            AS MOBILE_ACTIVE_FL,

        NCR.MOBILE_LAST1YEAR_FL::VARCHAR(1)
            AS MOBILE_LAST1YEAR_FL,

        NCR.MOBILE_EMAIL_ALERT_ACTIVE_FL::VARCHAR(1)
            AS MOBILE_EMAIL_ALERT_ACTIVE_FL,

        NCR.MOBILE_EMAIL_ALERT_LAST1YEAR_FL::VARCHAR(1)
            AS MOBILE_EMAIL_ALERT_LAST1YEAR_FL,

        NCR.MOBILE_SMS_ALERT_ACTIVE_FL::VARCHAR(1)
            AS MOBILE_SMS_ALERT_ACTIVE_FL,

        NCR.MOBILE_SMS_ALERT_LAST1YEAR_FL::VARCHAR(1)
            AS MOBILE_SMS_ALERT_LAST1YEAR_FL,

        NCR.WEB_PROFILE_ACTIVE_FL::VARCHAR(1)
            AS WEB_PROFILE_ACTIVE_FL,

        NCR.WEB_PROFILE_LAST1YEAR_FL::VARCHAR(1)
            AS WEB_PROFILE_LAST1YEAR_FL,

        NCR.SRC_MD5_CHECKSUM_VAL::VARCHAR(32)
            AS MD5_CHECKSUM_VAL

    FROM NUMBERED_CHANGED_RECORDS NCR
    CROSS JOIN TARGET_MAX_KEY TMK
)

SELECT
    PARTY_PREFERENCE_F_ID,
    EDW_CRTE_NM,
    EDW_CRTE_TS,
    EDW_LAST_UPDT_NM,
    EDW_LAST_UPDT_TS,
    ACCOUNT_D_ID,
    MOBILE_ACTIVE_FL,
    MOBILE_LAST1YEAR_FL,
    MOBILE_EMAIL_ALERT_ACTIVE_FL,
    MOBILE_EMAIL_ALERT_LAST1YEAR_FL,
    MOBILE_SMS_ALERT_ACTIVE_FL,
    MOBILE_SMS_ALERT_LAST1YEAR_FL,
    WEB_PROFILE_ACTIVE_FL,
    WEB_PROFILE_LAST1YEAR_FL,
    MD5_CHECKSUM_VAL
FROM SOURCE_ROWS

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY PARTY_PREFERENCE_F_ID
    ORDER BY MD5_CHECKSUM_VAL
) = 1