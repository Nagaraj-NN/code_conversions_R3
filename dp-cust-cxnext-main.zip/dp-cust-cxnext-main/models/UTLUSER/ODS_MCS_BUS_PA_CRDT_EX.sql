

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'PROD_ORDR_NB'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BUS_PA_CRDT_EX')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BUS_PA_CRDT_EX')
    ]
) }}

WITH ODS_MCS_BUS_PA_CRDT_EX_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.PROD_ORDR_NB,
    s.CO_CD_OWNR,
    s.PAY_ARRG_STAT_CD,
    s.DFLT_PAGR_DSCN_DT,
    s.STAT_LAST_CHNG_DT,
    s.CNFR_LTTR_FL,
    s.PAY_AGRM_AGCY_FL,
    s.PAY_AGRM_BILL_FL,
    s.REVW_ON_DFLT_FL,
    s.RESN_DELE_TX,
    s.CNCL_DFLT_FL,
    s.PA_RESN_CRTD_CD,
    s.EXTN_TYPE_CD,
    s.EXTN_DT,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    s.IPR_STATUS_FL,
    s.IPR_ACTION_CD,
    s.DFLT_PAGR_REMN_AT,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS BILL_ACCT_NB,
        /* PROD_ORDR_NB                 <- prod_ordr_nb                 NUMBER(10,0) -> NUMBER(10,0) */
        p."prod_ordr_nb" AS PROD_ORDR_NB,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__2, 16777216), '') AS CO_CD_OWNR,
        /* PAY_ARRG_STAT_CD             <- pay_arrg_stat_cd             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__3, 16777216), '') AS PAY_ARRG_STAT_CD,
        /* DFLT_PAGR_DSCN_DT            <- dflt_pagr_dscn_dt            DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."dflt_pagr_dscn_dt" AS TIMESTAMP_NTZ(9)) AS DFLT_PAGR_DSCN_DT,
        /* STAT_LAST_CHNG_DT            <- stat_last_chng_dt            DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."stat_last_chng_dt" AS TIMESTAMP_NTZ(9)) AS STAT_LAST_CHNG_DT,
        /* CNFR_LTTR_FL                 <- cnfr_lttr_fl                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__4, 16777216), '') AS CNFR_LTTR_FL,
        /* PAY_AGRM_AGCY_FL             <- pay_agrm_agcy_fl             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS PAY_AGRM_AGCY_FL,
        /* PAY_AGRM_BILL_FL             <- pay_agrm_bill_fl             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS PAY_AGRM_BILL_FL,
        /* REVW_ON_DFLT_FL              <- revw_on_dflt_fl              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS REVW_ON_DFLT_FL,
        /* RESN_DELE_TX                 <- resn_dele_tx                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS RESN_DELE_TX,
        /* CNCL_DFLT_FL                 <- cncl_dflt_fl                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS CNCL_DFLT_FL,
        /* PA_RESN_CRTD_CD              <- pa_resn_crtd_cd              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS PA_RESN_CRTD_CD,
        /* EXTN_TYPE_CD                 <- extn_type_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS EXTN_TYPE_CD,
        /* EXTN_DT                      <- extn_dt                      DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."extn_dt" AS TIMESTAMP_NTZ(9)) AS EXTN_DT,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* IPR_STATUS_FL                <- ipr_status_fl                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__13, 16777216), 'N') AS IPR_STATUS_FL,   /* DDL default */
        /* IPR_ACTION_CD                <- ipr_action_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__14, 16777216), 'N') AS IPR_ACTION_CD,   /* DDL default */
        /* DFLT_PAGR_REMN_AT            <- dflt_pagr_remn_at            NUMBER(10,2) -> NUMBER(10,2) */
        p."dflt_pagr_remn_at" AS DFLT_PAGR_REMN_AT
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."pay_arrg_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* pay_arrg_stat_cd -> PAY_ARRG_STAT_CD */,
            REGEXP_REPLACE(src."cnfr_lttr_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* cnfr_lttr_fl -> CNFR_LTTR_FL */,
            REGEXP_REPLACE(src."pay_agrm_agcy_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* pay_agrm_agcy_fl -> PAY_AGRM_AGCY_FL */,
            REGEXP_REPLACE(src."pay_agrm_bill_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* pay_agrm_bill_fl -> PAY_AGRM_BILL_FL */,
            REGEXP_REPLACE(src."revw_on_dflt_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* revw_on_dflt_fl -> REVW_ON_DFLT_FL */,
            REGEXP_REPLACE(src."resn_dele_tx", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* resn_dele_tx -> RESN_DELE_TX */,
            REGEXP_REPLACE(src."cncl_dflt_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* cncl_dflt_fl -> CNCL_DFLT_FL */,
            REGEXP_REPLACE(src."pa_resn_crtd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* pa_resn_crtd_cd -> PA_RESN_CRTD_CD */,
            REGEXP_REPLACE(src."extn_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* extn_type_cd -> EXTN_TYPE_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */,
            REGEXP_REPLACE(src."ipr_status_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* ipr_status_fl -> IPR_STATUS_FL */,
            REGEXP_REPLACE(src."ipr_action_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* ipr_action_cd -> IPR_ACTION_CD */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_BUS_PA_CRDT_EX') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_bus_pa_crdt_ex"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* PROD_ORDR_NB */
    AND s.PROD_ORDR_NB IS NOT NULL   /* NULL or blank in a key column */
    /* STAT_LAST_CHNG_DT */
    AND s.STAT_LAST_CHNG_DT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* DFLT_PAGR_REMN_AT */
    AND s.DFLT_PAGR_REMN_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.PROD_ORDR_NB
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.PROD_ORDR_NB,
    SRC.CO_CD_OWNR,
    SRC.PAY_ARRG_STAT_CD,
    SRC.DFLT_PAGR_DSCN_DT,
    SRC.STAT_LAST_CHNG_DT,
    SRC.CNFR_LTTR_FL,
    SRC.PAY_AGRM_AGCY_FL,
    SRC.PAY_AGRM_BILL_FL,
    SRC.REVW_ON_DFLT_FL,
    SRC.RESN_DELE_TX,
    SRC.CNCL_DFLT_FL,
    SRC.PA_RESN_CRTD_CD,
    SRC.EXTN_TYPE_CD,
    SRC.EXTN_DT,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.IPR_STATUS_FL,
    SRC.IPR_ACTION_CD,
    SRC.DFLT_PAGR_REMN_AT,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_BUS_PA_CRDT_EX_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BUS_PA_CRDT_EX') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, PROD_ORDR_NB
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.PROD_ORDR_NB = TGT.PROD_ORDR_NB
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.PAY_ARRG_STAT_CD, TGT.PAY_ARRG_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.DFLT_PAGR_DSCN_DT, TGT.DFLT_PAGR_DSCN_DT, 1, 0) = 0
        OR DECODE(SRC.STAT_LAST_CHNG_DT, TGT.STAT_LAST_CHNG_DT, 1, 0) = 0
        OR DECODE(SRC.CNFR_LTTR_FL, TGT.CNFR_LTTR_FL, 1, 0) = 0
        OR DECODE(SRC.PAY_AGRM_AGCY_FL, TGT.PAY_AGRM_AGCY_FL, 1, 0) = 0
        OR DECODE(SRC.PAY_AGRM_BILL_FL, TGT.PAY_AGRM_BILL_FL, 1, 0) = 0
        OR DECODE(SRC.REVW_ON_DFLT_FL, TGT.REVW_ON_DFLT_FL, 1, 0) = 0
        OR DECODE(SRC.RESN_DELE_TX, TGT.RESN_DELE_TX, 1, 0) = 0
        OR DECODE(SRC.CNCL_DFLT_FL, TGT.CNCL_DFLT_FL, 1, 0) = 0
        OR DECODE(SRC.PA_RESN_CRTD_CD, TGT.PA_RESN_CRTD_CD, 1, 0) = 0
        OR DECODE(SRC.EXTN_TYPE_CD, TGT.EXTN_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.EXTN_DT, TGT.EXTN_DT, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.IPR_STATUS_FL, TGT.IPR_STATUS_FL, 1, 0) = 0
        OR DECODE(SRC.IPR_ACTION_CD, TGT.IPR_ACTION_CD, 1, 0) = 0
        OR DECODE(SRC.DFLT_PAGR_REMN_AT, TGT.DFLT_PAGR_REMN_AT, 1, 0) = 0
    )

