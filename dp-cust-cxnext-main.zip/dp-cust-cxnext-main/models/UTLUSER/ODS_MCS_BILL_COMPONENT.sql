{{ config(
    schema='UTLUSER',
    materialized='incremental',
    incremental_strategy='merge',
    unique_key=[
        'BILL_ACCT_NB',
        'BILL_HEAD_NB',
        'BILL_COMP_NB'
    ],
    full_refresh=false,
        pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILL_COMPONENT')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILL_COMPONENT')
    ]
) }}

WITH SOURCE_DATA AS (
    SELECT
        CAST(
            LEFT(
                REGEXP_REPLACE(
                    SRC."bill_acct_nb",
                    '^[[:space:]]+|[[:space:]]+$',
                    ''
                ),
                10
            ) AS VARCHAR(10)
        ) AS BILL_ACCT_NB,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."bill_head_nb")), ''),
            5,
            0
        ) AS BILL_HEAD_NB,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."bill_comp_nb")), ''),
            5,
            0
        ) AS BILL_COMP_NB,

        SRC."tot_bill_at" AS TOT_BILL_AT,
        SRC."cust_chrg_at" AS CUST_CHRG_AT,
        SRC."dmnd_chrg_tot_at" AS DMND_CHRG_TOT_AT,
        SRC."enrg_chrg_tot_at" AS ENRG_CHRG_TOT_AT,
        SRC."fuel_chrg_tot_at" AS FUEL_CHRG_TOT_AT,
        SRC."misc_chrg_tot_at" AS MISC_CHRG_TOT_AT,
        SRC."rctv_dmnd_chg_at" AS RCTV_DMND_CHG_AT,
        SRC."surc_tot_at" AS SURC_TOT_AT,
        SRC."tax_tot_at" AS TAX_TOT_AT,

        COALESCE(
            REGEXP_REPLACE(
                SRC."hist_crrc_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS HIST_CRRC_CD,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."tarf_cd")), ''),
            5,
            0
        ) AS TARF_CD,

        SRC."nmtr_actv_unts_qy" AS NMTR_ACTV_UNTS_QY,
        SRC."prrt_fctr_qy" AS PRRT_FCTR_QY,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."revn_clas_cd")), ''),
            5,
            0
        ) AS REVN_CLAS_CD,

        CAST(
            SRC."bill_perd_from_dt" AS TIMESTAMP_NTZ(9)
        ) AS BILL_PERD_FROM_DT,

        CAST(
            SRC."bill_perd_to_dt" AS TIMESTAMP_NTZ(9)
        ) AS BILL_PERD_TO_DT,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."orig_bill_comp_nb")), ''),
            5,
            0
        ) AS ORIG_BILL_COMP_NB,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."supr_bill_comp_nb")), ''),
            5,
            0
        ) AS SUPR_BILL_COMP_NB,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."supr_bill_head_nb")), ''),
            5,
            0
        ) AS SUPR_BILL_HEAD_NB,

        TRY_TO_NUMBER(
            NULLIF(TRIM(TO_VARCHAR(SRC."orig_bill_head_nb")), ''),
            5,
            0
        ) AS ORIG_BILL_HEAD_NB,

        COALESCE(
            TRIM(TO_VARCHAR(SRC."bill_perd_fr_tm")),
            ''
        ) AS BILL_PERD_FR_TM,

        COALESCE(
            TRIM(TO_VARCHAR(SRC."bill_perd_to_tm")),
            ''
        ) AS BILL_PERD_TO_TM,

        COALESCE(
            REGEXP_REPLACE(
                SRC."prem_nb",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS PREM_NB,

        COALESCE(
            REGEXP_REPLACE(
                SRC."tarf_pnt_nb",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS TARF_PNT_NB,

        COALESCE(
            REGEXP_REPLACE(
                SRC."bill_comp_stat_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS BILL_COMP_STAT_CD,

        CAST(
            SRC."bill_comp_dt" AS TIMESTAMP_NTZ(9)
        ) AS BILL_COMP_DT,

        COALESCE(
            TRIM(TO_VARCHAR(SRC."bill_comp_tm")),
            ''
        ) AS BILL_COMP_TM,

        COALESCE(
            REGEXP_REPLACE(
                SRC."comp_type_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS COMP_TYPE_CD,

        SRC."smmr_usag_hist_qy" AS SMMR_USAG_HIST_QY,

        COALESCE(
            REGEXP_REPLACE(
                SRC."cumu_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS CUMU_CD,

        SRC."tarf_min_at" AS TARF_MIN_AT,
        SRC."tarf_max_at" AS TARF_MAX_AT,

        COALESCE(
            REGEXP_REPLACE(
                SRC."blpm_hist_exist_fl",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS BLPM_HIST_EXIST_FL,

        SRC."bb_estm_at" AS BB_ESTM_AT,

        CAST(
            SRC."fnnc_ts" AS TIMESTAMP_NTZ(6)
        ) AS FNNC_TS,

        COALESCE(
            REGEXP_REPLACE(
                SRC."fnnc_ts_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS FNNC_TS_CD,

        COALESCE(
            REGEXP_REPLACE(
                SRC."bb_estm_mthd_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS BB_ESTM_MTHD_CD,

        COALESCE(
            REGEXP_REPLACE(
                SRC."prorate_fl",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS PRORATE_FL,

        CAST(
            SRC."schd_bill_dt" AS TIMESTAMP_NTZ(9)
        ) AS SCHD_BILL_DT,

        SRC."dist_chrg_at" AS DIST_CHRG_AT,
        SRC."gen_chrg_at" AS GEN_CHRG_AT,
        SRC."trans_chrg_at" AS TRANS_CHRG_AT,

        COALESCE(
            REGEXP_REPLACE(
                SRC."tarf_cus_choice_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS TARF_CUS_CHOICE_CD,

        SRC."ptc_rt_value" AS PTC_RT_VALUE,

        COALESCE(
            REGEXP_REPLACE(
                SRC."last_tran_updt_nm",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ''
        ) AS LAST_TRAN_UPDT_NM,

        CAST(
            SRC."last_updt_ts" AS TIMESTAMP_NTZ(6)
        ) AS LAST_UPDT_TS,

        /* TAX_DSTC_CD is NOT NULL DEFAULT 0 in the target: pass the column's
           own default rather than dropping the row */
        COALESCE(SRC."tax_dstc_cd", '0') AS TAX_DSTC_CD,

        COALESCE(
            REGEXP_REPLACE(
                SRC."comp_on_cycle_cd",
                '^[[:space:]]+|[[:space:]]+$',
                ''
            ),
            ' '   /* DDL default */
        ) AS COMP_ON_CYCLE_CD,

        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)
            AS EDW_LAST_UPDT_TS

    FROM {{ source(
        'BRONZE_CUST_CONF_BRONZE_MACSS',
        'MCS_BILL_COMPONENT'
    ) }} SRC

    -- Source: BRONZE_CUST_CONF.BRONZE_MACSS.MCS_BILL_COMPONENT
),

VALIDATED_DATA AS (
    SELECT
        BILL_ACCT_NB,
        BILL_HEAD_NB,
        BILL_COMP_NB,
        TOT_BILL_AT,
        CUST_CHRG_AT,
        DMND_CHRG_TOT_AT,
        ENRG_CHRG_TOT_AT,
        FUEL_CHRG_TOT_AT,
        MISC_CHRG_TOT_AT,
        RCTV_DMND_CHG_AT,
        SURC_TOT_AT,
        TAX_TOT_AT,
        HIST_CRRC_CD,
        TARF_CD,
        NMTR_ACTV_UNTS_QY,
        PRRT_FCTR_QY,
        REVN_CLAS_CD,
        BILL_PERD_FROM_DT,
        BILL_PERD_TO_DT,
        ORIG_BILL_COMP_NB,
        SUPR_BILL_COMP_NB,
        SUPR_BILL_HEAD_NB,
        ORIG_BILL_HEAD_NB,
        BILL_PERD_FR_TM,
        BILL_PERD_TO_TM,
        PREM_NB,
        TARF_PNT_NB,
        BILL_COMP_STAT_CD,
        BILL_COMP_DT,
        BILL_COMP_TM,
        COMP_TYPE_CD,
        SMMR_USAG_HIST_QY,
        CUMU_CD,
        TARF_MIN_AT,
        TARF_MAX_AT,
        BLPM_HIST_EXIST_FL,
        BB_ESTM_AT,
        FNNC_TS,
        FNNC_TS_CD,
        BB_ESTM_MTHD_CD,
        PRORATE_FL,
        SCHD_BILL_DT,
        DIST_CHRG_AT,
        GEN_CHRG_AT,
        TRANS_CHRG_AT,
        TARF_CUS_CHOICE_CD,
        PTC_RT_VALUE,
        LAST_TRAN_UPDT_NM,
        LAST_UPDT_TS,
        TAX_DSTC_CD,
        COMP_ON_CYCLE_CD,
        EDW_LAST_UPDT_TS
    FROM SOURCE_DATA
    WHERE NULLIF(TRIM(BILL_ACCT_NB), '') IS NOT NULL
      AND BILL_HEAD_NB IS NOT NULL
      AND BILL_COMP_NB IS NOT NULL
      AND TOT_BILL_AT IS NOT NULL
      AND CUST_CHRG_AT IS NOT NULL
      AND DMND_CHRG_TOT_AT IS NOT NULL
      AND ENRG_CHRG_TOT_AT IS NOT NULL
      AND FUEL_CHRG_TOT_AT IS NOT NULL
      AND MISC_CHRG_TOT_AT IS NOT NULL
      AND RCTV_DMND_CHG_AT IS NOT NULL
      AND SURC_TOT_AT IS NOT NULL
      AND TAX_TOT_AT IS NOT NULL
      AND TARF_CD IS NOT NULL
      AND NMTR_ACTV_UNTS_QY IS NOT NULL
      AND PRRT_FCTR_QY IS NOT NULL
      AND REVN_CLAS_CD IS NOT NULL
      AND BILL_PERD_FROM_DT IS NOT NULL
      AND BILL_PERD_TO_DT IS NOT NULL
      AND ORIG_BILL_COMP_NB IS NOT NULL
      AND SUPR_BILL_COMP_NB IS NOT NULL
      AND SUPR_BILL_HEAD_NB IS NOT NULL
      AND ORIG_BILL_HEAD_NB IS NOT NULL
      AND BILL_COMP_DT IS NOT NULL
      AND SMMR_USAG_HIST_QY IS NOT NULL
      AND TARF_MIN_AT IS NOT NULL
      AND TARF_MAX_AT IS NOT NULL
      AND BB_ESTM_AT IS NOT NULL
      AND FNNC_TS IS NOT NULL
      AND SCHD_BILL_DT IS NOT NULL
      AND DIST_CHRG_AT IS NOT NULL
      AND GEN_CHRG_AT IS NOT NULL
      AND TRANS_CHRG_AT IS NOT NULL
      AND PTC_RT_VALUE IS NOT NULL
      AND LAST_UPDT_TS IS NOT NULL

    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
            BILL_ACCT_NB,
            BILL_HEAD_NB,
            BILL_COMP_NB
        ORDER BY
            LAST_UPDT_TS DESC,
            EDW_LAST_UPDT_TS DESC
    ) = 1
),

FINAL AS (
    SELECT
        SRC.BILL_ACCT_NB,
        SRC.BILL_HEAD_NB,
        SRC.BILL_COMP_NB,
        SRC.TOT_BILL_AT,
        SRC.CUST_CHRG_AT,
        SRC.DMND_CHRG_TOT_AT,
        SRC.ENRG_CHRG_TOT_AT,
        SRC.FUEL_CHRG_TOT_AT,
        SRC.MISC_CHRG_TOT_AT,
        SRC.RCTV_DMND_CHG_AT,
        SRC.SURC_TOT_AT,
        SRC.TAX_TOT_AT,
        SRC.HIST_CRRC_CD,
        SRC.TARF_CD,
        SRC.NMTR_ACTV_UNTS_QY,
        SRC.PRRT_FCTR_QY,
        SRC.REVN_CLAS_CD,
        SRC.BILL_PERD_FROM_DT,
        SRC.BILL_PERD_TO_DT,
        SRC.ORIG_BILL_COMP_NB,
        SRC.SUPR_BILL_COMP_NB,
        SRC.SUPR_BILL_HEAD_NB,
        SRC.ORIG_BILL_HEAD_NB,
        SRC.BILL_PERD_FR_TM,
        SRC.BILL_PERD_TO_TM,
        SRC.PREM_NB,
        SRC.TARF_PNT_NB,
        SRC.BILL_COMP_STAT_CD,
        SRC.BILL_COMP_DT,
        SRC.BILL_COMP_TM,
        SRC.COMP_TYPE_CD,
        SRC.SMMR_USAG_HIST_QY,
        SRC.CUMU_CD,
        SRC.TARF_MIN_AT,
        SRC.TARF_MAX_AT,
        SRC.BLPM_HIST_EXIST_FL,
        SRC.BB_ESTM_AT,
        SRC.FNNC_TS,
        SRC.FNNC_TS_CD,
        SRC.BB_ESTM_MTHD_CD,
        SRC.PRORATE_FL,
        SRC.SCHD_BILL_DT,
        SRC.DIST_CHRG_AT,
        SRC.GEN_CHRG_AT,
        SRC.TRANS_CHRG_AT,
        SRC.TARF_CUS_CHOICE_CD,
        SRC.PTC_RT_VALUE,
        SRC.LAST_TRAN_UPDT_NM,
        SRC.LAST_UPDT_TS,
        SRC.TAX_DSTC_CD,
        SRC.COMP_ON_CYCLE_CD,
        SRC.EDW_LAST_UPDT_TS
    FROM VALIDATED_DATA SRC

    {% if is_incremental() %}
     LEFT JOIN (
         /* the target is deduped too: a duplicate key already sitting in
            ODS would fan this join out and re-introduce duplicates */
         SELECT *
         FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BILL_COMPONENT') }}
         QUALIFY ROW_NUMBER() OVER (
             PARTITION BY BILL_ACCT_NB, BILL_HEAD_NB, BILL_COMP_NB
             ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
         ) = 1
     ) TGT
        ON SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
        AND SRC.BILL_HEAD_NB = TGT.BILL_HEAD_NB
        AND SRC.BILL_COMP_NB = TGT.BILL_COMP_NB

    WHERE TGT.BILL_ACCT_NB IS NULL
       OR (
            DECODE(
                SRC.TOT_BILL_AT,
                TGT.TOT_BILL_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.CUST_CHRG_AT,
                TGT.CUST_CHRG_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.DMND_CHRG_TOT_AT,
                TGT.DMND_CHRG_TOT_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.ENRG_CHRG_TOT_AT,
                TGT.ENRG_CHRG_TOT_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.FUEL_CHRG_TOT_AT,
                TGT.FUEL_CHRG_TOT_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.MISC_CHRG_TOT_AT,
                TGT.MISC_CHRG_TOT_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.RCTV_DMND_CHG_AT,
                TGT.RCTV_DMND_CHG_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.SURC_TOT_AT,
                TGT.SURC_TOT_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TAX_TOT_AT,
                TGT.TAX_TOT_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.HIST_CRRC_CD,
                TGT.HIST_CRRC_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TARF_CD,
                TGT.TARF_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.NMTR_ACTV_UNTS_QY,
                TGT.NMTR_ACTV_UNTS_QY,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.PRRT_FCTR_QY,
                TGT.PRRT_FCTR_QY,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.REVN_CLAS_CD,
                TGT.REVN_CLAS_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_PERD_FROM_DT,
                TGT.BILL_PERD_FROM_DT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_PERD_TO_DT,
                TGT.BILL_PERD_TO_DT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.ORIG_BILL_COMP_NB,
                TGT.ORIG_BILL_COMP_NB,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.SUPR_BILL_COMP_NB,
                TGT.SUPR_BILL_COMP_NB,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.SUPR_BILL_HEAD_NB,
                TGT.SUPR_BILL_HEAD_NB,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.ORIG_BILL_HEAD_NB,
                TGT.ORIG_BILL_HEAD_NB,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_PERD_FR_TM,
                TGT.BILL_PERD_FR_TM,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_PERD_TO_TM,
                TGT.BILL_PERD_TO_TM,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.PREM_NB,
                TGT.PREM_NB,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TARF_PNT_NB,
                TGT.TARF_PNT_NB,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_COMP_STAT_CD,
                TGT.BILL_COMP_STAT_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_COMP_DT,
                TGT.BILL_COMP_DT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BILL_COMP_TM,
                TGT.BILL_COMP_TM,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.COMP_TYPE_CD,
                TGT.COMP_TYPE_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.SMMR_USAG_HIST_QY,
                TGT.SMMR_USAG_HIST_QY,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.CUMU_CD,
                TGT.CUMU_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TARF_MIN_AT,
                TGT.TARF_MIN_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TARF_MAX_AT,
                TGT.TARF_MAX_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BLPM_HIST_EXIST_FL,
                TGT.BLPM_HIST_EXIST_FL,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BB_ESTM_AT,
                TGT.BB_ESTM_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.FNNC_TS,
                TGT.FNNC_TS,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.FNNC_TS_CD,
                TGT.FNNC_TS_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.BB_ESTM_MTHD_CD,
                TGT.BB_ESTM_MTHD_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.PRORATE_FL,
                TGT.PRORATE_FL,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.SCHD_BILL_DT,
                TGT.SCHD_BILL_DT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.DIST_CHRG_AT,
                TGT.DIST_CHRG_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.GEN_CHRG_AT,
                TGT.GEN_CHRG_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TRANS_CHRG_AT,
                TGT.TRANS_CHRG_AT,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TARF_CUS_CHOICE_CD,
                TGT.TARF_CUS_CHOICE_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.PTC_RT_VALUE,
                TGT.PTC_RT_VALUE,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.LAST_TRAN_UPDT_NM,
                TGT.LAST_TRAN_UPDT_NM,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.LAST_UPDT_TS,
                TGT.LAST_UPDT_TS,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.TAX_DSTC_CD,
                TGT.TAX_DSTC_CD,
                1,
                0
            ) = 0
            OR DECODE(
                SRC.COMP_ON_CYCLE_CD,
                TGT.COMP_ON_CYCLE_CD,
                1,
                0
            ) = 0
        )

    {% endif %}
)

SELECT
    BILL_ACCT_NB,
    BILL_HEAD_NB,
    BILL_COMP_NB,
    TOT_BILL_AT,
    CUST_CHRG_AT,
    DMND_CHRG_TOT_AT,
    ENRG_CHRG_TOT_AT,
    FUEL_CHRG_TOT_AT,
    MISC_CHRG_TOT_AT,
    RCTV_DMND_CHG_AT,
    SURC_TOT_AT,
    TAX_TOT_AT,
    HIST_CRRC_CD,
    TARF_CD,
    NMTR_ACTV_UNTS_QY,
    PRRT_FCTR_QY,
    REVN_CLAS_CD,
    BILL_PERD_FROM_DT,
    BILL_PERD_TO_DT,
    ORIG_BILL_COMP_NB,
    SUPR_BILL_COMP_NB,
    SUPR_BILL_HEAD_NB,
    ORIG_BILL_HEAD_NB,
    BILL_PERD_FR_TM,
    BILL_PERD_TO_TM,
    PREM_NB,
    TARF_PNT_NB,
    BILL_COMP_STAT_CD,
    BILL_COMP_DT,
    BILL_COMP_TM,
    COMP_TYPE_CD,
    SMMR_USAG_HIST_QY,
    CUMU_CD,
    TARF_MIN_AT,
    TARF_MAX_AT,
    BLPM_HIST_EXIST_FL,
    BB_ESTM_AT,
    FNNC_TS,
    FNNC_TS_CD,
    BB_ESTM_MTHD_CD,
    PRORATE_FL,
    SCHD_BILL_DT,
    DIST_CHRG_AT,
    GEN_CHRG_AT,
    TRANS_CHRG_AT,
    TARF_CUS_CHOICE_CD,
    PTC_RT_VALUE,
    LAST_TRAN_UPDT_NM,
    LAST_UPDT_TS,
    TAX_DSTC_CD,
    COMP_ON_CYCLE_CD,
    EDW_LAST_UPDT_TS
FROM FINAL