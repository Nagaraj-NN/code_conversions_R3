

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['CO_CD_OWNR', 'CRTN_TS'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_NOTES')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_NOTES')
    ]
) }}

WITH ODS_MCS_NOTES_SQ AS (
SELECT
    s.CO_CD_OWNR,
    s.CRTN_TS,
    s.NOTE_PRRT_CD,
    s.NOTE_FRMT_CD,
    s.USER_IDNT_CRTD_CD,
    s.USER_IDNT_UPDT_CD,
    s.NOTE_CD,
    s.NOTE_TS,
    s.LAST_UPD_DT,
    s.LAST_UPD_TM,
    s.ORGN_CONV_ID_NM,
    s.NOTE_DESC_TX,
    s.BILL_ACCT_NB,
    s.CUST_NB,
    s.PREM_NB,
    s.STATE_CD,
    s.DVSN_CD,
    s.AREA_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS CO_CD_OWNR,
        /* CRTN_TS                      <- crtn_ts                      TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."crtn_ts" AS CRTN_TS,
        /* NOTE_PRRT_CD                 <- note_prrt_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__2, 16777216), '') AS NOTE_PRRT_CD,
        /* NOTE_FRMT_CD                 <- note_frmt_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__3, 16777216), '') AS NOTE_FRMT_CD,
        /* USER_IDNT_CRTD_CD            <- user_idnt_crtd_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__4, 16777216), '') AS USER_IDNT_CRTD_CD,
        /* USER_IDNT_UPDT_CD            <- user_idnt_updt_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS USER_IDNT_UPDT_CD,
        /* NOTE_CD                      <- note_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS NOTE_CD,
        /* NOTE_TS                      <- note_ts                      TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."note_ts" AS NOTE_TS,
        /* LAST_UPD_DT                  <- last_upd_dt                  DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."last_upd_dt" AS TIMESTAMP_NTZ(9)) AS LAST_UPD_DT,
        /* LAST_UPD_TM                  <- last_upd_tm                  TIMESTAMP_NTZ(6) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS LAST_UPD_TM,
        /* ORGN_CONV_ID_NM              <- orgn_conv_id_nm              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS ORGN_CONV_ID_NM,
        /* NOTE_DESC_TX                 <- note_desc_tx                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS NOTE_DESC_TX,
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS BILL_ACCT_NB,
        /* CUST_NB                      <- cust_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS CUST_NB,
        /* PREM_NB                      <- prem_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS PREM_NB,
        /* STATE_CD                     <- state_cd                     VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__13, 16777216), '') AS STATE_CD,
        /* DVSN_CD                      <- dvsn_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__14, 16777216), '') AS DVSN_CD,
        /* AREA_CD                      <- area_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__15, 16777216), '') AS AREA_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__16, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."note_prrt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* note_prrt_cd -> NOTE_PRRT_CD */,
            REGEXP_REPLACE(src."note_frmt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* note_frmt_cd -> NOTE_FRMT_CD */,
            REGEXP_REPLACE(src."user_idnt_crtd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* user_idnt_crtd_cd -> USER_IDNT_CRTD_CD */,
            REGEXP_REPLACE(src."user_idnt_updt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* user_idnt_updt_cd -> USER_IDNT_UPDT_CD */,
            REGEXP_REPLACE(src."note_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* note_cd -> NOTE_CD */,
            REGEXP_REPLACE(TO_VARCHAR(src."last_upd_tm"), '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* last_upd_tm -> LAST_UPD_TM */,
            REGEXP_REPLACE(src."orgn_conv_id_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* orgn_conv_id_nm -> ORGN_CONV_ID_NM */,
            REGEXP_REPLACE(src."note_desc_tx", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* note_desc_tx -> NOTE_DESC_TX */,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."cust_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* cust_nb -> CUST_NB */,
            REGEXP_REPLACE(src."prem_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* prem_nb -> PREM_NB */,
            REGEXP_REPLACE(src."state_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* state_cd -> STATE_CD */,
            REGEXP_REPLACE(src."dvsn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* dvsn_cd -> DVSN_CD */,
            REGEXP_REPLACE(src."area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* area_cd -> AREA_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_NOTES') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_notes"
    ) p
) s
WHERE 1 = 1
    /* CO_CD_OWNR */
    AND (s.CO_CD_OWNR IS NOT NULL AND s.CO_CD_OWNR <> '')   /* NULL or blank in a key column */
    /* CRTN_TS */
    AND (s.CRTN_TS IS NULL OR YEAR(s.CRTN_TS) BETWEEN 1900 AND 9999)   /* date/timestamp outside the accepted year range */
    AND s.CRTN_TS IS NOT NULL   /* NULL or blank in a key column */
    /* NOTE_TS */
    AND s.NOTE_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPD_DT */
    AND s.LAST_UPD_DT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.CO_CD_OWNR, s.CRTN_TS
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.CO_CD_OWNR,
    SRC.CRTN_TS,
    SRC.NOTE_PRRT_CD,
    SRC.NOTE_FRMT_CD,
    SRC.USER_IDNT_CRTD_CD,
    SRC.USER_IDNT_UPDT_CD,
    SRC.NOTE_CD,
    SRC.NOTE_TS,
    SRC.LAST_UPD_DT,
    SRC.LAST_UPD_TM,
    SRC.ORGN_CONV_ID_NM,
    SRC.NOTE_DESC_TX,
    SRC.BILL_ACCT_NB,
    SRC.CUST_NB,
    SRC.PREM_NB,
    SRC.STATE_CD,
    SRC.DVSN_CD,
    SRC.AREA_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_NOTES_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_NOTES') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY CO_CD_OWNR, CRTN_TS
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.CO_CD_OWNR = TGT.CO_CD_OWNR
    AND SRC.CRTN_TS = TGT.CRTN_TS
WHERE
    TGT.CO_CD_OWNR IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.NOTE_PRRT_CD, TGT.NOTE_PRRT_CD, 1, 0) = 0
        OR DECODE(SRC.NOTE_FRMT_CD, TGT.NOTE_FRMT_CD, 1, 0) = 0
        OR DECODE(SRC.USER_IDNT_CRTD_CD, TGT.USER_IDNT_CRTD_CD, 1, 0) = 0
        OR DECODE(SRC.USER_IDNT_UPDT_CD, TGT.USER_IDNT_UPDT_CD, 1, 0) = 0
        OR DECODE(SRC.NOTE_CD, TGT.NOTE_CD, 1, 0) = 0
        OR DECODE(SRC.NOTE_TS, TGT.NOTE_TS, 1, 0) = 0
        OR DECODE(SRC.LAST_UPD_DT, TGT.LAST_UPD_DT, 1, 0) = 0
        OR DECODE(SRC.LAST_UPD_TM, TGT.LAST_UPD_TM, 1, 0) = 0
        OR DECODE(SRC.ORGN_CONV_ID_NM, TGT.ORGN_CONV_ID_NM, 1, 0) = 0
        OR DECODE(SRC.NOTE_DESC_TX, TGT.NOTE_DESC_TX, 1, 0) = 0
        OR DECODE(SRC.BILL_ACCT_NB, TGT.BILL_ACCT_NB, 1, 0) = 0
        OR DECODE(SRC.CUST_NB, TGT.CUST_NB, 1, 0) = 0
        OR DECODE(SRC.PREM_NB, TGT.PREM_NB, 1, 0) = 0
        OR DECODE(SRC.STATE_CD, TGT.STATE_CD, 1, 0) = 0
        OR DECODE(SRC.DVSN_CD, TGT.DVSN_CD, 1, 0) = 0
        OR DECODE(SRC.AREA_CD, TGT.AREA_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )

