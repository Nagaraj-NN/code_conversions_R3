{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['WEB_ID'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_WEB_USER')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_WEB_USER')
    ]
) }}

WITH ODS_MCS_WEB_USER_SQ AS (
SELECT
    s.WEB_ID,
    s.WEB_PSWD,
    s.WEB_PSWD_HINT,
    s.BILL_ACCT_NB,
    s.WEB_EMAIL,
    s.WEB_REG_KEY,
    s.WEB_RQST_NM,
    s.WEB_RQST_AD,
    s.PSWD_RQRD_CHG_DT,
    s.WEB_IND,
    s.WEB_USER_STAT_CD,
    s.WEB_FIRST_NM,
    s.WEB_LAST_NM,
    s.WEB_PREFIX_NM,
    s.EMAIL_FORMAT_CD,
    s.WEB_SMS,
    s.SMS_QUIET_START_TM,
    s.SMS_QUIET_END_TM,
    s.SMS_QUIET_TZ,
    s.CRTN_TS,
    s.LAST_UPDT_TS,
    s.WEB_ID_NB,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* WEB_ID                       <- web_id                       VARCHAR(134217728) -> VARCHAR(512) */
        LEFT(p.N__1, 512) AS WEB_ID,
        /* WEB_PSWD                     <- web_pswd                     VARCHAR(134217728) -> VARCHAR(12) */
        COALESCE(LEFT(p.N__2, 12), '') AS WEB_PSWD,
        /* WEB_PSWD_HINT                <- web_pswd_hint                VARCHAR(134217728) -> VARCHAR(50) */
        COALESCE(LEFT(p.N__3, 50), '') AS WEB_PSWD_HINT,
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(10) */
        COALESCE(LEFT(p.N__4, 10), '') AS BILL_ACCT_NB,
        /* WEB_EMAIL                    <- web_email                    VARCHAR(134217728) -> VARCHAR(100) */
        COALESCE(LEFT(p.N__5, 100), '') AS WEB_EMAIL,
        /* WEB_REG_KEY                  <- web_reg_key                  VARCHAR(134217728) -> VARCHAR(12) */
        COALESCE(LEFT(p.N__6, 12), '') AS WEB_REG_KEY,
        /* WEB_RQST_NM                  <- web_rqst_nm                  VARCHAR(134217728) -> VARCHAR(70) */
        COALESCE(LEFT(p.N__7, 70), '') AS WEB_RQST_NM,
        /* WEB_RQST_AD                  <- web_rqst_ad                  VARCHAR(134217728) -> VARCHAR(100) */
        COALESCE(LEFT(p.N__8, 100), '') AS WEB_RQST_AD,
        /* PSWD_RQRD_CHG_DT             <- pswd_rqrd_chg_dt             DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."pswd_rqrd_chg_dt" AS TIMESTAMP_NTZ(9)) AS PSWD_RQRD_CHG_DT,
        /* WEB_IND                      <- web_ind                      VARCHAR(134217728) -> VARCHAR(10) */
        COALESCE(LEFT(p.N__9, 10), '') AS WEB_IND,
        /* WEB_USER_STAT_CD             <- web_user_stat_cd             VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__10, 1), '') AS WEB_USER_STAT_CD,
        /* WEB_FIRST_NM                 <- web_first_nm                 VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__11, 35), '') AS WEB_FIRST_NM,
        /* WEB_LAST_NM                  <- web_last_nm                  VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__12, 35), '') AS WEB_LAST_NM,
        /* WEB_PREFIX_NM                <- web_prefix_nm                VARCHAR(134217728) -> VARCHAR(4) */
        COALESCE(LEFT(p.N__13, 4), '') AS WEB_PREFIX_NM,
        /* EMAIL_FORMAT_CD              <- email_format_cd              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__14, 1), 'H') AS EMAIL_FORMAT_CD,   /* DDL default */
        /* WEB_SMS                      <- web_sms                      VARCHAR(134217728) -> VARCHAR(256) */
        COALESCE(LEFT(p.N__15, 256), '') AS WEB_SMS,
        /* SMS_QUIET_START_TM           <- sms_quiet_start_tm           TIMESTAMP_NTZ(6) -> VARCHAR(8) */
        LEFT(p.N__16, 8) AS SMS_QUIET_START_TM,
        /* SMS_QUIET_END_TM             <- sms_quiet_end_tm             TIMESTAMP_NTZ(6) -> VARCHAR(8) */
        LEFT(p.N__17, 8) AS SMS_QUIET_END_TM,
        /* SMS_QUIET_TZ                 <- sms_quiet_tz                 VARCHAR(134217728) -> VARCHAR(3) */
        COALESCE(LEFT(p.N__18, 3), '') AS SMS_QUIET_TZ,
        /* CRTN_TS                      <- crtn_ts                      TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."crtn_ts" AS CRTN_TS,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* WEB_ID_NB                    <- web_id_nb                    NUMBER(10,0) -> NUMBER(10,0) */
        p."web_id_nb" AS WEB_ID_NB
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."web_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* web_id -> WEB_ID */,
            REGEXP_REPLACE(src."web_pswd", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* web_pswd -> WEB_PSWD */,
            REGEXP_REPLACE(src."web_pswd_hint", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* web_pswd_hint -> WEB_PSWD_HINT */,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."web_email", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* web_email -> WEB_EMAIL */,
            REGEXP_REPLACE(src."web_reg_key", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* web_reg_key -> WEB_REG_KEY */,
            REGEXP_REPLACE(src."web_rqst_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* web_rqst_nm -> WEB_RQST_NM */,
            REGEXP_REPLACE(src."web_rqst_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* web_rqst_ad -> WEB_RQST_AD */,
            REGEXP_REPLACE(src."web_ind", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* web_ind -> WEB_IND */,
            REGEXP_REPLACE(src."web_user_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* web_user_stat_cd -> WEB_USER_STAT_CD */,
            REGEXP_REPLACE(src."web_first_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* web_first_nm -> WEB_FIRST_NM */,
            REGEXP_REPLACE(src."web_last_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* web_last_nm -> WEB_LAST_NM */,
            REGEXP_REPLACE(src."web_prefix_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* web_prefix_nm -> WEB_PREFIX_NM */,
            REGEXP_REPLACE(src."email_format_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* email_format_cd -> EMAIL_FORMAT_CD */,
            REGEXP_REPLACE(src."web_sms", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* web_sms -> WEB_SMS */,
            REGEXP_REPLACE(TO_VARCHAR(src."sms_quiet_start_tm"), '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* sms_quiet_start_tm -> SMS_QUIET_START_TM */,
            REGEXP_REPLACE(TO_VARCHAR(src."sms_quiet_end_tm"), '^[[:space:]]+|[[:space:]]+$', '') AS N__17   /* sms_quiet_end_tm -> SMS_QUIET_END_TM */,
            REGEXP_REPLACE(src."sms_quiet_tz", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* sms_quiet_tz -> SMS_QUIET_TZ */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_WEB_USER') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_web_user"
    ) p
) s
WHERE 1 = 1
    /* WEB_ID */
    AND (s.WEB_ID IS NOT NULL AND s.WEB_ID <> '')   /* NULL or blank in a key column */
    /* CRTN_TS */
    AND s.CRTN_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* WEB_ID_NB */
    AND s.WEB_ID_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.WEB_ID
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.WEB_ID,
    SRC.WEB_PSWD,
    SRC.WEB_PSWD_HINT,
    SRC.BILL_ACCT_NB,
    SRC.WEB_EMAIL,
    SRC.WEB_REG_KEY,
    SRC.WEB_RQST_NM,
    SRC.WEB_RQST_AD,
    SRC.PSWD_RQRD_CHG_DT,
    SRC.WEB_IND,
    SRC.WEB_USER_STAT_CD,
    SRC.WEB_FIRST_NM,
    SRC.WEB_LAST_NM,
    SRC.WEB_PREFIX_NM,
    SRC.EMAIL_FORMAT_CD,
    SRC.WEB_SMS,
    SRC.SMS_QUIET_START_TM,
    SRC.SMS_QUIET_END_TM,
    SRC.SMS_QUIET_TZ,
    SRC.CRTN_TS,
    SRC.LAST_UPDT_TS,
    SRC.WEB_ID_NB,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_WEB_USER_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_WEB_USER') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY WEB_ID
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.WEB_ID = TGT.WEB_ID
WHERE
    TGT.WEB_ID IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.WEB_PSWD, TGT.WEB_PSWD, 1, 0) = 0
        OR DECODE(SRC.WEB_PSWD_HINT, TGT.WEB_PSWD_HINT, 1, 0) = 0
        OR DECODE(SRC.BILL_ACCT_NB, TGT.BILL_ACCT_NB, 1, 0) = 0
        OR DECODE(SRC.WEB_EMAIL, TGT.WEB_EMAIL, 1, 0) = 0
        OR DECODE(SRC.WEB_REG_KEY, TGT.WEB_REG_KEY, 1, 0) = 0
        OR DECODE(SRC.WEB_RQST_NM, TGT.WEB_RQST_NM, 1, 0) = 0
        OR DECODE(SRC.WEB_RQST_AD, TGT.WEB_RQST_AD, 1, 0) = 0
        OR DECODE(SRC.PSWD_RQRD_CHG_DT, TGT.PSWD_RQRD_CHG_DT, 1, 0) = 0
        OR DECODE(SRC.WEB_IND, TGT.WEB_IND, 1, 0) = 0
        OR DECODE(SRC.WEB_USER_STAT_CD, TGT.WEB_USER_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.WEB_FIRST_NM, TGT.WEB_FIRST_NM, 1, 0) = 0
        OR DECODE(SRC.WEB_LAST_NM, TGT.WEB_LAST_NM, 1, 0) = 0
        OR DECODE(SRC.WEB_PREFIX_NM, TGT.WEB_PREFIX_NM, 1, 0) = 0
        OR DECODE(SRC.EMAIL_FORMAT_CD, TGT.EMAIL_FORMAT_CD, 1, 0) = 0
        OR DECODE(SRC.WEB_SMS, TGT.WEB_SMS, 1, 0) = 0
        OR DECODE(SRC.SMS_QUIET_START_TM, TGT.SMS_QUIET_START_TM, 1, 0) = 0
        OR DECODE(SRC.SMS_QUIET_END_TM, TGT.SMS_QUIET_END_TM, 1, 0) = 0
        OR DECODE(SRC.SMS_QUIET_TZ, TGT.SMS_QUIET_TZ, 1, 0) = 0
        OR DECODE(SRC.CRTN_TS, TGT.CRTN_TS, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.WEB_ID_NB, TGT.WEB_ID_NB, 1, 0) = 0
    )

