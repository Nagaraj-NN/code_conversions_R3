

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['CUST_NB'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_CUSTOMER')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_CUSTOMER')
    ]
) }}

WITH ODS_MCS_CUSTOMER_SQ AS (
SELECT
    s.CUST_NB,
    s.CO_CD_OWNR,
    s.RSDN_CORP_IND_CD,
    s.SRVY_SENT_DT,
    s.CUST_NM_INFO_FL,
    s.OWNR_AGNT_FLAG_FL,
    s.NFNC_CNTL_UNIT_NB,
    s.CRPR_AFFL_NM,
    s.CUST_1ST_1_NM,
    s.CUST_LAST_1_NM,
    s.CUST_MDDL_1_NM,
    s.CUST_PRFX_1_NM,
    s.CUST_SFFX_1_NM,
    s.CUST_1ST_2_NM,
    s.CUST_LAST_2_NM,
    s.CUST_MDDL_2_NM,
    s.CUST_PRFX_2_NM,
    s.CUST_SFFX_2_NM,
    s.CUST_ENVL_OVRR_FL,
    s.CRDT_RTNG_NB,
    s.HNDBK_SENT_DT,
    s.TAX_ID,
    s.CRDT_RTNG_RECV_DT,
    s.ENERGY_DVRSN_FL,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* CUST_NB                      <- cust_nb                      VARCHAR(134217728) -> VARCHAR(9) */
        LEFT(p.N__1, 9) AS CUST_NB,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__2, 2), '') AS CO_CD_OWNR,
        /* RSDN_CORP_IND_CD             <- rsdn_corp_ind_cd             VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__3, 1), '') AS RSDN_CORP_IND_CD,
        /* SRVY_SENT_DT                 <- srvy_sent_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."srvy_sent_dt" AS TIMESTAMP_NTZ(9)) AS SRVY_SENT_DT,
        /* CUST_NM_INFO_FL              <- cust_nm_info_fl              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__4, 1), '') AS CUST_NM_INFO_FL,
        /* OWNR_AGNT_FLAG_FL            <- ownr_agnt_flag_fl            VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__5, 1), '') AS OWNR_AGNT_FLAG_FL,
        /* NFNC_CNTL_UNIT_NB            <- nfnc_cntl_unit_nb            NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__6, 5, 0) AS NFNC_CNTL_UNIT_NB,
        p.N__6 AS RAW__6,
        /* CRPR_AFFL_NM                 <- crpr_affl_nm                 VARCHAR(134217728) -> VARCHAR(20) */
        COALESCE(LEFT(p.N__7, 20), '') AS CRPR_AFFL_NM,
        /* CUST_1ST_1_NM                <- cust_1st_1_nm                VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__8, 35), '') AS CUST_1ST_1_NM,
        /* CUST_LAST_1_NM               <- cust_last_1_nm               VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__9, 35), '') AS CUST_LAST_1_NM,
        /* CUST_MDDL_1_NM               <- cust_mddl_1_nm               VARCHAR(134217728) -> VARCHAR(20) */
        COALESCE(LEFT(p.N__10, 20), '') AS CUST_MDDL_1_NM,
        /* CUST_PRFX_1_NM               <- cust_prfx_1_nm               VARCHAR(134217728) -> VARCHAR(4) */
        COALESCE(LEFT(p.N__11, 4), '') AS CUST_PRFX_1_NM,
        /* CUST_SFFX_1_NM               <- cust_sffx_1_nm               VARCHAR(134217728) -> VARCHAR(3) */
        COALESCE(LEFT(p.N__12, 3), '') AS CUST_SFFX_1_NM,
        /* CUST_1ST_2_NM                <- cust_1st_2_nm                VARCHAR(134217728) -> VARCHAR(20) */
        COALESCE(LEFT(p.N__13, 20), '') AS CUST_1ST_2_NM,
        /* CUST_LAST_2_NM               <- cust_last_2_nm               VARCHAR(134217728) -> VARCHAR(20) */
        COALESCE(LEFT(p.N__14, 20), '') AS CUST_LAST_2_NM,
        /* CUST_MDDL_2_NM               <- cust_mddl_2_nm               VARCHAR(134217728) -> VARCHAR(20) */
        COALESCE(LEFT(p.N__15, 20), '') AS CUST_MDDL_2_NM,
        /* CUST_PRFX_2_NM               <- cust_prfx_2_nm               VARCHAR(134217728) -> VARCHAR(4) */
        COALESCE(LEFT(p.N__16, 4), '') AS CUST_PRFX_2_NM,
        /* CUST_SFFX_2_NM               <- cust_sffx_2_nm               VARCHAR(134217728) -> VARCHAR(3) */
        COALESCE(LEFT(p.N__17, 3), '') AS CUST_SFFX_2_NM,
        /* CUST_ENVL_OVRR_FL            <- cust_envl_ovrr_fl            VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__18, 1), '') AS CUST_ENVL_OVRR_FL,
        /* CRDT_RTNG_NB                 <- crdt_rtng_nb                 NUMBER(10,0) -> NUMBER(10,0) */
        p."crdt_rtng_nb" AS CRDT_RTNG_NB,
        /* HNDBK_SENT_DT                <- hndbk_sent_dt                DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."hndbk_sent_dt" AS TIMESTAMP_NTZ(9)) AS HNDBK_SENT_DT,
        /* TAX_ID                       <- tax_id                       VARCHAR(134217728) -> VARCHAR(9) */
        COALESCE(LEFT(p.N__19, 9), '') AS TAX_ID,
        /* CRDT_RTNG_RECV_DT            <- crdt_rtng_recv_dt            DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."crdt_rtng_recv_dt" AS TIMESTAMP_NTZ(9)) AS CRDT_RTNG_RECV_DT,
        /* ENERGY_DVRSN_FL              <- energy_dvrsn_fl              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__20, 1), '') AS ENERGY_DVRSN_FL,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(8) */
        COALESCE(LEFT(p.N__21, 8), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."cust_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* cust_nb -> CUST_NB */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."rsdn_corp_ind_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* rsdn_corp_ind_cd -> RSDN_CORP_IND_CD */,
            REGEXP_REPLACE(src."cust_nm_info_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* cust_nm_info_fl -> CUST_NM_INFO_FL */,
            REGEXP_REPLACE(src."ownr_agnt_flag_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* ownr_agnt_flag_fl -> OWNR_AGNT_FLAG_FL */,
            TO_VARCHAR(src."nfnc_cntl_unit_nb") AS N__6   /* nfnc_cntl_unit_nb -> NFNC_CNTL_UNIT_NB */,
            REGEXP_REPLACE(src."crpr_affl_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* crpr_affl_nm -> CRPR_AFFL_NM */,
            REGEXP_REPLACE(src."cust_1st_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* cust_1st_1_nm -> CUST_1ST_1_NM */,
            REGEXP_REPLACE(src."cust_last_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* cust_last_1_nm -> CUST_LAST_1_NM */,
            REGEXP_REPLACE(src."cust_mddl_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* cust_mddl_1_nm -> CUST_MDDL_1_NM */,
            REGEXP_REPLACE(src."cust_prfx_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* cust_prfx_1_nm -> CUST_PRFX_1_NM */,
            REGEXP_REPLACE(src."cust_sffx_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* cust_sffx_1_nm -> CUST_SFFX_1_NM */,
            REGEXP_REPLACE(src."cust_1st_2_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* cust_1st_2_nm -> CUST_1ST_2_NM */,
            REGEXP_REPLACE(src."cust_last_2_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* cust_last_2_nm -> CUST_LAST_2_NM */,
            REGEXP_REPLACE(src."cust_mddl_2_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* cust_mddl_2_nm -> CUST_MDDL_2_NM */,
            REGEXP_REPLACE(src."cust_prfx_2_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* cust_prfx_2_nm -> CUST_PRFX_2_NM */,
            REGEXP_REPLACE(src."cust_sffx_2_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__17   /* cust_sffx_2_nm -> CUST_SFFX_2_NM */,
            REGEXP_REPLACE(src."cust_envl_ovrr_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* cust_envl_ovrr_fl -> CUST_ENVL_OVRR_FL */,
            REGEXP_REPLACE(src."tax_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__19   /* tax_id -> TAX_ID */,
            REGEXP_REPLACE(src."energy_dvrsn_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__20   /* energy_dvrsn_fl -> ENERGY_DVRSN_FL */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__21   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_CUSTOMER') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_customer"
    ) p
) s
WHERE 1 = 1
    /* CUST_NB */
    AND (s.CUST_NB IS NOT NULL AND s.CUST_NB <> '')   /* NULL or blank in a key column */
    /* NFNC_CNTL_UNIT_NB */
    AND (s.RAW__6 IS NULL OR s.NFNC_CNTL_UNIT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.NFNC_CNTL_UNIT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* CRDT_RTNG_NB */
    AND s.CRDT_RTNG_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.CUST_NB
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.CUST_NB,
    SRC.CO_CD_OWNR,
    SRC.RSDN_CORP_IND_CD,
    SRC.SRVY_SENT_DT,
    SRC.CUST_NM_INFO_FL,
    SRC.OWNR_AGNT_FLAG_FL,
    SRC.NFNC_CNTL_UNIT_NB,
    SRC.CRPR_AFFL_NM,
    SRC.CUST_1ST_1_NM,
    SRC.CUST_LAST_1_NM,
    SRC.CUST_MDDL_1_NM,
    SRC.CUST_PRFX_1_NM,
    SRC.CUST_SFFX_1_NM,
    SRC.CUST_1ST_2_NM,
    SRC.CUST_LAST_2_NM,
    SRC.CUST_MDDL_2_NM,
    SRC.CUST_PRFX_2_NM,
    SRC.CUST_SFFX_2_NM,
    SRC.CUST_ENVL_OVRR_FL,
    SRC.CRDT_RTNG_NB,
    SRC.HNDBK_SENT_DT,
    SRC.TAX_ID,
    SRC.CRDT_RTNG_RECV_DT,
    SRC.ENERGY_DVRSN_FL,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_CUSTOMER_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_CUSTOMER') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY CUST_NB
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.CUST_NB = TGT.CUST_NB
WHERE
    TGT.CUST_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.RSDN_CORP_IND_CD, TGT.RSDN_CORP_IND_CD, 1, 0) = 0
        OR DECODE(SRC.SRVY_SENT_DT, TGT.SRVY_SENT_DT, 1, 0) = 0
        OR DECODE(SRC.CUST_NM_INFO_FL, TGT.CUST_NM_INFO_FL, 1, 0) = 0
        OR DECODE(SRC.OWNR_AGNT_FLAG_FL, TGT.OWNR_AGNT_FLAG_FL, 1, 0) = 0
        OR DECODE(SRC.NFNC_CNTL_UNIT_NB, TGT.NFNC_CNTL_UNIT_NB, 1, 0) = 0
        OR DECODE(SRC.CRPR_AFFL_NM, TGT.CRPR_AFFL_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_1ST_1_NM, TGT.CUST_1ST_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_LAST_1_NM, TGT.CUST_LAST_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_MDDL_1_NM, TGT.CUST_MDDL_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_PRFX_1_NM, TGT.CUST_PRFX_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_SFFX_1_NM, TGT.CUST_SFFX_1_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_1ST_2_NM, TGT.CUST_1ST_2_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_LAST_2_NM, TGT.CUST_LAST_2_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_MDDL_2_NM, TGT.CUST_MDDL_2_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_PRFX_2_NM, TGT.CUST_PRFX_2_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_SFFX_2_NM, TGT.CUST_SFFX_2_NM, 1, 0) = 0
        OR DECODE(SRC.CUST_ENVL_OVRR_FL, TGT.CUST_ENVL_OVRR_FL, 1, 0) = 0
        OR DECODE(SRC.CRDT_RTNG_NB, TGT.CRDT_RTNG_NB, 1, 0) = 0
        OR DECODE(SRC.HNDBK_SENT_DT, TGT.HNDBK_SENT_DT, 1, 0) = 0
        OR DECODE(SRC.TAX_ID, TGT.TAX_ID, 1, 0) = 0
        OR DECODE(SRC.CRDT_RTNG_RECV_DT, TGT.CRDT_RTNG_RECV_DT, 1, 0) = 0
        OR DECODE(SRC.ENERGY_DVRSN_FL, TGT.ENERGY_DVRSN_FL, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )

