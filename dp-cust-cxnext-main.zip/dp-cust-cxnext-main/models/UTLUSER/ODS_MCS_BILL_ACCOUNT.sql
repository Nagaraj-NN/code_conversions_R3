

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILL_ACCOUNT')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILL_ACCOUNT')
    ]
) }}

WITH ODS_MCS_BILL_ACCOUNT_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.BILL_CHCK_DIGIT_NB,
    s.CO_CD_OWNR,
    s.ADDR_ID_AD,
    s.ACCT_BAL_AT,
    s.AVG_SRVC_BILL_AT,
    s.BAL_DUE_AT,
    s.BB_ESTM_AT,
    s.DFRR_BAL_AT,
    s.MTHY_ACTV_AT,
    s.OPNN_MTHY_BAL_AT,
    s.UNPR_BAL_AT,
    s.PAYABLE_BAL_AT,
    s.ACCT_STAT_CD,
    s.ACCT_TYPE_CD,
    s.BB_ESTM_MTHD_CD,
    s.BILL_STAT_CD,
    s.COLL_HIST_CD,
    s.CRDT_HIST_CD,
    s.JRSD_CD,
    s.LIFE_SPPR_CD,
    s.PYMN_PRFL_CD,
    s.REVN_CLAS_CD,
    s.SIC_CD,
    s.SPCL_HNDL_CD,
    s.SPCL_CIRM_CD,
    s.EMP_ASSC_CO_CD,
    s.EMP_CD_CD,
    s.TLPH_USE_1_CD,
    s.TLPH_USE_2_CD,
    s.UUE_TYPE_CD,
    s.ACCT_DISPUTE_CD,
    s.STATE_CD,
    s.DVSN_CD,
    s.AREA_CD,
    s.SLCT_DUE_DAY_NB,
    s.DPC_CNCL_REV_MO_DT,
    s.TURN_OFF_DT,
    s.TURN_ON_DT,
    s.ED_DT,
    s.LCI_ACCT_FL,
    s.MAIL_UNDL_FL,
    s.OUT_OF_BAL_FL,
    s.AUTO_TRF_BA_NB,
    s.OWN_HOME_IND_CD,
    s.CNSL_BILL_GRP_NB,
    s.CUST_NB,
    s.FNNC_CNTL_UNIT_NB,
    s.MOS_AVG_USG_QY,
    s.REF_DEP_CTR_QY,
    s.NFNC_CNTL_UNIT_NB,
    s.OLD_ACCT_NB,
    s.PREM_NB,
    s.TLPH_1_NB,
    s.TLPH_2_NB,
    s.RTRN_CHCK_HIST_CD,
    s.ENVL_CNTR_CD,
    s.ADDL_BLLS_QY,
    s.CHRG_OFF_PRCS_DT,
    s.DPC_FL,
    s.CHRG_OFF_CD,
    s.OVRI_CHRG_OFF_DT,
    s.RTRN_CHCK_ARRS_CD,
    s.ASSS_PGM_CD,
    s.UNDLVR_MAIL_CD,
    s.COLL_CLAS_CD,
    s.UNDLVR_MAIL_DT,
    s.CAR_BILL_PERD_DT,
    s.SCHD_TYPE_CD,
    s.CNTA_CO_NBR_CD,
    s.EDI_BILL_CD,
    s.STORE_ID_NB,
    s.EDI_CUST_CD,
    s.LIFE_SPPR_EXPR_DT,
    s.RES_BILL_OVR_FL,
    s.OPTED_OUT_CD,
    s.VEND_PROG_FL,
    s.RISK_LEVEL_CD,
    s.RISK_SCORE_NB,
    s.RISK_ASGN_DT,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    s.AR_OPT_OUT_CD,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(10) */
        LEFT(p.N__1, 10) AS BILL_ACCT_NB,
        /* BILL_CHCK_DIGIT_NB           <- bill_chck_digit_nb           NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__2, 5, 0) AS BILL_CHCK_DIGIT_NB,
        p.N__2 AS RAW__2,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__3, 2), '') AS CO_CD_OWNR,
        /* ADDR_ID_AD                   <- addr_id_ad                   VARCHAR(134217728) -> VARCHAR(7) */
        COALESCE(LEFT(p.N__4, 7), '') AS ADDR_ID_AD,
        /* ACCT_BAL_AT                  <- acct_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."acct_bal_at" AS ACCT_BAL_AT,
        /* AVG_SRVC_BILL_AT             <- avg_srvc_bill_at             NUMBER(10,2) -> NUMBER(10,2) */
        p."avg_srvc_bill_at" AS AVG_SRVC_BILL_AT,
        /* BAL_DUE_AT                   <- bal_due_at                   NUMBER(10,2) -> NUMBER(10,2) */
        p."bal_due_at" AS BAL_DUE_AT,
        /* BB_ESTM_AT                   <- bb_estm_at                   NUMBER(7,2) -> NUMBER(7,2) */
        p."bb_estm_at" AS BB_ESTM_AT,
        /* DFRR_BAL_AT                  <- dfrr_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."dfrr_bal_at" AS DFRR_BAL_AT,
        /* MTHY_ACTV_AT                 <- mthy_actv_at                 NUMBER(10,2) -> NUMBER(10,2) */
        p."mthy_actv_at" AS MTHY_ACTV_AT,
        /* OPNN_MTHY_BAL_AT             <- opnn_mthy_bal_at             NUMBER(10,2) -> NUMBER(10,2) */
        p."opnn_mthy_bal_at" AS OPNN_MTHY_BAL_AT,
        /* UNPR_BAL_AT                  <- unpr_bal_at                  NUMBER(10,2) -> NUMBER(10,2) */
        p."unpr_bal_at" AS UNPR_BAL_AT,
        /* PAYABLE_BAL_AT               <- payable_bal_at               NUMBER(10,2) -> NUMBER(10,2) */
        p."payable_bal_at" AS PAYABLE_BAL_AT,
        /* ACCT_STAT_CD                 <- acct_stat_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__5, 1), '') AS ACCT_STAT_CD,
        /* ACCT_TYPE_CD                 <- acct_type_cd                 VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__6, 2), '') AS ACCT_TYPE_CD,
        /* BB_ESTM_MTHD_CD              <- bb_estm_mthd_cd              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__7, 1), '') AS BB_ESTM_MTHD_CD,
        /* BILL_STAT_CD                 <- bill_stat_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__8, 1), '') AS BILL_STAT_CD,
        /* COLL_HIST_CD                 <- coll_hist_cd                 VARCHAR(134217728) -> VARCHAR(36) */
        COALESCE(LEFT(p.N__9, 36), '') AS COLL_HIST_CD,
        /* CRDT_HIST_CD                 <- crdt_hist_cd                 VARCHAR(134217728) -> VARCHAR(36) */
        COALESCE(LEFT(p.N__10, 36), '') AS CRDT_HIST_CD,
        /* JRSD_CD                      <- jrsd_cd                      VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__11, 2), '') AS JRSD_CD,
        /* LIFE_SPPR_CD                 <- life_sppr_cd                 VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__12, 2), '') AS LIFE_SPPR_CD,
        /* PYMN_PRFL_CD                 <- pymn_prfl_cd                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__13, 5, 0) AS PYMN_PRFL_CD,
        p.N__13 AS RAW__13,
        /* REVN_CLAS_CD                 <- revn_clas_cd                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__14, 5, 0) AS REVN_CLAS_CD,
        p.N__14 AS RAW__14,
        /* SIC_CD                       <- sic_cd                       NUMBER(10,0) -> NUMBER(10,0) */
        p."sic_cd" AS SIC_CD,
        /* SPCL_HNDL_CD                 <- spcl_hndl_cd                 VARCHAR(134217728) -> VARCHAR(3) */
        COALESCE(LEFT(p.N__15, 3), '') AS SPCL_HNDL_CD,
        /* SPCL_CIRM_CD                 <- spcl_cirm_cd                 VARCHAR(134217728) -> VARCHAR(3) */
        COALESCE(LEFT(p.N__16, 3), '') AS SPCL_CIRM_CD,
        /* EMP_ASSC_CO_CD               <- emp_assc_co_cd               NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__17, 5, 0) AS EMP_ASSC_CO_CD,
        p.N__17 AS RAW__17,
        /* EMP_CD_CD                    <- emp_cd_cd                    VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__18, 1), '') AS EMP_CD_CD,
        /* TLPH_USE_1_CD                <- tlph_use_1_cd                VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__19, 1), '') AS TLPH_USE_1_CD,
        /* TLPH_USE_2_CD                <- tlph_use_2_cd                VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__20, 1), '') AS TLPH_USE_2_CD,
        /* UUE_TYPE_CD                  <- uue_type_cd                  VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__21, 2), '') AS UUE_TYPE_CD,
        /* ACCT_DISPUTE_CD              <- acct_dispute_cd              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__22, 1), '') AS ACCT_DISPUTE_CD,
        /* STATE_CD                     <- state_cd                     VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__23, 2), '') AS STATE_CD,
        /* DVSN_CD                      <- dvsn_cd                      VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__24, 2), '') AS DVSN_CD,
        /* AREA_CD                      <- area_cd                      VARCHAR(134217728) -> VARCHAR(3) */
        COALESCE(LEFT(p.N__25, 3), '') AS AREA_CD,
        /* SLCT_DUE_DAY_NB              <- slct_due_day_nb              NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__26, 5, 0) AS SLCT_DUE_DAY_NB,
        p.N__26 AS RAW__26,
        /* DPC_CNCL_REV_MO_DT           <- dpc_cncl_rev_mo_dt           DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."dpc_cncl_rev_mo_dt" AS TIMESTAMP_NTZ(9)) AS DPC_CNCL_REV_MO_DT,
        /* TURN_OFF_DT                  <- turn_off_dt                  DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."turn_off_dt" AS TIMESTAMP_NTZ(9)) AS TURN_OFF_DT,
        /* TURN_ON_DT                   <- turn_on_dt                   DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."turn_on_dt" AS TIMESTAMP_NTZ(9)) AS TURN_ON_DT,
        /* ED_DT                        <- ed_dt                        DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."ed_dt" AS TIMESTAMP_NTZ(9)) AS ED_DT,
        /* LCI_ACCT_FL                  <- lci_acct_fl                  VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__27, 1), '') AS LCI_ACCT_FL,
        /* MAIL_UNDL_FL                 <- mail_undl_fl                 VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__28, 1), '') AS MAIL_UNDL_FL,
        /* OUT_OF_BAL_FL                <- out_of_bal_fl                VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__29, 1), '') AS OUT_OF_BAL_FL,
        /* AUTO_TRF_BA_NB               <- auto_trf_ba_nb               VARCHAR(134217728) -> VARCHAR(10) */
        COALESCE(LEFT(p.N__30, 10), '') AS AUTO_TRF_BA_NB,
        /* OWN_HOME_IND_CD              <- own_home_ind_cd              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__31, 1), '') AS OWN_HOME_IND_CD,
        /* CNSL_BILL_GRP_NB             <- cnsl_bill_grp_nb             NUMBER(10,0) -> NUMBER(10,0) */
        p."cnsl_bill_grp_nb" AS CNSL_BILL_GRP_NB,
        /* CUST_NB                      <- cust_nb                      VARCHAR(134217728) -> VARCHAR(9) */
        COALESCE(LEFT(p.N__32, 9), '') AS CUST_NB,
        /* FNNC_CNTL_UNIT_NB            <- fnnc_cntl_unit_nb            NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__33, 5, 0) AS FNNC_CNTL_UNIT_NB,
        p.N__33 AS RAW__33,
        /* MOS_AVG_USG_QY               <- mos_avg_usg_qy               NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__34, 5, 0) AS MOS_AVG_USG_QY,
        p.N__34 AS RAW__34,
        /* REF_DEP_CTR_QY               <- ref_dep_ctr_qy               NUMBER(2,0) -> NUMBER(2,0) */
        p."ref_dep_ctr_qy" AS REF_DEP_CTR_QY,
        /* NFNC_CNTL_UNIT_NB            <- nfnc_cntl_unit_nb            NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__35, 5, 0) AS NFNC_CNTL_UNIT_NB,
        p.N__35 AS RAW__35,
        /* OLD_ACCT_NB                  <- old_acct_nb                  VARCHAR(134217728) -> VARCHAR(13) */
        COALESCE(LEFT(p.N__36, 13), '') AS OLD_ACCT_NB,
        /* PREM_NB                      <- prem_nb                      VARCHAR(134217728) -> VARCHAR(9) */
        COALESCE(LEFT(p.N__37, 9), '') AS PREM_NB,
        /* TLPH_1_NB                    <- tlph_1_nb                    NUMBER(10,0) -> NUMBER(10,0) */
        p."tlph_1_nb" AS TLPH_1_NB,
        /* TLPH_2_NB                    <- tlph_2_nb                    NUMBER(10,0) -> NUMBER(10,0) */
        p."tlph_2_nb" AS TLPH_2_NB,
        /* RTRN_CHCK_HIST_CD            <- rtrn_chck_hist_cd            VARCHAR(134217728) -> VARCHAR(36) */
        COALESCE(LEFT(p.N__38, 36), '') AS RTRN_CHCK_HIST_CD,
        /* ENVL_CNTR_CD                 <- envl_cntr_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__39, 1), '') AS ENVL_CNTR_CD,
        /* ADDL_BLLS_QY                 <- addl_blls_qy                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__40, 5, 0) AS ADDL_BLLS_QY,
        p.N__40 AS RAW__40,
        /* CHRG_OFF_PRCS_DT             <- chrg_off_prcs_dt             DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."chrg_off_prcs_dt" AS TIMESTAMP_NTZ(9)) AS CHRG_OFF_PRCS_DT,
        /* DPC_FL                       <- dpc_fl                       VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__41, 1), '') AS DPC_FL,
        /* CHRG_OFF_CD                  <- chrg_off_cd                  VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__42, 1), '') AS CHRG_OFF_CD,
        /* OVRI_CHRG_OFF_DT             <- ovri_chrg_off_dt             DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."ovri_chrg_off_dt" AS TIMESTAMP_NTZ(9)) AS OVRI_CHRG_OFF_DT,
        /* RTRN_CHCK_ARRS_CD            <- rtrn_chck_arrs_cd            VARCHAR(134217728) -> VARCHAR(12) */
        COALESCE(LEFT(p.N__43, 12), '') AS RTRN_CHCK_ARRS_CD,
        /* ASSS_PGM_CD                  <- asss_pgm_cd                  VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__44, 1), '') AS ASSS_PGM_CD,
        /* UNDLVR_MAIL_CD               <- undlvr_mail_cd               VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__45, 1), '') AS UNDLVR_MAIL_CD,
        /* COLL_CLAS_CD                 <- coll_clas_cd                 VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__46, 2), '') AS COLL_CLAS_CD,
        /* UNDLVR_MAIL_DT               <- undlvr_mail_dt               DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."undlvr_mail_dt" AS TIMESTAMP_NTZ(9)) AS UNDLVR_MAIL_DT,
        /* CAR_BILL_PERD_DT             <- car_bill_perd_dt             DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."car_bill_perd_dt" AS TIMESTAMP_NTZ(9)) AS CAR_BILL_PERD_DT,
        /* SCHD_TYPE_CD                 <- schd_type_cd                 VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__47, 2), '') AS SCHD_TYPE_CD,
        /* CNTA_CO_NBR_CD               <- cnta_co_nbr_cd               VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__48, 2), '') AS CNTA_CO_NBR_CD,
        /* EDI_BILL_CD                  <- edi_bill_cd                  VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__49, 1), '') AS EDI_BILL_CD,
        /* STORE_ID_NB                  <- store_id_nb                  VARCHAR(134217728) -> VARCHAR(11) */
        COALESCE(LEFT(p.N__50, 11), '') AS STORE_ID_NB,
        /* EDI_CUST_CD                  <- edi_cust_cd                  VARCHAR(134217728) -> VARCHAR(6) */
        COALESCE(LEFT(p.N__51, 6), '') AS EDI_CUST_CD,
        /* LIFE_SPPR_EXPR_DT            <- life_sppr_expr_dt            DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."life_sppr_expr_dt" AS TIMESTAMP_NTZ(9)) AS LIFE_SPPR_EXPR_DT,
        /* RES_BILL_OVR_FL              <- res_bill_ovr_fl              VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__52, 1), '') AS RES_BILL_OVR_FL,
        /* OPTED_OUT_CD                 <- opted_out_cd                 VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__53, 2), '') AS OPTED_OUT_CD,
        /* VEND_PROG_FL                 <- vend_prog_fl                 VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__54, 1), '') AS VEND_PROG_FL,
        /* RISK_LEVEL_CD                <- risk_level_cd                VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__55, 1), '') AS RISK_LEVEL_CD,
        /* RISK_SCORE_NB                <- risk_score_nb                NUMBER(10,0) -> NUMBER(10,0) */
        p."risk_score_nb" AS RISK_SCORE_NB,
        /* RISK_ASGN_DT                 <- risk_asgn_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."risk_asgn_dt" AS TIMESTAMP_NTZ(9)) AS RISK_ASGN_DT,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(8) */
        COALESCE(LEFT(p.N__56, 8), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* AR_OPT_OUT_CD                <- ar_opt_out_cd                VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__57, 1), ' ') AS AR_OPT_OUT_CD   /* DDL default */
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            TO_VARCHAR(src."bill_chck_digit_nb") AS N__2   /* bill_chck_digit_nb -> BILL_CHCK_DIGIT_NB */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."addr_id_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* addr_id_ad -> ADDR_ID_AD */,
            REGEXP_REPLACE(src."acct_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* acct_stat_cd -> ACCT_STAT_CD */,
            REGEXP_REPLACE(src."acct_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* acct_type_cd -> ACCT_TYPE_CD */,
            REGEXP_REPLACE(src."bb_estm_mthd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* bb_estm_mthd_cd -> BB_ESTM_MTHD_CD */,
            REGEXP_REPLACE(src."bill_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* bill_stat_cd -> BILL_STAT_CD */,
            REGEXP_REPLACE(src."coll_hist_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* coll_hist_cd -> COLL_HIST_CD */,
            REGEXP_REPLACE(src."crdt_hist_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* crdt_hist_cd -> CRDT_HIST_CD */,
            REGEXP_REPLACE(src."jrsd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* jrsd_cd -> JRSD_CD */,
            REGEXP_REPLACE(src."life_sppr_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* life_sppr_cd -> LIFE_SPPR_CD */,
            TO_VARCHAR(src."pymn_prfl_cd") AS N__13   /* pymn_prfl_cd -> PYMN_PRFL_CD */,
            TO_VARCHAR(src."revn_clas_cd") AS N__14   /* revn_clas_cd -> REVN_CLAS_CD */,
            REGEXP_REPLACE(src."spcl_hndl_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* spcl_hndl_cd -> SPCL_HNDL_CD */,
            REGEXP_REPLACE(src."spcl_cirm_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* spcl_cirm_cd -> SPCL_CIRM_CD */,
            TO_VARCHAR(src."emp_assc_co_cd") AS N__17   /* emp_assc_co_cd -> EMP_ASSC_CO_CD */,
            REGEXP_REPLACE(src."emp_cd_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* emp_cd_cd -> EMP_CD_CD */,
            REGEXP_REPLACE(src."tlph_use_1_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__19   /* tlph_use_1_cd -> TLPH_USE_1_CD */,
            REGEXP_REPLACE(src."tlph_use_2_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__20   /* tlph_use_2_cd -> TLPH_USE_2_CD */,
            REGEXP_REPLACE(src."uue_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__21   /* uue_type_cd -> UUE_TYPE_CD */,
            REGEXP_REPLACE(src."acct_dispute_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__22   /* acct_dispute_cd -> ACCT_DISPUTE_CD */,
            REGEXP_REPLACE(src."state_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__23   /* state_cd -> STATE_CD */,
            REGEXP_REPLACE(src."dvsn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__24   /* dvsn_cd -> DVSN_CD */,
            REGEXP_REPLACE(src."area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__25   /* area_cd -> AREA_CD */,
            TO_VARCHAR(src."slct_due_day_nb") AS N__26   /* slct_due_day_nb -> SLCT_DUE_DAY_NB */,
            REGEXP_REPLACE(src."lci_acct_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__27   /* lci_acct_fl -> LCI_ACCT_FL */,
            REGEXP_REPLACE(src."mail_undl_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__28   /* mail_undl_fl -> MAIL_UNDL_FL */,
            REGEXP_REPLACE(src."out_of_bal_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__29   /* out_of_bal_fl -> OUT_OF_BAL_FL */,
            REGEXP_REPLACE(src."auto_trf_ba_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__30   /* auto_trf_ba_nb -> AUTO_TRF_BA_NB */,
            REGEXP_REPLACE(src."own_home_ind_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__31   /* own_home_ind_cd -> OWN_HOME_IND_CD */,
            REGEXP_REPLACE(src."cust_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__32   /* cust_nb -> CUST_NB */,
            TO_VARCHAR(src."fnnc_cntl_unit_nb") AS N__33   /* fnnc_cntl_unit_nb -> FNNC_CNTL_UNIT_NB */,
            TO_VARCHAR(src."mos_avg_usg_qy") AS N__34   /* mos_avg_usg_qy -> MOS_AVG_USG_QY */,
            TO_VARCHAR(src."nfnc_cntl_unit_nb") AS N__35   /* nfnc_cntl_unit_nb -> NFNC_CNTL_UNIT_NB */,
            REGEXP_REPLACE(src."old_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__36   /* old_acct_nb -> OLD_ACCT_NB */,
            REGEXP_REPLACE(src."prem_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__37   /* prem_nb -> PREM_NB */,
            REGEXP_REPLACE(src."rtrn_chck_hist_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__38   /* rtrn_chck_hist_cd -> RTRN_CHCK_HIST_CD */,
            REGEXP_REPLACE(src."envl_cntr_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__39   /* envl_cntr_cd -> ENVL_CNTR_CD */,
            TO_VARCHAR(src."addl_blls_qy") AS N__40   /* addl_blls_qy -> ADDL_BLLS_QY */,
            REGEXP_REPLACE(src."dpc_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__41   /* dpc_fl -> DPC_FL */,
            REGEXP_REPLACE(src."chrg_off_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__42   /* chrg_off_cd -> CHRG_OFF_CD */,
            REGEXP_REPLACE(src."rtrn_chck_arrs_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__43   /* rtrn_chck_arrs_cd -> RTRN_CHCK_ARRS_CD */,
            REGEXP_REPLACE(src."asss_pgm_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__44   /* asss_pgm_cd -> ASSS_PGM_CD */,
            REGEXP_REPLACE(src."undlvr_mail_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__45   /* undlvr_mail_cd -> UNDLVR_MAIL_CD */,
            REGEXP_REPLACE(src."coll_clas_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__46   /* coll_clas_cd -> COLL_CLAS_CD */,
            REGEXP_REPLACE(src."schd_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__47   /* schd_type_cd -> SCHD_TYPE_CD */,
            REGEXP_REPLACE(src."cnta_co_nbr_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__48   /* cnta_co_nbr_cd -> CNTA_CO_NBR_CD */,
            REGEXP_REPLACE(src."edi_bill_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__49   /* edi_bill_cd -> EDI_BILL_CD */,
            REGEXP_REPLACE(src."store_id_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__50   /* store_id_nb -> STORE_ID_NB */,
            REGEXP_REPLACE(src."edi_cust_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__51   /* edi_cust_cd -> EDI_CUST_CD */,
            REGEXP_REPLACE(src."res_bill_ovr_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__52   /* res_bill_ovr_fl -> RES_BILL_OVR_FL */,
            REGEXP_REPLACE(src."opted_out_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__53   /* opted_out_cd -> OPTED_OUT_CD */,
            REGEXP_REPLACE(src."vend_prog_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__54   /* vend_prog_fl -> VEND_PROG_FL */,
            REGEXP_REPLACE(src."risk_level_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__55   /* risk_level_cd -> RISK_LEVEL_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__56   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */,
            REGEXP_REPLACE(src."ar_opt_out_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__57   /* ar_opt_out_cd -> AR_OPT_OUT_CD */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_BILL_ACCOUNT') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_bill_account"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* BILL_CHCK_DIGIT_NB */
    AND (s.RAW__2 IS NULL OR s.BILL_CHCK_DIGIT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.BILL_CHCK_DIGIT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* ACCT_BAL_AT */
    AND s.ACCT_BAL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* AVG_SRVC_BILL_AT */
    AND s.AVG_SRVC_BILL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BAL_DUE_AT */
    AND s.BAL_DUE_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BB_ESTM_AT */
    AND s.BB_ESTM_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* DFRR_BAL_AT */
    AND s.DFRR_BAL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* MTHY_ACTV_AT */
    AND s.MTHY_ACTV_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* OPNN_MTHY_BAL_AT */
    AND s.OPNN_MTHY_BAL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* UNPR_BAL_AT */
    AND s.UNPR_BAL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PAYABLE_BAL_AT */
    AND s.PAYABLE_BAL_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PYMN_PRFL_CD */
    AND (s.RAW__13 IS NULL OR s.PYMN_PRFL_CD IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.PYMN_PRFL_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* REVN_CLAS_CD */
    AND (s.RAW__14 IS NULL OR s.REVN_CLAS_CD IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.REVN_CLAS_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* SIC_CD */
    AND s.SIC_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* EMP_ASSC_CO_CD */
    AND (s.RAW__17 IS NULL OR s.EMP_ASSC_CO_CD IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.EMP_ASSC_CO_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* SLCT_DUE_DAY_NB */
    AND (s.RAW__26 IS NULL OR s.SLCT_DUE_DAY_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.SLCT_DUE_DAY_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* CNSL_BILL_GRP_NB */
    AND s.CNSL_BILL_GRP_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* FNNC_CNTL_UNIT_NB */
    AND (s.RAW__33 IS NULL OR s.FNNC_CNTL_UNIT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.FNNC_CNTL_UNIT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* MOS_AVG_USG_QY */
    AND (s.RAW__34 IS NULL OR s.MOS_AVG_USG_QY IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.MOS_AVG_USG_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* REF_DEP_CTR_QY */
    AND s.REF_DEP_CTR_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NFNC_CNTL_UNIT_NB */
    AND (s.RAW__35 IS NULL OR s.NFNC_CNTL_UNIT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.NFNC_CNTL_UNIT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TLPH_1_NB */
    AND s.TLPH_1_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* TLPH_2_NB */
    AND s.TLPH_2_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* ADDL_BLLS_QY */
    AND (s.RAW__40 IS NULL OR s.ADDL_BLLS_QY IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.ADDL_BLLS_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* RISK_SCORE_NB */
    AND s.RISK_SCORE_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.BILL_CHCK_DIGIT_NB,
    SRC.CO_CD_OWNR,
    SRC.ADDR_ID_AD,
    SRC.ACCT_BAL_AT,
    SRC.AVG_SRVC_BILL_AT,
    SRC.BAL_DUE_AT,
    SRC.BB_ESTM_AT,
    SRC.DFRR_BAL_AT,
    SRC.MTHY_ACTV_AT,
    SRC.OPNN_MTHY_BAL_AT,
    SRC.UNPR_BAL_AT,
    SRC.PAYABLE_BAL_AT,
    SRC.ACCT_STAT_CD,
    SRC.ACCT_TYPE_CD,
    SRC.BB_ESTM_MTHD_CD,
    SRC.BILL_STAT_CD,
    SRC.COLL_HIST_CD,
    SRC.CRDT_HIST_CD,
    SRC.JRSD_CD,
    SRC.LIFE_SPPR_CD,
    SRC.PYMN_PRFL_CD,
    SRC.REVN_CLAS_CD,
    SRC.SIC_CD,
    SRC.SPCL_HNDL_CD,
    SRC.SPCL_CIRM_CD,
    SRC.EMP_ASSC_CO_CD,
    SRC.EMP_CD_CD,
    SRC.TLPH_USE_1_CD,
    SRC.TLPH_USE_2_CD,
    SRC.UUE_TYPE_CD,
    SRC.ACCT_DISPUTE_CD,
    SRC.STATE_CD,
    SRC.DVSN_CD,
    SRC.AREA_CD,
    SRC.SLCT_DUE_DAY_NB,
    SRC.DPC_CNCL_REV_MO_DT,
    SRC.TURN_OFF_DT,
    SRC.TURN_ON_DT,
    SRC.ED_DT,
    SRC.LCI_ACCT_FL,
    SRC.MAIL_UNDL_FL,
    SRC.OUT_OF_BAL_FL,
    SRC.AUTO_TRF_BA_NB,
    SRC.OWN_HOME_IND_CD,
    SRC.CNSL_BILL_GRP_NB,
    SRC.CUST_NB,
    SRC.FNNC_CNTL_UNIT_NB,
    SRC.MOS_AVG_USG_QY,
    SRC.REF_DEP_CTR_QY,
    SRC.NFNC_CNTL_UNIT_NB,
    SRC.OLD_ACCT_NB,
    SRC.PREM_NB,
    SRC.TLPH_1_NB,
    SRC.TLPH_2_NB,
    SRC.RTRN_CHCK_HIST_CD,
    SRC.ENVL_CNTR_CD,
    SRC.ADDL_BLLS_QY,
    SRC.CHRG_OFF_PRCS_DT,
    SRC.DPC_FL,
    SRC.CHRG_OFF_CD,
    SRC.OVRI_CHRG_OFF_DT,
    SRC.RTRN_CHCK_ARRS_CD,
    SRC.ASSS_PGM_CD,
    SRC.UNDLVR_MAIL_CD,
    SRC.COLL_CLAS_CD,
    SRC.UNDLVR_MAIL_DT,
    SRC.CAR_BILL_PERD_DT,
    SRC.SCHD_TYPE_CD,
    SRC.CNTA_CO_NBR_CD,
    SRC.EDI_BILL_CD,
    SRC.STORE_ID_NB,
    SRC.EDI_CUST_CD,
    SRC.LIFE_SPPR_EXPR_DT,
    SRC.RES_BILL_OVR_FL,
    SRC.OPTED_OUT_CD,
    SRC.VEND_PROG_FL,
    SRC.RISK_LEVEL_CD,
    SRC.RISK_SCORE_NB,
    SRC.RISK_ASGN_DT,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.AR_OPT_OUT_CD,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_BILL_ACCOUNT_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BILL_ACCOUNT') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.BILL_CHCK_DIGIT_NB, TGT.BILL_CHCK_DIGIT_NB, 1, 0) = 0
        OR DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.ADDR_ID_AD, TGT.ADDR_ID_AD, 1, 0) = 0
        OR DECODE(SRC.ACCT_BAL_AT, TGT.ACCT_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.AVG_SRVC_BILL_AT, TGT.AVG_SRVC_BILL_AT, 1, 0) = 0
        OR DECODE(SRC.BAL_DUE_AT, TGT.BAL_DUE_AT, 1, 0) = 0
        OR DECODE(SRC.BB_ESTM_AT, TGT.BB_ESTM_AT, 1, 0) = 0
        OR DECODE(SRC.DFRR_BAL_AT, TGT.DFRR_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.MTHY_ACTV_AT, TGT.MTHY_ACTV_AT, 1, 0) = 0
        OR DECODE(SRC.OPNN_MTHY_BAL_AT, TGT.OPNN_MTHY_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.UNPR_BAL_AT, TGT.UNPR_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.PAYABLE_BAL_AT, TGT.PAYABLE_BAL_AT, 1, 0) = 0
        OR DECODE(SRC.ACCT_STAT_CD, TGT.ACCT_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.ACCT_TYPE_CD, TGT.ACCT_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.BB_ESTM_MTHD_CD, TGT.BB_ESTM_MTHD_CD, 1, 0) = 0
        OR DECODE(SRC.BILL_STAT_CD, TGT.BILL_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.COLL_HIST_CD, TGT.COLL_HIST_CD, 1, 0) = 0
        OR DECODE(SRC.CRDT_HIST_CD, TGT.CRDT_HIST_CD, 1, 0) = 0
        OR DECODE(SRC.JRSD_CD, TGT.JRSD_CD, 1, 0) = 0
        OR DECODE(SRC.LIFE_SPPR_CD, TGT.LIFE_SPPR_CD, 1, 0) = 0
        OR DECODE(SRC.PYMN_PRFL_CD, TGT.PYMN_PRFL_CD, 1, 0) = 0
        OR DECODE(SRC.REVN_CLAS_CD, TGT.REVN_CLAS_CD, 1, 0) = 0
        OR DECODE(SRC.SIC_CD, TGT.SIC_CD, 1, 0) = 0
        OR DECODE(SRC.SPCL_HNDL_CD, TGT.SPCL_HNDL_CD, 1, 0) = 0
        OR DECODE(SRC.SPCL_CIRM_CD, TGT.SPCL_CIRM_CD, 1, 0) = 0
        OR DECODE(SRC.EMP_ASSC_CO_CD, TGT.EMP_ASSC_CO_CD, 1, 0) = 0
        OR DECODE(SRC.EMP_CD_CD, TGT.EMP_CD_CD, 1, 0) = 0
        OR DECODE(SRC.TLPH_USE_1_CD, TGT.TLPH_USE_1_CD, 1, 0) = 0
        OR DECODE(SRC.TLPH_USE_2_CD, TGT.TLPH_USE_2_CD, 1, 0) = 0
        OR DECODE(SRC.UUE_TYPE_CD, TGT.UUE_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.ACCT_DISPUTE_CD, TGT.ACCT_DISPUTE_CD, 1, 0) = 0
        OR DECODE(SRC.STATE_CD, TGT.STATE_CD, 1, 0) = 0
        OR DECODE(SRC.DVSN_CD, TGT.DVSN_CD, 1, 0) = 0
        OR DECODE(SRC.AREA_CD, TGT.AREA_CD, 1, 0) = 0
        OR DECODE(SRC.SLCT_DUE_DAY_NB, TGT.SLCT_DUE_DAY_NB, 1, 0) = 0
        OR DECODE(SRC.DPC_CNCL_REV_MO_DT, TGT.DPC_CNCL_REV_MO_DT, 1, 0) = 0
        OR DECODE(SRC.TURN_OFF_DT, TGT.TURN_OFF_DT, 1, 0) = 0
        OR DECODE(SRC.TURN_ON_DT, TGT.TURN_ON_DT, 1, 0) = 0
        OR DECODE(SRC.ED_DT, TGT.ED_DT, 1, 0) = 0
        OR DECODE(SRC.LCI_ACCT_FL, TGT.LCI_ACCT_FL, 1, 0) = 0
        OR DECODE(SRC.MAIL_UNDL_FL, TGT.MAIL_UNDL_FL, 1, 0) = 0
        OR DECODE(SRC.OUT_OF_BAL_FL, TGT.OUT_OF_BAL_FL, 1, 0) = 0
        OR DECODE(SRC.AUTO_TRF_BA_NB, TGT.AUTO_TRF_BA_NB, 1, 0) = 0
        OR DECODE(SRC.OWN_HOME_IND_CD, TGT.OWN_HOME_IND_CD, 1, 0) = 0
        OR DECODE(SRC.CNSL_BILL_GRP_NB, TGT.CNSL_BILL_GRP_NB, 1, 0) = 0
        OR DECODE(SRC.CUST_NB, TGT.CUST_NB, 1, 0) = 0
        OR DECODE(SRC.FNNC_CNTL_UNIT_NB, TGT.FNNC_CNTL_UNIT_NB, 1, 0) = 0
        OR DECODE(SRC.MOS_AVG_USG_QY, TGT.MOS_AVG_USG_QY, 1, 0) = 0
        OR DECODE(SRC.REF_DEP_CTR_QY, TGT.REF_DEP_CTR_QY, 1, 0) = 0
        OR DECODE(SRC.NFNC_CNTL_UNIT_NB, TGT.NFNC_CNTL_UNIT_NB, 1, 0) = 0
        OR DECODE(SRC.OLD_ACCT_NB, TGT.OLD_ACCT_NB, 1, 0) = 0
        OR DECODE(SRC.PREM_NB, TGT.PREM_NB, 1, 0) = 0
        OR DECODE(SRC.TLPH_1_NB, TGT.TLPH_1_NB, 1, 0) = 0
        OR DECODE(SRC.TLPH_2_NB, TGT.TLPH_2_NB, 1, 0) = 0
        OR DECODE(SRC.RTRN_CHCK_HIST_CD, TGT.RTRN_CHCK_HIST_CD, 1, 0) = 0
        OR DECODE(SRC.ENVL_CNTR_CD, TGT.ENVL_CNTR_CD, 1, 0) = 0
        OR DECODE(SRC.ADDL_BLLS_QY, TGT.ADDL_BLLS_QY, 1, 0) = 0
        OR DECODE(SRC.CHRG_OFF_PRCS_DT, TGT.CHRG_OFF_PRCS_DT, 1, 0) = 0
        OR DECODE(SRC.DPC_FL, TGT.DPC_FL, 1, 0) = 0
        OR DECODE(SRC.CHRG_OFF_CD, TGT.CHRG_OFF_CD, 1, 0) = 0
        OR DECODE(SRC.OVRI_CHRG_OFF_DT, TGT.OVRI_CHRG_OFF_DT, 1, 0) = 0
        OR DECODE(SRC.RTRN_CHCK_ARRS_CD, TGT.RTRN_CHCK_ARRS_CD, 1, 0) = 0
        OR DECODE(SRC.ASSS_PGM_CD, TGT.ASSS_PGM_CD, 1, 0) = 0
        OR DECODE(SRC.UNDLVR_MAIL_CD, TGT.UNDLVR_MAIL_CD, 1, 0) = 0
        OR DECODE(SRC.COLL_CLAS_CD, TGT.COLL_CLAS_CD, 1, 0) = 0
        OR DECODE(SRC.UNDLVR_MAIL_DT, TGT.UNDLVR_MAIL_DT, 1, 0) = 0
        OR DECODE(SRC.CAR_BILL_PERD_DT, TGT.CAR_BILL_PERD_DT, 1, 0) = 0
        OR DECODE(SRC.SCHD_TYPE_CD, TGT.SCHD_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.CNTA_CO_NBR_CD, TGT.CNTA_CO_NBR_CD, 1, 0) = 0
        OR DECODE(SRC.EDI_BILL_CD, TGT.EDI_BILL_CD, 1, 0) = 0
        OR DECODE(SRC.STORE_ID_NB, TGT.STORE_ID_NB, 1, 0) = 0
        OR DECODE(SRC.EDI_CUST_CD, TGT.EDI_CUST_CD, 1, 0) = 0
        OR DECODE(SRC.LIFE_SPPR_EXPR_DT, TGT.LIFE_SPPR_EXPR_DT, 1, 0) = 0
        OR DECODE(SRC.RES_BILL_OVR_FL, TGT.RES_BILL_OVR_FL, 1, 0) = 0
        OR DECODE(SRC.OPTED_OUT_CD, TGT.OPTED_OUT_CD, 1, 0) = 0
        OR DECODE(SRC.VEND_PROG_FL, TGT.VEND_PROG_FL, 1, 0) = 0
        OR DECODE(SRC.RISK_LEVEL_CD, TGT.RISK_LEVEL_CD, 1, 0) = 0
        OR DECODE(SRC.RISK_SCORE_NB, TGT.RISK_SCORE_NB, 1, 0) = 0
        OR DECODE(SRC.RISK_ASGN_DT, TGT.RISK_ASGN_DT, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.AR_OPT_OUT_CD, TGT.AR_OPT_OUT_CD, 1, 0) = 0
    )

