{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['CO_CD_OWNR', 'ADDR_ID_AD'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_ADDRESS')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_ADDRESS')
    ]
) }}

WITH ODS_MCS_ADDRESS_SQ AS (
SELECT
    s.CO_CD_OWNR,
    s.ADDR_ID_AD,
    s.MAIL_1_NM,
    s.MAIL_2_NM,
    s.MAIL_1_AD,
    s.MAIL_2_AD,
    s.MAIL_CITY_AD,
    s.STATE_CD_AD,
    s.MAIL_ZIP_AD,
    s.CARI_RTE_CD,
    s.OVRI_SRVC_NAME_FL,
    s.DELV_PT_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(2) */
        LEFT(p.N__1, 2) AS CO_CD_OWNR,
        /* ADDR_ID_AD                   <- addr_id_ad                   VARCHAR(134217728) -> VARCHAR(7) */
        LEFT(p.N__2, 7) AS ADDR_ID_AD,
        /* MAIL_1_NM                    <- mail_1_nm                    VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__3, 35), '') AS MAIL_1_NM,
        /* MAIL_2_NM                    <- mail_2_nm                    VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__4, 35), '') AS MAIL_2_NM,
        /* MAIL_1_AD                    <- mail_1_ad                    VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__5, 35), '') AS MAIL_1_AD,
        /* MAIL_2_AD                    <- mail_2_ad                    VARCHAR(134217728) -> VARCHAR(35) */
        COALESCE(LEFT(p.N__6, 35), '') AS MAIL_2_AD,
        /* MAIL_CITY_AD                 <- mail_city_ad                 VARCHAR(134217728) -> VARCHAR(20) */
        COALESCE(LEFT(p.N__7, 20), '') AS MAIL_CITY_AD,
        /* STATE_CD_AD                  <- state_cd_ad                  VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__8, 2), '') AS STATE_CD_AD,
        /* MAIL_ZIP_AD                  <- mail_zip_ad                  VARCHAR(134217728) -> VARCHAR(10) */
        COALESCE(LEFT(p.N__9, 10), '') AS MAIL_ZIP_AD,
        /* CARI_RTE_CD                  <- cari_rte_cd                  VARCHAR(134217728) -> VARCHAR(4) */
        COALESCE(LEFT(p.N__10, 4), '') AS CARI_RTE_CD,
        /* OVRI_SRVC_NAME_FL            <- ovri_srvc_name_fl            VARCHAR(134217728) -> VARCHAR(1) */
        COALESCE(LEFT(p.N__11, 1), '') AS OVRI_SRVC_NAME_FL,
        /* DELV_PT_CD                   <- delv_pt_cd                   VARCHAR(134217728) -> VARCHAR(2) */
        COALESCE(LEFT(p.N__12, 2), '') AS DELV_PT_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(8) */
        COALESCE(LEFT(p.N__13, 8), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."addr_id_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* addr_id_ad -> ADDR_ID_AD */,
            REGEXP_REPLACE(src."mail_1_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* mail_1_nm -> MAIL_1_NM */,
            REGEXP_REPLACE(src."mail_2_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* mail_2_nm -> MAIL_2_NM */,
            REGEXP_REPLACE(src."mail_1_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* mail_1_ad -> MAIL_1_AD */,
            REGEXP_REPLACE(src."mail_2_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* mail_2_ad -> MAIL_2_AD */,
            REGEXP_REPLACE(src."mail_city_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* mail_city_ad -> MAIL_CITY_AD */,
            REGEXP_REPLACE(src."state_cd_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* state_cd_ad -> STATE_CD_AD */,
            REGEXP_REPLACE(src."mail_zip_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* mail_zip_ad -> MAIL_ZIP_AD */,
            REGEXP_REPLACE(src."cari_rte_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* cari_rte_cd -> CARI_RTE_CD */,
            REGEXP_REPLACE(src."ovri_srvc_name_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* ovri_srvc_name_fl -> OVRI_SRVC_NAME_FL */,
            REGEXP_REPLACE(src."delv_pt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* delv_pt_cd -> DELV_PT_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_ADDRESS') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_address"
    ) p
) s
WHERE 1 = 1
    /* CO_CD_OWNR */
    AND (s.CO_CD_OWNR IS NOT NULL AND s.CO_CD_OWNR <> '')   /* NULL or blank in a key column */
    /* ADDR_ID_AD */
    AND (s.ADDR_ID_AD IS NOT NULL AND s.ADDR_ID_AD <> '')   /* NULL or blank in a key column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.CO_CD_OWNR, s.ADDR_ID_AD
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.CO_CD_OWNR,
    SRC.ADDR_ID_AD,
    SRC.MAIL_1_NM,
    SRC.MAIL_2_NM,
    SRC.MAIL_1_AD,
    SRC.MAIL_2_AD,
    SRC.MAIL_CITY_AD,
    SRC.STATE_CD_AD,
    SRC.MAIL_ZIP_AD,
    SRC.CARI_RTE_CD,
    SRC.OVRI_SRVC_NAME_FL,
    SRC.DELV_PT_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_ADDRESS_SQ SRC

LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_ADDRESS') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY CO_CD_OWNR, ADDR_ID_AD
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.CO_CD_OWNR = TGT.CO_CD_OWNR
    AND SRC.ADDR_ID_AD = TGT.ADDR_ID_AD
WHERE
    TGT.CO_CD_OWNR IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.MAIL_1_NM, TGT.MAIL_1_NM, 1, 0) = 0
        OR DECODE(SRC.MAIL_2_NM, TGT.MAIL_2_NM, 1, 0) = 0
        OR DECODE(SRC.MAIL_1_AD, TGT.MAIL_1_AD, 1, 0) = 0
        OR DECODE(SRC.MAIL_2_AD, TGT.MAIL_2_AD, 1, 0) = 0
        OR DECODE(SRC.MAIL_CITY_AD, TGT.MAIL_CITY_AD, 1, 0) = 0
        OR DECODE(SRC.STATE_CD_AD, TGT.STATE_CD_AD, 1, 0) = 0
        OR DECODE(SRC.MAIL_ZIP_AD, TGT.MAIL_ZIP_AD, 1, 0) = 0
        OR DECODE(SRC.CARI_RTE_CD, TGT.CARI_RTE_CD, 1, 0) = 0
        OR DECODE(SRC.OVRI_SRVC_NAME_FL, TGT.OVRI_SRVC_NAME_FL, 1, 0) = 0
        OR DECODE(SRC.DELV_PT_CD, TGT.DELV_PT_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )