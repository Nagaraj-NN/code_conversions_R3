
{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'BILL_HEAD_NB', 'BILL_COMP_NB', 'TIME_OF_DAY_CD'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILLABLE_USAGE')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BILLABLE_USAGE')
    ]
) }}

WITH ODS_MCS_BILLABLE_USAGE_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.BILL_HEAD_NB,
    s.BILL_COMP_NB,
    s.TIME_OF_DAY_CD,
    s.DMND_TYPE_CD,
    s.READ_CD,
    s.TOD_CD_SORT_NB,
    s.BILL_DMND_QY,
    s.BILL_KWH_QY,
    s.NET_USAG_KVA_QY,
    s.NET_USAG_KVAR_QY,
    s.NET_USAG_KVARH_QY,
    s.NET_USAG_KW_QY,
    s.NET_USAG_KWH_QY,
    s.NET_USAG_QHR_QY,
    s.PWR_FCTR_QY,
    s.PWR_FCTR_CNST_QY,
    s.RCTV_DMND_QY,
    s.RCTV_HORS_QY,
    s.USAG_NBR_DAYS_QY,
    s.LOAD_FCTR_QY,
    s.HOURS_USED_QY,
    s.LCI_USAG_EXISTS_FL,
    s.EDI_CNTL_NB,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS BILL_ACCT_NB,
        /* BILL_HEAD_NB                 <- bill_head_nb                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__2, 5, 0) AS BILL_HEAD_NB,
        p.N__2 AS RAW__2,
        /* BILL_COMP_NB                 <- bill_comp_nb                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__3, 5, 0) AS BILL_COMP_NB,
        p.N__3 AS RAW__3,
        /* TIME_OF_DAY_CD               <- time_of_day_cd               VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__4, 16777216) AS TIME_OF_DAY_CD,
        /* DMND_TYPE_CD                 <- dmnd_type_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS DMND_TYPE_CD,
        /* READ_CD                      <- read_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS READ_CD,
        /* TOD_CD_SORT_NB               <- tod_cd_sort_nb               NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__7, 5, 0) AS TOD_CD_SORT_NB,
        p.N__7 AS RAW__7,
        /* BILL_DMND_QY                 <- bill_dmnd_qy                 NUMBER(7,1) -> NUMBER(7,1) */
        p."bill_dmnd_qy" AS BILL_DMND_QY,
        /* BILL_KWH_QY                  <- bill_kwh_qy                  NUMBER(10,0) -> NUMBER(10,0) */
        p."bill_kwh_qy" AS BILL_KWH_QY,
        /* NET_USAG_KVA_QY              <- net_usag_kva_qy              NUMBER(10,3) -> NUMBER(10,3) */
        p."net_usag_kva_qy" AS NET_USAG_KVA_QY,
        /* NET_USAG_KVAR_QY             <- net_usag_kvar_qy             NUMBER(10,3) -> NUMBER(10,3) */
        p."net_usag_kvar_qy" AS NET_USAG_KVAR_QY,
        /* NET_USAG_KVARH_QY            <- net_usag_kvarh_qy            NUMBER(10,0) -> NUMBER(10,0) */
        p."net_usag_kvarh_qy" AS NET_USAG_KVARH_QY,
        /* NET_USAG_KW_QY               <- net_usag_kw_qy               NUMBER(10,3) -> NUMBER(10,3) */
        p."net_usag_kw_qy" AS NET_USAG_KW_QY,
        /* NET_USAG_KWH_QY              <- net_usag_kwh_qy              NUMBER(10,0) -> NUMBER(10,0) */
        p."net_usag_kwh_qy" AS NET_USAG_KWH_QY,
        /* NET_USAG_QHR_QY              <- net_usag_qhr_qy              NUMBER(10,1) -> NUMBER(10,1) */
        p."net_usag_qhr_qy" AS NET_USAG_QHR_QY,
        /* PWR_FCTR_QY                  <- pwr_fctr_qy                  NUMBER(4,1) -> NUMBER(4,1) */
        p."pwr_fctr_qy" AS PWR_FCTR_QY,
        /* PWR_FCTR_CNST_QY             <- pwr_fctr_cnst_qy             NUMBER(7,4) -> NUMBER(7,4) */
        p."pwr_fctr_cnst_qy" AS PWR_FCTR_CNST_QY,
        /* RCTV_DMND_QY                 <- rctv_dmnd_qy                 NUMBER(7,1) -> NUMBER(7,1) */
        p."rctv_dmnd_qy" AS RCTV_DMND_QY,
        /* RCTV_HORS_QY                 <- rctv_hors_qy                 NUMBER(10,0) -> NUMBER(10,0) */
        p."rctv_hors_qy" AS RCTV_HORS_QY,
        /* USAG_NBR_DAYS_QY             <- usag_nbr_days_qy             NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__8, 5, 0) AS USAG_NBR_DAYS_QY,
        p.N__8 AS RAW__8,
        /* LOAD_FCTR_QY                 <- load_fctr_qy                 NUMBER(4,1) -> NUMBER(4,1) */
        p."load_fctr_qy" AS LOAD_FCTR_QY,
        /* HOURS_USED_QY                <- hours_used_qy                NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__9, 5, 0) AS HOURS_USED_QY,
        p.N__9 AS RAW__9,
        /* LCI_USAG_EXISTS_FL           <- lci_usag_exists_fl           VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS LCI_USAG_EXISTS_FL,
        /* EDI_CNTL_NB                  <- edi_cntl_nb                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS EDI_CNTL_NB,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            TO_VARCHAR(src."bill_head_nb") AS N__2   /* bill_head_nb -> BILL_HEAD_NB */,
            TO_VARCHAR(src."bill_comp_nb") AS N__3   /* bill_comp_nb -> BILL_COMP_NB */,
            REGEXP_REPLACE(src."time_of_day_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* time_of_day_cd -> TIME_OF_DAY_CD */,
            REGEXP_REPLACE(src."dmnd_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* dmnd_type_cd -> DMND_TYPE_CD */,
            REGEXP_REPLACE(src."read_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* read_cd -> READ_CD */,
            TO_VARCHAR(src."tod_cd_sort_nb") AS N__7   /* tod_cd_sort_nb -> TOD_CD_SORT_NB */,
            TO_VARCHAR(src."usag_nbr_days_qy") AS N__8   /* usag_nbr_days_qy -> USAG_NBR_DAYS_QY */,
            TO_VARCHAR(src."hours_used_qy") AS N__9   /* hours_used_qy -> HOURS_USED_QY */,
            REGEXP_REPLACE(src."lci_usag_exists_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* lci_usag_exists_fl -> LCI_USAG_EXISTS_FL */,
            REGEXP_REPLACE(src."edi_cntl_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* edi_cntl_nb -> EDI_CNTL_NB */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_BILLABLE_USAGE') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_billable_usage"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* BILL_HEAD_NB */
    AND (s.RAW__2 IS NULL OR s.BILL_HEAD_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.BILL_HEAD_NB IS NOT NULL   /* NULL or blank in a key column */
    /* BILL_COMP_NB */
    AND (s.RAW__3 IS NULL OR s.BILL_COMP_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.BILL_COMP_NB IS NOT NULL   /* NULL or blank in a key column */
    /* TIME_OF_DAY_CD */
    AND (s.TIME_OF_DAY_CD IS NOT NULL AND s.TIME_OF_DAY_CD <> '')   /* NULL or blank in a key column */
    /* TOD_CD_SORT_NB */
    AND (s.RAW__7 IS NULL OR s.TOD_CD_SORT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.TOD_CD_SORT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_DMND_QY */
    AND s.BILL_DMND_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_KWH_QY */
    AND s.BILL_KWH_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NET_USAG_KVA_QY */
    AND s.NET_USAG_KVA_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NET_USAG_KVAR_QY */
    AND s.NET_USAG_KVAR_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NET_USAG_KVARH_QY */
    AND s.NET_USAG_KVARH_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NET_USAG_KW_QY */
    AND s.NET_USAG_KW_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NET_USAG_KWH_QY */
    AND s.NET_USAG_KWH_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NET_USAG_QHR_QY */
    AND s.NET_USAG_QHR_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PWR_FCTR_QY */
    AND s.PWR_FCTR_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PWR_FCTR_CNST_QY */
    AND s.PWR_FCTR_CNST_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* RCTV_DMND_QY */
    AND s.RCTV_DMND_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* RCTV_HORS_QY */
    AND s.RCTV_HORS_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* USAG_NBR_DAYS_QY */
    AND (s.RAW__8 IS NULL OR s.USAG_NBR_DAYS_QY IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.USAG_NBR_DAYS_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LOAD_FCTR_QY */
    AND s.LOAD_FCTR_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* HOURS_USED_QY */
    AND (s.RAW__9 IS NULL OR s.HOURS_USED_QY IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.HOURS_USED_QY IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.BILL_HEAD_NB, s.BILL_COMP_NB, s.TIME_OF_DAY_CD
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.BILL_HEAD_NB,
    SRC.BILL_COMP_NB,
    SRC.TIME_OF_DAY_CD,
    SRC.DMND_TYPE_CD,
    SRC.READ_CD,
    SRC.TOD_CD_SORT_NB,
    SRC.BILL_DMND_QY,
    SRC.BILL_KWH_QY,
    SRC.NET_USAG_KVA_QY,
    SRC.NET_USAG_KVAR_QY,
    SRC.NET_USAG_KVARH_QY,
    SRC.NET_USAG_KW_QY,
    SRC.NET_USAG_KWH_QY,
    SRC.NET_USAG_QHR_QY,
    SRC.PWR_FCTR_QY,
    SRC.PWR_FCTR_CNST_QY,
    SRC.RCTV_DMND_QY,
    SRC.RCTV_HORS_QY,
    SRC.USAG_NBR_DAYS_QY,
    SRC.LOAD_FCTR_QY,
    SRC.HOURS_USED_QY,
    SRC.LCI_USAG_EXISTS_FL,
    SRC.EDI_CNTL_NB,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_BILLABLE_USAGE_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BILLABLE_USAGE') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, BILL_HEAD_NB, BILL_COMP_NB, TIME_OF_DAY_CD
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.BILL_HEAD_NB = TGT.BILL_HEAD_NB
    AND SRC.BILL_COMP_NB = TGT.BILL_COMP_NB
    AND SRC.TIME_OF_DAY_CD = TGT.TIME_OF_DAY_CD
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.DMND_TYPE_CD, TGT.DMND_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.READ_CD, TGT.READ_CD, 1, 0) = 0
        OR DECODE(SRC.TOD_CD_SORT_NB, TGT.TOD_CD_SORT_NB, 1, 0) = 0
        OR DECODE(SRC.BILL_DMND_QY, TGT.BILL_DMND_QY, 1, 0) = 0
        OR DECODE(SRC.BILL_KWH_QY, TGT.BILL_KWH_QY, 1, 0) = 0
        OR DECODE(SRC.NET_USAG_KVA_QY, TGT.NET_USAG_KVA_QY, 1, 0) = 0
        OR DECODE(SRC.NET_USAG_KVAR_QY, TGT.NET_USAG_KVAR_QY, 1, 0) = 0
        OR DECODE(SRC.NET_USAG_KVARH_QY, TGT.NET_USAG_KVARH_QY, 1, 0) = 0
        OR DECODE(SRC.NET_USAG_KW_QY, TGT.NET_USAG_KW_QY, 1, 0) = 0
        OR DECODE(SRC.NET_USAG_KWH_QY, TGT.NET_USAG_KWH_QY, 1, 0) = 0
        OR DECODE(SRC.NET_USAG_QHR_QY, TGT.NET_USAG_QHR_QY, 1, 0) = 0
        OR DECODE(SRC.PWR_FCTR_QY, TGT.PWR_FCTR_QY, 1, 0) = 0
        OR DECODE(SRC.PWR_FCTR_CNST_QY, TGT.PWR_FCTR_CNST_QY, 1, 0) = 0
        OR DECODE(SRC.RCTV_DMND_QY, TGT.RCTV_DMND_QY, 1, 0) = 0
        OR DECODE(SRC.RCTV_HORS_QY, TGT.RCTV_HORS_QY, 1, 0) = 0
        OR DECODE(SRC.USAG_NBR_DAYS_QY, TGT.USAG_NBR_DAYS_QY, 1, 0) = 0
        OR DECODE(SRC.LOAD_FCTR_QY, TGT.LOAD_FCTR_QY, 1, 0) = 0
        OR DECODE(SRC.HOURS_USED_QY, TGT.HOURS_USED_QY, 1, 0) = 0
        OR DECODE(SRC.LCI_USAG_EXISTS_FL, TGT.LCI_USAG_EXISTS_FL, 1, 0) = 0
        OR DECODE(SRC.EDI_CNTL_NB, TGT.EDI_CNTL_NB, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )

