

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'DIR_TYPE_CD', 'PROD_ORDR_NB', 'DEBT_TS'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_DEBIT_ACTIVITY')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_DEBIT_ACTIVITY')
    ]
) }}

WITH ODS_MCS_DEBIT_ACTIVITY_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.DIR_TYPE_CD,
    s.PROD_ORDR_NB,
    s.DEBT_TS,
    s.DEBT_AT,
    s.REMN_DEBT_AT,
    s.BSNS_CD,
    s.DEBT_STAT_CD,
    s.HIST_CRRC_CD,
    s.SHOW_ON_BILL_CD,
    s.SORC_CD,
    s.BSNS_TYPE_CD,
    s.TRF_BETWEEN_CD,
    s.DEBT_DUE_DT,
    s.REVN_YEAR_MNTH_DT,
    s.AGE_OF_DEBIT_CD,
    s.PAGR_PRDN_ORDR_NB,
    s.BILL_HEAD_NB,
    s.DEBT_PRCS_DT,
    s.AR_SORT_CD,
    s.ELEC_BSNS_FL,
    s.BILL_COMP_NB,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    s.RCVR_TYPE_CD,
    s.CHRG_OFF_STAT_CD,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS BILL_ACCT_NB,
        /* DIR_TYPE_CD                  <- dir_type_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__2, 16777216) AS DIR_TYPE_CD,
        /* PROD_ORDR_NB                 <- prod_ordr_nb                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__3, 5, 0) AS PROD_ORDR_NB,
        p.N__3 AS RAW__3,
        /* DEBT_TS                      <- debt_ts                      TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."debt_ts" AS DEBT_TS,
        /* DEBT_AT                      <- debt_at                      NUMBER(10,2) -> NUMBER(10,2) */
        p."debt_at" AS DEBT_AT,
        /* REMN_DEBT_AT                 <- remn_debt_at                 NUMBER(10,2) -> NUMBER(10,2) */
        p."remn_debt_at" AS REMN_DEBT_AT,
        /* BSNS_CD                      <- bsns_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__4, 16777216), '') AS BSNS_CD,
        /* DEBT_STAT_CD                 <- debt_stat_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS DEBT_STAT_CD,
        /* HIST_CRRC_CD                 <- hist_crrc_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS HIST_CRRC_CD,
        /* SHOW_ON_BILL_CD              <- show_on_bill_cd              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS SHOW_ON_BILL_CD,
        /* SORC_CD                      <- sorc_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS SORC_CD,
        /* BSNS_TYPE_CD                 <- bsns_type_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS BSNS_TYPE_CD,
        /* TRF_BETWEEN_CD               <- trf_between_cd               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS TRF_BETWEEN_CD,
        /* DEBT_DUE_DT                  <- debt_due_dt                  DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."debt_due_dt" AS TIMESTAMP_NTZ(9)) AS DEBT_DUE_DT,
        /* REVN_YEAR_MNTH_DT            <- revn_year_mnth_dt            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS REVN_YEAR_MNTH_DT,
        /* AGE_OF_DEBIT_CD              <- age_of_debit_cd              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS AGE_OF_DEBIT_CD,
        /* PAGR_PRDN_ORDR_NB            <- pagr_prdn_ordr_nb            NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__13, 5, 0) AS PAGR_PRDN_ORDR_NB,
        p.N__13 AS RAW__13,
        /* BILL_HEAD_NB                 <- bill_head_nb                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__14, 5, 0) AS BILL_HEAD_NB,
        p.N__14 AS RAW__14,
        /* DEBT_PRCS_DT                 <- debt_prcs_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."debt_prcs_dt" AS TIMESTAMP_NTZ(9)) AS DEBT_PRCS_DT,
        /* AR_SORT_CD                   <- ar_sort_cd                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__15, 16777216), '') AS AR_SORT_CD,
        /* ELEC_BSNS_FL                 <- elec_bsns_fl                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__16, 16777216), '') AS ELEC_BSNS_FL,
        /* BILL_COMP_NB                 <- bill_comp_nb                 NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__17, 5, 0) AS BILL_COMP_NB,
        p.N__17 AS RAW__17,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__18, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* RCVR_TYPE_CD                 <- rcvr_type_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__19, 16777216) AS RCVR_TYPE_CD,
        /* CHRG_OFF_STAT_CD             <- chrg_off_stat_cd             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__20, 16777216), '') AS CHRG_OFF_STAT_CD
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."dir_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* dir_type_cd -> DIR_TYPE_CD */,
            TO_VARCHAR(src."prod_ordr_nb") AS N__3   /* prod_ordr_nb -> PROD_ORDR_NB */,
            REGEXP_REPLACE(src."bsns_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* bsns_cd -> BSNS_CD */,
            REGEXP_REPLACE(src."debt_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* debt_stat_cd -> DEBT_STAT_CD */,
            REGEXP_REPLACE(src."hist_crrc_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* hist_crrc_cd -> HIST_CRRC_CD */,
            REGEXP_REPLACE(src."show_on_bill_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* show_on_bill_cd -> SHOW_ON_BILL_CD */,
            REGEXP_REPLACE(src."sorc_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* sorc_cd -> SORC_CD */,
            REGEXP_REPLACE(src."bsns_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* bsns_type_cd -> BSNS_TYPE_CD */,
            REGEXP_REPLACE(src."trf_between_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* trf_between_cd -> TRF_BETWEEN_CD */,
            REGEXP_REPLACE(src."revn_year_mnth_dt", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* revn_year_mnth_dt -> REVN_YEAR_MNTH_DT */,
            REGEXP_REPLACE(src."age_of_debit_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* age_of_debit_cd -> AGE_OF_DEBIT_CD */,
            TO_VARCHAR(src."pagr_prdn_ordr_nb") AS N__13   /* pagr_prdn_ordr_nb -> PAGR_PRDN_ORDR_NB */,
            TO_VARCHAR(src."bill_head_nb") AS N__14   /* bill_head_nb -> BILL_HEAD_NB */,
            REGEXP_REPLACE(src."ar_sort_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* ar_sort_cd -> AR_SORT_CD */,
            REGEXP_REPLACE(src."elec_bsns_fl", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* elec_bsns_fl -> ELEC_BSNS_FL */,
            TO_VARCHAR(src."bill_comp_nb") AS N__17   /* bill_comp_nb -> BILL_COMP_NB */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */,
            REGEXP_REPLACE(src."rcvr_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__19   /* rcvr_type_cd -> RCVR_TYPE_CD */,
            REGEXP_REPLACE(src."chrg_off_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__20   /* chrg_off_stat_cd -> CHRG_OFF_STAT_CD */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_DEBIT_ACTIVITY') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_debit_activity"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* DIR_TYPE_CD */
    AND (s.DIR_TYPE_CD IS NOT NULL AND s.DIR_TYPE_CD <> '')   /* NULL or blank in a key column */
    /* PROD_ORDR_NB */
    AND (s.RAW__3 IS NULL OR s.PROD_ORDR_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.PROD_ORDR_NB IS NOT NULL   /* NULL or blank in a key column */
    /* DEBT_TS */
    AND (s.DEBT_TS IS NULL OR YEAR(s.DEBT_TS) BETWEEN 1900 AND 9999)   /* date/timestamp outside the accepted year range */
    AND s.DEBT_TS IS NOT NULL   /* NULL or blank in a key column */
    /* DEBT_AT */
    AND s.DEBT_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* REMN_DEBT_AT */
    AND s.REMN_DEBT_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PAGR_PRDN_ORDR_NB */
    AND (s.RAW__13 IS NULL OR s.PAGR_PRDN_ORDR_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.PAGR_PRDN_ORDR_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_HEAD_NB */
    AND (s.RAW__14 IS NULL OR s.BILL_HEAD_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.BILL_HEAD_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* DEBT_PRCS_DT */
    AND s.DEBT_PRCS_DT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_COMP_NB */
    AND (s.RAW__17 IS NULL OR s.BILL_COMP_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.BILL_COMP_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.DIR_TYPE_CD, s.PROD_ORDR_NB, s.DEBT_TS
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.DIR_TYPE_CD,
    SRC.PROD_ORDR_NB,
    SRC.DEBT_TS,
    SRC.DEBT_AT,
    SRC.REMN_DEBT_AT,
    SRC.BSNS_CD,
    SRC.DEBT_STAT_CD,
    SRC.HIST_CRRC_CD,
    SRC.SHOW_ON_BILL_CD,
    SRC.SORC_CD,
    SRC.BSNS_TYPE_CD,
    SRC.TRF_BETWEEN_CD,
    SRC.DEBT_DUE_DT,
    SRC.REVN_YEAR_MNTH_DT,
    SRC.AGE_OF_DEBIT_CD,
    SRC.PAGR_PRDN_ORDR_NB,
    SRC.BILL_HEAD_NB,
    SRC.DEBT_PRCS_DT,
    SRC.AR_SORT_CD,
    SRC.ELEC_BSNS_FL,
    SRC.BILL_COMP_NB,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.RCVR_TYPE_CD,
    SRC.CHRG_OFF_STAT_CD,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_DEBIT_ACTIVITY_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_DEBIT_ACTIVITY') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, DIR_TYPE_CD, PROD_ORDR_NB, DEBT_TS
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.DIR_TYPE_CD = TGT.DIR_TYPE_CD
    AND SRC.PROD_ORDR_NB = TGT.PROD_ORDR_NB
    AND SRC.DEBT_TS = TGT.DEBT_TS
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.DEBT_AT, TGT.DEBT_AT, 1, 0) = 0
        OR DECODE(SRC.REMN_DEBT_AT, TGT.REMN_DEBT_AT, 1, 0) = 0
        OR DECODE(SRC.BSNS_CD, TGT.BSNS_CD, 1, 0) = 0
        OR DECODE(SRC.DEBT_STAT_CD, TGT.DEBT_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.HIST_CRRC_CD, TGT.HIST_CRRC_CD, 1, 0) = 0
        OR DECODE(SRC.SHOW_ON_BILL_CD, TGT.SHOW_ON_BILL_CD, 1, 0) = 0
        OR DECODE(SRC.SORC_CD, TGT.SORC_CD, 1, 0) = 0
        OR DECODE(SRC.BSNS_TYPE_CD, TGT.BSNS_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.TRF_BETWEEN_CD, TGT.TRF_BETWEEN_CD, 1, 0) = 0
        OR DECODE(SRC.DEBT_DUE_DT, TGT.DEBT_DUE_DT, 1, 0) = 0
        OR DECODE(SRC.REVN_YEAR_MNTH_DT, TGT.REVN_YEAR_MNTH_DT, 1, 0) = 0
        OR DECODE(SRC.AGE_OF_DEBIT_CD, TGT.AGE_OF_DEBIT_CD, 1, 0) = 0
        OR DECODE(SRC.PAGR_PRDN_ORDR_NB, TGT.PAGR_PRDN_ORDR_NB, 1, 0) = 0
        OR DECODE(SRC.BILL_HEAD_NB, TGT.BILL_HEAD_NB, 1, 0) = 0
        OR DECODE(SRC.DEBT_PRCS_DT, TGT.DEBT_PRCS_DT, 1, 0) = 0
        OR DECODE(SRC.AR_SORT_CD, TGT.AR_SORT_CD, 1, 0) = 0
        OR DECODE(SRC.ELEC_BSNS_FL, TGT.ELEC_BSNS_FL, 1, 0) = 0
        OR DECODE(SRC.BILL_COMP_NB, TGT.BILL_COMP_NB, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.RCVR_TYPE_CD, TGT.RCVR_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.CHRG_OFF_STAT_CD, TGT.CHRG_OFF_STAT_CD, 1, 0) = 0
    )
