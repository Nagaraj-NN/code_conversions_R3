
         

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['PREM_NB'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_PREMISE')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_PREMISE')
    ]
) }}

WITH ODS_MCS_PREMISE_SQ AS (
SELECT
    s.PREM_NB,
    s.CO_CD_OWNR,
    s.SER_HALF_IND_AD,
    s.SERV_CITY_AD,
    s.SERV_HOUS_NBR_AD,
    s.SERV_PTDR_AD,
    s.SERV_PRDR_AD,
    s.ADDL_SRV_DATA_AD,
    s.STATE_CD,
    s.SERV_ST_NAME_AD,
    s.SERV_ST_DSGT_AD,
    s.SERV_UNIT_DSGT_AD,
    s.SERV_UNIT_NBR_AD,
    s.SERV_ZIP_AD,
    s.ST_CD_AD,
    s.CARI_RTE_CD,
    s.IRRG_USE_CD,
    s.LOAD_AREA_CD,
    s.REDDY_CRCT_CENT_CD,
    s.PREM_STAT_CD,
    s.SRVC_ENTN_CD,
    s.AREA_CD,
    s.CUMU_CD,
    s.TAX_DSTC_CD,
    s.DVSN_CD,
    s.LAST_RRTE_DT,
    s.NFNC_CNTL_UNIT_NB,
    s.CYCL_NB,
    s.KEY_NB,
    s.MTR_RDG_RTE_NB,
    s.OA_AGRM_NB,
    s.RDG_SEQ_NB,
    s.SERV_MAIL_CITY_AD,
    s.RURL_RTE_TYPE_CD,
    s.ROUTE_NB_AD,
    s.BOX_AD,
    s.MTR_RTE_OWNR_NB,
    s.SRVC_POLE_NB,
    s.TRSF_POLE_NB,
    s.HSNG_CTGY_CD,
    s.SUB_AREA_CD,
    s.DELV_PT_CD,
    s.SRVC_ST_CD,
    s.MAIL_ZIP_AD,
    s.POWER_POOL_CD,
    s.MTR_REDR_ID,
    s.IRRG_USE_EFCT_DT,
    s.PRX_VERIFY_DT,
    s.FIPS_ANNEX_DT,
    s.ANNEX_STAT_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    s.AMI_FTPRNT_CD,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* PREM_NB                      <- prem_nb                      VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS PREM_NB,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__2, 16777216), '') AS CO_CD_OWNR,
        /* SER_HALF_IND_AD              <- ser_half_ind_ad              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__3, 16777216), '') AS SER_HALF_IND_AD,
        /* SERV_CITY_AD                 <- serv_city_ad                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__4, 16777216), '') AS SERV_CITY_AD,
        /* SERV_HOUS_NBR_AD             <- serv_hous_nbr_ad             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS SERV_HOUS_NBR_AD,
        /* SERV_PTDR_AD                 <- serv_ptdr_ad                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS SERV_PTDR_AD,
        /* SERV_PRDR_AD                 <- serv_prdr_ad                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS SERV_PRDR_AD,
        /* ADDL_SRV_DATA_AD             <- addl_srv_data_ad             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS ADDL_SRV_DATA_AD,
        /* STATE_CD                     <- state_cd                     VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS STATE_CD,
        /* SERV_ST_NAME_AD              <- serv_st_name_ad              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS SERV_ST_NAME_AD,
        /* SERV_ST_DSGT_AD              <- serv_st_dsgt_ad              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS SERV_ST_DSGT_AD,
        /* SERV_UNIT_DSGT_AD            <- serv_unit_dsgt_ad            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS SERV_UNIT_DSGT_AD,
        /* SERV_UNIT_NBR_AD             <- serv_unit_nbr_ad             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__13, 16777216), '') AS SERV_UNIT_NBR_AD,
        /* SERV_ZIP_AD                  <- serv_zip_ad                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__14, 16777216), '') AS SERV_ZIP_AD,
        /* ST_CD_AD                     <- st_cd_ad                     VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__15, 16777216), '') AS ST_CD_AD,
        /* CARI_RTE_CD                  <- cari_rte_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__16, 16777216), '') AS CARI_RTE_CD,
        /* IRRG_USE_CD                  <- irrg_use_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__17, 16777216), '') AS IRRG_USE_CD,
        /* LOAD_AREA_CD                 <- load_area_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__18, 16777216), '') AS LOAD_AREA_CD,
        /* REDDY_CRCT_CENT_CD           <- reddy_crct_cent_cd           VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__19, 16777216), '') AS REDDY_CRCT_CENT_CD,
        /* PREM_STAT_CD                 <- prem_stat_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__20, 16777216), '') AS PREM_STAT_CD,
        /* SRVC_ENTN_CD                 <- srvc_entn_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__21, 16777216), '') AS SRVC_ENTN_CD,
        /* AREA_CD                      <- area_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__22, 16777216), '') AS AREA_CD,
        /* CUMU_CD                      <- cumu_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__23, 16777216), '') AS CUMU_CD,
        /* TAX_DSTC_CD                  <- tax_dstc_cd                  NUMBER(10,0) -> NUMBER(10,0) */
        p."tax_dstc_cd" AS TAX_DSTC_CD,
        /* DVSN_CD                      <- dvsn_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__24, 16777216), '') AS DVSN_CD,
        /* LAST_RRTE_DT                 <- last_rrte_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."last_rrte_dt" AS TIMESTAMP_NTZ(9)) AS LAST_RRTE_DT,
        /* NFNC_CNTL_UNIT_NB            <- nfnc_cntl_unit_nb            NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__25, 5, 0) AS NFNC_CNTL_UNIT_NB,
        p.N__25 AS RAW__25,
        /* CYCL_NB                      <- cycl_nb                      NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__26, 5, 0) AS CYCL_NB,
        p.N__26 AS RAW__26,
        /* KEY_NB                       <- key_nb                       NUMBER(10,0) -> NUMBER(5,0) */
        TRY_TO_NUMBER(p.N__27, 5, 0) AS KEY_NB,
        p.N__27 AS RAW__27,
        /* MTR_RDG_RTE_NB               <- mtr_rdg_rte_nb               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__28, 16777216), '') AS MTR_RDG_RTE_NB,
        /* OA_AGRM_NB                   <- oa_agrm_nb                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__29, 16777216), '') AS OA_AGRM_NB,
        /* RDG_SEQ_NB                   <- rdg_seq_nb                   NUMBER(10,0) -> NUMBER(10,0) */
        p."rdg_seq_nb" AS RDG_SEQ_NB,
        /* SERV_MAIL_CITY_AD            <- serv_mail_city_ad            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__30, 16777216), '') AS SERV_MAIL_CITY_AD,
        /* RURL_RTE_TYPE_CD             <- rurl_rte_type_cd             VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__31, 16777216), '') AS RURL_RTE_TYPE_CD,
        /* ROUTE_NB_AD                  <- route_nb_ad                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__32, 16777216), '') AS ROUTE_NB_AD,
        /* BOX_AD                       <- box_ad                       VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__33, 16777216), '') AS BOX_AD,
        /* MTR_RTE_OWNR_NB              <- mtr_rte_ownr_nb              NUMBER(10,0) -> NUMBER(10,0) */
        p."mtr_rte_ownr_nb" AS MTR_RTE_OWNR_NB,
        /* SRVC_POLE_NB                 <- srvc_pole_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__34, 16777216), '') AS SRVC_POLE_NB,
        /* TRSF_POLE_NB                 <- trsf_pole_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__35, 16777216), '') AS TRSF_POLE_NB,
        /* HSNG_CTGY_CD                 <- hsng_ctgy_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__36, 16777216), '') AS HSNG_CTGY_CD,
        /* SUB_AREA_CD                  <- sub_area_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__37, 16777216), '') AS SUB_AREA_CD,
        /* DELV_PT_CD                   <- delv_pt_cd                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__38, 16777216), '') AS DELV_PT_CD,
        /* SRVC_ST_CD                   <- srvc_st_cd                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__39, 16777216), '') AS SRVC_ST_CD,
        /* MAIL_ZIP_AD                  <- mail_zip_ad                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__40, 16777216), '') AS MAIL_ZIP_AD,
        /* POWER_POOL_CD                <- power_pool_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__41, 16777216), '') AS POWER_POOL_CD,
        /* MTR_REDR_ID                  <- mtr_redr_id                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__42, 16777216), '') AS MTR_REDR_ID,
        /* IRRG_USE_EFCT_DT             <- irrg_use_efct_dt             DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."irrg_use_efct_dt" AS TIMESTAMP_NTZ(9)) AS IRRG_USE_EFCT_DT,
        /* PRX_VERIFY_DT                <- prx_verify_dt                DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."prx_verify_dt" AS TIMESTAMP_NTZ(9)) AS PRX_VERIFY_DT,
        /* FIPS_ANNEX_DT                <- fips_annex_dt                DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."fips_annex_dt" AS TIMESTAMP_NTZ(9)) AS FIPS_ANNEX_DT,
        /* ANNEX_STAT_CD                <- annex_stat_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__43, 16777216), '') AS ANNEX_STAT_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__44, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* AMI_FTPRNT_CD                <- ami_ftprnt_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__45, 16777216), ' ') AS AMI_FTPRNT_CD   /* DDL default */
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."prem_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* prem_nb -> PREM_NB */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."ser_half_ind_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* ser_half_ind_ad -> SER_HALF_IND_AD */,
            REGEXP_REPLACE(src."serv_city_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* serv_city_ad -> SERV_CITY_AD */,
            REGEXP_REPLACE(src."serv_hous_nbr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* serv_hous_nbr_ad -> SERV_HOUS_NBR_AD */,
            REGEXP_REPLACE(src."serv_ptdr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* serv_ptdr_ad -> SERV_PTDR_AD */,
            REGEXP_REPLACE(src."serv_prdr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* serv_prdr_ad -> SERV_PRDR_AD */,
            REGEXP_REPLACE(src."addl_srv_data_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* addl_srv_data_ad -> ADDL_SRV_DATA_AD */,
            REGEXP_REPLACE(src."state_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* state_cd -> STATE_CD */,
            REGEXP_REPLACE(src."serv_st_name_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* serv_st_name_ad -> SERV_ST_NAME_AD */,
            REGEXP_REPLACE(src."serv_st_dsgt_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* serv_st_dsgt_ad -> SERV_ST_DSGT_AD */,
            REGEXP_REPLACE(src."serv_unit_dsgt_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* serv_unit_dsgt_ad -> SERV_UNIT_DSGT_AD */,
            REGEXP_REPLACE(src."serv_unit_nbr_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__13   /* serv_unit_nbr_ad -> SERV_UNIT_NBR_AD */,
            REGEXP_REPLACE(src."serv_zip_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__14   /* serv_zip_ad -> SERV_ZIP_AD */,
            REGEXP_REPLACE(src."st_cd_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__15   /* st_cd_ad -> ST_CD_AD */,
            REGEXP_REPLACE(src."cari_rte_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__16   /* cari_rte_cd -> CARI_RTE_CD */,
            REGEXP_REPLACE(src."irrg_use_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__17   /* irrg_use_cd -> IRRG_USE_CD */,
            REGEXP_REPLACE(src."load_area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__18   /* load_area_cd -> LOAD_AREA_CD */,
            REGEXP_REPLACE(src."reddy_crct_cent_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__19   /* reddy_crct_cent_cd -> REDDY_CRCT_CENT_CD */,
            REGEXP_REPLACE(src."prem_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__20   /* prem_stat_cd -> PREM_STAT_CD */,
            REGEXP_REPLACE(src."srvc_entn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__21   /* srvc_entn_cd -> SRVC_ENTN_CD */,
            REGEXP_REPLACE(src."area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__22   /* area_cd -> AREA_CD */,
            REGEXP_REPLACE(src."cumu_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__23   /* cumu_cd -> CUMU_CD */,
            REGEXP_REPLACE(src."dvsn_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__24   /* dvsn_cd -> DVSN_CD */,
            TO_VARCHAR(src."nfnc_cntl_unit_nb") AS N__25   /* nfnc_cntl_unit_nb -> NFNC_CNTL_UNIT_NB */,
            TO_VARCHAR(src."cycl_nb") AS N__26   /* cycl_nb -> CYCL_NB */,
            TO_VARCHAR(src."key_nb") AS N__27   /* key_nb -> KEY_NB */,
            REGEXP_REPLACE(src."mtr_rdg_rte_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__28   /* mtr_rdg_rte_nb -> MTR_RDG_RTE_NB */,
            REGEXP_REPLACE(src."oa_agrm_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__29   /* oa_agrm_nb -> OA_AGRM_NB */,
            REGEXP_REPLACE(src."serv_mail_city_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__30   /* serv_mail_city_ad -> SERV_MAIL_CITY_AD */,
            REGEXP_REPLACE(src."rurl_rte_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__31   /* rurl_rte_type_cd -> RURL_RTE_TYPE_CD */,
            REGEXP_REPLACE(src."route_nb_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__32   /* route_nb_ad -> ROUTE_NB_AD */,
            REGEXP_REPLACE(src."box_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__33   /* box_ad -> BOX_AD */,
            REGEXP_REPLACE(src."srvc_pole_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__34   /* srvc_pole_nb -> SRVC_POLE_NB */,
            REGEXP_REPLACE(src."trsf_pole_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__35   /* trsf_pole_nb -> TRSF_POLE_NB */,
            REGEXP_REPLACE(src."hsng_ctgy_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__36   /* hsng_ctgy_cd -> HSNG_CTGY_CD */,
            REGEXP_REPLACE(src."sub_area_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__37   /* sub_area_cd -> SUB_AREA_CD */,
            REGEXP_REPLACE(src."delv_pt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__38   /* delv_pt_cd -> DELV_PT_CD */,
            REGEXP_REPLACE(src."srvc_st_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__39   /* srvc_st_cd -> SRVC_ST_CD */,
            REGEXP_REPLACE(src."mail_zip_ad", '^[[:space:]]+|[[:space:]]+$', '') AS N__40   /* mail_zip_ad -> MAIL_ZIP_AD */,
            REGEXP_REPLACE(src."power_pool_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__41   /* power_pool_cd -> POWER_POOL_CD */,
            REGEXP_REPLACE(src."mtr_redr_id", '^[[:space:]]+|[[:space:]]+$', '') AS N__42   /* mtr_redr_id -> MTR_REDR_ID */,
            REGEXP_REPLACE(src."annex_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__43   /* annex_stat_cd -> ANNEX_STAT_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__44   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */,
            REGEXP_REPLACE(src."ami_ftprnt_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__45   /* ami_ftprnt_cd -> AMI_FTPRNT_CD */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_PREMISE') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_premise"
    ) p
) s
WHERE 1 = 1
    /* PREM_NB */
    AND (s.PREM_NB IS NOT NULL AND s.PREM_NB <> '')   /* NULL or blank in a key column */
    /* TAX_DSTC_CD */
    AND s.TAX_DSTC_CD IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* NFNC_CNTL_UNIT_NB */
    AND (s.RAW__25 IS NULL OR s.NFNC_CNTL_UNIT_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.NFNC_CNTL_UNIT_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* CYCL_NB */
    AND (s.RAW__26 IS NULL OR s.CYCL_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.CYCL_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* KEY_NB */
    AND (s.RAW__27 IS NULL OR s.KEY_NB IS NOT NULL)   /* value could not be converted / does not fit the target precision */
    AND s.KEY_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* RDG_SEQ_NB */
    AND s.RDG_SEQ_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* MTR_RTE_OWNR_NB */
    AND s.MTR_RTE_OWNR_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.PREM_NB
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.PREM_NB,
    SRC.CO_CD_OWNR,
    SRC.SER_HALF_IND_AD,
    SRC.SERV_CITY_AD,
    SRC.SERV_HOUS_NBR_AD,
    SRC.SERV_PTDR_AD,
    SRC.SERV_PRDR_AD,
    SRC.ADDL_SRV_DATA_AD,
    SRC.STATE_CD,
    SRC.SERV_ST_NAME_AD,
    SRC.SERV_ST_DSGT_AD,
    SRC.SERV_UNIT_DSGT_AD,
    SRC.SERV_UNIT_NBR_AD,
    SRC.SERV_ZIP_AD,
    SRC.ST_CD_AD,
    SRC.CARI_RTE_CD,
    SRC.IRRG_USE_CD,
    SRC.LOAD_AREA_CD,
    SRC.REDDY_CRCT_CENT_CD,
    SRC.PREM_STAT_CD,
    SRC.SRVC_ENTN_CD,
    SRC.AREA_CD,
    SRC.CUMU_CD,
    SRC.TAX_DSTC_CD,
    SRC.DVSN_CD,
    SRC.LAST_RRTE_DT,
    SRC.NFNC_CNTL_UNIT_NB,
    SRC.CYCL_NB,
    SRC.KEY_NB,
    SRC.MTR_RDG_RTE_NB,
    SRC.OA_AGRM_NB,
    SRC.RDG_SEQ_NB,
    SRC.SERV_MAIL_CITY_AD,
    SRC.RURL_RTE_TYPE_CD,
    SRC.ROUTE_NB_AD,
    SRC.BOX_AD,
    SRC.MTR_RTE_OWNR_NB,
    SRC.SRVC_POLE_NB,
    SRC.TRSF_POLE_NB,
    SRC.HSNG_CTGY_CD,
    SRC.SUB_AREA_CD,
    SRC.DELV_PT_CD,
    SRC.SRVC_ST_CD,
    SRC.MAIL_ZIP_AD,
    SRC.POWER_POOL_CD,
    SRC.MTR_REDR_ID,
    SRC.IRRG_USE_EFCT_DT,
    SRC.PRX_VERIFY_DT,
    SRC.FIPS_ANNEX_DT,
    SRC.ANNEX_STAT_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.AMI_FTPRNT_CD,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_PREMISE_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_PREMISE') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PREM_NB
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.PREM_NB = TGT.PREM_NB
WHERE
    TGT.PREM_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.SER_HALF_IND_AD, TGT.SER_HALF_IND_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_CITY_AD, TGT.SERV_CITY_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_HOUS_NBR_AD, TGT.SERV_HOUS_NBR_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_PTDR_AD, TGT.SERV_PTDR_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_PRDR_AD, TGT.SERV_PRDR_AD, 1, 0) = 0
        OR DECODE(SRC.ADDL_SRV_DATA_AD, TGT.ADDL_SRV_DATA_AD, 1, 0) = 0
        OR DECODE(SRC.STATE_CD, TGT.STATE_CD, 1, 0) = 0
        OR DECODE(SRC.SERV_ST_NAME_AD, TGT.SERV_ST_NAME_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_ST_DSGT_AD, TGT.SERV_ST_DSGT_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_UNIT_DSGT_AD, TGT.SERV_UNIT_DSGT_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_UNIT_NBR_AD, TGT.SERV_UNIT_NBR_AD, 1, 0) = 0
        OR DECODE(SRC.SERV_ZIP_AD, TGT.SERV_ZIP_AD, 1, 0) = 0
        OR DECODE(SRC.ST_CD_AD, TGT.ST_CD_AD, 1, 0) = 0
        OR DECODE(SRC.CARI_RTE_CD, TGT.CARI_RTE_CD, 1, 0) = 0
        OR DECODE(SRC.IRRG_USE_CD, TGT.IRRG_USE_CD, 1, 0) = 0
        OR DECODE(SRC.LOAD_AREA_CD, TGT.LOAD_AREA_CD, 1, 0) = 0
        OR DECODE(SRC.REDDY_CRCT_CENT_CD, TGT.REDDY_CRCT_CENT_CD, 1, 0) = 0
        OR DECODE(SRC.PREM_STAT_CD, TGT.PREM_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.SRVC_ENTN_CD, TGT.SRVC_ENTN_CD, 1, 0) = 0
        OR DECODE(SRC.AREA_CD, TGT.AREA_CD, 1, 0) = 0
        OR DECODE(SRC.CUMU_CD, TGT.CUMU_CD, 1, 0) = 0
        OR DECODE(SRC.TAX_DSTC_CD, TGT.TAX_DSTC_CD, 1, 0) = 0
        OR DECODE(SRC.DVSN_CD, TGT.DVSN_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_RRTE_DT, TGT.LAST_RRTE_DT, 1, 0) = 0
        OR DECODE(SRC.NFNC_CNTL_UNIT_NB, TGT.NFNC_CNTL_UNIT_NB, 1, 0) = 0
        OR DECODE(SRC.CYCL_NB, TGT.CYCL_NB, 1, 0) = 0
        OR DECODE(SRC.KEY_NB, TGT.KEY_NB, 1, 0) = 0
        OR DECODE(SRC.MTR_RDG_RTE_NB, TGT.MTR_RDG_RTE_NB, 1, 0) = 0
        OR DECODE(SRC.OA_AGRM_NB, TGT.OA_AGRM_NB, 1, 0) = 0
        OR DECODE(SRC.RDG_SEQ_NB, TGT.RDG_SEQ_NB, 1, 0) = 0
        OR DECODE(SRC.SERV_MAIL_CITY_AD, TGT.SERV_MAIL_CITY_AD, 1, 0) = 0
        OR DECODE(SRC.RURL_RTE_TYPE_CD, TGT.RURL_RTE_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.ROUTE_NB_AD, TGT.ROUTE_NB_AD, 1, 0) = 0
        OR DECODE(SRC.BOX_AD, TGT.BOX_AD, 1, 0) = 0
        OR DECODE(SRC.MTR_RTE_OWNR_NB, TGT.MTR_RTE_OWNR_NB, 1, 0) = 0
        OR DECODE(SRC.SRVC_POLE_NB, TGT.SRVC_POLE_NB, 1, 0) = 0
        OR DECODE(SRC.TRSF_POLE_NB, TGT.TRSF_POLE_NB, 1, 0) = 0
        OR DECODE(SRC.HSNG_CTGY_CD, TGT.HSNG_CTGY_CD, 1, 0) = 0
        OR DECODE(SRC.SUB_AREA_CD, TGT.SUB_AREA_CD, 1, 0) = 0
        OR DECODE(SRC.DELV_PT_CD, TGT.DELV_PT_CD, 1, 0) = 0
        OR DECODE(SRC.SRVC_ST_CD, TGT.SRVC_ST_CD, 1, 0) = 0
        OR DECODE(SRC.MAIL_ZIP_AD, TGT.MAIL_ZIP_AD, 1, 0) = 0
        OR DECODE(SRC.POWER_POOL_CD, TGT.POWER_POOL_CD, 1, 0) = 0
        OR DECODE(SRC.MTR_REDR_ID, TGT.MTR_REDR_ID, 1, 0) = 0
        OR DECODE(SRC.IRRG_USE_EFCT_DT, TGT.IRRG_USE_EFCT_DT, 1, 0) = 0
        OR DECODE(SRC.PRX_VERIFY_DT, TGT.PRX_VERIFY_DT, 1, 0) = 0
        OR DECODE(SRC.FIPS_ANNEX_DT, TGT.FIPS_ANNEX_DT, 1, 0) = 0
        OR DECODE(SRC.ANNEX_STAT_CD, TGT.ANNEX_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.AMI_FTPRNT_CD, TGT.AMI_FTPRNT_CD, 1, 0) = 0
    )

/* ---------------------------------------------------------------
   Run it:   dbt run --select ods_mcs_premise
   Merges only the rows that are new or whose non-key values changed.
   The target table is never dropped or recreated: full_refresh=false
   blocks --full-refresh, and the join to {{ this }} means the model
   errors out if the table is missing instead of creating one.

   Run ODS_MCS_PREMISE.reject_check.sql first to see how many
   rows each rule drops and why.
   --------------------------------------------------------------- */