

{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'CRDT_CRTN_TS'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_CREDIT_SOURCE')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_CREDIT_SOURCE')
    ]
) }}

WITH ODS_MCS_CREDIT_SOURCE_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.CRDT_CRTN_TS,
    s.CO_CD_OWNR,
    s.PYMN_CRDT_AT,
    s.APPL_CD,
    s.PYMN_CRDT_SORC_CD,
    s.SHOW_ON_BILL_CD,
    s.TRF_BETWEEN_CD,
    s.PYMN_CRDT_DT,
    s.TRANS_TYPE_CD,
    s.CASH_BTCH_NB,
    s.PYMN_SEQ_NB,
    s.AGNT_CMMR_COLL_CD,
    s.PYMN_CSHR_CD,
    s.HIST_CRRC_CD,
    s.PYMN_IND_CD,
    s.BILL_HEAD_NB,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(16777216) */
        LEFT(p.N__1, 16777216) AS BILL_ACCT_NB,
        /* CRDT_CRTN_TS                 <- crdt_crtn_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."crdt_crtn_ts" AS CRDT_CRTN_TS,
        /* CO_CD_OWNR                   <- co_cd_ownr                   VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__2, 16777216), '') AS CO_CD_OWNR,
        /* PYMN_CRDT_AT                 <- pymn_crdt_at                 NUMBER(10,2) -> NUMBER(10,2) */
        p."pymn_crdt_at" AS PYMN_CRDT_AT,
        /* APPL_CD                      <- appl_cd                      VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__3, 16777216), '') AS APPL_CD,
        /* PYMN_CRDT_SORC_CD            <- pymn_crdt_sorc_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__4, 16777216), '') AS PYMN_CRDT_SORC_CD,
        /* SHOW_ON_BILL_CD              <- show_on_bill_cd              VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__5, 16777216), '') AS SHOW_ON_BILL_CD,
        /* TRF_BETWEEN_CD               <- trf_between_cd               VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__6, 16777216), '') AS TRF_BETWEEN_CD,
        /* PYMN_CRDT_DT                 <- pymn_crdt_dt                 DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."pymn_crdt_dt" AS TIMESTAMP_NTZ(9)) AS PYMN_CRDT_DT,
        /* TRANS_TYPE_CD                <- trans_type_cd                VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__7, 16777216), '') AS TRANS_TYPE_CD,
        /* CASH_BTCH_NB                 <- cash_btch_nb                 NUMBER(10,0) -> NUMBER(38,0) */
        p."cash_btch_nb" AS CASH_BTCH_NB,
        /* PYMN_SEQ_NB                  <- pymn_seq_nb                  NUMBER(10,0) -> NUMBER(38,0) */
        p."pymn_seq_nb" AS PYMN_SEQ_NB,
        /* AGNT_CMMR_COLL_CD            <- agnt_cmmr_coll_cd            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__8, 16777216), '') AS AGNT_CMMR_COLL_CD,
        /* PYMN_CSHR_CD                 <- pymn_cshr_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__9, 16777216), '') AS PYMN_CSHR_CD,
        /* HIST_CRRC_CD                 <- hist_crrc_cd                 VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__10, 16777216), '') AS HIST_CRRC_CD,
        /* PYMN_IND_CD                  <- pymn_ind_cd                  VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__11, 16777216), '') AS PYMN_IND_CD,
        /* BILL_HEAD_NB                 <- bill_head_nb                 NUMBER(10,0) -> NUMBER(38,0) */
        p."bill_head_nb" AS BILL_HEAD_NB,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(16777216) */
        COALESCE(LEFT(p.N__12, 16777216), '') AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."co_cd_ownr", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* co_cd_ownr -> CO_CD_OWNR */,
            REGEXP_REPLACE(src."appl_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* appl_cd -> APPL_CD */,
            REGEXP_REPLACE(src."pymn_crdt_sorc_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* pymn_crdt_sorc_cd -> PYMN_CRDT_SORC_CD */,
            REGEXP_REPLACE(src."show_on_bill_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* show_on_bill_cd -> SHOW_ON_BILL_CD */,
            REGEXP_REPLACE(src."trf_between_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__6   /* trf_between_cd -> TRF_BETWEEN_CD */,
            REGEXP_REPLACE(src."trans_type_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__7   /* trans_type_cd -> TRANS_TYPE_CD */,
            REGEXP_REPLACE(src."agnt_cmmr_coll_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__8   /* agnt_cmmr_coll_cd -> AGNT_CMMR_COLL_CD */,
            REGEXP_REPLACE(src."pymn_cshr_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__9   /* pymn_cshr_cd -> PYMN_CSHR_CD */,
            REGEXP_REPLACE(src."hist_crrc_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__10   /* hist_crrc_cd -> HIST_CRRC_CD */,
            REGEXP_REPLACE(src."pymn_ind_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__11   /* pymn_ind_cd -> PYMN_IND_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__12   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_CREDIT_SOURCE') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_credit_source"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* CRDT_CRTN_TS */
    AND (s.CRDT_CRTN_TS IS NULL OR YEAR(s.CRDT_CRTN_TS) BETWEEN 1900 AND 9999)   /* date/timestamp outside the accepted year range */
    AND s.CRDT_CRTN_TS IS NOT NULL   /* NULL or blank in a key column */
    /* PYMN_CRDT_AT */
    AND s.PYMN_CRDT_AT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PYMN_CRDT_DT */
    AND s.PYMN_CRDT_DT IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* CASH_BTCH_NB */
    AND s.CASH_BTCH_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* PYMN_SEQ_NB */
    AND s.PYMN_SEQ_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* BILL_HEAD_NB */
    AND s.BILL_HEAD_NB IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* LAST_UPDT_TS */
    AND s.LAST_UPDT_TS IS NOT NULL   /* NULL or blank landing in a NOT NULL target column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.CRDT_CRTN_TS
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.CRDT_CRTN_TS,
    SRC.CO_CD_OWNR,
    SRC.PYMN_CRDT_AT,
    SRC.APPL_CD,
    SRC.PYMN_CRDT_SORC_CD,
    SRC.SHOW_ON_BILL_CD,
    SRC.TRF_BETWEEN_CD,
    SRC.PYMN_CRDT_DT,
    SRC.TRANS_TYPE_CD,
    SRC.CASH_BTCH_NB,
    SRC.PYMN_SEQ_NB,
    SRC.AGNT_CMMR_COLL_CD,
    SRC.PYMN_CSHR_CD,
    SRC.HIST_CRRC_CD,
    SRC.PYMN_IND_CD,
    SRC.BILL_HEAD_NB,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_CREDIT_SOURCE_SQ SRC

-- Compare against what is already in the target and keep only the rows
-- that are new or whose values changed. No is_incremental() guard: the
-- target always exists, and if it ever does not this fails loudly rather
-- than letting dbt create the table with its own inferred DDL.
LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_CREDIT_SOURCE') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, CRDT_CRTN_TS
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT
    ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.CRDT_CRTN_TS = TGT.CRDT_CRTN_TS
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.CO_CD_OWNR, TGT.CO_CD_OWNR, 1, 0) = 0
        OR DECODE(SRC.PYMN_CRDT_AT, TGT.PYMN_CRDT_AT, 1, 0) = 0
        OR DECODE(SRC.APPL_CD, TGT.APPL_CD, 1, 0) = 0
        OR DECODE(SRC.PYMN_CRDT_SORC_CD, TGT.PYMN_CRDT_SORC_CD, 1, 0) = 0
        OR DECODE(SRC.SHOW_ON_BILL_CD, TGT.SHOW_ON_BILL_CD, 1, 0) = 0
        OR DECODE(SRC.TRF_BETWEEN_CD, TGT.TRF_BETWEEN_CD, 1, 0) = 0
        OR DECODE(SRC.PYMN_CRDT_DT, TGT.PYMN_CRDT_DT, 1, 0) = 0
        OR DECODE(SRC.TRANS_TYPE_CD, TGT.TRANS_TYPE_CD, 1, 0) = 0
        OR DECODE(SRC.CASH_BTCH_NB, TGT.CASH_BTCH_NB, 1, 0) = 0
        OR DECODE(SRC.PYMN_SEQ_NB, TGT.PYMN_SEQ_NB, 1, 0) = 0
        OR DECODE(SRC.AGNT_CMMR_COLL_CD, TGT.AGNT_CMMR_COLL_CD, 1, 0) = 0
        OR DECODE(SRC.PYMN_CSHR_CD, TGT.PYMN_CSHR_CD, 1, 0) = 0
        OR DECODE(SRC.HIST_CRRC_CD, TGT.HIST_CRRC_CD, 1, 0) = 0
        OR DECODE(SRC.PYMN_IND_CD, TGT.PYMN_IND_CD, 1, 0) = 0
        OR DECODE(SRC.BILL_HEAD_NB, TGT.BILL_HEAD_NB, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
    )

