       
{{ config(
    database='UTLDB01',
    schema='UTLUSER',
    materialized='incremental',
    unique_key=['BILL_ACCT_NB', 'GP_EFCT_DT'],
    incremental_strategy='merge',
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BA_GREEN_PWR')
    ],
    post_hook=[
        log_model_end(this, 'DP_CDC3002_ODS_TBLSC_ODS_MCS_BA_GREEN_PWR')
    ]
) }}

WITH ODS_MCS_BA_GREEN_PWR_SQ AS (
SELECT
    s.BILL_ACCT_NB,
    s.GP_EFCT_DT,
    s.GP_AGRMT_STAT_CD,
    s.GP_EXPR_DT,
    s.GP_MNTH_AGRMT_QY,
    s.SCHD_MTHY_KWH_QY,
    s.GP_KWH_USAG_PC,
    s.GP_REASON_CD,
    s.LAST_TRAN_UPDT_NM,
    s.LAST_UPDT_TS,
    s.SUPRT_RENEW_RES_CD,
    CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(6)        AS EDW_LAST_UPDT_TS
FROM (
    /* layer 2: convert each normalised value to the target type */
    SELECT
        /* BILL_ACCT_NB                 <- bill_acct_nb                 VARCHAR(134217728) -> VARCHAR(10) */
        LEFT(p.N__1, 10) AS BILL_ACCT_NB,
        /* GP_EFCT_DT                   <- gp_efct_dt                   DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."gp_efct_dt" AS TIMESTAMP_NTZ(9)) AS GP_EFCT_DT,
        /* GP_AGRMT_STAT_CD             <- gp_agrmt_stat_cd             VARCHAR(134217728) -> VARCHAR(1) */
        LEFT(p.N__2, 1) AS GP_AGRMT_STAT_CD,
        /* GP_EXPR_DT                   <- gp_expr_dt                   DATE -> TIMESTAMP_NTZ(9) */
        CAST(p."gp_expr_dt" AS TIMESTAMP_NTZ(9)) AS GP_EXPR_DT,
        /* GP_MNTH_AGRMT_QY             <- gp_mnth_agrmt_qy             NUMBER(10,0) -> NUMBER(38,0) */
        p."gp_mnth_agrmt_qy" AS GP_MNTH_AGRMT_QY,
        /* SCHD_MTHY_KWH_QY             <- schd_mthy_kwh_qy             NUMBER(10,0) -> NUMBER(38,0) */
        p."schd_mthy_kwh_qy" AS SCHD_MTHY_KWH_QY,
        /* GP_KWH_USAG_PC               <- gp_kwh_usag_pc               NUMBER(10,0) -> NUMBER(38,18) */
        p."gp_kwh_usag_pc" AS GP_KWH_USAG_PC,
        /* GP_REASON_CD                 <- gp_reason_cd                 VARCHAR(134217728) -> VARCHAR(1) */
        LEFT(p.N__3, 1) AS GP_REASON_CD,
        /* LAST_TRAN_UPDT_NM            <- last_tran_updt_nm            VARCHAR(134217728) -> VARCHAR(8) */
        LEFT(p.N__4, 8) AS LAST_TRAN_UPDT_NM,
        /* LAST_UPDT_TS                 <- last_updt_ts                 TIMESTAMP_NTZ(6) -> TIMESTAMP_NTZ(6) */
        p."last_updt_ts" AS LAST_UPDT_TS,
        /* SUPRT_RENEW_RES_CD           <- suprt_renew_res_cd           VARCHAR(134217728) -> VARCHAR(2) */
        LEFT(p.N__5, 2) AS SUPRT_RENEW_RES_CD
    FROM (
        /* layer 1: trim; blanks kept as '' for string targets; blank -> NULL for numeric/date targets */
        SELECT
            src.*,
            REGEXP_REPLACE(src."bill_acct_nb", '^[[:space:]]+|[[:space:]]+$', '') AS N__1   /* bill_acct_nb -> BILL_ACCT_NB */,
            REGEXP_REPLACE(src."gp_agrmt_stat_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__2   /* gp_agrmt_stat_cd -> GP_AGRMT_STAT_CD */,
            REGEXP_REPLACE(src."gp_reason_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__3   /* gp_reason_cd -> GP_REASON_CD */,
            REGEXP_REPLACE(src."last_tran_updt_nm", '^[[:space:]]+|[[:space:]]+$', '') AS N__4   /* last_tran_updt_nm -> LAST_TRAN_UPDT_NM */,
            REGEXP_REPLACE(src."suprt_renew_res_cd", '^[[:space:]]+|[[:space:]]+$', '') AS N__5   /* suprt_renew_res_cd -> SUPRT_RENEW_RES_CD */
        FROM {{ source('BRONZE_CUST_CONF_BRONZE_MACSS', 'MCS_BA_GREEN_PWR') }} src   -- BRONZE_CUST_CONF."bronze_macss"."mcs_ba_green_pwr"
    ) p
) s
WHERE 1 = 1
    /* BILL_ACCT_NB */
    AND (s.BILL_ACCT_NB IS NOT NULL AND s.BILL_ACCT_NB <> '')   /* NULL or blank in a key column */
    /* GP_EFCT_DT */
    AND (s.GP_EFCT_DT IS NULL OR YEAR(s.GP_EFCT_DT) BETWEEN 1900 AND 9999)   /* date/timestamp outside the accepted year range */
    AND s.GP_EFCT_DT IS NOT NULL   /* NULL or blank in a key column */
    /* one row per key: a merge aborts with 100090 if the source
       hands it two rows for the same unique_key */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY s.BILL_ACCT_NB, s.GP_EFCT_DT
        ORDER BY s.LAST_UPDT_TS DESC NULLS LAST
    ) = 1
)

SELECT
    SRC.BILL_ACCT_NB,
    SRC.GP_EFCT_DT,
    SRC.GP_AGRMT_STAT_CD,
    SRC.GP_EXPR_DT,
    SRC.GP_MNTH_AGRMT_QY,
    SRC.SCHD_MTHY_KWH_QY,
    SRC.GP_KWH_USAG_PC,
    SRC.GP_REASON_CD,
    SRC.LAST_TRAN_UPDT_NM,
    SRC.LAST_UPDT_TS,
    SRC.SUPRT_RENEW_RES_CD,
    SRC.EDW_LAST_UPDT_TS
FROM ODS_MCS_BA_GREEN_PWR_SQ SRC

LEFT JOIN (
    /* the target is deduped too: a duplicate key already sitting in
       ODS would fan this join out and re-introduce duplicates */
    SELECT *
    FROM {{ source('UTLDB01_UTLUSER', 'ODS_MCS_BA_GREEN_PWR') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY BILL_ACCT_NB, GP_EFCT_DT
        ORDER BY EDW_LAST_UPDT_TS DESC NULLS LAST
    ) = 1
) TGT   ON  SRC.BILL_ACCT_NB = TGT.BILL_ACCT_NB
    AND SRC.GP_EFCT_DT = TGT.GP_EFCT_DT
WHERE
    TGT.BILL_ACCT_NB IS NULL   /* new row - no match in the target */
    OR (
        DECODE(SRC.GP_AGRMT_STAT_CD, TGT.GP_AGRMT_STAT_CD, 1, 0) = 0
        OR DECODE(SRC.GP_EXPR_DT, TGT.GP_EXPR_DT, 1, 0) = 0
        OR DECODE(SRC.GP_MNTH_AGRMT_QY, TGT.GP_MNTH_AGRMT_QY, 1, 0) = 0
        OR DECODE(SRC.SCHD_MTHY_KWH_QY, TGT.SCHD_MTHY_KWH_QY, 1, 0) = 0
        OR DECODE(SRC.GP_KWH_USAG_PC, TGT.GP_KWH_USAG_PC, 1, 0) = 0
        OR DECODE(SRC.GP_REASON_CD, TGT.GP_REASON_CD, 1, 0) = 0
        OR DECODE(SRC.LAST_TRAN_UPDT_NM, TGT.LAST_TRAN_UPDT_NM, 1, 0) = 0
        OR DECODE(SRC.LAST_UPDT_TS, TGT.LAST_UPDT_TS, 1, 0) = 0
        OR DECODE(SRC.SUPRT_RENEW_RES_CD, TGT.SUPRT_RENEW_RES_CD, 1, 0) = 0
    )
 