{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='CALLCTR_AGENT_D_ID',
    merge_update_columns=[
        'CC_ID',
        'EDW_LAST_UPDT_TS',
        'EDW_LAST_UPDT_NM',
        'AGENT_FIRST_NM',
        'AGENT_LAST_NM',
        'AGENT_PHONE_NB',
        'CALLCTR_AGENCY_D_ID',
        'IS_ACTIVE',
        'MD5_CHECKSUM_VAL'
    ],
    meta={
        "mapping_name": "m_CALLCTR_AGENT_D"
    },
    full_refresh=false,
    pre_hook=[
        log_model_start(this, 'DP_CXN1005C_CALLCTR_AGENT_D')
    ],
    post_hook=[
        log_model_end(this, 'DP_CXN1005C_CALLCTR_AGENT_D')
    ]
) }}

WITH TARGET_MAX_KEY AS
(
    {% if is_incremental() %}

    SELECT
        COALESCE(MAX(CALLCTR_AGENT_D_ID), 0)::NUMBER(38,0)
            AS MAX_CALLCTR_AGENT_D_ID
    FROM {{ source('UTLDB01_CDWADM','CALLCTR_AGENT_D') }}

    {% else %}

    SELECT
        0::NUMBER(38,0) AS MAX_CALLCTR_AGENT_D_ID

    {% endif %}
),

VA_USERS_RESOURCE_UNION AS
(
    SELECT
        USERID,
        CC_ID,
        FIRSTNAME,
        LASTNAME,
        SUPERVISOR_ID,
        TO_VARCHAR(TRY_TO_NUMBER(TO_VARCHAR(IS_ACTIVE))) AS IS_ACTIVE,
        PHONE
    FROM {{ source('UTLDB01_CXNADM', 'VA_USERS_STG') }}

    UNION

    SELECT
        RES.USERID,
        COALESCE(TO_VARCHAR(VUS.CC_ID), '-999') AS CC_ID,
        RES.FIRSTNAME,
        RES.LASTNAME,
        COALESCE(TO_VARCHAR(VUS.SUPERVISOR_ID), '_')
            AS SUPERVISOR_ID,
        COALESCE(TO_VARCHAR(TRY_TO_NUMBER(TO_VARCHAR(VUS.IS_ACTIVE))), '-999')
            AS IS_ACTIVE,
        COALESCE(TO_VARCHAR(VUS.PHONE), 'DEFAULT')
            AS PHONE
    FROM
    (
        SELECT
            USERID,
            FIRSTNAME,
            LASTNAME
        FROM
        (
            SELECT
                EMPLOYEE_ID AS USERID,
                AGENT_FIRST_NAME AS FIRSTNAME,
                AGENT_LAST_NAME AS LASTNAME,
                RANK() OVER
                (
                    PARTITION BY EMPLOYEE_ID
                    ORDER BY GMT_END_TIME DESC
                ) AS LATEST
            FROM {{ source('UTLDB01_CUSADM', 'RESOURCE_') }}
            WHERE UPPER(RESOURCE_TYPE) = UPPER('AGENT')
        ) RESOURCE_RANKED
        WHERE LATEST = 1
    ) RES
    LEFT JOIN {{ source('UTLDB01_CXNADM', 'VA_USERS_STG') }} VUS
        ON VUS.USERID = RES.USERID
    WHERE VUS.USERID IS NULL
),

SOURCE_WITH_AGENCY AS
(
    SELECT
        VAU.USERID,
        VAU.CC_ID,
        VAU.FIRSTNAME,
        VAU.LASTNAME,
        VAU.SUPERVISOR_ID,
        VAU.IS_ACTIVE,
        VAU.PHONE,
        CAD.CALLCTR_AGENCY_D_ID
    FROM VA_USERS_RESOURCE_UNION VAU
    LEFT JOIN {{ source('UTLDB01_CDWADM', 'CALLCTR_AGENCY_D') }} CAD
        ON CAD.CALLCTR_CD = VAU.CC_ID
),

SQ_VA_USERS_STG AS
(
    SELECT
        SRC.USERID,
        SRC.CC_ID,
        SRC.FIRSTNAME,
        SRC.LASTNAME,
        SRC.SUPERVISOR_ID,
        SRC.IS_ACTIVE,
        SRC.PHONE,
        SRC.CALLCTR_AGENCY_D_ID,

        {% if is_incremental() %}

        CA.CALLCTR_AGENT_D_ID,
        CA.EDW_CRTE_TS AS EXISTING_EDW_CRTE_TS,
        CA.EDW_CRTE_NM AS EXISTING_EDW_CRTE_NM,
        CA.SUPERVISOR_ID AS EXISTING_SUPERVISOR_ID,
        CA.AGENT_PHONE_EXTENSION_NB
            AS EXISTING_AGENT_PHONE_EXTENSION_NB,
        CA.MD5_CHECKSUM_VAL,

        {% else %}

        NULL::NUMBER(38,0) AS CALLCTR_AGENT_D_ID,
        NULL::TIMESTAMP_NTZ(9) AS EXISTING_EDW_CRTE_TS,
        NULL::VARCHAR(50) AS EXISTING_EDW_CRTE_NM,
        NULL::VARCHAR(50) AS EXISTING_SUPERVISOR_ID,
        NULL::VARCHAR(50) AS EXISTING_AGENT_PHONE_EXTENSION_NB,
        NULL::VARCHAR(32) AS MD5_CHECKSUM_VAL,

        {% endif %}

        {% if is_incremental() %}

        CA.AGENT_USER_ID AS EXISTING_AGENT_USER_ID,
        CA.CC_ID AS EXISTING_CC_ID

        {% else %}

        NULL::VARCHAR(255) AS EXISTING_AGENT_USER_ID,
        NULL::VARCHAR(10) AS EXISTING_CC_ID

        {% endif %}

    FROM SOURCE_WITH_AGENCY SRC

    {% if is_incremental() %}

    LEFT JOIN {{ source('UTLDB01_CDWADM','CALLCTR_AGENT_D') }} CA
        ON SRC.USERID = CA.AGENT_USER_ID
       AND SRC.CC_ID = CA.CC_ID

    {% endif %}
),

EXP_AUDIT_FIELDS AS
(
    SELECT
        USERID,
        CC_ID,
        FIRSTNAME,
        LASTNAME,
        SUPERVISOR_ID,
        IS_ACTIVE,
        PHONE,
        CALLCTR_AGENCY_D_ID,
        CALLCTR_AGENT_D_ID,
        EXISTING_EDW_CRTE_TS,
        EXISTING_EDW_CRTE_NM,
        EXISTING_SUPERVISOR_ID,
        EXISTING_AGENT_PHONE_EXTENSION_NB,
        EXISTING_AGENT_USER_ID,
        EXISTING_CC_ID,
        MD5_CHECKSUM_VAL,
        's_m_CALLCTR_AGENT_D'::VARCHAR(50)
            AS O_EDW_CREATE_NM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS O_EDW_CREATE_TS,
        's_m_CALLCTR_AGENT_D'::VARCHAR(50)
            AS O_EDW_UPDT_NM,
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ(9)
            AS O_EDW_UPDT_TS,
        MD5
        (
            COALESCE(FIRSTNAME, '')
            || COALESCE(LASTNAME, '')
            || COALESCE(SUPERVISOR_ID, '')
            || COALESCE(TO_VARCHAR(IS_ACTIVE), '')
            || COALESCE(PHONE, '')
            || COALESCE(TO_VARCHAR(CALLCTR_AGENCY_D_ID), '')
        )::VARCHAR(32) AS O_MD5_CHECKSUM_VAL
    FROM SQ_VA_USERS_STG
),

RTR_FLAG_RECORDS AS
(
    SELECT
        USERID,
        CC_ID,
        FIRSTNAME,
        LASTNAME,
        SUPERVISOR_ID,
        IS_ACTIVE,
        PHONE,
        CALLCTR_AGENCY_D_ID,
        CALLCTR_AGENT_D_ID,
        EXISTING_EDW_CRTE_TS,
        EXISTING_EDW_CRTE_NM,
        EXISTING_SUPERVISOR_ID,
        EXISTING_AGENT_PHONE_EXTENSION_NB,
        EXISTING_AGENT_USER_ID,
        EXISTING_CC_ID,
        MD5_CHECKSUM_VAL,
        O_EDW_CREATE_NM,
        O_EDW_CREATE_TS,
        O_EDW_UPDT_NM,
        O_EDW_UPDT_TS,
        O_MD5_CHECKSUM_VAL,
        CASE
            WHEN CALLCTR_AGENT_D_ID IS NULL
                THEN 'INSERT'
            WHEN CALLCTR_AGENT_D_ID IS NOT NULL
             AND MD5_CHECKSUM_VAL <> O_MD5_CHECKSUM_VAL
                THEN 'UPDATE'
            ELSE 'DEFAULT'
        END AS ROUTER_GROUP
    FROM EXP_AUDIT_FIELDS
),

CHANGED_RECORDS AS
(
    SELECT
        USERID,
        CC_ID,
        FIRSTNAME,
        LASTNAME,
        SUPERVISOR_ID,
        IS_ACTIVE,
        PHONE,
        CALLCTR_AGENCY_D_ID,
        CALLCTR_AGENT_D_ID,
        EXISTING_EDW_CRTE_TS,
        EXISTING_EDW_CRTE_NM,
        EXISTING_SUPERVISOR_ID,
        EXISTING_AGENT_PHONE_EXTENSION_NB,
        EXISTING_AGENT_USER_ID,
        EXISTING_CC_ID,
        O_EDW_CREATE_NM,
        O_EDW_CREATE_TS,
        O_EDW_UPDT_NM,
        O_EDW_UPDT_TS,
        O_MD5_CHECKSUM_VAL,
        ROUTER_GROUP,
        CASE
            WHEN ROUTER_GROUP = 'INSERT'
                THEN ROW_NUMBER() OVER
                (
                    PARTITION BY ROUTER_GROUP
                    ORDER BY USERID, CC_ID
                )
        END AS INSERT_ROW_NUMBER
    FROM RTR_FLAG_RECORDS
    WHERE ROUTER_GROUP IN ('INSERT', 'UPDATE')
),

SOURCE_ROWS AS
(
    SELECT
        CASE
            WHEN CR.ROUTER_GROUP = 'INSERT'
                THEN TMK.MAX_CALLCTR_AGENT_D_ID
                   + CR.INSERT_ROW_NUMBER
            ELSE CR.CALLCTR_AGENT_D_ID
        END::NUMBER(38,0) AS CALLCTR_AGENT_D_ID,

        CR.USERID::VARCHAR(255) AS AGENT_USER_ID,

        CR.CC_ID::VARCHAR(10) AS CC_ID,

        CASE
            WHEN CR.ROUTER_GROUP = 'INSERT'
                THEN CR.O_EDW_CREATE_TS
            ELSE CR.EXISTING_EDW_CRTE_TS
        END::TIMESTAMP_NTZ(9) AS EDW_CRTE_TS,

        CASE
            WHEN CR.ROUTER_GROUP = 'INSERT'
                THEN CR.O_EDW_CREATE_NM
            ELSE CR.EXISTING_EDW_CRTE_NM
        END::VARCHAR(50) AS EDW_CRTE_NM,

        CR.O_EDW_UPDT_TS::TIMESTAMP_NTZ(9)
            AS EDW_LAST_UPDT_TS,

        CR.O_EDW_UPDT_NM::VARCHAR(50)
            AS EDW_LAST_UPDT_NM,

        CR.FIRSTNAME::VARCHAR(100)
            AS AGENT_FIRST_NM,

        CR.LASTNAME::VARCHAR(100)
            AS AGENT_LAST_NM,

        CASE
            WHEN CR.ROUTER_GROUP = 'INSERT'
                THEN CR.SUPERVISOR_ID
            ELSE CR.EXISTING_SUPERVISOR_ID
        END::VARCHAR(50) AS SUPERVISOR_ID,

        CR.PHONE::VARCHAR(50)
            AS AGENT_PHONE_NB,

        CR.EXISTING_AGENT_PHONE_EXTENSION_NB::VARCHAR(50)
            AS AGENT_PHONE_EXTENSION_NB,

        CR.CALLCTR_AGENCY_D_ID::NUMBER(38,0)
            AS CALLCTR_AGENCY_D_ID,

        CR.IS_ACTIVE::VARCHAR(4)
            AS IS_ACTIVE,

        CR.O_MD5_CHECKSUM_VAL::VARCHAR(32)
            AS MD5_CHECKSUM_VAL

    FROM CHANGED_RECORDS CR
    CROSS JOIN TARGET_MAX_KEY TMK
)

SELECT
    CALLCTR_AGENT_D_ID,
    AGENT_USER_ID,
    CC_ID,
    EDW_CRTE_TS,
    EDW_CRTE_NM,
    EDW_LAST_UPDT_TS,
    EDW_LAST_UPDT_NM,
    AGENT_FIRST_NM,
    AGENT_LAST_NM,
    SUPERVISOR_ID,
    AGENT_PHONE_NB,
    AGENT_PHONE_EXTENSION_NB,
    CALLCTR_AGENCY_D_ID,
    IS_ACTIVE,
    MD5_CHECKSUM_VAL
FROM SOURCE_ROWS

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY CALLCTR_AGENT_D_ID
    ORDER BY MD5_CHECKSUM_VAL
) = 1