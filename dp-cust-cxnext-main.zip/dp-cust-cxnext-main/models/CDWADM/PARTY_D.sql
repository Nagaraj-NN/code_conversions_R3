{{ config(
    materialized='view',
    alias='PARTY_D_VW',
    meta={"mapping_name": "m_PARTY_D"},
    pre_hook=[
        open_control_window(this, 'DP_CXN1003C_PARTY_D'),
        log_model_start(this, 'DP_CXN1003C_PARTY_D')
    ],
    post_hook=[
        "MERGE INTO {{ source('UTLDB01_CDWADM','PARTY_D') }} AS TGT
     USING {{ this }} AS SRC
     ON TGT.PARTY_D_ID = SRC.PARTY_D_ID
     WHEN MATCHED AND SRC.TARGET_OPERATION = 'U' THEN
         UPDATE SET
             TGT.EDW_LAST_UPDT_TS = SRC.OUT_EDW_LAST_UPDT_TS,
             TGT.EDW_LAST_UPDT_NM = SRC.OUT_EDW_LAST_UPDT_NM,
             TGT.PREFIX_NM = SRC.PREFIX_NM,
             TGT.FIRST_NM = SRC.FIRST_NM,
             TGT.MIDDLE_NM = SRC.MIDDLE_NM,
             TGT.LAST_NM = SRC.LAST_NM,
             TGT.SUFFIX_NM = SRC.SUFFIX_NM,
             TGT.ACTIVE_FLAG = SRC.OUT_ACTIVE_FLAG
     WHEN NOT MATCHED AND SRC.TARGET_OPERATION = 'I' THEN
         INSERT
         (
             PARTY_D_ID,
             PARTY_ID,
             PARTY_SOURCE_CD,
             PARTY_TYPE_CD,
             EDW_CRTE_TS,
             EDW_CRTE_NM,
             EDW_LAST_UPDT_TS,
             EDW_LAST_UPDT_NM,
             PREFIX_NM,
             FIRST_NM,
             MIDDLE_NM,
             LAST_NM,
             SUFFIX_NM,
             ACTIVE_FLAG
         )
         VALUES
         (
             SRC.PARTY_D_ID,
             SRC.PARTY_ID,
             SRC.PARTY_SOURCE,
             SRC.PARTY_TYPE_CD,
             SRC.OUT_EDW_CRTE_TS,
             SRC.OUT_EDW_CRTE_NM,
             SRC.OUT_EDW_LAST_UPDT_TS,
             SRC.OUT_EDW_LAST_UPDT_NM,
             SRC.PREFIX_NM,
             SRC.FIRST_NM,
             SRC.MIDDLE_NM,
             SRC.LAST_NM,
             SRC.SUFFIX_NM,
             SRC.OUT_ACTIVE_FLAG
         )",
         update_control_table(this, 'DP_CXN1003C_PARTY_D'),
        log_model_end(this, 'DP_CXN1003C_PARTY_D')
    ]
) }}

WITH 
JOB_CONTROL AS (
    SELECT JOB_ID, START_DATE, END_DATE FROM {{source('UTLDB01_METADATA','CXNADM_JOB_CONTROL')}}
    WHERE JOB_NAME= 'PARTY_D' AND AUTOSYS_JOB_NAME = 'DP_CXN1003C_PARTY_D'),
 P1_SOURCE AS (
    SELECT
        CUST.CUST_PRFX_1_NM AS PREFIX_NM,
        CUST.CUST_SFFX_1_NM AS SUFFIX_NM,
        CUST.CUST_1ST_1_NM AS FIRST_NM,
        CUST.CUST_LAST_1_NM AS LAST_NM,
        CUST.CUST_MDDL_1_NM AS MIDDLE_NM,
        CUST.CUST_NB AS PARTY_ID,
        'M' AS PARTY_SOURCE,
        'P1' AS PARTY_TYPE_CD
    FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_CUSTOMER') }} AS CUST
    WHERE CUST.EDW_LAST_UPDT_TS > (select start_Date from job_control)
      AND CUST.EDW_LAST_UPDT_TS <= (SELECT END_dATE FROM JOB_CONTROL )
),
P2_SOURCE AS (
    SELECT
        CUST_2.CUST_PRFX_2_NM AS PREFIX_NM,
        CUST_2.CUST_SFFX_2_NM AS SUFFIX_NM,
        CUST_2.CUST_1ST_2_NM AS FIRST_NM,
        CUST_2.CUST_LAST_2_NM AS LAST_NM,
        CUST_2.CUST_MDDL_2_NM AS MIDDLE_NM,
        CUST_2.CUST_NB AS PARTY_ID,
        'M' AS PARTY_SOURCE,
        'P2' AS PARTY_TYPE_CD
    FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_CUSTOMER') }} AS CUST_2
    WHERE CUST_2.EDW_LAST_UPDT_TS > (select start_Date from job_control)
      AND CUST_2.EDW_LAST_UPDT_TS <= (SELECT END_dATE FROM JOB_CONTROL )
      AND TRIM(CUST_2.CUST_LAST_2_NM) IS NOT NULL
),
W1_RANKED AS (
    SELECT
        WUSER.WEB_PREFIX_NM AS PREFIX_NM,
        '' AS SUFFIX_NM,
        WUSER.WEB_FIRST_NM AS FIRST_NM,
        WUSER.WEB_LAST_NM AS LAST_NM,
        '' AS MIDDLE_NM,
        WEB.CUST_NB AS PARTY_ID,
        'M' AS PARTY_SOURCE,
        'W1' AS PARTY_TYPE_CD,
        RANK() OVER (
            PARTITION BY WEB.CUST_NB
            ORDER BY WUSER.CRTN_TS DESC
        ) AS RNK
    FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_WEB_BILL_ACCT') }} AS WEB
    INNER JOIN {{ source('UTLDB01_UTLUSER','ODS_MCS_WEB_USER') }} AS WUSER
        ON WEB.WEB_ID = WUSER.WEB_ID
    WHERE WEB.CUST_NB NOT IN (
        SELECT DISTINCT MCS_CUSTOMER.CUST_NB
        FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_CUSTOMER') }} AS MCS_CUSTOMER
        WHERE TRIM(MCS_CUSTOMER.CUST_1ST_2_NM) IS NOT NULL
    )
      AND TRIM(WUSER.WEB_LAST_NM) IS NOT NULL
      AND (
            (
                WUSER.EDW_LAST_UPDT_TS > (select start_Date from job_control)
                AND WUSER.EDW_LAST_UPDT_TS <= (SELECT END_dATE FROM JOB_CONTROL )
            )
            OR
            (
                WEB.EDW_LAST_UPDT_TS >(select start_Date from job_control)
                AND WEB.EDW_LAST_UPDT_TS <= (SELECT END_dATE FROM JOB_CONTROL )
            )
      )
),
W1_SOURCE AS (
    SELECT DISTINCT
        W1_RANKED.PREFIX_NM,
        W1_RANKED.SUFFIX_NM,
        W1_RANKED.FIRST_NM,
        W1_RANKED.LAST_NM,
        W1_RANKED.MIDDLE_NM,
        W1_RANKED.PARTY_ID,
        W1_RANKED.PARTY_SOURCE,
        W1_RANKED.PARTY_TYPE_CD
    FROM W1_RANKED
    WHERE W1_RANKED.RNK = 1
),
SRC AS (
    SELECT * FROM P1_SOURCE
    UNION
    SELECT * FROM P2_SOURCE
    UNION
    SELECT * FROM W1_SOURCE
),
SQ_MCS_CUSTOMER AS (
    SELECT
        SRC.PREFIX_NM,
        SRC.SUFFIX_NM,
        SRC.FIRST_NM,
        SRC.LAST_NM,
        SRC.MIDDLE_NM,
        SRC.PARTY_ID,
        SRC.PARTY_SOURCE,
        SRC.PARTY_TYPE_CD,
        TGT.PARTY_D_ID
    FROM SRC
    LEFT OUTER JOIN {{ source('UTLDB01_CDWADM','PARTY_D') }} AS TGT
        ON SRC.PARTY_ID = TGT.PARTY_ID
       AND SRC.PARTY_SOURCE = TGT.PARTY_SOURCE_CD
       AND SRC.PARTY_TYPE_CD = TGT.PARTY_TYPE_CD
),
EXP_AUDIT_PARTY_D AS (
    SELECT
        SQ_MCS_CUSTOMER.PREFIX_NM,
        SQ_MCS_CUSTOMER.SUFFIX_NM,
        SQ_MCS_CUSTOMER.FIRST_NM,
        SQ_MCS_CUSTOMER.LAST_NM,
        SQ_MCS_CUSTOMER.MIDDLE_NM,
        SQ_MCS_CUSTOMER.PARTY_ID,
        SQ_MCS_CUSTOMER.PARTY_SOURCE,
        SQ_MCS_CUSTOMER.PARTY_TYPE_CD,
        SQ_MCS_CUSTOMER.PARTY_D_ID,
        CURRENT_TIMESTAMP() AS OUT_EDW_CRTE_TS,
        's_m_PARTY_D' AS OUT_EDW_CRTE_NM,
        CURRENT_TIMESTAMP() AS OUT_EDW_LAST_UPDT_TS,
        's_m_PARTY_D' AS OUT_EDW_LAST_UPDT_NM,
        'Y' AS OUT_ACTIVE_FLAG
    FROM SQ_MCS_CUSTOMER
),
PARTY_D_KEY AS (
    SELECT COALESCE(MAX(PARTY_D.PARTY_D_ID), 0) AS MAX_PARTY_D_ID
    FROM {{ source('UTLDB01_CDWADM','PARTY_D') }} AS PARTY_D
),

FINAL_ROWS AS (

SELECT
    COALESCE(
        E.PARTY_D_ID,
        PARTY_D_KEY.MAX_PARTY_D_ID + ROW_NUMBER() OVER (
            PARTITION BY CASE WHEN E.PARTY_D_ID IS NULL THEN 1 ELSE 0 END
            ORDER BY
                E.PARTY_ID,
                E.PARTY_SOURCE,
                E.PARTY_TYPE_CD
        )
    ) AS PARTY_D_ID,
    IFF(E.PARTY_D_ID IS NOT NULL, 'U', 'I') AS TARGET_OPERATION,
    E.PREFIX_NM,
    E.SUFFIX_NM,
    E.FIRST_NM,
    E.LAST_NM,
    E.MIDDLE_NM,
    E.PARTY_ID,
    E.PARTY_SOURCE,
    E.PARTY_TYPE_CD,
    E.OUT_EDW_CRTE_TS,
    E.OUT_EDW_CRTE_NM,
    E.OUT_EDW_LAST_UPDT_TS,
    E.OUT_EDW_LAST_UPDT_NM,
    E.OUT_ACTIVE_FLAG

FROM
    EXP_AUDIT_PARTY_D E
    CROSS JOIN PARTY_D_KEY

)

SELECT *
FROM FINAL_ROWS

/* one row per merge key: the post-hook MERGE matches on PARTY_D_ID, and two
   source rows resolving to the same id abort it with 100090. Ties out of the
   W1 RANK() share a natural key, so on the update path they resolve to the
   same existing PARTY_D_ID. Rows being inserted are untouched - ROW_NUMBER
   already gave them distinct ids, so both tied rows still insert, matching
   the mapping. */
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY PARTY_D_ID
    ORDER BY LAST_NM, FIRST_NM, MIDDLE_NM, PREFIX_NM, SUFFIX_NM
) = 1