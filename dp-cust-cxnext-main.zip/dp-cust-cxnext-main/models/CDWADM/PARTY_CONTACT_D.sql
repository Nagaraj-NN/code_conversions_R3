{{ config(
    materialized='view',
    alias='PARTY_CONTACT_D_VW',
    meta={"mapping_name": "m_PARTY_CONTACT_D"},
    pre_hook=[
        log_model_start(this, 'DP_CXN1003C_PARTY_CONTACT_D')
    ],
    post_hook=[
        "MERGE INTO {{ source('UTLDB01_CDWADM','PARTY_CONTACT_D') }} AS PARTY_CONTACT_D
     USING {{ this }} AS SOURCE_ROWS
     ON PARTY_CONTACT_D.PARTY_CONTACT_D_ID = SOURCE_ROWS.PARTY_CONTACT_D_ID
     WHEN MATCHED AND SOURCE_ROWS.TARGET_OPERATION = 'U' THEN
         UPDATE SET
             PARTY_CONTACT_D.TERM_TS = SOURCE_ROWS.TERM_TS,
             PARTY_CONTACT_D.EDW_LAST_UPDT_TS = SOURCE_ROWS.EDW_LAST_UPDT_TS,
             PARTY_CONTACT_D.EDW_LAST_UPDT_NM = SOURCE_ROWS.EDW_LAST_UPDT_NM,
             PARTY_CONTACT_D.ACTIVE_FLAG = SOURCE_ROWS.ACTIVE_FLAG
     WHEN NOT MATCHED AND SOURCE_ROWS.TARGET_OPERATION = 'I' THEN
         INSERT
         (
             PARTY_CONTACT_D_ID,
             PARTY_D_ID,
             BILL_ACCOUNT_NB,
             CUST_NBR,
             ADDR_ID_AD,
             CO_CD_OWNR,
             EFFECTIVE_TS,
             TERM_TS,
             EDW_CRTE_TS,
             EDW_CRTE_NM,
             EDW_LAST_UPDT_TS,
             EDW_LAST_UPDT_NM,
             HOME_PHONE_NB,
             MOBILE_PHONE_NB,
             EMAIL,
             WEB_USER_NM,
             MAILL_1_AD,
             MAILL_2_AD,
             MAILING_ADDRESS_CITY_NM,
             MAILING_ADDRESS_STATE_CD,
             MAILING_ADDRESS_ZIP,
             MD5_CHECKSUM_VAL,
             ACTIVE_FLAG
         )
         VALUES
         (
             SOURCE_ROWS.PARTY_CONTACT_D_ID,
             SOURCE_ROWS.PARTY_D_ID,
             SOURCE_ROWS.BILL_ACCOUNT_NB,
             SOURCE_ROWS.CUST_NBR,
             SOURCE_ROWS.ADDR_ID_AD,
             SOURCE_ROWS.CO_CD_OWNR,
             SOURCE_ROWS.EFFECTIVE_TS,
             SOURCE_ROWS.TERM_TS,
             SOURCE_ROWS.EDW_CRTE_TS,
             SOURCE_ROWS.EDW_CRTE_NM,
             SOURCE_ROWS.EDW_LAST_UPDT_TS,
             SOURCE_ROWS.EDW_LAST_UPDT_NM,
             SOURCE_ROWS.HOME_PHONE_NB,
             SOURCE_ROWS.MOBILE_PHONE_NB,
             SOURCE_ROWS.EMAIL,
             SOURCE_ROWS.WEB_USER_NM,
             SOURCE_ROWS.MAILL_1_AD,
             SOURCE_ROWS.MAILL_2_AD,
             SOURCE_ROWS.MAILING_ADDRESS_CITY_NM,
             SOURCE_ROWS.MAILING_ADDRESS_STATE_CD,
             SOURCE_ROWS.MAILING_ADDRESS_ZIP,
             SOURCE_ROWS.MD5_CHECKSUM_VAL,
             SOURCE_ROWS.ACTIVE_FLAG
         )",
        log_model_end(this, 'DP_CXN1003C_PARTY_CONTACT_D')
    ]
) }}

WITH SQ_PARTY_CONTACT_D AS
    (
        SELECT
            TGT.PARTY_CONTACT_D_ID AS TGT_PARTY_CONTACT_D_ID,
            STG.PARTY_D_ID AS PARTY_D_ID,
            STG.BILL_ACCOUNT_NB AS BILL_ACCOUNT_NB,
            STG.CUST_NBR AS CUST_NBR,
            STG.ADDR_ID_AD AS ADDR_ID_AD,
            STG.CO_CD_OWNR AS CO_CD_OWNR,
            STG.HOME_PHONE_NB AS HOME_PHONE_NB,
            STG.MOBILE_PHONE_NB AS MOBILE_PHONE_NB,
            STG.EMAIL AS EMAIL,
            STG.WEB_USER_NM AS WEB_USER_NM,
            STG.MAILL_1_AD AS MAILL_1_AD,
            STG.MAILL_2_AD AS MAILL_2_AD,
            STG.MAILING_ADDRESS_CITY_NM AS MAILING_ADDRESS_CITY_NM,
            STG.MAILING_ADDRESS_STATE_CD AS MAILING_ADDRESS_STATE_CD,
            STG.MAILING_ADDRESS_ZIP AS MAILING_ADDRESS_ZIP,
            STG.MD5_CHECKSUM_VAL AS MD5_CHECKSUM_VAL,
            TGT.MD5_CHECKSUM_VAL AS TGT_MD5_CHECKSUM_VAL
        FROM
        (
            SELECT
                PARTY_D_ID,
                CUST_NB AS CUST_NBR,
                EMAIL,
                ADDR_ID_AD,
                CO_CD_OWNR,
                HOME_PHONE_NB,
                MOBILE_PHONE_NB,
                WEB_USER_NM,
                MAILL_1_AD,
                MAILL_2_AD,
                MAILING_ADDRESS_CITY_NM,
                MAILING_ADDRESS_STATE_CD,
                MAILING_ADDRESS_ZIP,
                BILL_ACCOUNT_NB,
                MD5(
                    COALESCE(TO_VARCHAR(HOME_PHONE_NB), '') || '~' ||
                    COALESCE(TO_VARCHAR(MOBILE_PHONE_NB), '') || '~' ||
                    COALESCE(EMAIL, '') || '~' ||
                    COALESCE(WEB_USER_NM, '') || '~' ||
                    COALESCE(MAILL_1_AD, '') || '~' ||
                    COALESCE(MAILL_2_AD, '') || '~' ||
                    COALESCE(MAILING_ADDRESS_CITY_NM, '') || '~' ||
                    COALESCE(MAILING_ADDRESS_STATE_CD, '') || '~' ||
                    COALESCE(MAILING_ADDRESS_ZIP, '')
                ) AS MD5_CHECKSUM_VAL
            FROM
            (
                SELECT DISTINCT
                    BA.PARTY_D_ID,
                    BA.CUST_NB,
                    EM.P_EMAIL AS EMAIL,
                    BA.ADDR_ID_AD,
                    BA.CO_CD_OWNR,
                    IDD.TLPH_1_NB AS HOME_PHONE_NB,
                    IDD.TLPH_2_NB AS MOBILE_PHONE_NB,
                    EM.WEB_FIRST_NM || ' ' || EM.WEB_LAST_NM AS WEB_USER_NM,
                    CASE
                        WHEN BA.ADDR_ID_AD IS NOT NULL THEN AD.MAIL_1_AD
                        ELSE IDD.SERV_HOUS_NBR_AD || ' ' || IDD.SERV_PRDR_AD || ' ' || IDD.SERV_ST_NAME_AD || ' ' || IDD.SERV_ST_DSGT_AD || ' ' || IDD.SERV_PTDR_AD
                    END AS MAILL_1_AD,
                    CASE
                        WHEN BA.ADDR_ID_AD IS NOT NULL THEN AD.MAIL_2_AD
                        ELSE IDD.SERV_UNIT_DSGT_AD || ' ' || IDD.SERV_UNIT_NBR_AD || ' ' || IDD.SER_HALF_IND_AD
                    END AS MAILL_2_AD,
                    CASE
                        WHEN BA.ADDR_ID_AD IS NOT NULL THEN AD.MAIL_CITY_AD
                        ELSE IDD.SERV_CITY_AD
                    END AS MAILING_ADDRESS_CITY_NM,
                    CASE
                        WHEN BA.ADDR_ID_AD IS NOT NULL THEN AD.STATE_CD_AD
                        ELSE IDD.STATE_CD
                    END AS MAILING_ADDRESS_STATE_CD,
                    CASE
                        WHEN BA.ADDR_ID_AD IS NOT NULL THEN AD.MAIL_ZIP_AD
                        ELSE IDD.SERV_ZIP_AD
                    END AS MAILING_ADDRESS_ZIP,
                    A_D.BILL_ACCOUNT_NB
                FROM
                (
                    SELECT BILL_ACCOUNT_NB
                    FROM {{ source('UTLDB01_CDWADM','ACCOUNT_D') }}
                    WHERE (
BILL_ACCOUNT_NB BETWEEN '0100000000' AND '0299999999'
                       OR BILL_ACCOUNT_NB BETWEEN '0300000000' AND '0499999999'
                       OR BILL_ACCOUNT_NB BETWEEN '0600000000' AND '0699999999'
                       OR BILL_ACCOUNT_NB BETWEEN '0700000000' AND '0799999999'
                       OR BILL_ACCOUNT_NB BETWEEN '1000000000' AND '1099999999'
                       OR BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9599999999'
                       OR BILL_ACCOUNT_NB BETWEEN '9600000000' AND '9799999999'
                    )
                      AND ACTIVE_FLAG = 'Y'
                      AND CONTRACT_SRVC_STAT_CD IN ('A', 'N', 'D')
                    GROUP BY BILL_ACCOUNT_NB
                ) A_D
                LEFT OUTER JOIN
                (
                    SELECT DISTINCT
                        ACCT.ADDR_ID_AD,
                        ACCT.CUST_NB,
                        ACCT.CO_CD_OWNR,
                        ACCT.BILL_ACCT_NB,
                        PARTY.PARTY_D_ID
                    FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_BILL_ACCOUNT') }} ACCT
                    CROSS JOIN
                    (
                        SELECT PARTY_D_ID, PARTY_ID
                        FROM {{ source('UTLDB01_CDWADM','PARTY_D') }}
                        WHERE PARTY_TYPE_CD IN ('P1', 'W')
                        GROUP BY PARTY_D_ID, PARTY_ID
                    ) PARTY
                    WHERE (
ACCT.BILL_ACCT_NB BETWEEN '0100000000' AND '0299999999'
                          OR ACCT.BILL_ACCT_NB BETWEEN '0300000000' AND '0499999999'
                          OR ACCT.BILL_ACCT_NB BETWEEN '0600000000' AND '0699999999'
                          OR ACCT.BILL_ACCT_NB BETWEEN '0700000000' AND '0799999999'
                          OR ACCT.BILL_ACCT_NB BETWEEN '1000000000' AND '1099999999'
                          OR ACCT.BILL_ACCT_NB BETWEEN '9400000000' AND '9599999999'
                          OR ACCT.BILL_ACCT_NB BETWEEN '9600000000' AND '9799999999'
                    )
                      AND ACCT.CUST_NB = PARTY.PARTY_ID
                ) BA
                    ON BA.BILL_ACCT_NB = A_D.BILL_ACCOUNT_NB
                LEFT OUTER JOIN
                (
                    SELECT
                        ADDR_ID_AD,
                        CO_CD_OWNR,
                        MAIL_1_AD,
                        MAIL_2_AD,
                        MAIL_CITY_AD,
                        STATE_CD_AD,
                        MAIL_ZIP_AD,
                        EDW_LAST_UPDT_TS
                    FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_ADDRESS') }}
                    GROUP BY
                        ADDR_ID_AD,
                        CO_CD_OWNR,
                        MAIL_1_AD,
                        MAIL_2_AD,
                        MAIL_CITY_AD,
                        STATE_CD_AD,
                        MAIL_ZIP_AD,
                        EDW_LAST_UPDT_TS
                ) AD
                    ON AD.ADDR_ID_AD = BA.ADDR_ID_AD
                   AND AD.CO_CD_OWNR = BA.CO_CD_OWNR
                INNER JOIN
                (
                    SELECT
                        BILL_ACCT_NB,
                        CUST_NB,
                        NAME_IDNT_CD,
                        ACCT_CLAS_CD,
                        ACCT_STAT_CD,
                        TLPH_1_NB,
                        TLPH_2_NB,
                        SERV_HOUS_NBR_AD,
                        SERV_PRDR_AD,
                        SERV_ST_NAME_AD,
                        SERV_ST_DSGT_AD,
                        SERV_PTDR_AD,
                        SERV_UNIT_DSGT_AD,
                        SERV_UNIT_NBR_AD,
                        SER_HALF_IND_AD,
                        SERV_CITY_AD,
                        STATE_CD,
                        SERV_ZIP_AD,
                        EDW_LAST_UPDT_TS
                    FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_INDICATIV_DATA') }}
                    WHERE (
BILL_ACCT_NB BETWEEN '0100000000' AND '0299999999'
                       OR BILL_ACCT_NB BETWEEN '0300000000' AND '0499999999'
                       OR BILL_ACCT_NB BETWEEN '0600000000' AND '0699999999'
                       OR BILL_ACCT_NB BETWEEN '0700000000' AND '0799999999'
                       OR BILL_ACCT_NB BETWEEN '1000000000' AND '1099999999'
                       OR BILL_ACCT_NB BETWEEN '9400000000' AND '9599999999'
                       OR BILL_ACCT_NB BETWEEN '9600000000' AND '9799999999'
                    )
                      AND NAME_IDNT_CD = 'P'
                      AND ACCT_CLAS_CD = 'R'
                      AND ACCT_STAT_CD IN ('A', 'D', 'N')
                    GROUP BY
                        BILL_ACCT_NB,
                        CUST_NB,
                        NAME_IDNT_CD,
                        ACCT_CLAS_CD,
                        ACCT_STAT_CD,
                        TLPH_1_NB,
                        TLPH_2_NB,
                        SERV_HOUS_NBR_AD,
                        SERV_PRDR_AD,
                        SERV_ST_NAME_AD,
                        SERV_ST_DSGT_AD,
                        SERV_PTDR_AD,
                        SERV_UNIT_DSGT_AD,
                        SERV_UNIT_NBR_AD,
                        SER_HALF_IND_AD,
                        SERV_CITY_AD,
                        STATE_CD,
                        SERV_ZIP_AD,
                        EDW_LAST_UPDT_TS
                ) IDD
                    ON IDD.CUST_NB = BA.CUST_NB
                   AND IDD.BILL_ACCT_NB = BA.BILL_ACCT_NB
                LEFT OUTER JOIN
                (
                    SELECT
                        WEB_FIRST_NM,
                        WEB_LAST_NM,
                        BILL_ACCT_NB AS P_BILL,
                        WEB_EMAIL AS P_EMAIL
                    FROM
                    (
                        SELECT DISTINCT
                            WEB_FIRST_NM,
                            WEB_LAST_NM,
                            BILL_ACCT_NB,
                            WEB_EMAIL,
                            CRTN_TS,
                            RANK() OVER
                            (
                                PARTITION BY BILL_ACCT_NB
                                ORDER BY BILL_ACCT_NB, CRTN_TS DESC, WEB_EMAIL DESC
                            ) AS RNK
                        FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_WEB_USER') }}
                    )
                    WHERE RNK = 1
                ) EM
                    ON EM.P_BILL = BA.BILL_ACCT_NB
            )
        ) STG
        LEFT OUTER JOIN
        (
            SELECT
                PARTY_CONTACT_D_ID,
                PARTY_D_ID,
                BILL_ACCOUNT_NB,
                CUST_NBR,
                ADDR_ID_AD,
                CO_CD_OWNR,
                MD5_CHECKSUM_VAL
            FROM {{ source('UTLDB01_CDWADM','PARTY_CONTACT_D') }}
            WHERE ACTIVE_FLAG = 'Y'
        ) TGT
            ON TGT.PARTY_D_ID = STG.PARTY_D_ID
           AND TGT.BILL_ACCOUNT_NB = STG.BILL_ACCOUNT_NB
           AND TGT.CUST_NBR = STG.CUST_NBR
           AND TGT.ADDR_ID_AD = STG.ADDR_ID_AD
           AND TGT.CO_CD_OWNR = STG.CO_CD_OWNR
    ),
    exp_Audit_Columns AS
    (
        SELECT
            SQ_PARTY_CONTACT_D.TGT_PARTY_CONTACT_D_ID AS TGT_PARTY_CONTACT_D_ID,
            SQ_PARTY_CONTACT_D.PARTY_D_ID AS PARTY_D_ID,
            SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB AS BILL_ACCOUNT_NB,
            SQ_PARTY_CONTACT_D.CUST_NBR AS CUST_NBR,
            SQ_PARTY_CONTACT_D.ADDR_ID_AD AS ADDR_ID_AD,
            SQ_PARTY_CONTACT_D.CO_CD_OWNR AS CO_CD_OWNR,
            SQ_PARTY_CONTACT_D.HOME_PHONE_NB AS HOME_PHONE_NB,
            SQ_PARTY_CONTACT_D.MOBILE_PHONE_NB AS MOBILE_PHONE_NB,
            SQ_PARTY_CONTACT_D.EMAIL AS EMAIL,
            SQ_PARTY_CONTACT_D.WEB_USER_NM AS WEB_USER_NM,
            SQ_PARTY_CONTACT_D.MAILL_1_AD AS MAILL_1_AD,
            SQ_PARTY_CONTACT_D.MAILL_2_AD AS MAILL_2_AD,
            SQ_PARTY_CONTACT_D.MAILING_ADDRESS_CITY_NM AS MAILING_ADDRESS_CITY_NM,
            SQ_PARTY_CONTACT_D.MAILING_ADDRESS_STATE_CD AS MAILING_ADDRESS_STATE_CD,
            SQ_PARTY_CONTACT_D.MAILING_ADDRESS_ZIP AS MAILING_ADDRESS_ZIP,
            SQ_PARTY_CONTACT_D.MD5_CHECKSUM_VAL AS MD5_CHECKSUM_VAL,
            SQ_PARTY_CONTACT_D.TGT_MD5_CHECKSUM_VAL AS TGT_MD5_CHECKSUM_VAL,
            CURRENT_TIMESTAMP() AS o_EDW_CREATE_TS,
            CASE
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0100000000' AND '0299999999' THEN 's_m_PARTY_CONTACT_D_01_02'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0300000000' AND '0499999999' THEN 's_m_PARTY_CONTACT_D_03_04'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0600000000' AND '0699999999' THEN 's_m_PARTY_CONTACT_D_06_069'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0700000000' AND '0799999999' THEN 's_m_PARTY_CONTACT_D_07_079'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '1000000000' AND '1099999999' THEN 's_m_PARTY_CONTACT_D_10_109'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9599999999' THEN 's_m_PARTY_CONTACT_D_94_95'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '9600000000' AND '9799999999' THEN 's_m_PARTY_CONTACT_D_96_97'
            END AS o_EDW_CREATE_NM,
            CURRENT_TIMESTAMP() AS o_EDW_UPDT_TS,
            CASE
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0100000000' AND '0299999999' THEN 's_m_PARTY_CONTACT_D_01_02'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0300000000' AND '0499999999' THEN 's_m_PARTY_CONTACT_D_03_04'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0600000000' AND '0699999999' THEN 's_m_PARTY_CONTACT_D_06_069'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '0700000000' AND '0799999999' THEN 's_m_PARTY_CONTACT_D_07_079'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '1000000000' AND '1099999999' THEN 's_m_PARTY_CONTACT_D_10_109'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '9400000000' AND '9599999999' THEN 's_m_PARTY_CONTACT_D_94_95'
                WHEN SQ_PARTY_CONTACT_D.BILL_ACCOUNT_NB BETWEEN '9600000000' AND '9799999999' THEN 's_m_PARTY_CONTACT_D_96_97'
            END AS o_EDW_UPDT_NM,
            'Y' AS o_ACTIVE_FLAG_Y,
            'N' AS o_ACTIVE_FLAG_N,
            CURRENT_TIMESTAMP() AS o_EFFECTIVE_TS,
            TO_TIMESTAMP_NTZ('9999-12-31 00:00:00') AS o_TERM_TS
        FROM SQ_PARTY_CONTACT_D
    ),
    rtr_Validate_trfm AS
    (
        SELECT
            exp_Audit_Columns.*,
            CASE
                WHEN exp_Audit_Columns.TGT_PARTY_CONTACT_D_ID IS NULL THEN 'INSERT_ONLY'
                WHEN exp_Audit_Columns.TGT_PARTY_CONTACT_D_ID IS NOT NULL
                 AND exp_Audit_Columns.MD5_CHECKSUM_VAL <> exp_Audit_Columns.TGT_MD5_CHECKSUM_VAL THEN 'INSERT_UPDATE'
                ELSE 'DEFAULT1'
            END AS ROUTER_GROUP
        FROM exp_Audit_Columns
    ),
    upd_Updt AS
    (
        SELECT
            rtr_Validate_trfm.TGT_PARTY_CONTACT_D_ID AS PARTY_CONTACT_D_ID,
            CURRENT_TIMESTAMP() AS TERM_TS,
            rtr_Validate_trfm.o_EDW_UPDT_TS AS EDW_LAST_UPDT_TS,
            rtr_Validate_trfm.o_EDW_UPDT_NM AS EDW_LAST_UPDT_NM,
            rtr_Validate_trfm.o_ACTIVE_FLAG_N AS ACTIVE_FLAG
        FROM rtr_Validate_trfm
        WHERE rtr_Validate_trfm.ROUTER_GROUP = 'INSERT_UPDATE'
    ),
    upd_Insert AS
    (
        SELECT
            rtr_Validate_trfm.PARTY_D_ID AS PARTY_D_ID,
            rtr_Validate_trfm.BILL_ACCOUNT_NB AS BILL_ACCOUNT_NB,
            rtr_Validate_trfm.CUST_NBR AS CUST_NBR,
            rtr_Validate_trfm.ADDR_ID_AD AS ADDR_ID_AD,
            rtr_Validate_trfm.CO_CD_OWNR AS CO_CD_OWNR,
            rtr_Validate_trfm.o_EFFECTIVE_TS AS EFFECTIVE_TS,
            rtr_Validate_trfm.o_TERM_TS AS TERM_TS,
            rtr_Validate_trfm.o_EDW_CREATE_TS AS EDW_CRTE_TS,
            rtr_Validate_trfm.o_EDW_CREATE_NM AS EDW_CRTE_NM,
            rtr_Validate_trfm.o_EDW_UPDT_TS AS EDW_LAST_UPDT_TS,
            rtr_Validate_trfm.o_EDW_UPDT_NM AS EDW_LAST_UPDT_NM,
            rtr_Validate_trfm.HOME_PHONE_NB AS HOME_PHONE_NB,
            rtr_Validate_trfm.MOBILE_PHONE_NB AS MOBILE_PHONE_NB,
            rtr_Validate_trfm.EMAIL AS EMAIL,
            rtr_Validate_trfm.WEB_USER_NM AS WEB_USER_NM,
            rtr_Validate_trfm.MAILL_1_AD AS MAILL_1_AD,
            rtr_Validate_trfm.MAILL_2_AD AS MAILL_2_AD,
            rtr_Validate_trfm.MAILING_ADDRESS_CITY_NM AS MAILING_ADDRESS_CITY_NM,
            rtr_Validate_trfm.MAILING_ADDRESS_STATE_CD AS MAILING_ADDRESS_STATE_CD,
            rtr_Validate_trfm.MAILING_ADDRESS_ZIP AS MAILING_ADDRESS_ZIP,
            rtr_Validate_trfm.MD5_CHECKSUM_VAL AS MD5_CHECKSUM_VAL,
            rtr_Validate_trfm.o_ACTIVE_FLAG_Y AS ACTIVE_FLAG
        FROM rtr_Validate_trfm
        WHERE rtr_Validate_trfm.ROUTER_GROUP IN ('INSERT_ONLY', 'INSERT_UPDATE')
    ),
    PARTY_CONTACT_D_KEY AS
    (
        SELECT COALESCE(MAX(PARTY_CONTACT_D_ID), 0) AS MAX_PARTY_CONTACT_D_ID
        FROM {{ source('UTLDB01_CDWADM', 'PARTY_CONTACT_D') }}
    )
    SELECT
        'U' AS TARGET_OPERATION,
        upd_Updt.PARTY_CONTACT_D_ID AS PARTY_CONTACT_D_ID,
        NULL::NUMBER(38,0) AS PARTY_D_ID,
        NULL::VARCHAR AS BILL_ACCOUNT_NB,
        NULL::VARCHAR AS CUST_NBR,
        NULL::VARCHAR AS ADDR_ID_AD,
        NULL::VARCHAR AS CO_CD_OWNR,
        NULL::TIMESTAMP_NTZ AS EFFECTIVE_TS,
        upd_Updt.TERM_TS AS TERM_TS,
        NULL::TIMESTAMP_NTZ AS EDW_CRTE_TS,
        NULL::VARCHAR AS EDW_CRTE_NM,
        upd_Updt.EDW_LAST_UPDT_TS AS EDW_LAST_UPDT_TS,
        upd_Updt.EDW_LAST_UPDT_NM AS EDW_LAST_UPDT_NM,
        NULL::NUMBER AS HOME_PHONE_NB,
        NULL::NUMBER AS MOBILE_PHONE_NB,
        NULL::VARCHAR AS EMAIL,
        NULL::VARCHAR AS WEB_USER_NM,
        NULL::VARCHAR AS MAILL_1_AD,
        NULL::VARCHAR AS MAILL_2_AD,
        NULL::VARCHAR AS MAILING_ADDRESS_CITY_NM,
        NULL::VARCHAR AS MAILING_ADDRESS_STATE_CD,
        NULL::VARCHAR AS MAILING_ADDRESS_ZIP,
        NULL::VARCHAR AS MD5_CHECKSUM_VAL,
        upd_Updt.ACTIVE_FLAG AS ACTIVE_FLAG
    FROM upd_Updt
    /* one row per merge key: the post-hook MERGE matches on
       PARTY_CONTACT_D_ID, and two source rows resolving to the same id
       abort it with 100090. Ties out of the RANK() above carry the same
       natural key, so they land on the same existing id. Every column of
       upd_Updt is identical across such rows (TERM_TS is CURRENT_TIMESTAMP,
       ACTIVE_FLAG is constant), so collapsing them loses nothing.
       The 'I' branch below is unaffected - its ids are MAX + ROW_NUMBER
       and therefore already distinct. */
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY upd_Updt.PARTY_CONTACT_D_ID
        ORDER BY upd_Updt.PARTY_CONTACT_D_ID
    ) = 1
    UNION ALL
    SELECT
        'I' AS TARGET_OPERATION,
        (
            PARTY_CONTACT_D_KEY.MAX_PARTY_CONTACT_D_ID
            + ROW_NUMBER() OVER (ORDER BY upd_Insert.PARTY_D_ID)
        )::NUMBER(15,0) AS PARTY_CONTACT_D_ID,
        upd_Insert.PARTY_D_ID,
        upd_Insert.BILL_ACCOUNT_NB,
        upd_Insert.CUST_NBR,
        upd_Insert.ADDR_ID_AD,
        upd_Insert.CO_CD_OWNR,
        upd_Insert.EFFECTIVE_TS,
        upd_Insert.TERM_TS,
        upd_Insert.EDW_CRTE_TS,
        upd_Insert.EDW_CRTE_NM,
        upd_Insert.EDW_LAST_UPDT_TS,
        upd_Insert.EDW_LAST_UPDT_NM,
        upd_Insert.HOME_PHONE_NB,
        upd_Insert.MOBILE_PHONE_NB,
        upd_Insert.EMAIL,
        upd_Insert.WEB_USER_NM,
        upd_Insert.MAILL_1_AD,
        upd_Insert.MAILL_2_AD,
        upd_Insert.MAILING_ADDRESS_CITY_NM,
        upd_Insert.MAILING_ADDRESS_STATE_CD,
        upd_Insert.MAILING_ADDRESS_ZIP,
        upd_Insert.MD5_CHECKSUM_VAL,
        upd_Insert.ACTIVE_FLAG
    FROM upd_Insert
    CROSS JOIN PARTY_CONTACT_D_KEY