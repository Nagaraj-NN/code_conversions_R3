-- ===========================================================================
-- Model      : ACCOUNT_D_DEL
-- Mapping    : m_ACCOUNT_D_DEL
-- Target     : UTLDB01_DEV_SANDBOX.CDWADM.ACCOUNT_D
-- Load type  : view + UPDATE post-hook
-- ---------------------------------------------------------------------------
-- Logical delete for the account dimension. Active ACCOUNT_D rows are
-- left joined to the current MCS bill account / premise / premise-extension
-- population (primary tariff, active tariff point, metered, residential);
-- accounts that no longer appear there are terminated - TERM_TS is stamped
-- and ACTIVE_FLAG is set to 'N'.
-- ===========================================================================

{{ config(
    materialized='view',
    meta={"mapping_name": "m_ACCOUNT_D_DEL"},
    pre_hook=[
        log_model_start(this, 'DP_CXN1003C_ACCOUNT_D_DEL')
    ],
    post_hook=[
        "UPDATE {{ source('UTLDB01_CDWADM','ACCOUNT_D') }} TGT
     SET
       TERM_TS = CURRENT_TIMESTAMP(6),
       EDW_LAST_UPDT_TS = CURRENT_TIMESTAMP(),
       EDW_LAST_UPDT_NM = 's_m_ACCOUNT_D_DEL',
       ACTIVE_FLAG = 'N'
     FROM {{ this }} SRC
     WHERE TGT.ACCOUNT_D_ID = SRC.OUT_ACCOUNT_D_ID",
        log_model_end(this, 'DP_CXN1003C_ACCOUNT_D_DEL')
    ]
) }}

SELECT DISTINCT
        T_ACCOUNT.BILL_ACCOUNT_NB AS BILL_ACCT_NB,
        S_ACCOUNT.ACCT_STAT_CD,
        S_ACCOUNT.REVN_CLAS_CD,
        S_ACCOUNT.TURN_OFF_DT,
        S_ACCOUNT.TURN_ON_DT,
        S_ACCOUNT.PREM_NB,
        S_ACCOUNT.CO_CD_OWNR,
        S_ACCOUNT.SER_HALF_IND_AD,
        S_ACCOUNT.SERV_CITY_AD,
        S_ACCOUNT.SERV_HOUS_NBR_AD,
        S_ACCOUNT.SERV_PTDR_AD,
        S_ACCOUNT.SERV_PRDR_AD,
        S_ACCOUNT.SERV_ST_NAME_AD,
        S_ACCOUNT.SERV_ST_DSGT_AD,
        S_ACCOUNT.SERV_UNIT_DSGT_AD,
        S_ACCOUNT.SERV_UNIT_NBR_AD,
        S_ACCOUNT.SERV_ZIP_AD,
        S_ACCOUNT.STATE_CD,
        S_ACCOUNT.SRVC_ADDR_1_NM,
        S_ACCOUNT.SRVC_ADDR_2_NM,
        S_ACCOUNT.SRVC_ADDR_3_NM,
        S_ACCOUNT.SRVC_ADDR_4_NM,
        S_ACCOUNT.SRVC_ADDR_5_NM,
        S_ACCOUNT.CURR_ACCT_CLS_CD,
        T_ACCOUNT.ACCOUNT_D_ID AS OUT_ACCOUNT_D_ID,
        T_ACCOUNT.MD5_CHECKSUM_VAL AS OUT_MD5_CHECKSUM_VAL
    FROM
    (
        SELECT
            BILL_ACCOUNT_NB,
            ACCOUNT_D_ID,
            MD5_CHECKSUM_VAL
        FROM {{ source('UTLDB01_CDWADM','ACCOUNT_D') }}
        WHERE ACTIVE_FLAG = 'Y'
    ) AS T_ACCOUNT
    LEFT JOIN
    (
        SELECT
            BA.BILL_ACCT_NB,
            BA.ACCT_STAT_CD,
            BA.REVN_CLAS_CD,
            BA.TURN_OFF_DT,
            BA.TURN_ON_DT,
            BA.PREM_NB,
            PMS.CO_CD_OWNR,
            PMS.SER_HALF_IND_AD,
            PMS.SERV_CITY_AD,
            PMS.SERV_HOUS_NBR_AD,
            PMS.SERV_PTDR_AD,
            PMS.SERV_PRDR_AD,
            PMS.SERV_ST_NAME_AD,
            PMS.SERV_ST_DSGT_AD,
            PMS.SERV_UNIT_DSGT_AD,
            PMS.SERV_UNIT_NBR_AD,
            PMS.SERV_ZIP_AD,
            PMS.STATE_CD,
            PME.SRVC_ADDR_1_NM,
            PME.SRVC_ADDR_2_NM,
            PME.SRVC_ADDR_3_NM,
            PME.SRVC_ADDR_4_NM,
            PME.SRVC_ADDR_5_NM,
            PME.CURR_ACCT_CLS_CD
        FROM {{ source('UTLDB01_UTLUSER','ODS_MCS_BILL_ACCOUNT') }} AS BA
        LEFT JOIN {{ source('UTLDB01_UTLUSER','ODS_MCS_PREMISE') }} AS PMS
            ON BA.PREM_NB = PMS.PREM_NB
        LEFT JOIN {{ source('UTLDB01_UTLUSER','ODS_MCS_PREMISE_EXT') }} AS PME
            ON BA.PREM_NB = PME.PREM_NB
        WHERE PME.PRMR_TARF_FL = 'Y'
          AND PME.TARF_PT_STAT_CD = 'A'
          AND PME.TYPE_OF_SRVC_CD = 'M'
          AND PME.CURR_ACCT_CLS_CD = 'R'
    ) AS S_ACCOUNT
        ON T_ACCOUNT.BILL_ACCOUNT_NB = S_ACCOUNT.BILL_ACCT_NB
    WHERE S_ACCOUNT.BILL_ACCT_NB IS NULL
