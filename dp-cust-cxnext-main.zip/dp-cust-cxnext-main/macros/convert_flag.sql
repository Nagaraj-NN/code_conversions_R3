{% macro convert_int_flag_to_char(flag_value) %}
    case 
        when {{ flag_value }} = 1 then 'Y'
        when {{ flag_value }} = 0 then 'N'
        else null
    end
{% endmacro %}