{% macro job_control_update_STG(model_name, autosys_job_name, bronze_table) %}

    {% set app_name = var('app_name_by_schema').get(model.config.schema | upper) %}

    {% if app_name is none %}
        {{ exceptions.raise_compiler_error(
            "Missing required app_name for this model"
        ) }}
    {% endif %}

    {% set exec_table = model.database ~ '.METADATA.' ~ app_name ~ '_JOB_CONTROL' %}

    {%- if target.name == 'ci' -%}
    SELECT 1
    {%- else -%}
    UPDATE {{ exec_table }}
        SET PREV_START_DATE      = NVL(START_DATE, CURRENT_TIMESTAMP()),
            PREV_END_DATE        = END_DATE,
            START_DATE           = NVL(
                                       (SELECT MAX(aws_extract_dttm)
                                        FROM {{ source('BRONZE_CALL_CENTER', bronze_table) }}),
                                       CURRENT_TIMESTAMP()
                                   ),
            END_DATE             = CURRENT_TIMESTAMP(),
            ROW_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP()
        WHERE JOB_NAME = '{{ model_name.name }}'
        AND AUTOSYS_JOB_NAME = '{{ autosys_job_name }}';
    {%- endif -%}

{% endmacro %}