{% macro udf_convert_int_flag_to_char(input_val) %}
    CASE
        WHEN {{ input_val }} = 1  THEN 'Y'
        WHEN {{ input_val }} = 0  THEN 'N'
        ELSE NULL::TEXT
    END
{% endmacro %}