{% macro update_control_table(model_name, autosys_job_name) %}
    {% set app_name= var('app_name_by_schema').get(model.config.schema | upper) %}

    {% set exec_table = model.database ~ '.METADATA.' ~ app_name ~ '_JOB_CONTROL'%}

    {%- if target.name == 'ci' -%}
    SELECT 1
    {%- else -%}
    UPDATE {{exec_table}}
        SET PREV_START_DATE      = START_DATE,
            PREV_END_DATE        = END_DATE,
            START_DATE           = END_DATE,
            ROW_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP()
        WHERE JOB_NAME = '{{model_name.name}}'
        AND AUTOSYS_JOB_NAME = '{{autosys_job_name}}';
    {%- endif -%}

{% endmacro %}