{% macro open_control_window(model_name, autosys_job_name) %}
    {% set app_name= var('app_name_by_schema').get(model.config.schema | upper) %}

    {% set exec_table = model.database ~ '.METADATA.' ~ app_name ~ '_JOB_CONTROL'%}

    {%- if target.name == 'ci' -%}
    SELECT 1
    {%- else -%}
    UPDATE {{exec_table}}
        SET END_DATE             = CURRENT_TIMESTAMP(),
            ROW_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP()
        WHERE JOB_NAME = '{{model_name.name}}'
        AND AUTOSYS_JOB_NAME = '{{autosys_job_name}}';
    {%- endif -%}

{% endmacro %}