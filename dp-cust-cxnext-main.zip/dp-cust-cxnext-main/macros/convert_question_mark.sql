{% macro convert_question_mark(column) %}
    case
        when trim(replace({{ column }}, '?', '')) is null
          or trim(replace({{ column }}, '?', '')) = ''
        then '-'
        else trim({{ column }})
    end
{% endmacro %}