{% macro truncate_model(rel) %}
  {% if execute %}
    {% set relation = adapter.get_relation(
        database=rel.database,
        schema=rel.schema,
        identifier=rel.identifier
    ) %}
    {% if relation %}
      {% call statement('truncate_' ~ rel.identifier, fetch_result=False) %}
        TRUNCATE TABLE {{ rel }}
      {% endcall %}
    {% endif %}
  {% endif %}
{% endmacro %}
