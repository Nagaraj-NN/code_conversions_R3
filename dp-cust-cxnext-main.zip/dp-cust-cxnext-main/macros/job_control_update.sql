{% macro job_control_update_clause() %}

{% set app_name = var('app_name_by_schema').get(model.config.schema | upper) %}
    {% set exec_table = model.database ~ '.METADATA.' ~ app_name ~ '_JOB_CONTROL' %}

     {{ exec_table }}
SET
    START_DATE = END_DATE,
    END_DATE   = CURRENT_TIMESTAMP()
WHERE JOB_NAME = '{{ this.identifier }}' 

{% endmacro %}