{% macro udf_convert_question_mark (input_val) %}

    CASE WHEN TRIM(REPLACE({{ input_val }},''?'', '''')) IS NULL OR TRIM(REPLACE({{ input_val }},''?'', '''')) = ''''  THEN ''-''
         ELSE TRIM({{ input_val }})
    END 
{% endmacro %}