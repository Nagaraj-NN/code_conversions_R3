{% macro outbound_files_to_s3_internal(file_name, source_table) %}

COPY INTO @EXTRACTS.CORP.internal_landing_stage/shems/icoe/{{ file_name }}
FROM {{ source_table }}
FILE_FORMAT = (
  TYPE = 'CSV',
  FIELD_DELIMITER = ',',
  NULL_IF = ('NULL', 'null'),
  EMPTY_FIELD_AS_NULL = TRUE,
  COMPRESSION = NONE,
  FIELD_OPTIONALLY_ENCLOSED_BY = '"'
)
HEADER = TRUE
SINGLE = TRUE
OVERWRITE = TRUE;

{% endmacro %}