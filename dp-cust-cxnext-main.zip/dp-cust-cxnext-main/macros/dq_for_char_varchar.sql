{% macro dq_for_char_varchar(input_val) %}
    CASE
        WHEN {{ input_val }} IS NULL THEN NULL
        WHEN LENGTH(TRIM({{ input_val }})) = 0 THEN ''
        ELSE RTRIM({{ input_val }})
    END
{% endmacro %}